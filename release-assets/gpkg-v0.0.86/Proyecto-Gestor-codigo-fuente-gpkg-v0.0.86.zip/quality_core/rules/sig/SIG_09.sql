-- name: SIG_09
with b as(
select lgp.*, lrc.identificador from actualizacion.lc_gen_predio lgp join actualizacion.lc_reco_caracteristicasunidadconstruccion lrc on lgp.pk_id = lrc.fk_id 
where lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false
), b2 as(select l.pk_id, l.codigo, l.planta, l.tipo_construccion, l.etiqueta, l.identificador, 'LC_Gen_UnidadConstruccion' tabla 
from actualizacion.lc_gen_unidadconstruccion l where substring(l.codigo,22,1) <> '9' union 
select l.pk_id, l.codigo, l.planta, l.tipo_construccion, l.etiqueta, l.identificador, 'LC_Gen_UnidadConstruccion_Informal' tabla 
from actualizacion.lc_gen_unidadconstruccion_informal l where substring(l.codigo,22,1) <> '9'
), b3 as(select b2.* from b2 left join b on b2.codigo = b.numero_predial_nacional and b2.identificador = b.identificador where b.fid is null
), b4 as(select distinct on (b.pk_id) b.* from b where b.predio_tiene_cambio_fisico = true
), b5 as(select b3.* from b3 left join b4 on b3.codigo = b4.numero_predial_nacional where b4.fid is null)
select 'SIG_09' id_regla, 'Unidad de Construccion en comision sin cambio fisico' descripcion_regla, tabla tabla_error, b5.pk_id pk_tabla_error, b5.codigo, 
b5.identificador identificador_unidad_construccion, b5.planta planta_unidad_construccion, null tiene_excepcion
from b5 order by 5,6;
