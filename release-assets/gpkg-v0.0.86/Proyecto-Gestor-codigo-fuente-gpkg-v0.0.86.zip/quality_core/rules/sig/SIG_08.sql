-- name: SIG_08
with b as(
select lpp.* from actualizacion.lc_ph_predio lpp join actualizacion.lc_ph_novedadnumeropredial lpn on lpp.pk_id = lpn.fk_id 
where lpn.tipo_novedad in (5,6,7,8)
), b2 as(select lpp.* from actualizacion.lc_ph_predio lpp left join b on lpp.pk_id = b.pk_id where b.pk_id is null
), b3 as(select b2.*, lgp.nombre_proyecto from b2 join actualizacion.lc_gen_predio lgp on b2.fk_id = lgp.pk_id 
where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) and lgp.predio_tiene_cambio_fisico = true
), b4 as(
select l.pk_id, l.codigo, l.planta, l.tipo_construccion, l.etiqueta, l.identificador, 'LC_Gen_UnidadConstruccion' tabla 
from actualizacion.lc_gen_unidadconstruccion l WHERE substring(l.codigo,22,1) = '9' AND substring(l.codigo,27,4) <> '0000'
union 
select l.pk_id, l.codigo, l.planta, l.tipo_construccion, l.etiqueta, l.identificador, 'LC_Gen_UnidadConstruccion_Informal' tabla 
from actualizacion.lc_gen_unidadconstruccion_informal l WHERE pk_id NOT IN (SELECT pk_id from actualizacion.lc_gen_unidadconstruccion_informal l 
WHERE substring(l.codigo,22,1) = '9' AND substring(l.codigo,27,4) <> '0000') 
), b5 as(select b4.*, b3.pk_id pk_id_predio, b3.nombre_proyecto, b3.matricula_inmobiliaria, b3.destinacion_economica, b3.area_catastral_terreno from b4 
join b3 on b4.codigo = b3.numero_predial_nacional
)
select 'SIG_08' id_regla, 'Digitalizacion' componente, 'Unidad de Construccion PH en comision con cambio fisico' descripcion_regla, 
b5.nombre_proyecto proyecto, b5.pk_id_predio pk_id_predio, tabla tabla_error_1, b5.pk_id pk_tabla_error_1, 'LC_PH_Predio' tabla_error_2, 
b5.pk_id_predio pk_tabla_error_2, b5.codigo numero_predial_nacional, b5.matricula_inmobiliaria, lgdt.ilicode destino_economico, b5.area_catastral_terreno, 
b5.identificador identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, null uso_construccion, 
null area_construida, null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from b5 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on b5.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_ph_caracteristicasunidadconstruccion lrc on b5.pk_id_predio = lrc.fk_id and b5.identificador = lrc.identificador 
left join actualizacion.lc_gen_excepciones lge on b5.pk_id_predio = lge.fk_id and 'SIG_08' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on b5.pk_id_predio = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on b5.pk_id_predio = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where lrc.pk_id is null order by 10,4,14;
