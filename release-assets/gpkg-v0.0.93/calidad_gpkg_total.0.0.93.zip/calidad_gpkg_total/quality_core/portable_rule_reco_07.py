"""Independent portable implementation of canonical Reco_07."""
from .portable_construction_dominant import execute_construction_dominant
from .portable_construction_scalar import ConstructionScalarRule, _join_token

_RULE = ConstructionScalarRule(
    "Reco_07", "Calificacion",
    "Predios con destino economico Comercial con la Caracteristica Unidad de Construccion de mayor area diferente a un uso de construccion de tipo comercial",
    f"p.destinacion_economica = 6 AND c.type_key <> {_join_token(1)!r}", False,
    table_error_1="LC_Gen_Predio", table_error_1_source="predio",
    table_error_2="LC_Reco_Caracteristicasunidadconstruccion",
)

def execute_reco_07(data_source, layer_mapping, cancel_check=None):
    return execute_construction_dominant(_RULE, data_source, layer_mapping, cancel_check)
