"""Dominant-construction aggregation used by canonical Reco_06 through 08."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Iterator

from .portable_construction_scalar import (
    ConstructionScalarRule,
    _create_stage,
    _ingest_constructions,
    _ingest_enrichment,
    _ingest_predios,
    _join_token,
    _prepare_indexes,
    _result_row,
)
from .portable_primitives import raise_if_cancelled, sqlite_staging


def _prepare_dominant_selected(definition, db) -> None:
    db.execute("CREATE INDEX idx_predio_pk ON predio(pk_key)")
    db.execute("CREATE INDEX idx_construction_predio ON construction(predio_key)")
    db.execute("CREATE INDEX idx_construction_type ON construction(type_key)")
    db.execute(
        """
        WITH eligible AS (
            SELECT *
            FROM construction
            WHERE type_key IS NOT NULL AND type_key <> ?
        ), grouped AS (
            SELECT predio_key,type_key,SUM(area_construida) AS sum_area
            FROM eligible
            GROUP BY predio_key,type_key
        ), maxima AS (
            SELECT predio_key,MAX(sum_area) AS max_area
            FROM grouped
            GROUP BY predio_key
        ), dominant AS (
            SELECT e.*
            FROM eligible e
            JOIN maxima m
              ON e.predio_key = m.predio_key
             AND e.area_construida = m.max_area
        )
        INSERT INTO selected(
            predio_row_token,construction_row_token,pk_id,pk_key,
            numero_predial_nacional,proyecto,matricula_inmobiliaria,
            destinacion_economica,destination_key,area_catastral_terreno,
            juridico_assignment_key,juridico_control_key,
            reconocimiento_assignment_key,reconocimiento_control_key,
            informal_assignment_key,informal_control_key,
            geografico_assignment_key,geografico_control_key,
            pk_carac,identificador,total_plantas,type_key,use_key,
            uso_construccion,area_construida,puntaje)
        SELECT
            p.row_token,c.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,
            p.proyecto,p.matricula_inmobiliaria,p.destinacion_economica,
            p.destination_key,p.area_catastral_terreno,
            p.juridico_assignment_key,p.juridico_control_key,
            p.reconocimiento_assignment_key,p.reconocimiento_control_key,
            p.informal_assignment_key,p.informal_control_key,
            p.geografico_assignment_key,p.geografico_control_key,
            c.pk_carac,c.identificador,c.total_plantas,c.type_key,c.use_key,
            c.uso_construccion,c.area_construida,c.puntaje
        FROM predio p
        JOIN dominant c ON c.predio_key = p.pk_key
        WHERE {predicate}
        """.format(predicate=definition.predicate_sql),
        (_join_token(4),),
    )


def _result_sql() -> str:
    # The canonical query joins the same unit-type catalogue twice: once as an
    # unused INNER JOIN and once as the projected LEFT JOIN.  Both multiplicities
    # are therefore intentional and must survive the portable implementation.
    return """
        SELECT
            s.pk_id,s.numero_predial_nacional,s.proyecto,s.matricula_inmobiliaria,
            destination.ilicode,s.area_catastral_terreno,s.pk_carac,s.identificador,
            s.total_plantas,unit_type.ilicode,use_lu.ilicode,s.area_construida,
            s.puntaje,exception.fid,exception.descripcion_excepcion,
            jur_asig.ilicode,jur_ctrl.ilicode,reco_asig.ilicode,reco_ctrl.ilicode,
            info_asig.ilicode,info_ctrl.ilicode,geo_asig.ilicode,geo_ctrl.ilicode,
            user_assignment.pk_id
        FROM selected s
        JOIN unit_type_lookup required_unit ON required_unit.key_token = s.type_key
        LEFT JOIN destination_lookup destination
            ON destination.key_token = s.destination_key
        LEFT JOIN unit_type_lookup unit_type ON unit_type.key_token = s.type_key
        LEFT JOIN use_lookup use_lu ON use_lu.key_token = s.use_key
        LEFT JOIN exception_lookup exception ON exception.fk_token = s.pk_key
        LEFT JOIN user_assignment ON user_assignment.fk_token = s.pk_key
        LEFT JOIN assignment_lookup jur_asig
            ON jur_asig.key_token = s.juridico_assignment_key
        LEFT JOIN control_lookup jur_ctrl
            ON jur_ctrl.key_token = s.juridico_control_key
        LEFT JOIN assignment_lookup reco_asig
            ON reco_asig.key_token = s.reconocimiento_assignment_key
        LEFT JOIN control_lookup reco_ctrl
            ON reco_ctrl.key_token = s.reconocimiento_control_key
        LEFT JOIN assignment_lookup info_asig
            ON info_asig.key_token = s.informal_assignment_key
        LEFT JOIN control_lookup info_ctrl
            ON info_ctrl.key_token = s.informal_control_key
        LEFT JOIN assignment_lookup geo_asig
            ON geo_asig.key_token = s.geografico_assignment_key
        LEFT JOIN control_lookup geo_ctrl
            ON geo_ctrl.key_token = s.geografico_control_key
        ORDER BY
            s.numero_predial_nacional IS NULL,s.numero_predial_nacional,
            s.proyecto IS NULL,s.proyecto,s.identificador IS NULL,s.identificador,
            s.predio_row_token,s.construction_row_token,required_unit.row_token,
            destination.row_token,unit_type.row_token,use_lu.row_token,
            exception.row_token,user_assignment.row_token,jur_asig.row_token,
            jur_ctrl.row_token,reco_asig.row_token,reco_ctrl.row_token,
            info_asig.row_token,info_ctrl.row_token,geo_asig.row_token,
            geo_ctrl.row_token
    """


def execute_construction_dominant(
    definition: ConstructionScalarRule,
    data_source,
    layer_mapping,
    cancel_check=None,
) -> Iterator[dict[str, Any]]:
    execution_timestamp = datetime.now()
    prefix = "mapingtool-calidad-gpkg-{0}-".format(definition.canonical_id.lower())
    with sqlite_staging(cancel_check, prefix=prefix) as db:
        _create_stage(db)
        _ingest_predios(definition, data_source, layer_mapping, db, cancel_check)
        _ingest_constructions(definition, data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(definition, data_source, layer_mapping, db, cancel_check)
        _prepare_dominant_selected(definition, db)
        _prepare_indexes(db)
        db.commit()
        raise_if_cancelled(cancel_check)
        cursor = db.execute(_result_sql())
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                yield _result_row(definition, execution_timestamp, values)
        finally:
            cursor.close()
