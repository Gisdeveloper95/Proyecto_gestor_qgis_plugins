"""Small, reusable primitives for future portable rule implementations."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from contextlib import contextmanager
import base64
import json
import math
from pathlib import Path
import sqlite3
import tempfile
from typing import Any, Iterator


PORTABLE_INGEST_BATCH_SIZE = 256
PORTABLE_SQLITE_CACHE_KIB = 4 * 1024
_CANCELLED_MESSAGE = "Ejecucion portable cancelada por el usuario."


def raise_if_cancelled(cancel_check: Callable[[], bool] | None) -> None:
    if cancel_check is not None and cancel_check():
        raise InterruptedError(_CANCELLED_MESSAGE)


@contextmanager
def sqlite_staging(
    cancel_check: Callable[[], bool] | None = None,
    prefix: str = "mapingtool-calidad-gpkg-",
) -> Iterator[sqlite3.Connection]:
    """Yield a bounded, disk-backed SQLite stage with cooperative cancellation."""

    raise_if_cancelled(cancel_check)
    with tempfile.TemporaryDirectory(prefix=prefix) as temp_dir:
        stage_path = Path(temp_dir) / "stage.sqlite"
        db = sqlite3.connect(str(stage_path))
        try:
            db.execute("PRAGMA journal_mode=OFF")
            db.execute("PRAGMA synchronous=OFF")
            db.execute("PRAGMA temp_store=FILE")
            db.execute("PRAGMA cache_size=-{0}".format(PORTABLE_SQLITE_CACHE_KIB))
            if cancel_check is not None:
                db.set_progress_handler(lambda: 1 if cancel_check() else 0, 1000)
            yield db
            raise_if_cancelled(cancel_check)
        except sqlite3.OperationalError as exc:
            if cancel_check is not None and cancel_check():
                raise InterruptedError(_CANCELLED_MESSAGE) from exc
            raise
        finally:
            db.set_progress_handler(None, 0)
            db.close()


class BatchInserter:
    """Buffer at most 256 rows by default before ``executemany``."""

    def __init__(
        self,
        db: sqlite3.Connection,
        sql: str,
        batch_size: int = PORTABLE_INGEST_BATCH_SIZE,
        cancel_check: Callable[[], bool] | None = None,
    ):
        if (
            isinstance(batch_size, bool)
            or not isinstance(batch_size, int)
            or batch_size < 1
        ):
            raise ValueError("batch_size debe ser un entero positivo.")
        self.db = db
        self.sql = str(sql)
        self.batch_size = batch_size
        self.cancel_check = cancel_check
        self._rows: list[tuple[Any, ...]] = []

    @property
    def pending_count(self) -> int:
        return len(self._rows)

    def add(self, row: Sequence[Any]) -> None:
        raise_if_cancelled(self.cancel_check)
        self._rows.append(tuple(row))
        if len(self._rows) >= self.batch_size:
            self.flush()

    def flush(self) -> None:
        if not self._rows:
            return
        raise_if_cancelled(self.cancel_check)
        try:
            self.db.executemany(self.sql, self._rows)
        except sqlite3.OperationalError as exc:
            if self.cancel_check is not None and self.cancel_check():
                raise InterruptedError(_CANCELLED_MESSAGE) from exc
            raise
        self._rows.clear()
        raise_if_cancelled(self.cancel_check)

    def __enter__(self) -> "BatchInserter":
        return self

    def __exit__(self, exc_type, _exc, _traceback) -> bool:
        if exc_type is None:
            self.flush()
        else:
            self._rows.clear()
        return False


_POSTGRES_TRUE_TEXT = frozenset(("1", "t", "true", "y", "yes", "on"))
_POSTGRES_FALSE_TEXT = frozenset(("0", "f", "false", "n", "no", "off"))


def postgres_boolean(value: Any) -> bool | None:
    """Decode explicit PostgreSQL boolean spellings or fail closed."""

    if value is None:
        return None
    if type(value) is bool:
        return value
    if type(value) is int and value in (0, 1):
        return bool(value)
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in _POSTGRES_TRUE_TEXT:
            return True
        if normalized in _POSTGRES_FALSE_TEXT:
            return False
    raise ValueError("Valor booleano portable no reconocido: {0!r}.".format(value))


def postgres_boolean_is_true(value: Any) -> bool:
    """Match PostgreSQL ``value IS TRUE``."""

    return postgres_boolean(value) is True


def postgres_boolean_is_false_or_null(value: Any) -> bool:
    """Match PostgreSQL ``value IS NULL OR value = false``."""

    return postgres_boolean(value) is not True


def postgres_substring(value: Any, start: int, length: int | None = None) -> str | None:
    """Return PostgreSQL-style substring positions using a 1-based start."""

    if isinstance(start, bool) or not isinstance(start, int) or start < 1:
        raise ValueError("start debe ser un entero 1-based positivo.")
    if length is not None and (
        isinstance(length, bool) or not isinstance(length, int) or length < 0
    ):
        raise ValueError("length debe ser un entero no negativo.")
    if value is None:
        return None
    text = str(value)
    offset = start - 1
    if length is None:
        return text[offset:]
    return text[offset : offset + length]


def _typed_scalar(value: Any) -> list[Any]:
    if value is None:
        return ["null", None]
    if type(value) is bool:
        return ["boolean", value]
    if type(value) is int:
        return ["integer", str(value)]
    if type(value) is float:
        if math.isnan(value):
            encoded = "nan"
        elif math.isinf(value):
            encoded = "+inf" if value > 0 else "-inf"
        elif value == 0.0:
            encoded = float(0.0).hex()
        else:
            encoded = value.hex()
        return ["real", encoded]
    if isinstance(value, str):
        return ["text", value]
    if isinstance(value, (bytes, bytearray, memoryview)):
        encoded = base64.b64encode(bytes(value)).decode("ascii")
        return ["blob", encoded]
    raise TypeError(
        "Tipo no soportado para token UNION portable: {0}.".format(
            type(value).__name__
        )
    )


def typed_union_token(values: Iterable[Any]) -> str:
    """Create a deterministic, type-preserving token for UNION DISTINCT rows."""

    payload = {
        "format": "mapingtool-portable-union-token-v1",
        "values": [_typed_scalar(value) for value in values],
    }
    return json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    )
