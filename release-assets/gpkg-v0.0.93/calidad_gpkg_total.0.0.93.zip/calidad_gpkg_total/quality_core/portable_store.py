"""Bounded local SQLite storage for findings from portable rule backends."""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from contextlib import suppress
import json
from pathlib import Path
import sqlite3
import tempfile
from typing import Any, Callable


PORTABLE_EXPORT_COLUMNS = (
    "id_regla",
    "descripcion_regla",
    "componente",
    "proyecto",
    "pk_id_predio",
    "numero_predial_nacional",
    "matricula_inmobiliaria",
    "tabla_error_1",
    "pk_tabla_error_1",
    "tabla_error_2",
    "pk_tabla_error_2",
    "tiene_excepcion",
    "descripcion_excepcion",
    "identificador_caracteristica_unidad_construccion",
    "planta_unidad_construccion",
    "total_plantas",
    "tipo_unidad_construccion",
    "uso_construccion",
    "area_construida",
    "puntaje_calificacion",
    "custom_1",
    "custom_2",
    "custom_3",
    "custom_4",
    "custom_5",
    "custom_6",
    "custom_7",
    "custom_8",
    "custom_9",
    "custom_10",
    "custom_11",
    "custom_12",
)
DEFAULT_PAGE_SIZE = 250
MAX_PAGE_SIZE = 2000
PORTABLE_SEARCH_COLUMNS = (
    "numero_predial_nacional",
    "pk_id_predio",
    "pk_tabla_error_1",
    "pk_tabla_error_2",
    "proyecto",
)


def is_truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().casefold() in {
        "1",
        "t",
        "true",
        "y",
        "yes",
        "si",
        "sí",
        "verdadero",
    }


def portable_predio_scope_id(row: Mapping[str, Any]) -> str | None:
    """Resolve the general-property key used by operational filters.

    Most rules expose ``pk_id_predio`` directly.  A few canonical SQL rules
    (notably ``Jur_21``) intentionally return that column as NULL while
    keeping the actual ``LC_Gen_Predio`` key in the error-table columns.  The
    old portable store treated every NULL key as an unfilterable orphan and
    let it pass, which leaked out-of-scope properties into filtered runs.

    Only a key explicitly identified as belonging to ``LC_Gen_Predio`` is a
    safe fallback.  A genuinely orphan geographic finding remains visible
    because it does not represent a property to which the scope can apply.
    """

    direct = row.get("pk_id_predio")
    if direct not in (None, ""):
        value = str(direct).strip()
        return value or None

    for table_column, key_column in (
        ("tabla_error_1", "pk_tabla_error_1"),
        ("tabla_error_2", "pk_tabla_error_2"),
        ("tabla_error", "pk_tabla_error"),
    ):
        table_name = str(row.get(table_column) or "").strip()
        normalized_table = (
            table_name.rsplit(".", 1)[-1]
            .strip('"`[] ')
            .casefold()
        )
        if normalized_table != "lc_gen_predio":
            continue
        candidate = row.get(key_column)
        if candidate not in (None, ""):
            value = str(candidate).strip()
            if value:
                return value
    return None


def display_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "VERDADERO" if value else "FALSO"
    return str(value)


def csv_safe_value(value: Any, *, force_text: bool = False) -> str:
    text = display_value(value)
    if not text:
        return text
    meaningful = text.lstrip(" \t\r\n")
    if force_text or meaningful.startswith(("=", "+", "-", "@")):
        return "'" + text
    return text


def presentation_columns(manifest: Mapping[str, Any]) -> tuple[str, ...]:
    """Return the stable legacy projection plus every declared rule output.

    This keeps older CSV consumers compatible while preventing newly ported
    rules from silently hiding canonical fields in the table or CSV export.
    """

    rules = manifest.get("rules")
    if not isinstance(rules, dict):
        raise ValueError("El manifiesto portable no contiene reglas validas.")
    columns = list(PORTABLE_EXPORT_COLUMNS)
    seen = set(columns)
    for rule_id in sorted(rules):
        declaration = rules[rule_id]
        declared = (
            declaration.get("output_columns")
            if isinstance(declaration, dict)
            else None
        )
        if (
            not isinstance(declared, list)
            or not declared
            or any(not isinstance(column, str) or not column for column in declared)
            or len(set(declared)) != len(declared)
        ):
            raise ValueError(
                "output_columns invalido para {0}.".format(rule_id)
            )
        for column in declared:
            if column not in seen:
                seen.add(column)
                columns.append(column)
    return tuple(columns)


ALIASES = {
    "tabla_error": "tabla_error_1",
    "pk_tabla_error": "pk_tabla_error_1",
    "codigo": "numero_predial_nacional",
    "descripcion": "descripcion_regla",
    "identificador_unidad_construccion": "identificador_caracteristica_unidad_construccion",
}

RECO_SCOPE_READY_KEY = "reco_scope_ready"
PROCESSING_SCOPE_READY_PREFIX = "processing_scope_ready:"


def normalize_portable_row(row: dict[str, Any], fallback_rule_id: str) -> dict[str, Any]:
    normalized = {str(key).strip().lower(): value for key, value in row.items()}
    for source, target in ALIASES.items():
        if target not in normalized and source in normalized:
            normalized[target] = normalized[source]
    normalized["id_regla"] = normalized.get("id_regla") or fallback_rule_id
    value = normalized.get("tiene_excepcion")
    normalized["tiene_excepcion"] = value is True or str(value).strip().lower() in {
        "1",
        "true",
        "t",
        "yes",
        "si",
    }
    for column in PORTABLE_EXPORT_COLUMNS:
        normalized.setdefault(column, None)
    return normalized


def portable_search_text(payload: Mapping[str, Any]) -> str:
    """Build the bounded text projection used by the interactive detail search."""

    return " ".join(
        str(payload.get(column) or "").casefold()
        for column in PORTABLE_SEARCH_COLUMNS
    )


class PortableStoreCancelled(RuntimeError):
    pass


class PortableResultStore:
    """One writer/reader store with atomic replacement per portable rule."""

    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        self.db = sqlite3.connect(str(self.path))
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA busy_timeout=5000")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS findings ("
            "sequence INTEGER PRIMARY KEY AUTOINCREMENT, "
            "rule_id TEXT NOT NULL, "
            "has_exception INTEGER NOT NULL DEFAULT 0, "
            "search_text TEXT NOT NULL DEFAULT '', "
            "payload TEXT NOT NULL)"
        )
        existing_columns = {
            str(row[1]) for row in self.db.execute("PRAGMA table_info(findings)")
        }
        if "has_exception" not in existing_columns:
            self.db.execute(
                "ALTER TABLE findings "
                "ADD COLUMN has_exception INTEGER NOT NULL DEFAULT 0"
            )
        if "search_text" not in existing_columns:
            self.db.execute(
                "ALTER TABLE findings "
                "ADD COLUMN search_text TEXT NOT NULL DEFAULT ''"
            )
        self.db.execute(
            "CREATE INDEX IF NOT EXISTS idx_findings_rule ON findings(rule_id, sequence)"
        )
        self.db.execute(
            "CREATE INDEX IF NOT EXISTS idx_findings_exception "
            "ON findings(has_exception, sequence)"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS reco_allowed_predio ("
            "pk_id_predio TEXT PRIMARY KEY)"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS processing_allowed_predio ("
            "profile_id TEXT NOT NULL, "
            "pk_id_predio TEXT NOT NULL, "
            "PRIMARY KEY(profile_id, pk_id_predio))"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS project_allowed_predio ("
            "pk_id_predio TEXT PRIMARY KEY)"
        )
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS portable_store_state ("
            "key TEXT PRIMARY KEY, value TEXT NOT NULL)"
        )
        self.db.commit()

    @classmethod
    def create(cls) -> "PortableResultStore":
        descriptor, path = tempfile.mkstemp(
            prefix="mapingtool-calidad-gpkg-results-", suffix=".sqlite"
        )
        try:
            import os

            os.close(descriptor)
        except OSError:
            pass
        Path(path).unlink(missing_ok=True)
        return cls(path)

    @classmethod
    def open(cls, path: str | Path) -> "PortableResultStore":
        return cls(path)

    def replace_rule(
        self,
        rule_id: str,
        rows: Iterable[dict[str, Any]],
        cancel_check: Callable[[], bool] | None = None,
        *,
        apply_reco_filter: bool = False,
        filter_profile: str | None = None,
        project_name: str | None = None,
    ) -> int:
        count = 0
        iterator = iter(rows)
        iterator_closed = False
        try:
            self.db.execute("BEGIN IMMEDIATE")
            if apply_reco_filter:
                ready = self.db.execute(
                    "SELECT value FROM portable_store_state WHERE key = ?",
                    (RECO_SCOPE_READY_KEY,),
                ).fetchone()
                if ready != ("1",):
                    raise RuntimeError(
                        "El alcance RECO no fue cargado para esta ejecucion."
                    )
            normalized_profile = str(filter_profile or "").strip()
            normalized_project = str(project_name or "").strip()
            if normalized_profile:
                ready = self.db.execute(
                    "SELECT value FROM portable_store_state WHERE key = ?",
                    (PROCESSING_SCOPE_READY_PREFIX + normalized_profile,),
                ).fetchone()
                if ready != ("1",):
                    raise RuntimeError(
                        "El perfil operativo {0} no fue cargado para esta "
                        "ejecución.".format(normalized_profile)
                    )
            if normalized_project:
                ready = self.db.execute(
                    "SELECT value FROM portable_store_state WHERE key = ?",
                    ("project_scope_ready",),
                ).fetchone()
                if ready != ("1",):
                    raise RuntimeError(
                        "El proyecto de trabajo no fue cargado para esta ejecución."
                    )
            self.db.execute("DELETE FROM findings WHERE rule_id = ?", (rule_id,))
            while True:
                batch: list[dict[str, Any]] = []
                for _index in range(256):
                    if cancel_check is not None and cancel_check():
                        raise PortableStoreCancelled("Ejecucion portable cancelada.")
                    try:
                        row = next(iterator)
                    except StopIteration:
                        break
                    batch.append(normalize_portable_row(row, rule_id))
                if not batch:
                    break

                allowed: set[str] | None = None
                if apply_reco_filter:
                    predio_ids = sorted(
                        {
                            str(row.get("pk_id_predio")).strip()
                            for row in batch
                            if row.get("pk_id_predio") not in (None, "")
                        }
                    )
                    allowed = set()
                    if predio_ids:
                        placeholders = ",".join("?" for _value in predio_ids)
                        allowed = {
                            str(record[0])
                            for record in self.db.execute(
                                "SELECT pk_id_predio FROM reco_allowed_predio "
                                "WHERE pk_id_predio IN ({0})".format(placeholders),
                                predio_ids,
                            )
                        }
                elif normalized_profile:
                    predio_ids = sorted(
                        {
                            predio_id
                            for row in batch
                            if (predio_id := portable_predio_scope_id(row))
                        }
                    )
                    allowed = set()
                    if predio_ids:
                        placeholders = ",".join("?" for _value in predio_ids)
                        allowed = {
                            str(record[0])
                            for record in self.db.execute(
                                "SELECT pk_id_predio "
                                "FROM processing_allowed_predio "
                                "WHERE profile_id = ? "
                                "AND pk_id_predio IN ({0})".format(
                                    placeholders
                                ),
                                [normalized_profile, *predio_ids],
                            )
                        }

                project_allowed: set[str] | None = None
                if normalized_project:
                    project_predio_ids = sorted(
                        {
                            predio_id
                            for row in batch
                            if (predio_id := portable_predio_scope_id(row))
                        }
                    )
                    project_allowed = set()
                    if project_predio_ids:
                        placeholders = ",".join(
                            "?" for _value in project_predio_ids
                        )
                        project_allowed = {
                            str(record[0])
                            for record in self.db.execute(
                                "SELECT pk_id_predio FROM project_allowed_predio "
                                "WHERE pk_id_predio IN ({0})".format(
                                    placeholders
                                ),
                                project_predio_ids,
                            )
                        }

                inserts = []
                for normalized in batch:
                    predio_text = portable_predio_scope_id(normalized)
                    row_project = str(normalized.get("proyecto") or "").strip()
                    if normalized_project:
                        if row_project and row_project != normalized_project:
                            continue
                        if (
                            predio_text is not None
                            and predio_text not in (project_allowed or set())
                        ):
                            continue
                    if apply_reco_filter and (
                        predio_text is None or predio_text not in (allowed or set())
                    ):
                        continue
                    if (
                        normalized_profile
                        and predio_text is not None
                        and predio_text not in (allowed or set())
                    ):
                        continue
                    inserts.append(
                        (
                            rule_id,
                            1 if is_truthy(normalized.get("tiene_excepcion")) else 0,
                            portable_search_text(normalized),
                            json.dumps(
                                normalized,
                                ensure_ascii=False,
                                default=str,
                            ),
                        )
                    )
                if not inserts:
                    continue
                self.db.executemany(
                    "INSERT INTO findings("
                    "rule_id, has_exception, search_text, payload"
                    ") VALUES (?, ?, ?, ?)",
                    inserts,
                )
                count += len(inserts)
            if cancel_check is not None and cancel_check():
                raise PortableStoreCancelled("Ejecucion portable cancelada.")
            close = getattr(iterator, "close", None)
            if callable(close):
                close()
                iterator_closed = True
            self.db.commit()
            return count
        except BaseException:
            self.db.rollback()
            raise
        finally:
            if not iterator_closed:
                close = getattr(iterator, "close", None)
                if callable(close):
                    with suppress(Exception):
                        close()

    def replace_project_allowed(
        self,
        rows: Iterable[dict[str, Any]],
        cancel_check: Callable[[], bool] | None = None,
    ) -> int:
        iterator = iter(rows)
        iterator_closed = False
        count = 0
        try:
            self.db.execute("BEGIN IMMEDIATE")
            self.db.execute(
                "DELETE FROM portable_store_state WHERE key = ?",
                ("project_scope_ready",),
            )
            self.db.execute("DELETE FROM project_allowed_predio")
            while True:
                batch = []
                exhausted = False
                for _index in range(512):
                    if cancel_check is not None and cancel_check():
                        raise PortableStoreCancelled(
                            "Carga del proyecto cancelada."
                        )
                    try:
                        row = next(iterator)
                    except StopIteration:
                        exhausted = True
                        break
                    value = row.get("pk_id_predio")
                    if value not in (None, ""):
                        batch.append((str(value).strip(),))
                if batch:
                    before = self.db.total_changes
                    self.db.executemany(
                        "INSERT OR IGNORE INTO project_allowed_predio("
                        "pk_id_predio) VALUES (?)",
                        batch,
                    )
                    count += self.db.total_changes - before
                if exhausted:
                    break
            self.db.execute(
                "INSERT OR REPLACE INTO portable_store_state(key, value) "
                "VALUES (?, ?)",
                ("project_scope_ready", "1"),
            )
            self.db.commit()
            return count
        except BaseException:
            self.db.rollback()
            raise
        finally:
            if not iterator_closed:
                close = getattr(iterator, "close", None)
                if callable(close):
                    with suppress(Exception):
                        close()

    def replace_processing_allowed(
        self,
        profile_ids: Iterable[str],
        rows: Iterable[dict[str, Any]],
        cancel_check: Callable[[], bool] | None = None,
    ) -> dict[str, int]:
        """Persist independent operational scopes for the requested profiles."""

        profiles = tuple(
            dict.fromkeys(
                str(value).strip()
                for value in profile_ids
                if str(value).strip()
            )
        )
        counts = {profile: 0 for profile in profiles}
        iterator = iter(rows)
        iterator_closed = False
        try:
            self.db.execute("BEGIN IMMEDIATE")
            for profile in profiles:
                self.db.execute(
                    "DELETE FROM portable_store_state WHERE key = ?",
                    (PROCESSING_SCOPE_READY_PREFIX + profile,),
                )
                self.db.execute(
                    "DELETE FROM processing_allowed_predio "
                    "WHERE profile_id = ?",
                    (profile,),
                )
            while True:
                batch: list[tuple[str, str]] = []
                exhausted = False
                for _index in range(512):
                    if cancel_check is not None and cancel_check():
                        raise PortableStoreCancelled(
                            "Carga de filtros operativos cancelada."
                        )
                    try:
                        row = next(iterator)
                    except StopIteration:
                        exhausted = True
                        break
                    profile = str(row.get("profile_id") or "").strip()
                    value = row.get("pk_id_predio")
                    predio = (
                        str(value).strip()
                        if value not in (None, "")
                        else ""
                    )
                    if profile in counts and predio:
                        batch.append((profile, predio))
                if batch:
                    self.db.executemany(
                        "INSERT OR IGNORE INTO processing_allowed_predio("
                        "profile_id, pk_id_predio) VALUES (?, ?)",
                        batch,
                    )
                    # Derive exact per-profile counts after the bounded insert;
                    # ``total_changes`` alone cannot attribute duplicates.
                    for profile in {record[0] for record in batch}:
                        counts[profile] = int(
                            self.db.execute(
                                "SELECT COUNT(*) "
                                "FROM processing_allowed_predio "
                                "WHERE profile_id = ?",
                                (profile,),
                            ).fetchone()[0]
                        )
                if exhausted:
                    break
            if cancel_check is not None and cancel_check():
                raise PortableStoreCancelled(
                    "Carga de filtros operativos cancelada."
                )
            close = getattr(iterator, "close", None)
            if callable(close):
                close()
                iterator_closed = True
            for profile in profiles:
                self.db.execute(
                    "INSERT INTO portable_store_state(key, value) "
                    "VALUES (?, ?)",
                    (PROCESSING_SCOPE_READY_PREFIX + profile, "1"),
                )
            self.db.commit()
            return counts
        except BaseException:
            self.db.rollback()
            raise
        finally:
            if not iterator_closed:
                close = getattr(iterator, "close", None)
                if callable(close):
                    with suppress(Exception):
                        close()

    def processing_allowed_count(self, profile_id: str) -> int:
        return int(
            self.db.execute(
                "SELECT COUNT(*) FROM processing_allowed_predio "
                "WHERE profile_id = ?",
                (str(profile_id),),
            ).fetchone()[0]
        )

    def replace_reco_allowed(
        self,
        rows: Iterable[dict[str, Any]],
        cancel_check: Callable[[], bool] | None = None,
    ) -> int:
        """Persist the operational RECO scope without retaining it in memory."""

        inserted = 0
        iterator = iter(rows)
        iterator_closed = False
        try:
            self.db.execute("BEGIN IMMEDIATE")
            self.db.execute(
                "DELETE FROM portable_store_state WHERE key = ?",
                (RECO_SCOPE_READY_KEY,),
            )
            self.db.execute("DELETE FROM reco_allowed_predio")
            while True:
                batch: list[tuple[str]] = []
                exhausted = False
                for _index in range(256):
                    if cancel_check is not None and cancel_check():
                        raise PortableStoreCancelled(
                            "Carga del filtro RECO cancelada."
                        )
                    try:
                        row = next(iterator)
                    except StopIteration:
                        exhausted = True
                        break
                    value = row.get("pk_id_predio")
                    normalized = (
                        str(value).strip() if value not in (None, "") else ""
                    )
                    if normalized:
                        batch.append((normalized,))
                if not batch and exhausted:
                    break
                if batch:
                    before = self.db.total_changes
                    self.db.executemany(
                        "INSERT OR IGNORE INTO reco_allowed_predio(pk_id_predio) "
                        "VALUES (?)",
                        batch,
                    )
                    inserted += self.db.total_changes - before
                if exhausted:
                    break
            if cancel_check is not None and cancel_check():
                raise PortableStoreCancelled("Carga del filtro RECO cancelada.")
            close = getattr(iterator, "close", None)
            if callable(close):
                close()
                iterator_closed = True
            self.db.execute(
                "INSERT INTO portable_store_state(key, value) VALUES (?, ?)",
                (RECO_SCOPE_READY_KEY, "1"),
            )
            self.db.commit()
            return inserted
        except BaseException:
            self.db.rollback()
            try:
                self.db.execute(
                    "DELETE FROM portable_store_state WHERE key = ?",
                    (RECO_SCOPE_READY_KEY,),
                )
                self.db.commit()
            except Exception:
                self.db.rollback()
            raise
        finally:
            if not iterator_closed:
                close = getattr(iterator, "close", None)
                if callable(close):
                    with suppress(Exception):
                        close()

    def reco_allowed_count(self) -> int:
        return int(
            self.db.execute("SELECT COUNT(*) FROM reco_allowed_predio").fetchone()[0]
        )

    def iter_reco_filtered_rows(
        self,
        rows: Iterable[dict[str, Any]],
        cancel_check: Callable[[], bool] | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Yield original rows whose normalized predio belongs to RECO scope.

        The scope remains disk-backed and membership is resolved in batches, so
        the default operational API does not materialize every allowed PK in
        memory and does not alter value types such as execution timestamps.
        """

        ready = self.db.execute(
            "SELECT value FROM portable_store_state WHERE key = ?",
            (RECO_SCOPE_READY_KEY,),
        ).fetchone()
        if ready != ("1",):
            raise RuntimeError("El alcance RECO no fue cargado para esta ejecucion.")

        iterator = iter(rows)
        iterator_closed = False
        try:
            while True:
                batch: list[dict[str, Any]] = []
                exhausted = False
                for _index in range(256):
                    if cancel_check is not None and cancel_check():
                        raise PortableStoreCancelled("Ejecucion portable cancelada.")
                    try:
                        batch.append(next(iterator))
                    except StopIteration:
                        exhausted = True
                        break
                if not batch and exhausted:
                    break

                predio_ids = sorted(
                    {
                        str(row.get("pk_id_predio")).strip()
                        for row in batch
                        if row.get("pk_id_predio") not in (None, "")
                    }
                )
                allowed: set[str] = set()
                if predio_ids:
                    placeholders = ",".join("?" for _value in predio_ids)
                    allowed = {
                        str(record[0])
                        for record in self.db.execute(
                            "SELECT pk_id_predio FROM reco_allowed_predio "
                            "WHERE pk_id_predio IN ({0})".format(placeholders),
                            predio_ids,
                        )
                    }
                for row in batch:
                    if cancel_check is not None and cancel_check():
                        raise PortableStoreCancelled("Ejecucion portable cancelada.")
                    predio = row.get("pk_id_predio")
                    normalized = (
                        str(predio).strip() if predio not in (None, "") else None
                    )
                    if normalized is not None and normalized in allowed:
                        yield row
                if exhausted:
                    break
            close = getattr(iterator, "close", None)
            if callable(close):
                close()
                iterator_closed = True
        finally:
            if not iterator_closed:
                close = getattr(iterator, "close", None)
                if callable(close):
                    with suppress(Exception):
                        close()

    @staticmethod
    def _where(
        rule_id: str | None,
        search: str | None,
        exclude_exceptions: bool = False,
    ) -> tuple[str, list[Any]]:
        clauses = []
        parameters: list[Any] = []
        if rule_id:
            clauses.append("rule_id = ?")
            parameters.append(str(rule_id))
        if exclude_exceptions:
            clauses.append("has_exception = 0")
        if search:
            clauses.append("search_text LIKE ? ESCAPE '\\'")
            escaped = (
                str(search)
                .casefold()
                .replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_")
            )
            parameters.append("%" + escaped + "%")
        return (" WHERE " + " AND ".join(clauses) if clauses else "", parameters)

    def count(
        self,
        rule_id: str | None = None,
        search: str | None = None,
        *,
        exclude_exceptions: bool = False,
    ) -> int:
        where, parameters = self._where(rule_id, search, exclude_exceptions)
        return int(
            self.db.execute(
                "SELECT COUNT(*) FROM findings" + where,
                parameters,
            ).fetchone()[0]
        )

    def page(
        self,
        page_number: int,
        page_size: int = DEFAULT_PAGE_SIZE,
        *,
        rule_id: str | None = None,
        search: str | None = None,
        exclude_exceptions: bool = False,
    ) -> list[dict[str, Any]]:
        size = max(1, min(int(page_size), MAX_PAGE_SIZE))
        offset = max(0, int(page_number)) * size
        where, parameters = self._where(rule_id, search, exclude_exceptions)
        rows = self.db.execute(
            "SELECT payload FROM findings"
            + where
            + " ORDER BY sequence LIMIT ? OFFSET ?",
            [*parameters, size, offset],
        ).fetchall()
        return [json.loads(row[0]) for row in rows]

    def iter_rows(
        self,
        *,
        rule_id: str | None = None,
        search: str | None = None,
        exclude_exceptions: bool = False,
    ) -> Iterator[dict[str, Any]]:
        where, parameters = self._where(rule_id, search, exclude_exceptions)
        cursor = self.db.execute(
            "SELECT payload FROM findings" + where + " ORDER BY sequence",
            parameters,
        )
        try:
            for row in cursor:
                yield json.loads(row[0])
        finally:
            cursor.close()

    def iter_pages(
        self,
        *,
        page_size: int = DEFAULT_PAGE_SIZE,
        rule_id: str | None = None,
        search: str | None = None,
        exclude_exceptions: bool = False,
    ) -> Iterator[list[dict[str, Any]]]:
        page_number = 0
        while True:
            rows = self.page(
                page_number,
                page_size,
                rule_id=rule_id,
                search=search,
                exclude_exceptions=exclude_exceptions,
            )
            if not rows:
                break
            yield rows
            page_number += 1

    def rule_ids(self) -> list[str]:
        return [
            str(row[0])
            for row in self.db.execute(
                "SELECT rule_id FROM findings GROUP BY rule_id ORDER BY MIN(sequence)"
            )
        ]

    def rule_counts(self) -> dict[str, int]:
        return {
            str(row[0]): int(row[1])
            for row in self.db.execute(
                "SELECT rule_id, COUNT(*) FROM findings GROUP BY rule_id ORDER BY MIN(sequence)"
            )
        }

    def close(self) -> None:
        if self.db is not None:
            self.db.close()
            self.db = None

    def remove(self) -> None:
        path = self.path
        self.close()
        for candidate in (
            path,
            path.with_name(path.name + "-wal"),
            path.with_name(path.name + "-shm"),
        ):
            candidate.unlink(missing_ok=True)
