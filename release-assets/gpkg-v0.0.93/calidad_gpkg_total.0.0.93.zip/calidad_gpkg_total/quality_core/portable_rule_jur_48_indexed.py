"""Indexed SQLite adapter for Jur_48 without changing its canonical predicates."""
from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

from . import portable_jur_remaining_relational as base
from .portable_predio_scalar import _ingest_enrichment, _result_row
from .portable_primitives import raise_if_cancelled, sqlite_staging


def _create_indexes(db):
    """Bound the formal/improvement owner join on production-size packages."""

    db.executescript(
        """
        CREATE INDEX jur48_predio_npn_parts
          ON predio(substr(npn,22,1),substr(npn,1,21));
        CREATE INDEX jur48_derecho_predio ON derecho(predio_key);
        CREATE INDEX jur48_interesado_derecho ON interesado(derecho_key);
        CREATE INDEX jur48_interesado_documento ON interesado(documento);
        CREATE INDEX jur48_interesado_nombre ON interesado(nombre);
        """
    )


def execute_jur_48(data_source, layer_mapping, cancel_check=None):
    """Execute Jur_48 with the certified query and supporting SQLite indexes."""

    rule_id = "Jur_48"
    component, description, custom_7 = base.RULES[rule_id]
    definition = SimpleNamespace(
        canonical_id=rule_id,
        component=component,
        description=description,
        custom_7=custom_7,
    )
    timestamp = datetime.now()
    with sqlite_staging(
        cancel_check,
        prefix="mapingtool-calidad-gpkg-jur_48-indexed-",
    ) as db:
        base._create(db)
        base._ingest(rule_id, data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(
            definition,
            data_source,
            layer_mapping,
            db,
            cancel_check,
        )
        _create_indexes(db)
        base._prepare(rule_id, db)
        db.commit()
        cursor = db.execute(
            """SELECT c.pk_id_output,p.npn,p.project,p.registration,dest.ilicode,p.area,
            e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,
            ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.table1,c.pk1,c.table2,c.pk2
            FROM candidate c
            JOIN predio p ON p.row_token=c.predio_row
            LEFT JOIN destination_lookup dest ON dest.key_token=p.destination_key
            LEFT JOIN exception_lookup e ON e.fk_token=c.enrichment_key
            LEFT JOIN user_assignment ua ON ua.fk_token=c.enrichment_key
            LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a
            LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c
            LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a
            LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c
            LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a
            LEFT JOIN control_lookup ic ON ic.key_token=p.info_c
            LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a
            LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c
            ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project"""
        )
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                row = _result_row(definition, timestamp, values[:17])
                row.update(
                    {
                        "tabla_error_1": values[17],
                        "pk_tabla_error_1": values[18],
                        "tabla_error_2": values[19],
                        "pk_tabla_error_2": values[20],
                    }
                )
                yield row
        finally:
            cursor.close()
