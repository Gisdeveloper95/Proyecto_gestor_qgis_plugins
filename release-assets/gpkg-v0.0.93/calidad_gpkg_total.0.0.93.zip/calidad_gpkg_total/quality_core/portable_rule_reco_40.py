"""Independent portable implementation of canonical Reco_40."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_40", "Calificacion",
    "Caracteristica Unidad de Construccion sin el detalle de calificacion y sin puntaje anterior",
    "c.puntaje IS NULL OR c.puntaje = 0", False,
)

def execute_reco_40(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
