"""Portable implementation of the operational RECO predio scope."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
import re
from typing import Any

from .portable_primitives import (
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
)


RECO_POST_FILTER_FIELDS = (
    "pk_id",
    "juridico_predio_cancelado",
    "reconocimiento_estado_asignacion",
    "condicion",
    "informal_predio_para_visita",
)
_EXCLUDED_CONDITIONS = frozenset(("2", "5", "8", "9"))


def reco_predio_is_allowed(row: Mapping[str, Any]) -> bool:
    """Replicate the four predicates in ``reco_post_filter.sql``."""

    if not postgres_boolean_is_false_or_null(
        row.get("juridico_predio_cancelado")
    ):
        return False
    assignment = row.get("reconocimiento_estado_asignacion")
    if assignment is None or str(assignment).strip(" ") != "2":
        return False
    condition = re.sub(
        r"\.0$",
        "",
        str(
            row.get("condicion") if row.get("condicion") is not None else ""
        ).strip(" "),
    )
    if condition in _EXCLUDED_CONDITIONS:
        return False
    return postgres_boolean_is_false_or_null(
        row.get("informal_predio_para_visita")
    )


def iter_reco_allowed_predio_ids(
    data_source,
    layer_mapping,
    cancel_check=None,
) -> Iterator[dict[str, str]]:
    """Yield the normalized, bounded operational scope consumed by the store."""

    physical_name = layer_mapping.resolve("lc_gen_predio")
    for row in data_source.iter_rows(physical_name, RECO_POST_FILTER_FIELDS):
        raise_if_cancelled(cancel_check)
        if not reco_predio_is_allowed(row):
            continue
        value = row.get("pk_id")
        normalized = str(value).strip() if value not in (None, "") else ""
        if normalized:
            yield {"pk_id_predio": normalized}
