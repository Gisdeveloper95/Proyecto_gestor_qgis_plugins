"""Disk-backed portable engine for the remaining non-spatial Jur rules."""
from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_boolean_is_false_or_null, raise_if_cancelled, sqlite_staging


RULES = {
    "Jur_03": ("Juridico", "Predios con matricula inmobiliaria diferente a la matricula inmobiliaria anterior la cual esta repetida o duplicada", False),
    "Jur_10": ("Juridico", "Predios con numero predial nacional con longitud diferente a 30 caracteres", True),
    "Jur_21": ("Juridico", "Predios sin interesados activos", False),
    "Jur_37": ("Interesado", "Interesados anteriores que no existen en la base de datos", False),
    "Jur_38": ("Interesado", "Interesados nuevos existentes en los interesados anterior", False),
    "Jur_45": ("Interesado", "Interesados con el mismo documento de identidad pero diferente nombre", False),
    "Jur_48": ("Juridico", "Interesados existentes en mejoras y existentes en los predios formales", False),
    "Jur_80": ("Juridico", "Predios con interesados nuevos sin propietarios con cambio de propietario", True),
}
_BASE_PREDIO = (
    "pk_id", "numero_predial_nacional", "nombre_proyecto", "matricula_inmobiliaria",
    "destinacion_economica", "area_catastral_terreno", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion", "reconocimiento_estado_control",
    "informal_estado_asignacion", "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
_EXTRA_PREDIO = {
    "Jur_03": ("juridico_predio_cancelado", "matricula_inmobiliaria_anterior"),
    "Jur_10": ("juridico_predio_cancelado",), "Jur_21": ("juridico_predio_cancelado",),
    "Jur_37": ("juridico_predio_cancelado",), "Jur_38": ("juridico_predio_cancelado",),
    "Jur_45": ("juridico_predio_cancelado",),
    "Jur_48": (),
    "Jur_80": ("juridico_predio_cancelado", "destinacion_economica_anterior"),
}
_ACTIVE_RULES = set(RULES) - {"Jur_48"}


def _create(db):
    db.executescript("""
    CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,project,registration,previous_registration,destination,destination_key TEXT,previous_destination,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT,active INTEGER);
    CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,predio_key TEXT,type_key TEXT);
    CREATE TABLE rtype(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    CREATE TABLE interesado(row_token INTEGER PRIMARY KEY,fid,pk_id,pk_key TEXT,derecho_key TEXT,estado,tipo_documento,documento,nombre);
    CREATE TABLE anterior(row_token INTEGER PRIMARY KEY,fid,pk_id,pk_key TEXT,derecho_key TEXT);
    CREATE TABLE candidate(row_token INTEGER PRIMARY KEY,predio_row INTEGER,pk_id_output,table1,pk1,table2,pk2,enrichment_key TEXT);
    CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
    CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
    CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    """)


def _ingest(rule_id, source, mapping, db, cancel):
    fields = tuple(dict.fromkeys((*_BASE_PREDIO, *_EXTRA_PREDIO[rule_id])))
    sql = "INSERT INTO predio(pk_id,pk_key,npn,project,registration,previous_registration,destination,destination_key,previous_destination,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c,active)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    with BatchInserter(db, sql, cancel_check=cancel) as ins:
        for row in source.iter_rows(mapping.resolve("lc_gen_predio"), fields):
            raise_if_cancelled(cancel)
            active = int(postgres_boolean_is_false_or_null(row.get("juridico_predio_cancelado"))) if rule_id in _ACTIVE_RULES else 1
            ins.add((row.get("pk_id"), _join_token(row.get("pk_id")), row.get("numero_predial_nacional"), row.get("nombre_proyecto"), row.get("matricula_inmobiliaria"), row.get("matricula_inmobiliaria_anterior"), row.get("destinacion_economica"), _join_token(row.get("destinacion_economica")), row.get("destinacion_economica_anterior"), row.get("area_catastral_terreno"), _join_token(row.get("juridico_estado_asignacion")), _join_token(row.get("juridico_estado_control")), _join_token(row.get("reconocimiento_estado_asignacion")), _join_token(row.get("reconocimiento_estado_control")), _join_token(row.get("informal_estado_asignacion")), _join_token(row.get("informal_estado_control")), _join_token(row.get("geografico_estado_asignacion")), _join_token(row.get("geografico_estado_control")), active))
    if rule_id != "Jur_03":
        right_fields = ("pk_id", "fk_id", "tipo_derecho") if rule_id == "Jur_10" else ("pk_id", "fk_id")
        with BatchInserter(db, "INSERT INTO derecho(pk_id,pk_key,predio_key,type_key)VALUES(?,?,?,?)", cancel_check=cancel) as ins:
            for row in source.iter_rows(mapping.resolve("lc_jur_derecho"), right_fields):
                raise_if_cancelled(cancel); ins.add((row.get("pk_id"), _join_token(row.get("pk_id")), _join_token(row.get("fk_id")), _join_token(row.get("tipo_derecho"))))
    if rule_id == "Jur_10":
        with BatchInserter(db, "INSERT INTO rtype(key_token,ilicode)VALUES(?,?)", cancel_check=cancel) as ins:
            for row in source.iter_rows(mapping.resolve("lc_jur_derecho_tipo"), ("itfcode", "ilicode")):
                raise_if_cancelled(cancel); ins.add((_join_token(row.get("itfcode")), row.get("ilicode")))
    if rule_id in {"Jur_21", "Jur_37", "Jur_38", "Jur_45", "Jur_48", "Jur_80"}:
        fields_by_rule = {
            "Jur_21": ("pk_id", "fid", "fk_id", "estado_propietario"),
            "Jur_37": ("pk_id", "fid", "fk_id"), "Jur_38": ("pk_id", "fid", "fk_id"),
            "Jur_45": ("pk_id", "fid", "fk_id", "tipo_documento", "documento_identidad", "nombre_completo_propietario"),
            "Jur_48": ("pk_id", "fid", "fk_id", "documento_identidad", "nombre_completo_propietario"),
            "Jur_80": ("pk_id", "fid", "fk_id", "estado_propietario"),
        }
        with BatchInserter(db, "INSERT INTO interesado(fid,pk_id,pk_key,derecho_key,estado,tipo_documento,documento,nombre)VALUES(?,?,?,?,?,?,?,?)", cancel_check=cancel) as ins:
            for row in source.iter_rows(mapping.resolve("lc_jur_interesado"), fields_by_rule[rule_id]):
                raise_if_cancelled(cancel); ins.add((row.get("fid"), row.get("pk_id"), _join_token(row.get("pk_id")), _join_token(row.get("fk_id")), row.get("estado_propietario"), row.get("tipo_documento"), row.get("documento_identidad"), row.get("nombre_completo_propietario")))
    if rule_id in {"Jur_37", "Jur_38"}:
        with BatchInserter(db, "INSERT INTO anterior(fid,pk_id,pk_key,derecho_key)VALUES(?,?,?,?)", cancel_check=cancel) as ins:
            for row in source.iter_rows(mapping.resolve("lc_jur_interesado_anterior"), ("fid", "pk_id", "fk_id")):
                raise_if_cancelled(cancel); ins.add((row.get("fid"), row.get("pk_id"), _join_token(row.get("pk_id")), _join_token(row.get("fk_id"))))


def _prepare(rule_id, db):
    insert = "INSERT INTO candidate(predio_row,pk_id_output,table1,pk1,table2,pk2,enrichment_key) "
    if rule_id == "Jur_03":
        query = """WITH duplicate AS(SELECT registration FROM predio WHERE active=1 AND registration IS NOT NULL GROUP BY registration HAVING count(*)>1) SELECT p.row_token,p.pk_id,'LC_Gen_Predio',p.pk_id,NULL,NULL,p.pk_key FROM predio p JOIN duplicate d ON p.registration=d.registration WHERE p.active=1 AND ('190-'||CAST(p.registration AS TEXT))<>p.previous_registration"""
    elif rule_id == "Jur_10":
        query = """SELECT p.row_token,p.pk_id,'LC_Gen_Predio',p.pk_id,NULL,NULL,p.pk_key FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN rtype t ON t.key_token=d.type_key WHERE p.active=1 AND length(p.npn)<>30"""
    elif rule_id == "Jur_21":
        query = """SELECT p.row_token,NULL,'LC_Gen_Predio',p.pk_id,'LC_Jur_Derecho',NULL,NULL FROM predio p WHERE p.active=1 AND NOT EXISTS(SELECT 1 FROM derecho d JOIN interesado i ON i.derecho_key=d.pk_key WHERE d.predio_key=p.pk_key AND i.estado<>0)"""
    elif rule_id == "Jur_37":
        query = """SELECT p.row_token,p.pk_id,'LC_Jur_Derecho',d.pk_id,'LC_Jur_InteresadoAnterior',a.pk_id,p.pk_key FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN anterior a ON a.derecho_key=d.pk_key LEFT JOIN interesado i ON i.pk_key=a.pk_key WHERE p.active=1 AND i.fid IS NULL"""
    elif rule_id == "Jur_38":
        query = """SELECT p.row_token,p.pk_id,'LC_Jur_Derecho',d.pk_id,'LC_Jur_InteresadoAnterior',a.pk_id,p.pk_key FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN anterior a ON a.derecho_key=d.pk_key LEFT JOIN interesado i ON i.pk_key=a.pk_key WHERE p.active=1 AND lower(CAST(i.pk_id AS TEXT)) LIKE '{%' AND a.fid IS NOT NULL"""
    elif rule_id == "Jur_45":
        query = """WITH grouped AS(SELECT i.tipo_documento,i.documento,i.nombre,count(*) n FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key WHERE p.active=1 AND i.documento<>'0' GROUP BY i.tipo_documento,i.documento,i.nombre HAVING count(*)>1), docs AS(SELECT documento FROM grouped GROUP BY documento HAVING count(*)>1) SELECT p.row_token,p.pk_id,'LC_Jur_Derecho',d.pk_id,'LC_Jur_Interesado',i.pk_id,p.pk_key FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key JOIN docs x ON x.documento=i.documento WHERE p.active=1"""
    elif rule_id == "Jur_48":
        query = """WITH formal AS(SELECT p.row_token predio_row,p.pk_id,p.pk_key,p.npn,d.pk_id derecho_pk,i.documento,i.nombre FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key WHERE substr(p.npn,22,1)='0'), mejora AS(SELECT p.pk_id,p.npn,i.documento,i.nombre FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key WHERE substr(p.npn,22,1)='5') SELECT f.predio_row,f.pk_id,'LC_Gen_Predio',f.pk_id,'LC_Gen_Predio',m.pk_id,f.pk_key FROM formal f JOIN mejora m ON substr(f.npn,1,21)=substr(m.npn,1,21) WHERE f.documento=m.documento OR f.nombre=m.nombre"""
    else:
        query = """SELECT DISTINCT p.row_token,p.pk_id,'LC_Jur_Derecho',d.pk_id,NULL,NULL,p.pk_key FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key AND i.estado=1 WHERE p.active=1 AND p.previous_destination IS NOT NULL AND NOT EXISTS(SELECT 1 FROM derecho d0 JOIN interesado i0 ON i0.derecho_key=d0.pk_key AND i0.estado=0 WHERE d0.predio_key=p.pk_key)"""
    db.execute(insert + query)


def execute_rule(rule_id, data_source, layer_mapping, cancel_check=None):
    component, description, custom_7 = RULES[rule_id]
    definition = SimpleNamespace(canonical_id=rule_id, component=component, description=description, custom_7=custom_7)
    timestamp = datetime.now()
    with sqlite_staging(cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        _create(db); _ingest(rule_id, data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(definition, data_source, layer_mapping, db, cancel_check); _prepare(rule_id, db); db.commit()
        distinct = "DISTINCT " if rule_id == "Jur_80" else ""
        sql = f"""SELECT {distinct}c.pk_id_output,p.npn,p.project,p.registration,dest.ilicode,p.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.table1,c.pk1,c.table2,c.pk2 FROM candidate c JOIN predio p ON p.row_token=c.predio_row LEFT JOIN destination_lookup dest ON dest.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=c.enrichment_key LEFT JOIN user_assignment ua ON ua.fk_token=c.enrichment_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project"""
        cur = db.execute(sql)
        try:
            for values in cur:
                raise_if_cancelled(cancel_check); row = _result_row(definition, timestamp, values[:17]); row.update({"tabla_error_1": values[17], "pk_tabla_error_1": values[18], "tabla_error_2": values[19], "pk_tabla_error_2": values[20]}); yield row
        finally:
            cur.close()


def _entry(rule_id):
    def execute(data_source, layer_mapping, cancel_check=None): return execute_rule(rule_id, data_source, layer_mapping, cancel_check)
    execute.__name__ = f"execute_{rule_id.lower()}"; return execute


execute_jur_03=_entry("Jur_03"); execute_jur_10=_entry("Jur_10"); execute_jur_21=_entry("Jur_21"); execute_jur_37=_entry("Jur_37"); execute_jur_38=_entry("Jur_38"); execute_jur_45=_entry("Jur_45"); execute_jur_48=_entry("Jur_48"); execute_jur_80=_entry("Jur_80")
