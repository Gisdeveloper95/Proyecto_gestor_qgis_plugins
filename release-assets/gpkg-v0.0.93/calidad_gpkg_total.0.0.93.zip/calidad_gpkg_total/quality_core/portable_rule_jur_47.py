"""Portable exact-geometry implementation of canonical Jur_47."""
from datetime import datetime
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging

_PF=("pk_id","numero_predial_nacional","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")


def _geometry(payload):
 from qgis.core import QgsGeometry
 if isinstance(payload,str):return QgsGeometry.fromWkt(payload)
 data=bytes(payload)
 if data[:2]==b"GP":
  envelope=(data[3]>>1)&7;data=data[8+{0:0,1:32,2:48,3:48,4:64}.get(envelope,0):]
 geom=QgsGeometry();geom.fromWkb(data)
 if geom.isNull():raise ValueError("Geometria WKB/GPKG invalida en Jur_47")
 return geom


def _ingest_terrain(logical,table,data_source,mapping,db,cancel):
 physical=mapping.resolve(logical);fields=set(data_source.describe(physical).fields);geometry_field="geom"if"geom"in fields else"geom_wkt"
 with BatchInserter(db,f"INSERT INTO {table}(code_key,geometry,minx,miny,maxx,maxy)VALUES(?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for row in data_source.iter_rows(physical,("codigo",geometry_field)):
   raise_if_cancelled(cancel);payload=row.get(geometry_field);geom=_geometry(payload);box=geom.boundingBox();ins.add((_join_token(row.get("codigo")),payload,box.xMinimum(),box.yMinimum(),box.xMaximum(),box.yMaximum()))


def execute_jur_47(data_source,layer_mapping,cancel_check=None):
 definition=SimpleNamespace(canonical_id="Jur_47",component="Juridico",description="Interesados existentes en la informalidad y existentes en los predios formales",custom_7=False);stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix="mapingtool-calidad-gpkg-jur_47-")as db:
  db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,npn_key TEXT,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,predio_key TEXT);CREATE TABLE interesado(row_token INTEGER PRIMARY KEY,pk_id,derecho_key TEXT,documento,nombre);CREATE TABLE terrain_formal(row_token INTEGER PRIMARY KEY,code_key TEXT,geometry,minx,miny,maxx,maxy);CREATE TABLE terrain_informal(row_token INTEGER PRIMARY KEY,code_key TEXT,geometry,minx,miny,maxx,maxy);CREATE TABLE formal(row_token INTEGER PRIMARY KEY,predio_row INTEGER,terrain_row INTEGER,documento,nombre);CREATE TABLE informal(row_token INTEGER PRIMARY KEY,predio_row INTEGER,terrain_row INTEGER,documento,nombre);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,formal_predio_row INTEGER,informal_predio_pk);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
  with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,npn_key,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),_PF):raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),_join_token(r.get("numero_predial_nacional")),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
  with BatchInserter(db,"INSERT INTO derecho(pk_id,pk_key,predio_key)VALUES(?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_derecho"),("pk_id","fk_id")):raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id"))))
  with BatchInserter(db,"INSERT INTO interesado(pk_id,derecho_key,documento,nombre)VALUES(?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_interesado"),("pk_id","fk_id","documento_identidad","nombre_completo_propietario")):raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),r.get("documento_identidad"),r.get("nombre_completo_propietario")))
  _ingest_terrain("lc_gen_terreno","terrain_formal",data_source,layer_mapping,db,cancel_check);_ingest_terrain("lc_gen_terreno_informal","terrain_informal",data_source,layer_mapping,db,cancel_check);_ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
  db.executescript("""CREATE INDEX jur47_p_npn ON predio(npn_key);CREATE INDEX jur47_d_pred ON derecho(predio_key);CREATE INDEX jur47_i_der ON interesado(derecho_key);CREATE INDEX jur47_tf_code ON terrain_formal(code_key);CREATE INDEX jur47_ti_code ON terrain_informal(code_key);INSERT INTO formal(predio_row,terrain_row,documento,nombre)SELECT p.row_token,t.row_token,i.documento,i.nombre FROM predio p JOIN terrain_formal t ON t.code_key=p.npn_key JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key WHERE substr(p.npn,22,1)='0';INSERT INTO informal(predio_row,terrain_row,documento,nombre)SELECT p.row_token,t.row_token,i.documento,i.nombre FROM predio p JOIN terrain_informal t ON t.code_key=p.npn_key JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key WHERE substr(p.npn,22,1)='2';""")
  pairs=db.execute("""SELECT f.predio_row,p2.pk_id,tf.geometry,ti.geometry FROM formal f JOIN terrain_formal tf ON tf.row_token=f.terrain_row JOIN informal i ON (f.documento=i.documento OR f.nombre=i.nombre) JOIN terrain_informal ti ON ti.row_token=i.terrain_row JOIN predio p2 ON p2.row_token=i.predio_row WHERE tf.minx<ti.maxx AND tf.maxx>ti.minx AND tf.miny<ti.maxy AND tf.maxy>ti.miny""")
  for predio_row,informal_pk,formal_geom,informal_geom in pairs:
   raise_if_cancelled(cancel_check)
   if _geometry(formal_geom).overlaps(_geometry(informal_geom)):db.execute("INSERT INTO selected(formal_predio_row,informal_predio_pk)VALUES(?,?)",(predio_row,informal_pk))
  db.commit();cur=db.execute("""SELECT p.pk_id,p.npn,p.project,p.registration,d.ilicode,p.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.informal_predio_pk FROM selected s JOIN predio p ON p.row_token=s.formal_predio_row LEFT JOIN destination_lookup d ON d.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project""")
  try:
   for v in cur:raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row.update({"tabla_error_2":"LC_Gen_Predio","pk_tabla_error_2":v[17]});yield row
  finally:cur.close()
