"""Independent portable implementation of the canonical SIG_09 rule."""

from __future__ import annotations

from collections.abc import Callable, Iterator
import json
from pathlib import Path
import sqlite3
import tempfile
from typing import Any


SIG_09_INGEST_BATCH_SIZE = 256
SIG_09_SQLITE_CACHE_KIB = 4096


def _cancelled(cancel_check: Callable[[], bool] | None) -> None:
    if cancel_check is not None and cancel_check():
        raise InterruptedError("Ejecucion portable cancelada por el usuario.")


def _join_key(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)


def _active_predio(value: Any) -> bool:
    if value is None or value is False or value == 0:
        return True
    return str(value).strip().lower() in {"false", "f", "no", "n"}


def _is_true(value: Any) -> bool:
    if value is True or value == 1:
        return True
    return str(value).strip().lower() in {"true", "t", "yes", "y", "si"}


def _json_value(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))


def _flush_batch(db: sqlite3.Connection, sql: str, batch: list[tuple]) -> None:
    if batch:
        db.executemany(sql, batch)
        batch.clear()


def _is_non_ph_code(value: Any) -> bool:
    """Match PostgreSQL ``substring(codigo, 22, 1) <> '9'``."""

    if value is None:
        return False
    return str(value)[21:22] != "9"


def execute_sig_09(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield SIG_09 findings using bounded, disk-backed attribute joins."""

    with tempfile.TemporaryDirectory(prefix="mapingtool-calidad-gpkg-sig09-") as temp_dir:
        stage_path = Path(temp_dir) / "stage.sqlite"
        db = sqlite3.connect(str(stage_path))
        try:
            db.execute("PRAGMA journal_mode=OFF")
            db.execute("PRAGMA synchronous=OFF")
            db.execute("PRAGMA temp_store=FILE")
            db.execute("PRAGMA cache_size=-{0}".format(SIG_09_SQLITE_CACHE_KIB))
            if cancel_check is not None:
                db.set_progress_handler(lambda: 1 if cancel_check() else 0, 1000)

            db.execute(
                "CREATE TABLE predio ("
                "row_token INTEGER PRIMARY KEY, fid_is_null INTEGER NOT NULL, "
                "pk_key TEXT, number_key TEXT, change_is_true INTEGER NOT NULL)"
            )
            db.execute(
                "CREATE TABLE characteristic ("
                "row_token INTEGER PRIMARY KEY, fk_key TEXT, identifier_key TEXT)"
            )
            db.execute(
                "CREATE TABLE unit ("
                "distinct_token TEXT PRIMARY KEY, pk_json TEXT NOT NULL, "
                "code_json TEXT NOT NULL, planta_json TEXT NOT NULL, "
                "identifier_json TEXT NOT NULL, code_key TEXT NOT NULL, "
                "identifier_key TEXT, table_label TEXT NOT NULL, "
                "pk_is_null INTEGER NOT NULL, pk_sort TEXT NOT NULL, "
                "identifier_is_null INTEGER NOT NULL, identifier_sort TEXT NOT NULL) "
                "WITHOUT ROWID"
            )

            predio_batch: list[tuple] = []
            predio_layer = layer_mapping.resolve("lc_gen_predio")
            for row in data_source.iter_rows(
                predio_layer,
                (
                    "fid",
                    "pk_id",
                    "numero_predial_nacional",
                    "juridico_predio_cancelado",
                    "predio_tiene_cambio_fisico",
                ),
            ):
                _cancelled(cancel_check)
                if not _active_predio(row.get("juridico_predio_cancelado")):
                    continue
                predio_batch.append(
                    (
                        int(row.get("fid") is None),
                        _join_key(row.get("pk_id")),
                        _join_key(row.get("numero_predial_nacional")),
                        int(_is_true(row.get("predio_tiene_cambio_fisico"))),
                    )
                )
                if len(predio_batch) >= SIG_09_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT INTO predio(fid_is_null, pk_key, number_key, change_is_true) "
                        "VALUES (?, ?, ?, ?)",
                        predio_batch,
                    )
            _flush_batch(
                db,
                "INSERT INTO predio(fid_is_null, pk_key, number_key, change_is_true) "
                "VALUES (?, ?, ?, ?)",
                predio_batch,
            )
            if db.execute(
                "SELECT 1 FROM predio WHERE fid_is_null = 1 LIMIT 1"
            ).fetchone():
                raise ValueError(
                    "SIG_09 requiere fid no nulo en cada predio activo; "
                    "el LEFT JOIN canonico usa ese campo como centinela."
                )
            ambiguous_pk = db.execute(
                "SELECT pk_key FROM predio WHERE pk_key IS NOT NULL "
                "GROUP BY pk_key HAVING COUNT(DISTINCT CASE "
                "WHEN number_key IS NULL THEN 'N' ELSE 'V:' || number_key END) > 1 "
                "LIMIT 1"
            ).fetchone()
            if ambiguous_pk is not None:
                raise ValueError(
                    "SIG_09 no puede resolver predios activos con el mismo pk_id "
                    "y numeros prediales distintos; DISTINCT ON carece de orden."
                )
            db.execute("CREATE INDEX idx_sig09_predio_pk ON predio(pk_key)")

            characteristic_batch: list[tuple] = []
            characteristic_layer = layer_mapping.resolve(
                "lc_reco_caracteristicasunidadconstruccion"
            )
            for row in data_source.iter_rows(
                characteristic_layer, ("fk_id", "identificador")
            ):
                _cancelled(cancel_check)
                characteristic_batch.append(
                    (
                        _join_key(row.get("fk_id")),
                        _join_key(row.get("identificador")),
                    )
                )
                if len(characteristic_batch) >= SIG_09_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT INTO characteristic(fk_key, identifier_key) VALUES (?, ?)",
                        characteristic_batch,
                    )
            _flush_batch(
                db,
                "INSERT INTO characteristic(fk_key, identifier_key) VALUES (?, ?)",
                characteristic_batch,
            )
            db.execute("CREATE INDEX idx_sig09_characteristic_fk ON characteristic(fk_key)")
            db.execute(
                "CREATE TABLE joined_predio ("
                "row_token INTEGER PRIMARY KEY, fid_is_null INTEGER NOT NULL, "
                "pk_key TEXT NOT NULL, number_key TEXT, "
                "change_is_true INTEGER NOT NULL, identifier_key TEXT)"
            )
            db.execute(
                "INSERT INTO joined_predio("
                "fid_is_null, pk_key, number_key, change_is_true, identifier_key) "
                "SELECT p.fid_is_null, p.pk_key, p.number_key, p.change_is_true, "
                "c.identifier_key FROM predio p JOIN characteristic c "
                "ON p.pk_key = c.fk_key"
            )
            db.execute(
                "CREATE INDEX idx_sig09_join_match "
                "ON joined_predio(number_key, identifier_key)"
            )
            db.execute(
                "CREATE INDEX idx_sig09_join_changed "
                "ON joined_predio(change_is_true, pk_key, row_token)"
            )

            unit_batch: list[tuple] = []
            unit_insert = (
                "INSERT OR IGNORE INTO unit("
                "distinct_token, pk_json, code_json, planta_json, identifier_json, "
                "code_key, identifier_key, table_label, pk_is_null, pk_sort, "
                "identifier_is_null, identifier_sort) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            )
            unit_layers = (
                ("lc_gen_unidadconstruccion", "LC_Gen_UnidadConstruccion"),
                (
                    "lc_gen_unidadconstruccion_informal",
                    "LC_Gen_UnidadConstruccion_Informal",
                ),
            )
            for logical_name, table_label in unit_layers:
                physical_layer = layer_mapping.resolve(logical_name)
                for row in data_source.iter_rows(
                    physical_layer,
                    (
                        "pk_id",
                        "codigo",
                        "planta",
                        "tipo_construccion",
                        "etiqueta",
                        "identificador",
                    ),
                ):
                    _cancelled(cancel_check)
                    raw_code = row.get("codigo")
                    if not _is_non_ph_code(raw_code):
                        continue
                    raw_pk = row.get("pk_id")
                    raw_planta = row.get("planta")
                    raw_identifier = row.get("identificador")
                    code_key = _join_key(raw_code)
                    identifier_key = _join_key(raw_identifier)
                    distinct_token = _json_value(
                        [
                            raw_pk,
                            raw_code,
                            raw_planta,
                            row.get("tipo_construccion"),
                            row.get("etiqueta"),
                            raw_identifier,
                            table_label,
                        ]
                    )
                    unit_batch.append(
                        (
                            distinct_token,
                            _json_value(raw_pk),
                            _json_value(raw_code),
                            _json_value(raw_planta),
                            _json_value(raw_identifier),
                            code_key,
                            identifier_key,
                            table_label,
                            int(raw_pk is None),
                            "" if raw_pk is None else str(raw_pk),
                            int(raw_identifier is None),
                            "" if raw_identifier is None else str(raw_identifier),
                        )
                    )
                    if len(unit_batch) >= SIG_09_INGEST_BATCH_SIZE:
                        _flush_batch(db, unit_insert, unit_batch)
            _flush_batch(db, unit_insert, unit_batch)
            db.commit()
            _cancelled(cancel_check)

            cursor = db.execute(
                "WITH b3 AS ("
                "SELECT u.*, b.row_token AS matched_b_row, "
                "b.fid_is_null AS matched_fid_is_null "
                "FROM unit u LEFT JOIN joined_predio b "
                "ON u.code_key = b.number_key "
                "AND u.identifier_key = b.identifier_key "
                "WHERE b.row_token IS NULL OR b.fid_is_null = 1"
                "), ranked_changed AS ("
                "SELECT b.*, ROW_NUMBER() OVER ("
                "PARTITION BY b.pk_key ORDER BY b.row_token) AS selected_row "
                "FROM joined_predio b WHERE b.change_is_true = 1"
                "), b4 AS ("
                "SELECT * FROM ranked_changed WHERE selected_row = 1"
                ") "
                "SELECT b3.pk_json, b3.code_json, b3.planta_json, "
                "b3.identifier_json, b3.table_label "
                "FROM b3 LEFT JOIN b4 ON b3.code_key = b4.number_key "
                "WHERE b4.row_token IS NULL OR b4.fid_is_null = 1 "
                "ORDER BY b3.code_key, b3.identifier_is_null, "
                "b3.identifier_sort, b3.pk_is_null, b3.pk_sort, b3.table_label"
            )
            try:
                for pk_json, code_json, planta_json, identifier_json, table_label in cursor:
                    _cancelled(cancel_check)
                    yield {
                        "id_regla": "SIG_09",
                        "descripcion_regla": (
                            "Unidad de Construccion en comision sin cambio fisico"
                        ),
                        "tabla_error": table_label,
                        "pk_tabla_error": json.loads(pk_json),
                        "codigo": json.loads(code_json),
                        "identificador_unidad_construccion": json.loads(
                            identifier_json
                        ),
                        "planta_unidad_construccion": json.loads(planta_json),
                        "tiene_excepcion": None,
                    }
            finally:
                cursor.close()
        except sqlite3.OperationalError as exc:
            if cancel_check is not None and cancel_check():
                raise InterruptedError(
                    "Ejecucion portable cancelada por el usuario."
                ) from exc
            raise
        finally:
            db.close()
