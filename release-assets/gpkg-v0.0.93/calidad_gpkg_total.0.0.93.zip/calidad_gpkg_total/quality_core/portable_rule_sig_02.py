"""Independent portable implementation of the canonical SIG_02 rule."""

from __future__ import annotations

from collections.abc import Callable, Iterator
import json
from pathlib import Path
import sqlite3
import tempfile
from typing import Any


SIG_02_INGEST_BATCH_SIZE = 256
SIG_02_SQLITE_CACHE_KIB = 4096


def _cancelled(cancel_check: Callable[[], bool] | None) -> None:
    if cancel_check is not None and cancel_check():
        raise InterruptedError("Ejecucion portable cancelada por el usuario.")


def _join_key(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)


def _active_predio(value: Any) -> bool:
    """Match ``boolean IS NULL OR boolean = false`` for portable providers."""

    if value is None or value is False or value == 0:
        return True
    return str(value).strip().lower() in {"false", "f", "no", "n"}


def _json_value(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))


def _flush_batch(db: sqlite3.Connection, sql: str, batch: list[tuple]) -> None:
    if batch:
        db.executemany(sql, batch)
        batch.clear()


def execute_sig_02(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical SIG_02 findings without reading any geometry."""

    with tempfile.TemporaryDirectory(prefix="mapingtool-calidad-gpkg-sig02-") as temp_dir:
        stage_path = Path(temp_dir) / "stage.sqlite"
        db = sqlite3.connect(str(stage_path))
        try:
            db.execute("PRAGMA journal_mode=OFF")
            db.execute("PRAGMA synchronous=OFF")
            db.execute("PRAGMA temp_store=FILE")
            db.execute("PRAGMA cache_size=-{0}".format(SIG_02_SQLITE_CACHE_KIB))
            db.execute(
                "CREATE TABLE active_predio ("
                "row_token INTEGER PRIMARY KEY, "
                "number_key TEXT NOT NULL, "
                "pk_is_null INTEGER NOT NULL)"
            )
            db.execute(
                "CREATE TABLE terrain ("
                "pk_distinct TEXT NOT NULL, "
                "code_distinct TEXT NOT NULL, "
                "pk_json TEXT NOT NULL, "
                "code_json TEXT NOT NULL, "
                "pk_is_null INTEGER NOT NULL, "
                "code_is_null INTEGER NOT NULL, "
                "pk_sort TEXT NOT NULL, "
                "code_sort TEXT NOT NULL, "
                "PRIMARY KEY (pk_distinct, code_distinct)) WITHOUT ROWID"
            )
            if cancel_check is not None:
                db.set_progress_handler(lambda: 1 if cancel_check() else 0, 1000)

            active_batch: list[tuple] = []
            predio_layer = layer_mapping.resolve("lc_gen_predio")
            for row in data_source.iter_rows(
                predio_layer,
                ("pk_id", "numero_predial_nacional", "juridico_predio_cancelado"),
            ):
                _cancelled(cancel_check)
                if not _active_predio(row.get("juridico_predio_cancelado")):
                    continue
                number_key = _join_key(row.get("numero_predial_nacional"))
                if number_key is None:
                    continue
                active_batch.append((number_key, int(row.get("pk_id") is None)))
                if len(active_batch) >= SIG_02_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT INTO active_predio(number_key, pk_is_null) VALUES (?, ?)",
                        active_batch,
                    )
            _flush_batch(
                db,
                "INSERT INTO active_predio(number_key, pk_is_null) VALUES (?, ?)",
                active_batch,
            )
            db.execute("CREATE INDEX idx_active_predio_number ON active_predio(number_key)")

            terrain_batch: list[tuple] = []
            terrain_insert = (
                "INSERT OR IGNORE INTO terrain("
                "pk_distinct, code_distinct, pk_json, code_json, "
                "pk_is_null, code_is_null, pk_sort, code_sort) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            )
            for logical_name in ("lc_gen_terreno", "lc_gen_terreno_informal"):
                physical_layer = layer_mapping.resolve(logical_name)
                for row in data_source.iter_rows(physical_layer, ("pk_id", "codigo")):
                    _cancelled(cancel_check)
                    raw_pk = row.get("pk_id")
                    raw_code = row.get("codigo")
                    pk_key = _join_key(raw_pk)
                    code_key = _join_key(raw_code)
                    terrain_batch.append(
                        (
                            _json_value(pk_key),
                            _json_value(code_key),
                            _json_value(raw_pk),
                            _json_value(raw_code),
                            int(raw_pk is None),
                            int(raw_code is None),
                            "" if pk_key is None else pk_key,
                            "" if code_key is None else code_key,
                        )
                    )
                    if len(terrain_batch) >= SIG_02_INGEST_BATCH_SIZE:
                        _flush_batch(db, terrain_insert, terrain_batch)
            _flush_batch(db, terrain_insert, terrain_batch)
            db.commit()
            _cancelled(cancel_check)

            cursor = db.execute(
                "SELECT t.pk_json, t.code_json "
                "FROM terrain t LEFT JOIN active_predio p "
                "ON t.code_is_null = 0 AND t.code_sort = p.number_key "
                "WHERE p.row_token IS NULL OR p.pk_is_null = 1 "
                "ORDER BY t.code_is_null, t.code_sort, "
                "t.pk_is_null, t.pk_sort, p.row_token"
            )
            try:
                for pk_json, code_json in cursor:
                    _cancelled(cancel_check)
                    yield {
                        "id_regla": "SIG_02",
                        "descripcion_regla": "Terrenos en comision",
                        "tabla_error": "LC_Gen_Terreno",
                        "pk_tabla_error": json.loads(pk_json),
                        "codigo": json.loads(code_json),
                        "identificador_unidad_construccion": None,
                        "planta_unidad_construccion": None,
                        "tiene_excepcion": None,
                    }
            finally:
                cursor.close()
        except sqlite3.OperationalError as exc:
            if cancel_check is not None and cancel_check():
                raise InterruptedError(
                    "Ejecucion portable cancelada por el usuario."
                ) from exc
            raise
        finally:
            db.close()
