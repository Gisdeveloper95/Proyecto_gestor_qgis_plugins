"""Disk-backed pipeline for scalar construction-unit validation rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
    sqlite_staging,
    typed_union_token,
)


_PREDIO_BASE_FIELDS = (
    "pk_id",
    "numero_predial_nacional",
    "juridico_predio_cancelado",
    "nombre_proyecto",
    "matricula_inmobiliaria",
    "destinacion_economica",
    "area_catastral_terreno",
    "juridico_estado_asignacion",
    "juridico_estado_control",
    "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control",
    "informal_estado_asignacion",
    "informal_estado_control",
    "geografico_estado_asignacion",
    "geografico_estado_control",
)
_CONSTRUCTION_BASE_FIELDS = (
    "pk_id",
    "pk_carac",
    "identificador",
    "total_plantas",
    "tipo_unidad_construccion",
    "uso_construccion",
    "area_construida",
    "puntaje",
)


@dataclass(frozen=True)
class ConstructionScalarRule:
    canonical_id: str
    component: str
    description: str
    predicate_sql: str
    custom_7: bool
    predio_filter_fields: tuple[str, ...] = ()
    construction_filter_fields: tuple[str, ...] = ()
    table_error_1: str = "LC_Reco_Caracteristicasunidadconstruccion"
    table_error_1_source: str = "construction"
    table_error_2: str | None = None
    use_output: str = "lookup"
    join_use_lookup: bool = True
    duplicate_predio_join: bool = False


def _join_token(value: Any) -> str | None:
    if value is None:
        return None
    return typed_union_token((value,))


def _unique_fields(base: tuple[str, ...], extra: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys((*base, *extra)))


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE all_predio_key (
            row_token INTEGER PRIMARY KEY,
            pk_key TEXT
        );
        CREATE TABLE predio (
            row_token INTEGER PRIMARY KEY,
            pk_id,
            pk_key TEXT,
            numero_predial_nacional,
            proyecto,
            matricula_inmobiliaria,
            destinacion_economica,
            destination_key TEXT,
            area_catastral_terreno,
            juridico_assignment_key TEXT,
            juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT,
            informal_assignment_key TEXT,
            informal_control_key TEXT,
            geografico_assignment_key TEXT,
            geografico_control_key TEXT,
            predio_tiene_cambio_fisico
        );
        CREATE TABLE construction (
            row_token INTEGER PRIMARY KEY,
            predio_key TEXT,
            pk_carac,
            identificador,
            total_plantas,
            type_key TEXT,
            use_key TEXT,
            uso_construccion,
            area_construida,
            puntaje,
            puntaje_masivo,
            anio_construccion,
            estado_conservacion
        );
        CREATE TABLE selected (
            row_token INTEGER PRIMARY KEY,
            predio_row_token INTEGER,
            construction_row_token INTEGER,
            pk_id,
            pk_key TEXT,
            numero_predial_nacional,
            proyecto,
            matricula_inmobiliaria,
            destinacion_economica,
            destination_key TEXT,
            area_catastral_terreno,
            juridico_assignment_key TEXT,
            juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT,
            informal_assignment_key TEXT,
            informal_control_key TEXT,
            geografico_assignment_key TEXT,
            geografico_control_key TEXT,
            pk_carac,
            identificador,
            total_plantas,
            type_key TEXT,
            use_key TEXT,
            uso_construccion,
            area_construida,
            puntaje
        );
        CREATE TABLE destination_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        CREATE TABLE unit_type_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        CREATE TABLE use_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        CREATE TABLE exception_lookup (
            row_token INTEGER PRIMARY KEY,
            fk_token TEXT,
            fid,
            descripcion_excepcion
        );
        CREATE TABLE user_assignment (
            row_token INTEGER PRIMARY KEY,
            fk_token TEXT,
            pk_id
        );
        CREATE TABLE assignment_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        CREATE TABLE control_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        """
    )


def _ingest_predios(definition, data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("lc_gen_predio")
    fields = _unique_fields(_PREDIO_BASE_FIELDS, definition.predio_filter_fields)
    all_keys = BatchInserter(
        db,
        "INSERT INTO all_predio_key(pk_key) VALUES (?)",
        cancel_check=cancel_check,
    )
    selected = BatchInserter(
        db,
        "INSERT INTO predio("
        "pk_id,pk_key,numero_predial_nacional,proyecto,matricula_inmobiliaria,"
        "destinacion_economica,destination_key,area_catastral_terreno,"
        "juridico_assignment_key,"
        "juridico_control_key,reconocimiento_assignment_key,"
        "reconocimiento_control_key,informal_assignment_key,informal_control_key,"
        "geografico_assignment_key,geografico_control_key,"
        "predio_tiene_cambio_fisico) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    )
    with all_keys, selected:
        for row in data_source.iter_rows(physical_name, fields):
            raise_if_cancelled(cancel_check)
            pk_key = _join_token(row.get("pk_id"))
            all_keys.add((pk_key,))
            if not postgres_boolean_is_false_or_null(
                row.get("juridico_predio_cancelado")
            ):
                continue
            selected.add(
                (
                    row.get("pk_id"),
                    pk_key,
                    row.get("numero_predial_nacional"),
                    row.get("nombre_proyecto"),
                    row.get("matricula_inmobiliaria"),
                    row.get("destinacion_economica"),
                    _join_token(row.get("destinacion_economica")),
                    row.get("area_catastral_terreno"),
                    _join_token(row.get("juridico_estado_asignacion")),
                    _join_token(row.get("juridico_estado_control")),
                    _join_token(row.get("reconocimiento_estado_asignacion")),
                    _join_token(row.get("reconocimiento_estado_control")),
                    _join_token(row.get("informal_estado_asignacion")),
                    _join_token(row.get("informal_estado_control")),
                    _join_token(row.get("geografico_estado_asignacion")),
                    _join_token(row.get("geografico_estado_control")),
                    row.get("predio_tiene_cambio_fisico"),
                )
            )


def _ingest_constructions(
    definition, data_source, layer_mapping, db, cancel_check
) -> None:
    physical_name = layer_mapping.resolve("determinacion_area_construccion")
    fields = _unique_fields(
        _CONSTRUCTION_BASE_FIELDS, definition.construction_filter_fields
    )
    with BatchInserter(
        db,
        "INSERT INTO construction("
        "predio_key,pk_carac,identificador,total_plantas,type_key,use_key,"
        "uso_construccion,area_construida,puntaje,puntaje_masivo,"
        "anio_construccion,estado_conservacion) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, fields):
            raise_if_cancelled(cancel_check)
            inserter.add(
                (
                    _join_token(row.get("pk_id")),
                    row.get("pk_carac"),
                    row.get("identificador"),
                    row.get("total_plantas"),
                    _join_token(row.get("tipo_unidad_construccion")),
                    _join_token(row.get("uso_construccion")),
                    row.get("uso_construccion"),
                    row.get("area_construida"),
                    row.get("puntaje"),
                    row.get("puntaje_masivo"),
                    row.get("anio_construccion"),
                    row.get("estado_conservacion"),
                )
            )


def _ingest_simple_lookup(
    data_source, layer_mapping, db, cancel_check, logical_name, table_name
) -> None:
    physical_name = layer_mapping.resolve(logical_name)
    with BatchInserter(
        db,
        f"INSERT INTO {table_name}(key_token,ilicode) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("itfcode", "ilicode")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("itfcode")), row.get("ilicode")))


def _ingest_enrichment(definition, data_source, layer_mapping, db, cancel_check):
    for logical_name, table_name in (
        ("lc_gen_destinacioneconomica_tipo", "destination_lookup"),
        ("lc_reco_unidadconstruccion_tipo", "unit_type_lookup"),
        ("lc_gen_asignacion_tipo", "assignment_lookup"),
        ("lc_gen_estadocontrol_tipo", "control_lookup"),
    ):
        _ingest_simple_lookup(
            data_source,
            layer_mapping,
            db,
            cancel_check,
            logical_name,
            table_name,
        )
    if definition.join_use_lookup:
        _ingest_simple_lookup(
            data_source,
            layer_mapping,
            db,
            cancel_check,
            "lc_gen_usouconstruccion_tipo",
            "use_lookup",
        )

    physical_name = layer_mapping.resolve("lc_gen_excepciones")
    with BatchInserter(
        db,
        "INSERT INTO exception_lookup(fk_token,fid,descripcion_excepcion) "
        "VALUES (?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(
            physical_name, ("fid", "fk_id", "id_regla", "descripcion_excepcion")
        ):
            raise_if_cancelled(cancel_check)
            if row.get("id_regla") == definition.canonical_id:
                inserter.add(
                    (
                        _join_token(row.get("fk_id")),
                        row.get("fid"),
                        row.get("descripcion_excepcion"),
                    )
                )

    physical_name = layer_mapping.resolve("lc_gen_predio_usuarioasignacion")
    with BatchInserter(
        db,
        "INSERT INTO user_assignment(fk_token,pk_id) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("pk_id", "fk_id")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("fk_id")), row.get("pk_id")))


def _prepare_selected(definition, db) -> None:
    db.execute("CREATE INDEX idx_predio_pk ON predio(pk_key)")
    db.execute("CREATE INDEX idx_construction_predio ON construction(predio_key)")
    sql = """
        INSERT INTO selected(
            predio_row_token,construction_row_token,pk_id,pk_key,
            numero_predial_nacional,proyecto,matricula_inmobiliaria,
            destinacion_economica,destination_key,area_catastral_terreno,
            juridico_assignment_key,
            juridico_control_key,reconocimiento_assignment_key,
            reconocimiento_control_key,informal_assignment_key,
            informal_control_key,geografico_assignment_key,
            geografico_control_key,pk_carac,identificador,total_plantas,
            type_key,use_key,uso_construccion,area_construida,puntaje)
        SELECT
            p.row_token,c.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,
            p.proyecto,p.matricula_inmobiliaria,p.destinacion_economica,
            p.destination_key,
            p.area_catastral_terreno,p.juridico_assignment_key,
            p.juridico_control_key,p.reconocimiento_assignment_key,
            p.reconocimiento_control_key,p.informal_assignment_key,
            p.informal_control_key,p.geografico_assignment_key,
            p.geografico_control_key,c.pk_carac,c.identificador,c.total_plantas,
            c.type_key,c.use_key,c.uso_construccion,c.area_construida,c.puntaje
        FROM predio p
        JOIN construction c ON c.predio_key = p.pk_key
        WHERE {predicate}
    """.format(predicate=definition.predicate_sql)
    db.execute(sql)


def _prepare_indexes(db) -> None:
    db.executescript(
        """
        CREATE INDEX idx_all_predio_key ON all_predio_key(pk_key);
        CREATE INDEX idx_selected_destination ON selected(destination_key);
        CREATE INDEX idx_selected_pk ON selected(pk_key);
        CREATE INDEX idx_destination_key ON destination_lookup(key_token);
        CREATE INDEX idx_unit_type_key ON unit_type_lookup(key_token);
        CREATE INDEX idx_use_key ON use_lookup(key_token);
        CREATE INDEX idx_exception_fk ON exception_lookup(fk_token);
        CREATE INDEX idx_user_assignment_fk ON user_assignment(fk_token);
        CREATE INDEX idx_assignment_key ON assignment_lookup(key_token);
        CREATE INDEX idx_control_key ON control_lookup(key_token);
        """
    )


def _result_sql(definition: ConstructionScalarRule) -> str:
    use_join = (
        "LEFT JOIN use_lookup use_lu ON use_lu.key_token = s.use_key"
        if definition.join_use_lookup
        else ""
    )
    if definition.use_output == "lookup":
        use_output = "use_lu.ilicode"
    elif definition.use_output == "raw":
        use_output = "s.uso_construccion"
    elif definition.use_output == "null":
        use_output = "NULL"
    else:
        raise ValueError(f"use_output invalido: {definition.use_output}")
    duplicate_join = (
        "LEFT JOIN all_predio_key duplicate_predio ON duplicate_predio.pk_key = s.pk_key"
        if definition.duplicate_predio_join
        else ""
    )
    duplicate_order = (
        ", duplicate_predio.row_token" if definition.duplicate_predio_join else ""
    )
    use_order = ", use_lu.row_token" if definition.join_use_lookup else ""
    return f"""
        SELECT
            s.pk_id,s.numero_predial_nacional,s.proyecto,s.matricula_inmobiliaria,
            destination.ilicode,s.area_catastral_terreno,s.pk_carac,s.identificador,
            s.total_plantas,unit_type.ilicode,{use_output},s.area_construida,s.puntaje,
            exception.fid,exception.descripcion_excepcion,jur_asig.ilicode,
            jur_ctrl.ilicode,reco_asig.ilicode,reco_ctrl.ilicode,info_asig.ilicode,
            info_ctrl.ilicode,geo_asig.ilicode,geo_ctrl.ilicode,user_assignment.pk_id
        FROM selected s
        {duplicate_join}
        LEFT JOIN destination_lookup destination
            ON destination.key_token = s.destination_key
        LEFT JOIN unit_type_lookup unit_type ON unit_type.key_token = s.type_key
        {use_join}
        LEFT JOIN exception_lookup exception ON exception.fk_token = s.pk_key
        LEFT JOIN user_assignment ON user_assignment.fk_token = s.pk_key
        LEFT JOIN assignment_lookup jur_asig
            ON jur_asig.key_token = s.juridico_assignment_key
        LEFT JOIN control_lookup jur_ctrl
            ON jur_ctrl.key_token = s.juridico_control_key
        LEFT JOIN assignment_lookup reco_asig
            ON reco_asig.key_token = s.reconocimiento_assignment_key
        LEFT JOIN control_lookup reco_ctrl
            ON reco_ctrl.key_token = s.reconocimiento_control_key
        LEFT JOIN assignment_lookup info_asig
            ON info_asig.key_token = s.informal_assignment_key
        LEFT JOIN control_lookup info_ctrl
            ON info_ctrl.key_token = s.informal_control_key
        LEFT JOIN assignment_lookup geo_asig
            ON geo_asig.key_token = s.geografico_assignment_key
        LEFT JOIN control_lookup geo_ctrl
            ON geo_ctrl.key_token = s.geografico_control_key
        ORDER BY
            s.numero_predial_nacional IS NULL,s.numero_predial_nacional,
            s.proyecto IS NULL,s.proyecto,s.identificador IS NULL,s.identificador,
            s.predio_row_token,s.construction_row_token{duplicate_order},
            destination.row_token,unit_type.row_token{use_order},exception.row_token,
            user_assignment.row_token,jur_asig.row_token,jur_ctrl.row_token,
            reco_asig.row_token,reco_ctrl.row_token,info_asig.row_token,
            info_ctrl.row_token,geo_asig.row_token,geo_ctrl.row_token
    """


def _result_row(definition, execution_timestamp, values) -> dict[str, Any]:
    (
        pk_id,
        numero_predial_nacional,
        proyecto,
        matricula_inmobiliaria,
        destino_economico,
        area_catastral_terreno,
        pk_carac,
        identificador,
        total_plantas,
        tipo_unidad,
        uso_construccion,
        area_construida,
        puntaje,
        exception_fid,
        descripcion_excepcion,
        jur_asig,
        jur_ctrl,
        reco_asig,
        reco_ctrl,
        info_asig,
        info_ctrl,
        geo_asig,
        geo_ctrl,
        assignment_pk,
    ) = values
    predio_is_primary = definition.table_error_1_source == "predio"
    return {
        "id_regla": definition.canonical_id,
        "componente": definition.component,
        "descripcion_regla": definition.description,
        "proyecto": proyecto,
        "pk_id_predio": pk_id,
        "tabla_error_1": definition.table_error_1,
        "pk_tabla_error_1": pk_id if predio_is_primary else pk_carac,
        "tabla_error_2": definition.table_error_2,
        "pk_tabla_error_2": pk_carac if definition.table_error_2 else None,
        "numero_predial_nacional": numero_predial_nacional,
        "matricula_inmobiliaria": matricula_inmobiliaria,
        "destino_economico": destino_economico,
        "area_catastral_terreno": area_catastral_terreno,
        "identificador_caracteristica_unidad_construccion": identificador,
        "total_plantas": total_plantas,
        "tipo_unidad_construccion": tipo_unidad,
        "uso_construccion": uso_construccion,
        "area_construida": area_construida,
        "puntaje_calificacion": puntaje,
        "tipo_novedad": None,
        "numero_predial_nacional_novedad": None,
        "tiene_excepcion": exception_fid is not None,
        "descripcion_excepcion": descripcion_excepcion,
        "juridico_estado_asignacion": jur_asig,
        "juridico_estado_control": jur_ctrl,
        "reconocimiento_estado_asignacion": reco_asig,
        "reconocimiento_estado_control": reco_ctrl,
        "informal_estado_asignacion": info_asig,
        "informal_estado_control": info_ctrl,
        "geografico_estado_asignacion": geo_asig,
        "geografico_estado_control": geo_ctrl,
        "pk_lc_gen_predio_usuarioasignacion": assignment_pk,
        "usuario_creacion": "admin",
        "fecha_creacion": execution_timestamp,
        "usuario_modificacion": "admin",
        "fecha_modificacion": execution_timestamp,
        "custom_1": None,
        "custom_2": None,
        "custom_3": None,
        "custom_4": None,
        "custom_5": None,
        "custom_6": None,
        "custom_7": definition.custom_7,
        "custom_8": None,
        "custom_9": None,
        "custom_10": None,
        "custom_11": None,
        "custom_12": None,
    }


def execute_construction_scalar(
    definition: ConstructionScalarRule,
    data_source,
    layer_mapping,
    cancel_check=None,
) -> Iterator[dict[str, Any]]:
    execution_timestamp = datetime.now()
    prefix = f"mapingtool-calidad-gpkg-{definition.canonical_id.lower()}-"
    with sqlite_staging(cancel_check, prefix=prefix) as db:
        _create_stage(db)
        _ingest_predios(definition, data_source, layer_mapping, db, cancel_check)
        _ingest_constructions(
            definition, data_source, layer_mapping, db, cancel_check
        )
        _ingest_enrichment(
            definition, data_source, layer_mapping, db, cancel_check
        )
        _prepare_selected(definition, db)
        _prepare_indexes(db)
        db.commit()
        raise_if_cancelled(cancel_check)
        cursor = db.execute(_result_sql(definition))
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                yield _result_row(definition, execution_timestamp, values)
        finally:
            cursor.close()
