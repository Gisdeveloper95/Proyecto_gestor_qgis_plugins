# Release Calidad GPKG 0.0.91

## Objetivo

Publicar los seis plugins padre y sus perfiles simplificados para QGIS 3.36 o
posterior sin modificar reglas, planes, filtros ni resultados.

## Compatibilidad

- Minimo declarado: QGIS `3.36.0`.
- Entorno comprobado: QGIS `3.36.0-Maidenhead`, Python `3.9.18` y PyQt5.
- El smoke real cubre carga de los paquetes, interfaz, ejecucion portable,
  filtros operativos, paginacion, exportaciones y perfiles multiples.
- La certificacion previa en QGIS 3.44 se conserva como validacion adicional.

## Alcance funcional

No cambia el catalogo de 253 reglas ni sus planes `generated_plan_v1`. El
parche ajusta metadatos, el catalogo XML, los perfiles simplificados y el smoke
multiversion para reflejar la compatibilidad demostrada.
