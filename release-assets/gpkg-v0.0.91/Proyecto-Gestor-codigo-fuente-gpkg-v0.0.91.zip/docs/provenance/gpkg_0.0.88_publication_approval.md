# Aprobación de publicación Calidad GPKG 0.0.88

Fecha: 2026-08-02

El propietario `Gisdeveloper95` entregó evidencia en video del defecto visual y
autorizó instalar las herramientas necesarias, corregirlo y publicar el hotfix.

El cambio autorizado se limita a declarar colores explícitos para los estados
normal, `hover` y seleccionado del selector de alcance de predios, además de su
prueba de regresión. Las SQL, planes, filtros operativos, geometrías y resultados
permanecen idénticos a la línea certificada.

No se autorizan datos reales, secretos, `keys.txt`, ArcPy ni activos
institucionales en los artefactos. No se autoriza avanzar a `0.1.0`.
