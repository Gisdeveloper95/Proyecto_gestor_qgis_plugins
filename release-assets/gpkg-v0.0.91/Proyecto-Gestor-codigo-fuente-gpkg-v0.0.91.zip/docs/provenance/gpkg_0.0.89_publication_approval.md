# Aprobación de publicación Calidad GPKG 0.0.89

Fecha: 2026-08-03

El propietario `Gisdeveloper95` autorizó expresamente que los plugins hijos
simplificados consulten el canal Vercel al abrirse, notifiquen releases nuevos,
recomienden el `plugins.xml` cuando falta en QGIS y traten los releases revocados
de manera segura.

La autorización también cubre preservar la solicitud de dispositivo después
del inicio de sesión y mantener un identificador estable entre un ZIP físico y
su posterior publicación desde QGIS.

El cambio no modifica SQL, planes de homologación, filtros, geometrías ni
resultados. No se incluyen secretos, datos reales, `keys.txt`, ArcPy ni activos
institucionales. No se autoriza avanzar a `0.1.0`.
