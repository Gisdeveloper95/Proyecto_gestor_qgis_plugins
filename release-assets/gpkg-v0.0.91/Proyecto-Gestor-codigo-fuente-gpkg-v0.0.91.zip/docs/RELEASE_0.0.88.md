# Calidad GPKG 0.0.88 — contraste real al pasar el cursor

Esta versión corrige el estado visual observado en QGIS al desplegar el selector
**Alcance de predios para esta ejecución**.

`0.0.87` fijó los colores generales y del elemento seleccionado, pero el tema
de QGIS conservaba una regla global para `item:hover`: texto blanco sobre fondo
blanco. `0.0.88` define de forma explícita los tres estados del popup:

- normal: texto oscuro sobre fondo blanco;
- cursor encima (`hover`): texto blanco sobre fondo verde;
- seleccionado: texto blanco sobre fondo verde.

No cambian las SQL, los planes `generated_plan_v1`, los filtros, la paridad ni
los resultados de las 253 reglas. `0.1.0` continúa bloqueado.
