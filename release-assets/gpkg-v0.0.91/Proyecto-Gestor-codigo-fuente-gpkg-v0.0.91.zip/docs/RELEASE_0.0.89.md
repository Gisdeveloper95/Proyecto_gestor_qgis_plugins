# Calidad GPKG 0.0.89 — actualizaciones seguras de perfiles simplificados

Esta versión incorpora comprobación no bloqueante de actualizaciones al abrir un
plugin hijo simplificado. El proceso tarda como máximo tres segundos, ocurre en
segundo plano y nunca impide usar el plugin cuando no hay Internet.

- Detecta releases nuevos desde el canal público de Mapper GIS Catastral.
- Advierte con prioridad cuando la versión instalada fue retirada.
- Nunca recomienda un release revocado.
- Si el perfil se instaló desde un ZIP local, conserva su identificador al
  publicarlo y puede convertirse en una instalación actualizable.
- Si falta el repositorio en QGIS, muestra y permite copiar el `plugins.xml`.
- Los ZIP creados solo localmente no se registran como releases.
- La autorización QGIS → Vercel conserva la solicitud después del login.

No cambian las 253 SQL, los planes `generated_plan_v1`, los filtros operativos
ni sus resultados. `0.1.0` continúa bloqueado.
