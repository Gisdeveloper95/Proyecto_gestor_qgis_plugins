"""Secure GitHub release channel for simplified QGIS profile plugins.

This module never stores credentials.  The QGIS UI supplies a token loaded from
QGIS Authentication Manager, and the token remains in memory only for the
duration of the publication.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from urllib import error, parse, request
from xml.etree import ElementTree as ET


API = "https://api.github.com"
CATALOG_ASSET = "catalog.json"
XML_ASSET = "plugins.xml"
ICON_ASSET = "profile_icon.svg"
REPOSITORY_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
QGIS_MINIMUM_VERSION = "3.36.0"


class ProfileRepositoryError(RuntimeError):
    pass


def _validate_repository(owner_repo: str) -> str:
    value = str(owner_repo or "").strip().strip("/")
    if not REPOSITORY_RE.fullmatch(value):
        raise ProfileRepositoryError(
            "El repositorio debe tener el formato propietario/repositorio."
        )
    return value


def _headers(token: str, *, accept: str = "application/vnd.github+json") -> dict:
    clean = str(token or "").strip()
    if not clean:
        raise ProfileRepositoryError("Falta la credencial GitHub.")
    return {
        "Authorization": "Bearer " + clean,
        "Accept": accept,
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "Mapper-GIS-QGIS-Profile-Publisher",
    }


def _request_bytes(
    method: str,
    url: str,
    token: str,
    data: bytes | None = None,
    content_type: str | None = None,
    accept: str = "application/vnd.github+json",
) -> bytes:
    headers = _headers(token, accept=accept)
    if content_type:
        headers["Content-Type"] = content_type
    call = request.Request(url, data=data, headers=headers, method=method)
    try:
        with request.urlopen(call, timeout=60) as response:
            return response.read()
    except error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:1000]
        raise ProfileRepositoryError(
            "GitHub respondió HTTP {0}: {1}".format(exc.code, detail)
        ) from exc
    except error.URLError as exc:
        raise ProfileRepositoryError(
            "No fue posible conectar con GitHub: {0}".format(exc.reason)
        ) from exc


def _request_json(
    method: str,
    url: str,
    token: str,
    payload: dict | None = None,
) -> dict:
    raw = _request_bytes(
        method,
        url,
        token,
        None if payload is None else json.dumps(payload).encode("utf-8"),
        "application/json" if payload is not None else None,
    )
    return json.loads(raw.decode("utf-8")) if raw else {}


def load_profile_catalog(owner_repo: str, token: str) -> dict:
    """Load the current public catalog, or return a clean first revision."""

    owner_repo = _validate_repository(owner_repo)
    try:
        repository = _request_json(
            "GET", "{0}/repos/{1}".format(API, owner_repo), token
        )
    except ProfileRepositoryError as exc:
        if "HTTP 404" not in str(exc):
            raise
        owner, repository_name = owner_repo.split("/", 1)
        account = _request_json("GET", API + "/user", token)
        if str(account.get("login") or "").casefold() != owner.casefold():
            raise ProfileRepositoryError(
                "El repositorio no existe y la credencial no pertenece a {0}.".format(
                    owner
                )
            ) from exc
        repository = _request_json(
            "POST",
            API + "/user/repos",
            token,
            {
                "name": repository_name,
                "description": (
                    "Canal público de perfiles QGIS simplificados de Mapper GIS Catastral"
                ),
                "private": False,
                "auto_init": True,
                "has_issues": False,
                "has_projects": False,
                "has_wiki": False,
            },
        )
    if repository.get("private") is True:
        raise ProfileRepositoryError(
            "El repositorio de perfiles debe ser público para que QGIS actualice."
        )
    try:
        latest = _request_json(
            "GET",
            "{0}/repos/{1}/releases/latest".format(API, owner_repo),
            token,
        )
    except ProfileRepositoryError as exc:
        if "HTTP 404" not in str(exc):
            raise
        return {
            "schema_version": 1,
            "release_sequence": 0,
            "repository": owner_repo,
            "profiles": {},
        }
    asset = next(
        (
            value
            for value in latest.get("assets", [])
            if value.get("name") == CATALOG_ASSET
        ),
        None,
    )
    if asset is None:
        raise ProfileRepositoryError(
            "La última release no contiene catalog.json; no se sobrescribirá."
        )
    raw = _request_bytes(
        "GET",
        str(asset["url"]),
        token,
        accept="application/octet-stream",
    )
    try:
        catalog = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProfileRepositoryError("catalog.json no es válido.") from exc
    if (
        catalog.get("schema_version") != 1
        or not isinstance(catalog.get("profiles"), dict)
        or catalog.get("repository") != owner_repo
    ):
        raise ProfileRepositoryError(
            "catalog.json no cumple el contrato de perfiles v1."
        )
    return catalog


def next_profile_version(catalog: dict, package_id: str) -> str:
    current = str(
        catalog.get("profiles", {}).get(package_id, {}).get("version")
        or "0.0.0"
    )
    match = re.fullmatch(r"0\.0\.(\d+)", current)
    if not match:
        raise ProfileRepositoryError(
            "La versión del perfil no pertenece a la serie 0.0.x."
        )
    return "0.0.{0}".format(int(match.group(1)) + 1)


def _plugin_id(package_id: str) -> str:
    digest = int(hashlib.sha256(package_id.encode("utf-8")).hexdigest()[:8], 16)
    return str(970000 + digest % 29999)


def _render_plugins_xml(catalog: dict) -> bytes:
    root = ET.Element("plugins", {"edition": "mapper-gis-perfiles-gpkg"})
    for package_id, profile in sorted(catalog["profiles"].items()):
        node = ET.SubElement(
            root,
            "pyqgis_plugin",
            {
                "name": str(profile["display_name"]),
                "version": str(profile["version"]),
                "plugin_id": str(profile.get("plugin_id") or _plugin_id(package_id)),
            },
        )
        description = (
            "Perfil simplificado Mapper GIS con {0} regla(s).".format(
                int(profile["rule_count"])
            )
        )
        values = (
            ("description", description),
            ("about", description),
            ("trusted", "False"),
            ("version", str(profile["version"])),
            ("qgis_minimum_version", QGIS_MINIMUM_VERSION),
            ("qgis_maximum_version", "3.99.0"),
            ("homepage", "https://github.com/" + catalog["repository"]),
            ("file_name", str(profile["file_name"])),
            ("icon", str(profile["icon_url"])),
            ("download_url", str(profile["download_url"])),
            ("author_name", "Gisdeveloper95"),
            ("create_date", str(profile["updated_at"])),
            ("update_date", str(profile["updated_at"])),
            ("experimental", "False"),
            ("deprecated", "False"),
            ("tags", "catastro,calidad,gpkg,perfil,mapper-gis,qgis"),
            ("server", "False"),
        )
        for key, value in values:
            ET.SubElement(node, key).text = value
    ET.indent(root, space="  ")
    return ET.tostring(root, encoding="utf-8", xml_declaration=True) + b"\n"


def _upload_asset(release: dict, name: str, content: bytes, token: str) -> None:
    upload_url = str(release["upload_url"]).split("{", 1)[0]
    media_type = (
        "application/zip"
        if name.endswith(".zip")
        else "application/xml"
        if name.endswith(".xml")
        else "image/svg+xml"
        if name.endswith(".svg")
        else "application/json"
    )
    _request_bytes(
        "POST",
        upload_url + "?" + parse.urlencode({"name": name}),
        token,
        content,
        media_type,
    )


def publish_profile_release(
    owner_repo: str,
    token: str,
    catalog: dict,
    zip_path: str | Path,
    profile: dict,
    icon_bytes: bytes,
) -> dict:
    owner_repo = _validate_repository(owner_repo)
    package_id = str(profile["package_id"])
    version = str(profile["child_version"])
    if version != next_profile_version(catalog, package_id):
        raise ProfileRepositoryError(
            "La versión del perfil cambió durante la publicación."
        )
    sequence = int(catalog.get("release_sequence", 0)) + 1
    tag = "profiles-v0.0.{0}".format(sequence)
    asset_name = "{0}.{1}.zip".format(package_id, version)
    release_url = "https://github.com/{0}/releases/download/{1}".format(
        owner_repo, tag
    )
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace(
        "+00:00", "Z"
    )
    zip_bytes = Path(zip_path).read_bytes()
    record = {
        "package_id": package_id,
        "plugin_id": _plugin_id(package_id),
        "display_name": str(profile["display_name"]),
        "version": version,
        "parent_plugin": str(profile["parent_plugin"]),
        "parent_version": str(profile["parent_version"]),
        "selection_mode": str(profile["selection_mode"]),
        "selected_families": list(profile.get("selected_families") or []),
        "rule_count": len(profile.get("rule_ids") or []),
        "sha256": hashlib.sha256(zip_bytes).hexdigest().upper(),
        "file_name": asset_name,
        "download_url": release_url + "/" + asset_name,
        "icon_url": release_url + "/" + ICON_ASSET,
        "updated_at": now,
    }
    next_catalog = json.loads(json.dumps(catalog))
    next_catalog["release_sequence"] = sequence
    next_catalog["repository"] = owner_repo
    next_catalog["updated_at"] = now
    next_catalog.setdefault("profiles", {})[package_id] = record
    catalog_bytes = (
        json.dumps(
            next_catalog,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
        + "\n"
    ).encode("utf-8")
    xml_bytes = _render_plugins_xml(next_catalog)
    release = _request_json(
        "POST",
        "{0}/repos/{1}/releases".format(API, owner_repo),
        token,
        {
            "tag_name": tag,
            "name": "Perfiles Mapper GIS 0.0.{0}".format(sequence),
            "body": (
                "Actualiza el perfil `{0}` a `{1}`. "
                "Los perfiles anteriores permanecen disponibles mediante "
                "sus URLs inmutables."
            ).format(package_id, version),
            "draft": True,
            "prerelease": False,
        },
    )
    try:
        _upload_asset(release, asset_name, zip_bytes, token)
        _upload_asset(release, XML_ASSET, xml_bytes, token)
        _upload_asset(release, CATALOG_ASSET, catalog_bytes, token)
        _upload_asset(release, ICON_ASSET, icon_bytes, token)
        release = _request_json(
            "PATCH",
            "{0}/repos/{1}/releases/{2}".format(
                API, owner_repo, release["id"]
            ),
            token,
            {"draft": False, "prerelease": False, "make_latest": "true"},
        )
    except BaseException as exc:
        raise ProfileRepositoryError(
            "La publicación quedó como borrador y no se anunció: {0}".format(exc)
        ) from exc
    return {
        "catalog": next_catalog,
        "release_url": str(release.get("html_url") or ""),
        "repository_xml": (
            "https://github.com/{0}/releases/latest/download/plugins.xml".format(
                owner_repo
            )
        ),
        "profile": record,
    }
