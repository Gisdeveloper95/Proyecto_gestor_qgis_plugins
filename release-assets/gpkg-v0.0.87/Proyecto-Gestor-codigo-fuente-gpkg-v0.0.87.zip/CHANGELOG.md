# Changelog

Todos los cambios notables del Proyecto Gestor se documentan en este archivo.
La presencia de una version aqui no equivale a publicacion ni sustituye los
gates de licencia, procedencia, metadatos publicos, firma y confianza externa.

## [0.0.86] - 2026-07-31

- Sustituye la publicación directa con token GitHub por el Centro de Perfiles
  autenticado de Mapper GIS.
- Permite crear un perfil estable o actualizar uno existente desde cualquier
  plugin padre; la identidad del plugin y su URL de QGIS no cambian entre
  revisiones.
- Turso registra configuraciones, revisiones, compilaciones y auditoría; un
  workflow confiable genera el ZIP y actualiza el catálogo público.
- Los coordinadores autorizan el equipo en el navegador una sola vez. La
  autorización se guarda cifrada en QGIS y ningún usuario recibe claves de
  GitHub, Turso o Vercel.
- Conserva la exportación ZIP local y separa completamente ese flujo del canal
  central actualizable.
- El constructor reproduce exactamente reglas, planes SQL y filtros elegidos,
  sin rutas locales, geometrías ni credenciales.

## [0.0.85] - 2026-07-31

- Sustituye el selector exclusivo `Todos/un grupo` por una selección múltiple
  persistente de Económico, Jurídico, PH, RECO y SIG.
- Mantiene bloqueadas las reglas de los perfiles simplificados; únicamente un
  hijo mixto permite elegir uno o varios de los grupos que ya contiene.
- Descubre los proyectos disponibles desde `lc_gen_predio.nombre_proyecto`,
  reconoce automáticamente el nombre de la carpeta/QGZ y exige una selección
  explícita cuando el paquete contiene varios proyectos.
- Aplica el proyecto elegido como alcance común a los resultados antes de
  mostrarlos o exportarlos, sin modificar el GeoPackage recibido.
- Conserva la exportación ZIP local y añade un canal independiente para
  publicar perfiles simplificados actualizables mediante `plugins.xml` y
  releases inmutables de GitHub.
- El token de publicación no se empaqueta ni se registra: puede almacenarse
  cifrado mediante el gestor de autenticación de QGIS.

## [0.0.84] - 2026-07-31

- Corrige una fuga real del filtro operativo: los hallazgos que sí pertenecen
  a `LC_Gen_Predio` ya no atraviesan el alcance solo porque
  `pk_id_predio` venga nulo.
- Recupera de forma segura el identificador desde `pk_tabla_error_1` o
  `pk_tabla_error_2` únicamente cuando la tabla declarada es
  `LC_Gen_Predio`. Los hallazgos geográficos genuinamente huérfanos continúan
  visibles porque no representan un predio al cual aplicar el alcance.
- Verifica sobre `actualizacion.gpkg` que `lc_gen_predio.condicion` coincide
  con el dígito 22 del NPN en los 1.065 predios del paquete analizado.
- Corrige el caso real `Jur_21`: sus 184 filas crudas tenían
  `pk_id_predio = NULL`; ahora ninguna condición 9 se filtra como NPH o
  Informalidad.
- Editar cualquier bloque NPH, Condominio, PH o Informalidad activa ese perfil
  para todas las reglas seleccionadas. Cambiar de grupo o marcar todas las
  reglas visibles ya no altera el alcance activo.
- El estado visual distingue claramente alcance automático (advertencia) y
  perfil forzado (confirmación).

## [0.0.83] - 2026-07-30

- Corrige el alcance de Informalidad al ejecutar grupos amplios como
  RECO/Calificación: el operador puede forzar un perfil de predios sobre todas
  las reglas seleccionadas, sin depender de la clasificación automática de
  nueve reglas informales.
- Conserva los filtros generales de cancelación y asignación junto con las
  condiciones configuradas de Informalidad; la condición 0 se admite
  únicamente cuando `informal_predio_para_visita` está activa.
- Verifica que todas las reglas RECO de Calificación exponen `pk_id_predio`
  para que el filtro no pueda omitirse silenciosamente.
- El plugin Total genera un único hijo `Mixto personalizado` con cualquier
  combinación marcada de Económico, Jurídico, PH, RECO y SIG. El hijo conserva
  reglas, familias, mapeo y política de filtros del padre.
- QGIS 3.44.11 verificó los filtros, repetición limpia, paginación,
  exportaciones y generación de perfiles individuales y mixtos.

## [0.0.82] - 2026-07-29

- Migra las 253 reglas GPKG al modo único `generated_plan_v1`, ejecutado por
  un runtime genérico SQLite/GEOS; los ZIP ya no contienen adaptadores Python
  por regla ni el registro Python legado.
- Corrige resolución de CTE sin distinguir mayúsculas, acceso directo de solo
  lectura al GeoPackage, geometrías GPKG, `ST_Area`, nulos, cancelación y
  materialización temporal de `determinacion_area_construccion`.
- Añade el contrato estructural de 152 tablas, la dependencia opcional
  `SIG_16`, 253 planes JSON con hashes y evidencia diferencial de tres semillas.
- Certifica el paquete real `pvall_044_nu`: 252 reglas aplicables ejecutadas,
  cero errores, `SIG_16` no aplicable y paridad con PostgreSQL/PostGIS y
  `0.0.81`; las salidas de área usan una tolerancia absoluta documentada de
  `0,02 m²`.
- Los seis plugins padre y todos los perfiles simplificados reutilizan el
  mismo runtime. Cada hijo incorpora únicamente su manifiesto y los planes de
  las reglas seleccionadas.
- QGIS 3.44.11 verificó instalación lógica, capas cargadas y GPKG directo,
  filtros, repetición limpia, paginación, mapa, formulario, excepciones,
  CSV/XLSX/GPKG y generación múltiple de perfiles.

## [0.0.74] - 2026-07-28

- Añade cuatro interruptores independientes para el alcance operativo RECO:
  predios cancelados, asignación de reconocimiento distinta de 2, condiciones
  2/5/8/9 y predios marcados para visita informal.
- Los cuatro filtros inician activos para conservar el comportamiento
  histórico, pero el usuario puede activar o desactivar cada uno desde la UI.
- La selección queda guardada por edición y familia, se congela durante la
  corrida y se registra de forma explícita en la consola.
- Si se desactivan los cuatro filtros, las reglas RECO conservan todas sus
  filas crudas y no construyen un alcance posterior.
- PostGIS y GPKG comparten el mismo contrato de selección sin modificar las
  253 reglas, sus adaptadores portables ni la evidencia de homologación.
- La edición GPKG reporta por regla filas crudas, conservadas y descartadas.
  La edición DBA equivalente se construye localmente como `0.0.10` y no se
  publica en el repositorio público GPKG.

## [0.0.73] - 2026-07-27

- Conserva íntegramente la corrección de Microsoft Excel, el paquete ZIP por
  regla y el CSV compatible incorporados en `0.0.72`.
- Corrige el pipeline de publicación: el checkpoint local `0.0.20` queda como
  evidencia histórica de esa versión y deja de aplicarse incorrectamente a
  releases posteriores.
- Mantiene los gates reproducibles, la aprobación versionada, los hashes y la
  certificación Windows/QGIS antes de publicar los seis plugins sincronizados.

## [0.0.72] - 2026-07-27

- El escritor OOXML ordena `sheetViews`, `sheetFormatPr`, `cols` y `sheetData`
  según el contrato estricto que exige Microsoft Excel. Excel ya no debe
  reparar el libro ni descartar sus registros al abrirlo.
- La exportación Excel entrega un ZIP con `Reporte_general.xlsx`, `LEEME.txt`
  y un libro `Reglas/<CODIGO>.xlsx` por cada regla ejecutada, incluso cuando
  una regla termina con cero hallazgos.
- El reporte general conserva Resumen, Detalle/Matriz, hojas individuales por
  regla y Consola. Todos los libros mantienen encabezados congelados,
  autofiltros, texto ajustado y anchos de columna más legibles.
- Excel y CSV usan la misma proyección dinámica de columnas, incluidas las
  columnas particulares declaradas por reglas GPKG.
- El CSV conserva UTF-8 con BOM, separador punto y coma, finales de línea CRLF,
  identificadores como texto y neutralización de fórmulas para apertura directa
  en Microsoft Excel.

## [0.0.71] - 2026-07-27

- Las seis ediciones GPKG detectan y remapean automáticamente las capas
  vectoriales que se añaden o retiran del proyecto QGIS; ya no es necesario
  cargar manualmente el archivo para que el plugin descubra el paquete.
- El mapeo reconoce el nombre visible y el nombre físico declarado por el
  proveedor/URI. Mantiene el bloqueo cuando dos capas compiten por la misma
  entidad lógica.
- `SIG_16` se declara opcional para paquetes de trabajo: si no se recibe
  `perimetro_urbano_20260702`, queda `not_applicable`, no cuenta como error y no
  genera una alerta roja. Si faltan otras dependencias requeridas, el preflight
  continúa fallando de forma segura.
- Los campos `Estado` y estado general son áreas de solo lectura con scroll.
  Los diálogos resumen mensajes muy extensos y conservan el detalle completo
  en Estado y Consola.
- El smoke offscreen QGIS 3.44.11 verificó las doce ediciones coexistentes, las
  253 reglas, GPKG directo, capas cargadas, proveedor memory y limpieza.

## [0.0.70] - 2026-07-23

- El lector directo reconoce las tablas relacionales ordinarias que los
  paquetes Mergin/CartoFlow almacenan fuera de `gpkg_contents`, sin modificar el
  GeoPackage entregado.
- `determinacion_area_construccion` se reconstruye en memoria cuando sus tablas
  fuente están presentes; la copia base interna de `.mergin` queda bloqueada.
- Cada paquete puede declarar sus reglas aplicables mediante
  `mapingtool_scope.json`; las demás quedan fuera del alcance y no se confunden
  con dependencias faltantes.
- En ausencia de alcance declarado se conserva la selección manual. Preflight y
  ejecución usan solo las reglas marcadas.
- QGIS 3.44.11 ejecutó el catálogo contra el paquete real `pvall_044_nu`: 252
  reglas listas, `SIG_16` como única dependencia faltante y cero errores de
  runtime. Este control técnico no obliga a ejecutar todo el catálogo.

## [0.0.69] - 2026-07-19

- Se restaura en las seis ediciones GPKG el armazón visual del plugin original:
  barra de acciones, reglas seleccionables, secciones plegables, resumen,
  detalle paginado, consola, mapa, formulario y exportaciones CSV/XLSX/GPKG.
- La única sustitución visible del flujo original es el panel de conexión:
  PostgreSQL/PostGIS se reemplaza por capas cargadas o un GeoPackage local con
  mapeo explícito de entidades.
- La UI compartida se extrae durante el build desde la plantilla original para
  impedir que las dos ediciones vuelvan a divergir silenciosamente.

## [0.0.68] - 2026-07-19

- Se corrige la visibilidad del repositorio QGIS: las seis ediciones GPKG son
  complementos estables y ahora declaran `experimental=False` tanto en
  `metadata.txt` como en `plugins.xml`.
- El gate de publicación falla si una edición vuelve a quedar oculta por la
  configuración predeterminada del administrador de complementos de QGIS.
- No cambian las 253 reglas ni sus resultados respecto de `0.0.67`.

## [0.0.67] - 2026-07-19

- Se completó la homologación portable de las 253 reglas: Jurídico 82, RECO 71,
  SIG 16, PH 77 y Económico 7.
- Las 253 reglas coincidieron con sus SQL canónicos sobre fixtures sintéticos
  en PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y GPKG físico.
- PH_76 compila sus 463 condiciones de nombres de entidades públicas a un AST
  portable versionado. Reco_56/57 consumen ese artefacto declarativo y ya no
  necesitan ni distribuyen SQL canónico.
- QGIS 3.44.11 cargó conjuntamente las doce ediciones y reconoció los conteos
  253/82/71/16/77/7 en Total y familias.
- Los seis ZIP Calidad GPKG `0.0.67` son reproducibles byte a byte, incluyen
  licencia `GPL-2.0-or-later` y se publicaron en el tag `gpkg-v0.0.67` junto con
  XML estable, hashes SHA-256, firma RSA-3072 y clave pública. No se instaló
  ningún perfil QGIS.

## [0.0.20] - 2026-07-19

- Lote portable de ocho reglas RECO relacionadas con contactos y fotos:
  `Reco_11–15`, `Reco_17`, `Reco_21` y `Reco_69`.
- La cobertura GPKG pasa de 52 a 60 reglas: Jurídico 13, RECO 43, SIG 4;
  PH y Económico permanecen en cero explícito.
- Un pipeline SQLite temporal acotado implementa joins internos, anti-joins,
  filtros de filas relacionadas y la multiplicidad duplicada de `Reco_21`.
- Las 60 reglas coincidieron con PostgreSQL 18.4/PostGIS 3.6.2,
  `MappingDataSource` y GPKG físico. QGIS 3.44.11 aprobó archivo directo,
  capas OGR y proveedor `memory` para las doce ediciones.
- Los seis ZIP GPKG `0.0.20` son reproducibles. No hubo instalación, tag, push,
  release, publicación ni despliegue.

## [0.0.19] - 2026-07-19

- Segundo lote escalar de construcción RECO: `Reco_10`, `Reco_20`, `Reco_23`
  y `Reco_25`.
- La cobertura GPKG pasa de 48 a 52 reglas: Jurídico 13, RECO 35, SIG 4;
  PH y Económico permanecen explícitamente en cero.
- Se preserva el comportamiento publicado de `Reco_10`, que proyecta el
  catálogo de uso tanto en `tipo_unidad_construccion` como en
  `uso_construccion`, y los campos deliberadamente nulos de `Reco_20`.
- El fixture prueba la expresión regular ASCII de `Reco_23` y la multiplicidad
  `2×2` causada por su join final redundante a predio.
- Las 52 reglas coincidieron con PostgreSQL 18.4/PostGIS 3.6.2,
  `MappingDataSource` y GPKG físico sintético. QGIS 3.44.11 repitió los tres
  modos de entrada en las doce ediciones.
- Los seis ZIP GPKG `0.0.19` son reproducibles. No hubo instalación, tag, push,
  release, publicación ni despliegue.

## [0.0.18] - 2026-07-19

- Lote portable de 16 reglas RECO sobre
  `general.determinacion_area_construccion`: `Reco_29–37`, `Reco_40`,
  `Reco_45`, `Reco_54`, `Reco_55`, `Reco_64`, `Reco_66` y `Reco_67`.
- La cobertura GPKG pasa de 32 a 48 reglas: Jurídico 13, RECO 31, SIG 4;
  PH y Económico siguen explícitamente en cero.
- Un pipeline SQLite temporal y acotado conserva joins tipados, multiplicidad,
  catálogos de unidad/uso, excepciones, asignaciones, nulos y los joins
  redundantes presentes en `Reco_30` y `Reco_45`.
- El arnés de equivalencia admite ahora tablas de fixture ubicadas en el esquema
  PostgreSQL `general`, sin cambiar los nombres lógicos usados por GPKG.
- Las 48 reglas coincidieron con PostgreSQL 18.4/PostGIS 3.6.2,
  `MappingDataSource` y GPKG físico sintético. QGIS 3.44.11 repitió GPKG
  directo, capas OGR y proveedor `memory` en las doce ediciones.
- Los seis ZIP GPKG `0.0.18` son reproducibles y los seis ZIP DBA conservan sus
  hashes. No hubo instalación, tag, push, release, publicación ni despliegue.

## [0.0.17] - 2026-07-19

- Lote portable RECO: `Reco_03`, `Reco_04`, `Reco_05`, `Reco_16`, `Reco_18`
  y `Reco_48`.
- La cobertura GPKG pasa de 26 a 32 reglas: Jurídico 13, RECO 15, SIG 4;
  PH y Económico permanecen explícitamente en cero.
- PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y GPKG físico coincidieron
  en las 32 reglas sobre fixtures sintéticos. QGIS 3.44.11 verificó GPKG
  directo, capas OGR cargadas y proveedor `memory` en las doce ediciones.
- `Reco_16` deja visible una contradicción canónica: su consulta cruda exige
  estado de asignación distinto de 2, mientras el filtro global RECO conserva
  únicamente estado 2; por eso produce 1 hallazgo crudo y 0 operativos en el
  fixture. No se alteró ni se ocultó ese comportamiento.
- Se corrigió el verificador de timestamps para aceptar correctamente el caso
  matemáticamente vacío (cero filas operativas) y se añadió selección
  diagnóstica por regla sin reducir el gate oficial de suite completa.
- El empaquetador DBA ahora excluye por patrón cualquier módulo `portable*`,
  evitando que futuras homologaciones GPKG se filtren en los ZIP PostGIS.
- Se detectó que el SQL canónico `Jur_10.sql` devuelve y consulta excepciones
  con `Jur_06`; quedó aislado como defecto de catálogo y no fue homologado bajo
  una identidad falsa.
- Los seis ZIP GPKG `0.0.17` son reproducibles. No hubo instalación, tag, push,
  release, publicación ni despliegue.

## [0.0.16] - 2026-07-19

- Segundo lote portable de predio: `Jur_01`, `Jur_04`, `Jur_07–09`, `Jur_16`,
  `Reco_52`, `Reco_53`, `Reco_58` y `Reco_60–63`.
- La cobertura GPKG pasa de 13 a 26 reglas: Jurídico 13, RECO 9, SIG 4 y
  PH/Económico continúan explícitamente en cero.
- La API normal del backend aplica obligatoriamente `reco_post_filter` a las
  nueve reglas RECO. La ejecución cruda queda expuesta solo mediante
  `execute_raw()` para el arnés de equivalencia; el worker comparte y persiste
  el alcance una sola vez por lote.
- Las 13 reglas nuevas coincidieron con el SQL canónico en PostgreSQL
  18.4/PostGIS 3.6.2, `MappingDataSource` y GPKG físico. `Reco_60` fija el caso
  visible 3 crudas → 2 operativas; las demás conservan sus propios predicados.
- QGIS 3.44.11 verificó las 26 reglas con GPKG directo, capas OGR cargadas y
  proveedor `memory`, además de las doce ediciones coexistentes y su limpieza.
- Se congelaron portal web y aplicación desktop. GPKG directo queda como motor
  portable primario; SpatiaLite se evaluará como acelerador espacial y PostGIS
  temporal solo como fallback opcional controlado.
- Los seis ZIP `0.0.16` son reproducibles y el checkpoint local v3 fija hashes,
  cobertura, evidencia y la decisión de alcance. No hubo instalación, tag,
  push, release ni despliegue.

## [0.0.15] - 2026-07-19

- Primer slice portable RECO: `Reco_50` y `Reco_51`, sin distribuir ni ejecutar
  SQL PostgreSQL dentro de los ZIP Calidad GPKG.
- Total GPKG pasa de 11 a 13 reglas y RECO GPKG de 0 a 2. Jurídico conserva 7,
  SIG conserva 4 y PH/Económico permanecen explícitamente en cero.
- Se separó la consulta cruda de cada regla del filtro operativo compartido
  `reco_post_filter`: el alcance se calcula como un conjunto normalizado y
  distinto de `pk_id`, y luego se filtran los hallazgos sin perder duplicados.
- Sobre el mismo fixture sintético, PostgreSQL 18.4/PostGIS 3.6.2,
  `MappingDataSource` y un GPKG físico coincidieron en consulta cruda, alcance
  y resultado final: `Reco_50` 9→5, `Reco_51` 7→3 y alcance común de 8 predios.
- El postfiltro se carga una sola vez por worker, se almacena en SQLite temporal
  con memoria acotada, responde a cancelación y queda protegido por hashes de
  implementación, SQL canónico normalizado y bundle de ejecución.
- QGIS 3.44.11 verificó las doce ediciones coexistentes, ejecución directa
  sobre GPKG, capas OGR cargadas y proveedor `memory`; Total y RECO muestran los
  conteos finales 5/3, no los conteos crudos 9/7.
- Los seis ZIP DBA `0.0.9` conservan exactamente sus hashes certificados. Los
  seis ZIP Calidad GPKG `0.0.15` se reconstruyeron de forma reproducible y el
  checkpoint local fija nombres, tamaños, hashes y las 13 evidencias.

Estado de publicación: no publicable. No existe tag, push, release,
instalación en perfiles de usuario ni despliegue; permanecen exactamente nueve
bloqueos externos de licencia, metadata y aprobación.

## [0.0.14] - 2026-07-19

- Primer slice portable Jurídico: `Jur_05`, `Jur_12`, `Jur_13`, `Jur_14`,
  `Jur_15`, `Jur_17` y `Jur_18` sobre un motor declarativo común de predio.
- Total GPKG pasa de 4 a 11 reglas y Jurídico GPKG de 0 a 7; SIG conserva sus
  cuatro reglas y RECO, PH y Económico permanecen explícitamente en cero.
- Cada regla conserva un wrapper ejecutable e integrity-pinned independiente;
  añadir otra configuración no cambia los bytes ni la evidencia histórica de
  las siete actuales. El staging y las primitivas compartidas también quedan
  fijados dentro del bundle de cada regla.
- PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y un GPKG físico entregaron
  los mismos multiconjuntos con multiplicidad. Los fixtures esperados contienen
  `4/2/2/1/2/5/9` filas respectivamente.
- El backend resuelve IDs sin distinguir mayúsculas, pero conserva la grafía
  canónica `Jur_XX` y rechaza colisiones ambiguas.
- Los seis ZIP DBA `0.0.9` conservan exactamente sus hashes certificados; el
  código Jurídico portable queda excluido de esa edición.

Estado de publicación: no publicable. No existe tag, push, release,
instalación en perfiles de usuario ni despliegue; permanecen los nueve bloqueos
externos de licencia, metadata y aprobación.

## [0.0.13] - 2026-07-19

- Cuarta implementación portable independiente: `SIG_01`, con selección del
  proveedor formal/informal por el carácter 22, semántica NULL, predios
  activos, `UNION DISTINCT`, excepciones y multiplicidad de catálogos.
- Total GPKG y SIG GPKG pasan a cuatro reglas (`SIG_01`, `SIG_02`, `SIG_09`,
  `SIG_10`). Cobertura portable total: 4/253; las otras cuatro familias siguen
  explícitamente en cero.
- PostgreSQL 18.4/PostGIS 3.6.2, el proveedor en memoria y un GPKG físico
  sintético produjeron 18/18 filas y el mismo multiconjunto en 46 columnas
  estables. Solo se excluyó el
  valor exacto de los dos timestamps `now()`; su presencia y constancia también
  quedaron verificadas.
- Una observación adicional con ocho tablas de la restauración local produjo
  9.528/9.528 filas equivalentes; el GPKG temporal fue eliminado y no se añadió
  a Git ni a los fixtures.
- Nuevo contrato de integridad para implementación y archivos auxiliares:
  hashes individuales, bundle agregado, importación diferida y verificación
  tanto en fuente como dentro de cada ZIP.
- El staging común conserva caché SQLite de 4 MiB, lotes de 256, cancelación y
  limpieza. La prueba consumió 20.000 hallazgos desde el cursor, permaneció por
  debajo de 24 MiB de heap Python y canceló durante staging y salida.
- El escritor de evidencia puede seleccionar una regla nueva y se niega a
  sobrescribir artefactos históricos divergentes.
- QGIS 3.44.11 validó los doce plugins coexistentes, GPKG directo, capas
  cargadas y un proveedor `memory`; también verificó el cableado del botón
  Cancelar. Los seis ZIP DBA `0.0.9` conservaron sus hashes anteriores.
- La tabla y el CSV agregan todas las columnas canónicas declaradas sin romper
  la proyección heredada. CI verifica evidencia inmutable, build doble
  reproducible y que el checkpoint coincida con los doce ZIP.
- Las ediciones fragmentadas sin cobertura todavía declarada ya no transportan
  implementaciones SIG inutilizadas; solo Total y SIG contienen esas reglas.

Estado de publicación: no publicable. No existe tag, push, release, instalación
en perfiles de usuario ni despliegue; permanecen exactamente nueve bloqueos
externos de licencia, metadata y aprobación.

## [0.0.12] - 2026-07-18

- Tercera implementacion portable independiente: `SIG_10`, sin traducir ni
  distribuir el SQL PostgreSQL dentro de los ZIP Calidad GPKG.
- Total GPKG y SIG GPKG pasan a tres reglas reales (`SIG_02`, `SIG_09`,
  `SIG_10`); RECO, PH, Juridico y Economico permanecen explicitamente en cero.
  Cobertura portable total: 3/253.
- `SIG_10` consume seis capas declaradas y reproduce novedades PH 5-8,
  predios activos, unidades con codigo PH, `NULL`, `UNION DISTINCT`, los dos
  anti-joins, multiplicidad formal/informal y supresion por cambio fisico.
- El fixture sintetico fue ampliado con novedades 5, 6, 7 y 8, novedad nula y
  duplicada, campos ocultos diferentes que conservan filas finales repetidas,
  duplicados con campos ocultos nulos y casos cancelado/sin caracteristica.
- PostgreSQL 18.4/PostGIS 3.6.2 y el backend GPKG entregaron 14/14 filas y el
  mismo multiconjunto normalizado. El orden queda solo como diagnostico porque
  el SQL canonico no define un desempate total y cada motor usa su collation.
- `SIG_10` usa staging SQLite en disco, cache de 4 MiB, lotes de 256, cursor,
  cancelacion y limpieza verificadas; identidades PH no trasladables de forma
  determinista se rechazan en vez de inventar un desempate.
- Los seis ZIP GPKG se construyen juntos como `0.0.12`. Los seis DBA/PostGIS
  permanecen funcionalmente intactos en `0.0.9` y excluyen los modulos
  portables.

Estado de publicacion: no publicable. No existe tag, push, release ni
instalacion en perfiles de usuario; los nueve gates juridicos y de aprobacion
permanecen cerrados.

## [0.0.11] - 2026-07-18

- Segunda implementacion portable independiente: `SIG_09`, sin geometria,
  PostGIS, QPSQL, autenticacion ni SQL canonico dentro de los ZIP Calidad GPKG.
- Total GPKG y SIG GPKG pasan de 1 a 2 reglas reales (`SIG_02`, `SIG_09`);
  RECO, PH, Juridico y Economico permanecen explicitamente en cero y devuelven
  `backend_unsupported` para lo no portado. Cobertura total: 2/253.
- `SIG_09` reproduce el filtro de posicion 22, predio activo, joins por codigo
  e identificador, `NULL`, `UNION DISTINCT`, supresion por cambio fisico y
  multiplicidad formal/informal. Rechaza `fid` nulo y claves de predio cuyo
  `DISTINCT ON` canonico seria ambiguo.
- Cada implementacion portable vive ahora en un archivo propio fijado por
  SHA-256. Agregar una regla nueva ya no invalida silenciosamente el hash ni la
  evidencia de una regla anterior; el runtime contrasta simbolo, modulo,
  archivo y contenido antes de ejecutar.
- Fixtures GeoPackage declarativos, staging SQLite en disco con cache de 4 MiB,
  lotes de 256, cursores, cancelacion y pruebas de memoria acotada para ambas
  reglas.
- Harness y gates de equivalencia generalizados por regla. PostgreSQL
  18.4/PostGIS 3.6.2 y el backend portable deben entregar el mismo
  multiconjunto normalizado sobre cada fixture sintetico autorizado.
- Los seis ZIP GPKG se construyen juntos como `0.0.11`; los seis DBA/PostGIS
  permanecen sin cambios funcionales en `0.0.9` y excluyen todo modulo
  portable.

Estado de publicacion: no publicable. No existe tag, push, release ni
instalacion en perfiles de usuario; continúan cerrados los gates juridicos,
procedencia, metadata, aprobacion y licencia first-party.

## [0.0.10] - 2026-07-18

- Contratos `DataSource`, `LayerMapping`, `RuleBackend` y `BackendPreflight`
  para fuentes vectoriales portables, sin traducir automaticamente el SQL
  PostgreSQL canonico.
- Doce paquetes coexistentes: los seis DBA/PostGIS permanecen en `0.0.9` y los
  seis nuevos Calidad GPKG nacen en `0.0.10`, con IDs, nombres, ZIP,
  preferencias, menus, toolbars, temporales, manifiestos y gates separados.
- Los paquetes DBA no reciben selector GPKG ni cambios funcionales. Los GPKG no
  contienen QPSQL, autenticacion, credenciales ni ninguno de los 253 SQL
  canonicos. El mapeo portable conserva el `layerId` de QGIS o nombre de tabla.
- Snapshot GPKG temporal por corrida. El lector SQLite abre `mode=ro`, solicita
  solo columnas declaradas y no lee blobs geometricos. La procedencia registra
  proveedor, capa, CRS, campos, conteo y hash de la URI, nunca la URI o claves.
  Backup, captura y hash muestran progreso/cancelacion; el worker revalida el
  SHA-256 antes de abrir el snapshot.
- Primera implementacion real: `SIG_02`, una regla referencial de atributos. Se
  preservan `NULL`, booleanos, `UNION` distinct y la cardinalidad del `LEFT
  JOIN`, incluso cuando `lc_gen_predio.pk_id` es nulo.
  Su estado intermedio usa SQLite temporal en disco, cache de 4 MiB y lotes de
  256; el cursor no materializa predios, terrenos o hallazgos completos en RAM.
- Total GPKG y SIG GPKG ejecutan `SIG_02`. Eco, Juridico, PH y RECO GPKG cargan
  con cero reglas portadas y estado `backend_unsupported`, nunca un falso OK.
  Capas, campos o tipos incompatibles producen `dependency_missing`; un hash
  de implementacion alterado produce `backend_integrity_error` y un snapshot
  alterado bloquea la corrida antes de abrirlo.
- Fixture vectorial GPKG completamente sintetico y pruebas puras, de paquete y
  QGIS offscreen. DuckDB Spatial no se instala ni descarga en tiempo de uso.
- Evidencia cruzada `passed_synthetic_fixture_v1` para `SIG_02`: el SQL
  canonico ejecutado en PostgreSQL 18.4/PostGIS 3.6.2 y la implementacion
  portable entregan seis filas y el mismo multiconjunto de 33 columnas
  normalizadas. El gate fija fixture, SQL, normalizador, implementacion y
  evidencia por SHA-256, y CI repite la prueba en una base PostGIS desechable.
- Workflows separados por `dba-v*` y `gpkg-v*`; un tag de Calidad GPKG no
  dispara el release DBA.

Estado de publicacion: no publicable. La evidencia sintetica de una regla no
resuelve licencia, procedencia, aprobaciones ni las otras 252 implementaciones;
no existe tag, push, release ni instalacion en un perfil QGIS de usuario.

## [0.0.9] - 2026-07-17

- Ejecucion QtSql `forward-only` consumida como cursor, sin lista Python con la
  totalidad de hallazgos.
- Almacen temporal SQLite local en modo WAL, transacciones atomicas por regla y
  buffers acotados a 256 filas.
- Filtro RECO posterior conservado exactamente, con sus IDs permitidos en disco
  y sin un `set` proporcional al universo.
- Tabla y ventana de detalle paginadas en bloques de 250, con filtro por regla y
  busqueda ejecutados contra SQLite.
- CSV y XLSX incrementales; GPKG y cache cartografica escritos por paginas. XLSX
  registra filas realmente escritas por regla y por hoja/split, y contrasta ese
  manifiesto con SQLite antes del reemplazo. Las capas del mapa usan el GPKG
  temporal mediante OGR.
- Deteccion del error QtSql posterior a `next()`, con rollback de cualquier fila
  parcial; cancelacion y error de driver permanecen estados distintos.
- Reemplazo atomico de CSV/XLSX/GPKG, verificacion de conteos GPKG y cleanup
  diferido/reintentable para archivos SQLite/GPKG bloqueados en Windows.
- Mapa y exportaciones deshabilitados durante el worker. La geometria sigue
  limitada a `lc_gen_predio`; la fuente exacta por regla SIG queda pendiente.
- El refresco de detalle se difiere hasta `finished_all`: resumen y progreso se
  mantienen vivos sin competir con la conexion SQLite escritora. Filtros y
  ventana de detalle tampoco leen el store durante la corrida.
- Pruebas deterministas de cota de buffer, crecimiento de heap, paginacion,
  rollback por cancelacion, RECO, XLSX incremental, rechazo de iteradores
  truncados y sincronizacion de los seis paquetes.
- Corrida real QGIS/PostGIS con cinco familias, `5.489` hallazgos, mapa,
  formulario y tres exportaciones; cancelacion real confirmada en `172 ms`.
- Contrato futuro para GPKG y otras capas abiertas documentado, sin ampliar el
  alcance exclusivamente PostGIS de esta version.

Estado de publicacion: no publicable. Continuan abiertos los gates de licencia,
procedencia, identidades, equivalencia RECO y autoridad externa. No existe tag
ni release de `0.0.9`.

## [0.0.8] - 2026-07-17

- Objetivo QGIS 3.44 LTR, PostgreSQL 18 y puerto estandar 5432.
- Credenciales resueltas mediante `authcfg`; no hay claves predeterminadas.
- Seis paquetes sincronizados y construccion ZIP/XML determinista.
- Validacion exhaustiva del contenido de cada ZIP y de cada byte de
  `plugins.xml` contra el arbol revisado.
- Bundle de release separado con SBOM SPDX JSON, checksums, manifiesto y firma
  detached RSA-SHA256 anclada por un SHA-256 externo.
- `SIG_16` permanece visible como dependencia faltante cuando no existe el
  perimetro urbano real.

Estado de publicacion: retirado permanentemente. `0.0.8` conserva diferencias
RECO y contratos abiertos; no se creara su tag aunque aparezcan posteriormente
licencia, aprobaciones, endpoints, claves o trust anchor.
