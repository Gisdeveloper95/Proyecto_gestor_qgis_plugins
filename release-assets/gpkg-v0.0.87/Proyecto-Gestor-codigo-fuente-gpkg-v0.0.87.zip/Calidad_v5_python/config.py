"""
Archivo de configuración para credenciales de base de datos y queries por ciudad.
"""

import queries_valledupar

CONFIGURACION = {
    'valledupar': {
        'db': {
            'dbname': 'cartoflow',
            'user': 'XXXXXXX',
            'password': 'XXXXXXXXXX',
            'host': '100.87.33.25',
            'port': '5432'
        },
        'queries_module': queries_valledupar,
        'nombre_ciudad': 'Valledupar'
    },
}
