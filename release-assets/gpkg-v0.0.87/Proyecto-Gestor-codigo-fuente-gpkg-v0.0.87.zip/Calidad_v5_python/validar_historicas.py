import sys

import psycopg2

from config import CONFIGURACION


REGLAS_GEOGRAFICAS = {"SIG_02", "SIG_09", "SIG_10"}

TABLAS_DESTINO = {
    "alfanumericas": ("general", "lc_gen_inconsistencias_alfanumericas_historicas"),
    "geograficas": ("general", "lc_gen_inconsistencias_geograficas_historicas"),
}


def get_city_config():
    if len(sys.argv) < 2:
        print("Error: Debe proporcionar la ciudad como parametro")
        print("Uso: python validar_historicas.py [valledupar]")
        print(f"Ciudades disponibles: {', '.join(CONFIGURACION.keys())}")
        sys.exit(1)

    ciudad = sys.argv[1].lower()
    if ciudad not in CONFIGURACION:
        print(f"Error: Ciudad '{ciudad}' no encontrada en la configuracion")
        print(f"Ciudades disponibles: {', '.join(CONFIGURACION.keys())}")
        sys.exit(1)

    return ciudad, CONFIGURACION[ciudad]


def load_table_metadata(cur, schema_name, table_name):
    cur.execute(
        """
        select
            column_name,
            is_nullable = 'YES' as is_nullable,
            column_default is not null as has_default
        from information_schema.columns
        where table_schema = %s
          and table_name = %s
        order by ordinal_position
        """,
        (schema_name, table_name),
    )
    rows = cur.fetchall()
    if not rows:
        raise RuntimeError(
            f"No se encontraron columnas para {schema_name}.{table_name}. "
            "Verifica si la tabla existe en esa base, si el esquema es correcto "
            "o si el usuario tiene permisos para verla en information_schema."
        )
    columns = [row[0] for row in rows]
    required = [row[0] for row in rows if not row[1] and not row[2]]
    return columns, required


def get_query_columns(cur, sql_text):
    wrapped_sql = sql_text.strip().rstrip(";")
    cur.execute(f"select * from ({wrapped_sql}) as q limit 0")
    return [desc[0] for desc in cur.description]


def validate_rule(rule_name, query_sql, table_columns, required_columns, cur):
    result_columns = get_query_columns(cur, query_sql)
    result_map = {col.lower(): col for col in result_columns}
    table_map = {col.lower(): col for col in table_columns}
    result_set = set(result_map)
    table_set = set(table_map)

    extra_in_query = [col for col in result_columns if col.lower() not in table_set]
    missing_required = [col for col in required_columns if col.lower() not in result_set]

    return {
        "rule": rule_name,
        "result_columns": result_columns,
        "extra_in_query": extra_in_query,
        "missing_required": missing_required,
        "is_valid": not extra_in_query and not missing_required,
    }


def main():
    ciudad, config = get_city_config()
    conn = psycopg2.connect(**config["db"])
    cur = conn.cursor()

    try:
        table_metadata = {}
        for key, (schema_name, table_name) in TABLAS_DESTINO.items():
            table_metadata[key] = load_table_metadata(cur, schema_name, table_name)

        print(f"Validando tablas historicas para: {ciudad}")
        print("===================================")

        issues = []
        queries = config["queries_module"].get_all()

        for rule_name, query_sql in queries.items():
            target_key = "geograficas" if rule_name in REGLAS_GEOGRAFICAS else "alfanumericas"
            table_columns, required_columns = table_metadata[target_key]
            result = validate_rule(rule_name, query_sql, table_columns, required_columns, cur)

            if result["is_valid"]:
                print(f"{rule_name}: OK -> {target_key}")
                continue

            issues.append((target_key, result))
            print(f"{rule_name}: ERROR -> {target_key}")
            if result["extra_in_query"]:
                print(f"  Columnas en query que no existen en historica: {', '.join(result['extra_in_query'])}")
            if result["missing_required"]:
                print(f"  Columnas obligatorias de historica que no salen en query: {', '.join(result['missing_required'])}")

        print("===================================")
        print(f"Total reglas revisadas: {len(queries)}")
        print(f"Total reglas con problemas: {len(issues)}")

        if issues:
            sys.exit(2)

    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    main()
