# Standard library imports
import os
import sys
from datetime import datetime

# Third-party imports
import psycopg2
from rich.console import Console
from rich.text import Text

# Local imports
import tools
from config import CONFIGURACION

# Validar que se proporcionó el parámetro de ciudad
if len(sys.argv) < 2:
    print("Error: Debe proporcionar la ciudad como parámetro")
    print("Uso: python main_db.py [valledupar]")
    print(f"Ciudades disponibles: {', '.join(CONFIGURACION.keys())}")
    sys.exit(1)

ciudad = sys.argv[1].lower()

# Validar que la ciudad existe en la configuración
if ciudad not in CONFIGURACION:
    print(f"Error: Ciudad '{ciudad}' no encontrada en la configuración")
    print(f"Ciudades disponibles: {', '.join(CONFIGURACION.keys())}")
    sys.exit(1)

# Obtener configuración de la ciudad
config = CONFIGURACION[ciudad]
db_config = config['db']
queries_module = config['queries_module']
nombre_ciudad = config['nombre_ciudad']

# Definir las reglas que van a la tabla geográfica
REGLAS_GEOGRAFICAS = {'SIG_02', 'SIG_09', 'SIG_10'}

# Conectar a la base de datos usando la configuración de la ciudad
conn = psycopg2.connect(**db_config)
cur = conn.cursor()

# Imprimiendo encabezados de las columnas
print(f"GeoKAS Calidad - Version 2 (Guardado en Base de Datos) - {nombre_ciudad}")

# Creando carpeta de resultados
folder_name = "Resultados/" + datetime.now().strftime("%y_%m_%d-%H_%M_%S")
os.makedirs(folder_name, exist_ok=True)

print(f"Resultados se guardarán en: {folder_name}")
print("===================================")

# Contadores para reportes
total_alfanumericas = 0
total_geograficas = 0

for query in queries_module.get_all():

    print(f"Regla Calidad: {query}")

    cur.execute(queries_module.get_all()[query])
    rows = cur.fetchall()

    # Obtener los nombres de las columnas
    column_names = [desc[0] for desc in cur.description]

    if rows:
        # Guardar en Excel solo si hay registros
        csv_path = os.path.join(folder_name, f"{query}.xlsx")
        tools.save_to_excel(rows, csv_path, column_names)
        # Determinar en qué tabla guardar según la regla
        if query in REGLAS_GEOGRAFICAS:
            # Guardar en tabla geográfica
            try:
                inserted_count = tools.save_to_db_geograficas(conn, rows, column_names)
                total_geograficas += inserted_count
                print(f"  ✓ {len(rows)} registros encontrados")
                print(f"    → Guardados en BD (geograficas): {inserted_count}")
                print(f"    → Guardados en Excel: {query}.xlsx")
            except Exception as e:
                print(f"  ✗ Error al guardar en BD (geograficas): {e}")
                print(f"    → Solo guardado en Excel: {query}.xlsx")
        else:
            # Guardar en tabla alfanumérica
            try:
                inserted_count = tools.save_to_db_alfanumericas(conn, rows, column_names)
                total_alfanumericas += inserted_count
                print(f"  ✓ {len(rows)} registros encontrados")
                print(f"    → Guardados en BD (alfanumericas): {inserted_count}")
                print(f"    → Guardados en Excel: {query}.xlsx")
            except Exception as e:
                print(f"  ✗ Error al guardar en BD (alfanumericas): {e}")
                print(f"    → Solo guardado en Excel: {query}.xlsx")
    else:
        print(f"  ✓ Sin registros encontrados")

    print("")

# Combinar todos los archivos Excel generados
print("===================================")
print("Combinando archivos Excel...")
folder_basename = os.path.basename(folder_name)
output_filename = f"{nombre_ciudad}-{folder_basename}"
tools.combine_excel_files(folder_name, output_filename)

# Reporte final
print("")
print("===================================")
print("REPORTE FINAL DE GUARDADO EN BASE DE DATOS")
print("===================================")
print(f"Total registros guardados en tabla alfanumericas: {total_alfanumericas}")
print(f"Total registros guardados en tabla geograficas: {total_geograficas}")
print(f"Total general: {total_alfanumericas + total_geograficas}")
print("===================================")

# Cerrar conexión
cur.close()
conn.close()
