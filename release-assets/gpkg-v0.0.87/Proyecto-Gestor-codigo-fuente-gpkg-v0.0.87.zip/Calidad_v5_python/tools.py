# Standard library imports
import csv

# Third-party imports
import openpyxl
import pandas as pd


def save_to_csv(psyco_output, csv_path):
    """
    Receives the output from psyco (as a list of dicts or list of lists) and saves it as a CSV file.

    Args:
        psyco_output: List of dictionaries or list of lists representing the psyco output.
        csv_path: Path to the CSV file to save.
    """
    if not psyco_output:
        # Create an empty CSV file if no data is returned
        with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)
            # Write just the header or an empty file
            pass
        return

    # If output is list of dicts
    if isinstance(psyco_output[0], dict):
        fieldnames = psyco_output[0].keys()
        with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(psyco_output)
    # If output is list of lists
    elif isinstance(psyco_output[0], (list, tuple)):
        with open(csv_path, "w", newline="", encoding="utf-8") as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(psyco_output)
    else:
        raise TypeError("psyco_output must be a list of dicts or list of lists")


def save_to_excel(psyco_output, excel_path, column_names=None):
    """
    Receives the output from psyco (as a list of dicts or list of lists) and saves it as an Excel file.

    Args:
        psyco_output: List of dictionaries or list of lists representing the psyco output.
        excel_path: Path to the Excel file to save.
        column_names: List of column names to use as headers (optional).
    """
    if not psyco_output:
        # No crear archivo si no hay datos
        return

    # If output is list of dicts
    if isinstance(psyco_output[0], dict):
        df = pd.DataFrame(psyco_output)

        # Convertir columnas datetime con timezone a timezone-naive
        for col in df.select_dtypes(include=['datetimetz']).columns:
            df[col] = df[col].dt.tz_localize(None)

        df.to_excel(excel_path, index=False)

    # If output is list of lists
    elif isinstance(psyco_output[0], (list, tuple)):
        if column_names:
            df = pd.DataFrame(psyco_output, columns=column_names)
        else:
            df = pd.DataFrame(psyco_output)

        # Convertir columnas datetime con timezone a timezone-naive
        for col in df.select_dtypes(include=['datetimetz']).columns:
            df[col] = df[col].dt.tz_localize(None)

        df.to_excel(excel_path, index=False)

    else:
        raise TypeError("psyco_output must be a list of dicts or list of lists")


def combine_excel_files(folder_path, output_filename):
    """
    Combina todos los archivos Excel de una carpeta en un solo archivo con múltiples hojas.

    Args:
        folder_path: Ruta de la carpeta que contiene los archivos Excel
        output_filename: Nombre del archivo de salida (sin extensión)
    """
    import os
    import glob
    from openpyxl import Workbook

    # Buscar todos los archivos Excel en la carpeta (excluyendo archivos temporales)
    excel_files = glob.glob(os.path.join(folder_path, "*.xlsx"))
    excel_files = [
        f
        for f in excel_files
        if not os.path.basename(f).startswith("~$")
        and not os.path.basename(f).startswith("Valledupar-")
    ]

    if not excel_files:
        print("No se encontraron archivos Excel para combinar.")
        return

    # Crear el archivo de salida
    output_path = os.path.join(folder_path, f"{output_filename}.xlsx")

    # Usar pandas ExcelWriter para crear el archivo con múltiples hojas
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for excel_file in excel_files:
            # Obtener el nombre del archivo sin extensión para usar como nombre de hoja
            sheet_name = os.path.splitext(os.path.basename(excel_file))[0]

            try:
                # Leer el archivo Excel
                df = pd.read_excel(excel_file)

                # Escribir a una nueva hoja en el archivo combinado
                df.to_excel(writer, sheet_name=sheet_name, index=False)
                print(f"  ✓ Hoja '{sheet_name}' agregada con {len(df)} registros")

            except Exception as e:
                print(f"  ✗ Error al procesar {excel_file}: {str(e)}")

    print(f"\n✓ Archivo combinado creado: {output_filename}.xlsx")
    return output_path


def save_to_db_alfanumericas(conn, rows, column_names, batch_size=1000):
    """
    Guarda registros en la tabla lc_gen_inconsistencias_alfanumericas_historicas.

    Args:
        conn: Conexión a la base de datos PostgreSQL
        rows: Lista de tuplas con los datos a insertar
        column_names: Lista de nombres de columnas
        batch_size: Tamaño del lote para inserciones (default: 1000)
    """
    if not rows:
        return 0

    from psycopg2.extras import execute_values

    cur = conn.cursor()

    # Construir el INSERT statement
    columns_str = ', '.join(column_names)

    insert_query = f"""
        INSERT INTO general.lc_gen_inconsistencias_alfanumericas_historicas
        ({columns_str})
        VALUES %s
    """

    try:
        # Insertar en lotes para mejor rendimiento
        total_inserted = 0
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]
            execute_values(cur, insert_query, batch, page_size=batch_size)
            total_inserted += len(batch)

        conn.commit()
        return total_inserted
    except Exception as e:
        conn.rollback()
        print(f"Error al insertar en tabla alfanumericas: {e}")
        raise
    finally:
        cur.close()


def save_to_db_geograficas(conn, rows, column_names, batch_size=1000):
    """
    Guarda registros en la tabla lc_gen_inconsistencias_geograficas_historicas.

    Args:
        conn: Conexión a la base de datos PostgreSQL
        rows: Lista de tuplas con los datos a insertar
        column_names: Lista de nombres de columnas
        batch_size: Tamaño del lote para inserciones (default: 1000)
    """
    if not rows:
        return 0

    from psycopg2.extras import execute_values

    cur = conn.cursor()

    # Construir el INSERT statement
    columns_str = ', '.join(column_names)

    insert_query = f"""
        INSERT INTO general.lc_gen_inconsistencias_geograficas_historicas
        ({columns_str})
        VALUES %s
    """

    try:
        # Insertar en lotes para mejor rendimiento
        total_inserted = 0
        for i in range(0, len(rows), batch_size):
            batch = rows[i:i + batch_size]
            execute_values(cur, insert_query, batch, page_size=batch_size)
            total_inserted += len(batch)

        conn.commit()
        return total_inserted
    except Exception as e:
        conn.rollback()
        print(f"Error al insertar en tabla geograficas: {e}")
        raise
    finally:
        cur.close()

# def save_to_db_alfanumericas(conn, rows, column_names):
#     """
#     Guarda registros en la tabla lc_gen_inconsistencias_alfanumericas_historicas.

#     Args:
#         conn: Conexión a la base de datos PostgreSQL
#         rows: Lista de tuplas con los datos a insertar
#         column_names: Lista de nombres de columnas
#     """
#     if not rows:
#         return 0

#     cur = conn.cursor()

#     # Construir el INSERT statement
#     columns_str = ', '.join(column_names)
#     placeholders = ', '.join(['%s'] * len(column_names))

#     insert_query = f"""
#         INSERT INTO general.lc_gen_inconsistencias_alfanumericas_historicas
#         ({columns_str})
#         VALUES ({placeholders})
#     """

#     try:
#         # Insertar todos los registros
#         cur.executemany(insert_query, rows)
#         conn.commit()
#         return cur.rowcount
#     except Exception as e:
#         conn.rollback()
#         print(f"Error al insertar en tabla alfanumericas: {e}")
#         raise
#     finally:
#         cur.close()


# def save_to_db_geograficas(conn, rows, column_names):
#     """
#     Guarda registros en la tabla lc_gen_inconsistencias_geograficas_historicas.

#     Args:
#         conn: Conexión a la base de datos PostgreSQL
#         rows: Lista de tuplas con los datos a insertar
#         column_names: Lista de nombres de columnas
#     """
#     if not rows:
#         return 0

#     cur = conn.cursor()

#     # Construir el INSERT statement
#     columns_str = ', '.join(column_names)
#     placeholders = ', '.join(['%s'] * len(column_names))

#     insert_query = f"""
#         INSERT INTO general.lc_gen_inconsistencias_geograficas_historicas
#         ({columns_str})
#         VALUES ({placeholders})
#     """

#     try:
#         # Insertar todos los registros
#         cur.executemany(insert_query, rows)
#         conn.commit()
#         return cur.rowcount
#     except Exception as e:
#         conn.rollback()
#         print(f"Error al insertar en tabla geograficas: {e}")
#         raise
#     finally:
#         cur.close()