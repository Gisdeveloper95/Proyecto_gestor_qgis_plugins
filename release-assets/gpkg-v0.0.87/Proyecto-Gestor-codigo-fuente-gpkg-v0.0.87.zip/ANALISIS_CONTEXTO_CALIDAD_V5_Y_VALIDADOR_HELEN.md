# Analisis de contexto - Calidad_v5_python y validador_helen

Fecha de revision: 2026-07-16

## Resumen ejecutivo

El proyecto contiene dos piezas relacionadas, pero no equivalentes:

1. `Calidad_v5_python` es un motor batch: Python abre PostgreSQL, ejecuta reglas SQL, exporta Excel e inserta resultados en historicos.
2. `validador_helen` es un plugin QGIS: lee capas ya cargadas en QGIS, ejecuta reglas Python locales y ayuda a revisar/abrir predios en el formulario.

La relacion entre ambos es conceptual y nominal: el plugin implementa una parte de las reglas `Reco_*` del SQL, usando nombres y descripciones parecidas. No encontre una llamada directa del plugin al SQL ni al motor `Calidad_v5_python`.

Mi conclusion honesta: no conviene homologar las 252 reglas SQL a Python como estrategia principal. Conviene dejar SQL como fuente de verdad y usar Python/QGIS como interfaz de ejecucion, visualizacion, navegacion y correccion.

## Calidad_v5_python

Archivos principales:

- `main.py`: valida ciudad, conecta a PostgreSQL, recorre `queries_module.get_all()`, ejecuta cada regla, exporta `.xlsx`, inserta filas en historicos y consolida Excel.
- `tools.py`: guarda CSV/Excel, combina Excel y hace inserts masivos con `psycopg2.extras.execute_values`.
- `validar_historicas.py`: revisa que las columnas devueltas por cada regla coincidan con las tablas historicas.
- `config.py`: define conexion y modulo de consultas por ciudad.
- `queries_valledupar.sql`: contiene el catalogo de reglas.
- `manual.txt` y `requirements.txt`: instrucciones basicas y dependencias.

Inventario SQL:

- Total: 252 reglas marcadas con `-- name:`.
- `Reco`: 70 reglas.
- `PH`: 77 reglas.
- `SIG`: 16 reglas.
- `Jur`: 82 reglas.
- `Eco`: 7 reglas.

Problema operativo importante:

- `config.py` hace `import queries_valledupar`, pero en la carpeta solo existe `queries_valledupar.sql`, no `queries_valledupar.py`.
- Resultado local: `ModuleNotFoundError: No module named 'queries_valledupar'`.
- Por tanto, el motor no arranca tal como esta. Falta un cargador que lea el `.sql` por bloques `-- name:` y exponga `get_all()`, o generar un modulo `.py`.

Hallazgos de coherencia en el SQL:

- Marcador `Jur_10`, pero `id_regla` interno `Jur_06`.
- Marcador `Jur_60`, pero `id_regla` interno `Jur_59`.
- Join de excepciones con regla diferente:
  - `Reco_52` consulta excepciones como `Reco_51`.
  - `Jur_10` consulta excepciones como `Jur_06`.
  - `Jur_59` consulta excepciones como `Jur_58`.
  - `Jur_60` consulta excepciones como `Jur_58`.
- Solo `SIG_02`, `SIG_09` y `SIG_10` estan marcadas en Python como reglas geograficas. Las demas `SIG_*` caerian por defecto en historico alfanumerico, salvo que eso sea intencional por formato de salida.

## validador_helen

Es un plugin QGIS generado con Plugin Builder y luego modificado con logica propia.

Funciones reales:

- Agrega barra/menu en QGIS.
- Abre un DockWidget llamado "Reglas de Calidad".
- Lee capas por nombre desde el proyecto QGIS.
- Construye un diccionario base de predios.
- Importa dinamicamente archivos `inconsistencias_reco/reco_*.py`.
- Cada regla devuelve `pk_id` de predios con error.
- Cruza excepciones desde `lc_gen_excepciones`.
- Muestra resumen por regla, detalle por predio, zoom al predio, apertura del formulario QGIS y exportacion CSV.

Capas que usa el plugin:

- `lc_gen_predio`
- `lc_gen_excepciones`
- `lc_gen_fotos_predio`
- `lc_jur_derecho`
- `lc_jur_interesado`
- `lc_reco_caracteristicasunidadconstruccion`
- `lc_reco_cal_calificacionresidencial`
- `lc_reco_cal_calificacioncomercial`
- `lc_reco_cal_calificacionindustrial`
- `lc_reco_cal_calificacionnoconvencional`
- `lc_vis_contactovisita`

Comparacion con el SQL:

- El SQL toca 52 tablas o apoyos; el plugin toca 11 capas.
- El plugin cubre principalmente una porcion de `Reco`.
- No cubre `PH`, `SIG`, `Jur` ni `Eco` como familias completas.
- Del SQL hay 70 reglas `Reco`; el plugin tiene fuente Python para 42 de esas 70.
- Ademas tiene `Reco_71`, que no aparece en el SQL revisado.
- Hay 52 `.pyc` pero solo 43 `.py`; existen reglas compiladas sin fuente visible.

Reglas `Reco` del SQL sin fuente `.py` visible en el plugin:

`Reco_01`, `Reco_03`, `Reco_04`, `Reco_05`, `Reco_10`, `Reco_13`, `Reco_18`, `Reco_19`, `Reco_23`, `Reco_24`, `Reco_30`, `Reco_31`, `Reco_35`, `Reco_36`, `Reco_37`, `Reco_44`, `Reco_46`, `Reco_47`, `Reco_48`, `Reco_49`, `Reco_57`, `Reco_58`, `Reco_59`, `Reco_63`, `Reco_64`, `Reco_65`, `Reco_66`, `Reco_70`.

Reglas con `.pyc` pero sin `.py`:

`Reco_10`, `Reco_18`, `Reco_30`, `Reco_48`, `Reco_49`, `Reco_57`, `Reco_58`, `Reco_63`, `Reco_64`.

Reglas con fuente pero apagadas por defecto porque la UI no trae checkboxes:

`Reco_06`, `Reco_07`, `Reco_08`, `Reco_14`, `Reco_54`, `Reco_55`.

Reglas con codigo de prueba suelto al importar:

- `reco_12.py`
- `reco_22.py`
- `reco_34.py`
- `reco_55.py`

Esto puede ejecutar validaciones de prueba al importar el modulo, antes de la ejecucion formal del plugin.

## Riesgos del plugin

- No es equivalente al SQL: aplica filtros globales que cambian el universo validado.
- Solo deja pasar predios con `reconocimiento_estado_asignacion == '2'`.
- Excluye cancelados, ciertas condiciones (`2`, `5`, `8`, `9`) e informales marcados para visita.
- Muchas reglas devuelven solo `pk_id`, sin `tabla_error`, `pk_tabla_error`, componente, custom fields ni estructura historica.
- Si falta una capa, muchas reglas devuelven `[]`, lo que puede parecer "sin errores" cuando en realidad no se pudo validar.
- Las reglas de un digito se cargan como `RECO_2`, `RECO_6`, etc.; el SQL usa `Reco_02`, `Reco_06`. Esto puede romper excepciones y navegacion de pestañas.
- La interfaz no contiene los checkboxes que el codigo espera.
- La metadata del plugin esta en version `0.1` y conserva URLs placeholder.
- Hay pruebas boilerplate, pero no pruebas reales de reglas.
- Varias reglas Python son aproximaciones funcionales y no traducciones exactas de las consultas SQL.

## Optimizacion

Cosas buenas:

- Usa `QgsFeatureRequest.NoGeometry` en muchas reglas.
- Usa `set` y `dict` para cruces simples en memoria.
- El flujo sirve para revision interactiva en QGIS.

Limites:

- Cada regla vuelve a escanear capas completas.
- No reutiliza caches compartidos salvo el diccionario base de predios.
- No usa SQL/PostGIS para joins pesados, filtros espaciales o agregaciones complejas.
- No hay indices de proveedor ni filtros por expresion cuando se podria reducir lectura.
- Para reglas espaciales o con muchos joins, PostgreSQL/PostGIS sera mucho mas confiable y rapido.

## Recomendacion de arquitectura

Ruta recomendada:

1. Mantener `queries_valledupar.sql` como fuente canonica.
2. Crear un cargador Python de SQL por `-- name:` que exponga `get_all()`.
3. Normalizar IDs de reglas (`Reco_02`, no `Reco_2`) en todos los puntos.
4. Corregir desfaces de `id_regla` y excepciones en el SQL.
5. Usar el plugin QGIS como frontend: ejecutar SQL, mostrar resultados, hacer zoom, abrir formularios y exportar.
6. Mantener reglas Python solo para chequeos rapidos/interactivos cuando no dependan de joins complejos ni de PostGIS.
7. Si se requiere homologacion, hacerla por pruebas comparativas: cada regla Python debe producir los mismos `pk_id` que su SQL con el mismo dataset.

Mi opinion directa:

- Homologar 252 SQL a Python es una perdida de tiempo si el objetivo es validar con fidelidad y rendimiento.
- Si el objetivo es una herramienta de apoyo para reconocedores dentro de QGIS, el plugin si tiene valor, pero como interfaz y prevalidacion, no como motor oficial.
- El mejor producto seria hibrido: SQL manda, QGIS ayuda a operar.

