# Third-party notices

Este documento es un inventario tecnico y no concede licencias ni resuelve la
procedencia del catalogo SQL o de material derivado.

## Dependencias de ejecucion no incluidas en los ZIP

- QGIS 3.44 LTR y su API Python: suministrados por la instalacion de QGIS del
  usuario; no se redistribuyen dentro de estos paquetes.
- Qt/PyQt y el controlador PostgreSQL de Qt: suministrados por QGIS; no se
  redistribuyen dentro de estos paquetes.
- PostgreSQL/PostGIS: servicio externo al plugin; no se distribuye en los ZIP.

## Herramientas de release no incluidas en los ZIP

- `cryptography` 49.0.0: usada para la firma/verificacion RSA; licencia declarada
  por el proyecto upstream como Apache-2.0 OR BSD-3-Clause.
- `cffi` 2.0.0: dependencia de `cryptography`; licencia MIT declarada por el
  proyecto upstream.
- `pycparser` 3.0: dependencia de `cffi`; licencia BSD-3-Clause declarada por el
  proyecto upstream.

Las versiones y hashes de wheels admitidos para Windows/CI Linux estan fijados
en `requirements-release.txt`. Estas dependencias se instalan en el entorno de
release y no se empaquetan dentro de los plugins QGIS.

## Codigo y catalogo del Proyecto Gestor

Los seis ZIP contienen codigo Python, manifiestos y SQL propios del arbol de
fuente aprobado para la version. Su licencia y procedencia deben quedar
resueltas mediante los gates versionados antes de crear un bundle publicable.
El SBOM toma `licenseDeclared` y `licenseConcluded` exclusivamente de la
expresion SPDX machine-readable aprobada. El gate actual solo permite
`GPL-2.0-or-later`; no existe valor predeterminado ni inferencia desde el texto
de `LICENSE`.

## Fuente potencial bajo revision

El arbol de referencia `validador_helen` declara como autora a Sofia Helena
Restrepo Moreno y la licencia `GPL-2.0-or-later`. La auditoria tecnica encontro
una posible relacion de `Reco_71` y del filtro posterior RECO con ese material,
pero no confirma autoria, derivacion ni permiso aplicable al catalogo actual.
Antes de cualquier distribucion, el propietario debe resolver esa relacion con
evidencia autorizada y, si corresponde, incorporar la atribucion y los avisos
definitivos aprobados. Esta nota preventiva no concede derechos.
