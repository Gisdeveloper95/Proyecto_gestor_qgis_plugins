# Decisión temporal: foco exclusivo en plugins

Fecha: 2026-07-19

## Alcance vigente

Se congelan el portal web y la aplicación desktop de MapingTool Catastral. El
único frente activo es completar, probar y empaquetar las dos ediciones de los
seis validadores QGIS:

- DBA/PostGIS: catálogo canónico completo para el administrador con acceso a
  PostgreSQL/PostGIS;
- Calidad/GPKG: catálogo homologado para usuarios que reciben subconjuntos en
  GeoPackage y no tienen ni tendrán acceso a PostgreSQL.

La homologación portable continúa con independencia de que después se añada un
motor opcional. Ninguna regla se declara equivalente solo porque compile o
entregue un conteo plausible.

## Estado comprobado

| Familia | Catálogo canónico | Portable con evidencia PG/GPKG | Pendiente |
|---|---:|---:|---:|
| Jurídico | 82 | 82 | 0 |
| RECO | 71 | 71 | 0 |
| SIG | 16 | 16 | 0 |
| PH | 77 | 77 | 0 |
| Económico | 7 | 7 | 0 |
| **Total** | **253** | **253** | **0** |

Los checkpoints hasta `0.0.67` elevaron la cobertura de 13 a 253 reglas.
Las 253 produjeron el mismo multiconjunto que el SQL canónico sobre fixtures
sintéticos en PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y un GPKG
físico. QGIS 3.44.11 verificó archivo directo, capas OGR y proveedor `memory`;
los seis ZIP `0.0.67` quedaron reconstruidos y reproducibles.

Las 71 reglas RECO portadas conservan su predicado particular y declaran el
mismo postprocesador operativo global `reco_post_filter`. La API normal lo
aplica automáticamente; solo el harness de equivalencia puede solicitar de
forma explícita la etapa SQL cruda.

## Qué tan PostgreSQL/PostGIS es el catálogo

El inventario reproducible de 253 SQL encontró:

- 4 reglas con funciones espaciales `ST_*`: `Reco_49`, `PH_67`, `SIG_16` y
  `Jur_47`;
- 250 reglas con casts `::` de PostgreSQL;
- 27 con `ILIKE`;
- 17 con `DISTINCT ON`.

Por tanto, solo cuatro reglas contienen llamadas espaciales PostGIS explícitas,
pero casi todas necesitan alguna adaptación de dialecto. Además, una consulta
sin `ST_*` puede depender de una tabla derivada que no venga en el GPKG; el
preflight debe distinguir `dependency_missing` de un resultado vacío real.

## Evaluación de motores

### A. GPKG directo — motor primario

GeoPackage ya es un contenedor SQLite. Los `SELECT`, joins, CTE, uniones,
filtros y agregaciones compatibles pueden ejecutarse sobre un snapshot local de
solo lectura, sin una migración intermedia. Las diferencias de PostgreSQL se
resuelven mediante implementaciones portables versionadas, primitivas comunes y
reescrituras SQL SQLite cuando su semántica sea exacta. La geometría se procesa
con capacidades empaquetadas de GDAL/GEOS/QGIS cuando SQLite puro no alcance.

Ventajas: cero servidor, cero credenciales, menor tiempo de preparación, copia
temporal sencilla de limpiar, instalación natural para el grupo de calidad y
el mismo contrato de entrada que entrega el DBA.

Costo: hay que homologar y certificar las reglas; un SQL PostgreSQL no se puede
pegar sin traducción.

Decisión: **continuar como ruta obligatoria y motor predeterminado**.

### B. GPKG a SpatiaLite temporal — acelerador opcional

SpatiaLite también usa SQLite, pero cambia metadatos y codificación geométrica y
añade funciones e índices espaciales. La instalación local de QGIS 3.44.11
detecta drivers GDAL de lectura/escritura para GPKG y SQLite/SpatiaLite, incluido
`SPATIALITE=YES`.

Ventajas: servidor cero, archivo temporal único, SQL espacial local e índices.

Limitaciones: el ETL duplica los datos; no arregla `::`, `ILIKE` ni
`DISTINCT ON`; las funciones no son idénticas a PostGIS (`ST_DWithin`,
precisión, validez y tolerancias exigen equivalencia explícita); requiere probar
preservación de PK, CRS, geometría, nulos y tipos.

Decisión: **hacer un benchmark con las cuatro reglas espaciales y adoptarlo solo
si reduce complejidad o tiempo sin cambiar resultados**. No sustituye la
homologación de las otras 249.

### C. GPKG a PostgreSQL/PostGIS temporal — fallback controlado

Es el camino de mayor compatibilidad con el SQL canónico, pero exige un servidor
local o remoto, credenciales, carga ETL y administración de residuos. Crear y
eliminar una base por corrida necesita privilegios elevados y es innecesariamente
costoso.

Si se conserva como modo opcional, se usará una base de trabajo dedicada y un
schema único por corrida, con nombre aleatorio, propietario restringido,
transacción, manifiesto y `DROP SCHEMA ... CASCADE` en `finally`; un recolector
eliminará schemas huérfanos después de una caída. No se reutilizará un schema
entre usuarios ni se tocará la base catastral del DBA.

Decisión: **no usarlo como requisito para Calidad/GPKG**. Puede ser un motor
opcional en estaciones controladas o una herramienta de contraste, pero los
usuarios sin PostgreSQL deben conservar cobertura completa.

## Orden de ejecución

1. ampliar desde el checkpoint `0.0.67` los escenarios sintéticos y de carga;
2. endurecer los lotes por plantillas repetidas y sus pruebas de regresión;
3. mantener el gate PostgreSQL vs GPKG físico por regla y el filtro global RECO;
4. ejecutar el spike SpatiaLite sobre las cuatro reglas espaciales;
5. probar PostgreSQL temporal solo como fallback y medir ETL, ejecución,
   limpieza, concurrencia y residuos tras interrupción;
6. no reactivar web ni desktop hasta nueva instrucción del propietario.
