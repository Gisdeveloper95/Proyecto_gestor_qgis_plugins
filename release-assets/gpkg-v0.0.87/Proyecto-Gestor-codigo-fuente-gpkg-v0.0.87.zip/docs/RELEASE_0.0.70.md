# Calidad GPKG 0.0.70 — paquetes parciales y modelo relacional real

`0.0.70` adapta las seis ediciones GPKG al paquete de trabajo real
`pvall_044_nu`.

El lector ya no supone que todas las entidades aparecen registradas como capas
en `gpkg_contents`. Expone en modo solo lectura las tablas relacionales
ordinarias del mismo SQLite, excluye objetos internos y reconstruye
`determinacion_area_construccion` en memoria cuando existen sus fuentes. No
crea tablas, vistas ni residuos dentro del GeoPackage recibido.

El catálogo de 253 reglas representa la capacidad total, no el alcance
obligatorio de cada encargo. El analista puede marcar un subconjunto y el
coordinador/DBA puede entregar un `mapingtool_scope.json` adyacente con IDs
explícitos. Las reglas fuera de ese alcance permanecen visibles, pero no se
ejecutan ni se presentan como dependencias faltantes.

La auditoría read-only con QGIS 3.44.11 sobre el paquete real reconoció 153
entidades y obtuvo 252 reglas técnicamente listas. `SIG_16` conservó
correctamente el estado `dependency_missing` porque el paquete no contiene el
perímetro urbano requerido. No hubo errores de ejecución.

El formato del alcance y la política para futuras actualizaciones del SQL se
documentan en `docs/GPKG_WORK_PACKAGE_CONTRACT.md`.

Repositorio estable para QGIS:

`https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/latest/download/plugins.xml`
