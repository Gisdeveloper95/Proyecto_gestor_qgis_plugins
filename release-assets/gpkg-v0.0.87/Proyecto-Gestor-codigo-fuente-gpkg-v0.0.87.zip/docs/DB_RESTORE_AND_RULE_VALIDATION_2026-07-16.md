# Restauracion local y validacion SQL - 2026-07-16

> **Evidencia historica reemplazada.** Este documento describe la restauracion
> parcial del 16 de julio y no debe usarse como procedimiento vigente. La base
> canonica se restauro el 17 de julio de 2026 con PostgreSQL 18.4 en el puerto
> 5432, sin scripts heredados de secuencias/compatibilidad. Las validaciones
> actuales usan `gestor_validator_ro` mediante QGIS Auth Manager. Consulte
> `docs/DB_RESTORE_AND_RULE_VALIDATION_2026-07-17.md`.

## Resumen

Se restauro una copia parcial de CartoFlow para pruebas locales y se valido el catalogo SQL del proyecto contra esa base.

- Respaldo historico: `cartoflow_parcial_2026-07-16.dump` (ubicacion personal retirada del HEAD actual)
- Base local creada: `cartoflow_pruebas`
- Servidor usado: PostgreSQL 17 en `localhost:5433`
- Motivo de usar PostgreSQL 17: el dump fue generado con version de archivo 1.16; `pg_restore` de PostgreSQL 16 no lo puede leer.
- Restauracion final: correcta con `pg_restore --no-owner --no-acl`

No se documenta la clave local en este archivo; usar `PGPASSWORD` o el metodo seguro que aplique al equipo.

## Observaciones de restauracion

El respaldo es parcial. El README del backup indica que el usuario de origen no tenia permisos sobre todas las relaciones. Durante la primera restauracion fallaron muchas tablas de `actualizacion` porque el dump no incluia secuencias `*_fid_seq` usadas por columnas `fid`.

Se corrigio creando previamente las secuencias faltantes de `actualizacion`, se recreo la base de pruebas y la segunda restauracion finalizo con codigo de salida `0`.

Objetos principales disponibles despues de restaurar:

| Esquema | Tablas |
| --- | ---: |
| `actualizacion` | 152 |
| `general` | 5 |
| `public` | 1 |

Conteos relevantes:

| Tabla | Filas |
| --- | ---: |
| `actualizacion.lc_gen_predio` | 97.249 |
| `actualizacion.lc_reco_caracteristicasunidadconstruccion` | 97.852 |
| `actualizacion.lc_ph_predio` | 28.737 |
| `actualizacion.lc_ph_caracteristicasunidadconstruccion` | 26.551 |
| `actualizacion.lc_jur_interesado` | 113.381 |
| `actualizacion.lc_vis_contactovisita` | 1.322 |
| `actualizacion.lc_gen_fotos_predio` | 9.730 |
| `actualizacion.lc_gen_fotos_caracteristica` | 942 |
| `general.lc_gen_inconsistencias_alfanumericas_historicas` | 5.998.833 |
| `general.lc_gen_inconsistencias_geograficas_historicas` | 318.798 |

## Objetos faltantes y compatibilidad

Despues de comparar las referencias del catalogo SQL contra la DB restaurada, faltaban dos objetos usados por reglas:

- `general.determinacion_area_construccion`
- `public.perimetro_urbano_20260702`

`general.determinacion_area_construccion` parece ser una tabla derivada de caracteristicas de construccion. Para pruebas locales se reconstruyo como vista de compatibilidad en:

`tools/db/create_test_compatibility_objects.sql`

La vista une:

- `actualizacion.lc_reco_caracteristicasunidadconstruccion` con `actualizacion.lc_gen_predio`
- `actualizacion.lc_ph_caracteristicasunidadconstruccion` con `actualizacion.lc_ph_predio` y su matriz en `actualizacion.lc_gen_predio`

Tambien despliega los campos de uso de construccion (`uso_residencial`, `uso_comercial`, etc.) para conservar multiples usos cuando existan.

Conteo de la vista reconstruida:

| Fuente | Filas | Predios | Caracteristicas | Sin uso |
| --- | ---: | ---: | ---: | ---: |
| `LC_Reco_Caracteristicasunidadconstruccion` | 97.887 | 79.886 | 97.845 | 68 |
| `LC_Ph_Caracteristicasunidadconstruccion` | 26.551 | 25.674 | 26.551 | 743 |
| Total | 124.438 |  |  |  |

`public.perimetro_urbano_20260702` no fue reconstruido, porque es una capa geografica externa requerida por `SIG_16`. Crear una tabla vacia haria compilar la regla, pero ocultaria que falta informacion real.

## Pruebas automatizadas

Se creo:

`tools/validate_rules_against_db.py`

La herramienta valida el mismo catalogo `quality_core` que alimenta el plugin maestro y los plugins por grupo. No requiere `psycopg2`; ejecuta `psql` por subproceso.

Ejemplos:

```powershell
$env:PGPASSWORD='...'
python tools\validate_rules_against_db.py --host localhost --port 5433 --dbname cartoflow_pruebas --user postgres --mode compile

python tools\validate_rules_against_db.py --host localhost --port 5433 --dbname cartoflow_pruebas --user postgres --family reco --mode compile

python tools\validate_rules_against_db.py --host localhost --port 5433 --dbname cartoflow_pruebas --user postgres --rule Reco_71 --mode compile
```

Resultados de la validacion en modo `compile`:

| Alcance/plugin | Resultado |
| --- | ---: |
| Maestro/todas las reglas | 252/253 OK |
| `reco` | 71/71 OK |
| `ph` | 77/77 OK |
| `juridico` | 82/82 OK |
| `economico` | 7/7 OK |
| `sig` | 15/16 OK |

La unica regla que no compila con esta copia parcial es `SIG_16`, por ausencia de
`public.perimetro_urbano_20260702`. El validador vigente conserva el codigo de
salida no exitoso, pero clasifica esta condicion en CSV/JSON como `dependencia` y
no como error generico.

Reportes locales generados:

- `test_reports/20260716_120306_rules_all_compile.json`
- `test_reports/20260716_120306_rules_all_compile.csv`
- `test_reports/20260716_120328_rules_reco_compile.json`
- `test_reports/20260716_120329_rules_ph_compile.json`
- `test_reports/20260716_120359_rules_juridico_compile.json`
- `test_reports/20260716_120345_rules_economico_compile.json`
- `test_reports/20260716_120347_rules_sig_compile.json`

`test_reports/` y `restore_logs/` quedan ignorados por Git porque son salidas locales.

## Lectura tecnica

La copia parcial si tiene datos suficientes para probar seriamente:

- Reglas alfanumericas de Reco, PH, Juridico y Economico.
- La regla `Reco_71` homologada desde Python a SQL.
- Gran parte de SIG, salvo la validacion de perimetro urbano.

No tiene datos completos para validar `SIG_16` hasta importar o recuperar la capa `perimetro_urbano_20260702`.

Siguiente paso recomendado: implementar la capa de ejecucion SQL dentro del plugin QGIS usando `quality_core`, y hacer que cada plugin fragmentado llame el validador de su familia como prueba previa de release.
