# Equivalencia portable SIG_09 - 2026-07-18

## Resultado

`SIG_09` queda en estado `passed_synthetic_fixture_v1`. Sobre el mismo fixture
CC0 sintético, el SQL canónico ejecutado en PostgreSQL 18.4/PostGIS 3.6.2 y la
implementación Calidad GPKG entregaron ocho filas y el mismo multiconjunto
normalizado.

El fixture cubre coincidencia exacta, predio cancelado, cambio físico con y sin
característica RECO, identificadores distintos y nulos, código nulo, código
corto, `9` en la posición 22, duplicado interno eliminado y una fila equivalente
formal/informal que permanece dos veces porque cambia la tabla de origen.

El SHA-256 semántico común es
`FBDD6C795C3879D3BD31086EEFBAE84E41BE1796396C3B77D15CE43E9D195465`.
El orden observado también coincidió, con SHA-256
`054A7E0BA35B7626B9B5F62F9730095E5C3873359895A302C959545666861D02`;
se conserva solo como diagnóstico porque el SQL no define desempate total.

## Entradas fijadas

| Sujeto | SHA-256 |
| --- | --- |
| Fixture `portable-sig-09-synthetic-v1` | `ACADABA45F90C66F5D0A23DE4CAC9533BF28428A59FE30FEBFEA817C728562AE` |
| SQL canónico, UTF-8 normalizado a LF | `8E3660EBD0158262CD9D1F6073001A787C996A7DAA1EC50099DF4BEBA9ADE157` |
| Implementación portable aislada | `FC09103A85E549E1C3041B6C26832F2738A72C0C2CF8D4BB14E85A5BE4BEDA28` |
| Normalizador de resultados | `CFF7090B047C33D9E373463C0B36E03FD65B990E26E5D29E7963AD97EAD75163` |
| Evidencia JSON | `B0C234AD7E83B341772D88ADB5204AF9A92396277B9911D951881B79F61543AC` |

El harness crea una base aleatoria con prefijo seguro `mt_gpkg_eq_`, carga DDL
declarativo, ejecuta ambas reglas y elimina la base antes de aceptar la
evidencia. No serializa DSN, contraseña, host ni nombre aleatorio.

## Límites

Esta certificación cubre exclusivamente el fixture sintético. No afirma
equivalencia productiva, geometría, rendimiento global ni 253/253. Total GPKG
y SIG GPKG alcanzan 2/253; las otras familias siguen en cero y deben mostrar
`backend_unsupported`.

Tampoco concede licencia, procedencia ni autorización de publicación. La
edición `0.0.11` permanece local y bloqueada por sus gates externos.
