# Equivalencia portable SIG_10 - 2026-07-18

## Resultado

`SIG_10` queda en estado `passed_synthetic_fixture_v1`. Sobre el mismo fixture
CC0 sintético, el SQL canónico ejecutado en PostgreSQL 18.4/PostGIS 3.6.2 y la
implementación Calidad GPKG produjeron 14 filas cada uno y el mismo
multiconjunto normalizado, incluida su multiplicidad.

El SHA-256 semántico común es
`72C2AFD9EB0D48C311B47BADCEE83014C012FD93788E547444204C1A681E96A8`.
`ordered_equal` es `false`: PostgreSQL y SQLite ordenaron de forma distinta
filas empatadas. El SQL canónico solo ordena por código e identificador, no
define un desempate total para el resto de atributos y ambos motores aplican
reglas de colación diferentes. Por ello el orden es diagnóstico y no una
diferencia semántica; el criterio certificado es el multiconjunto normalizado
con multiplicidad.

## Cobertura del fixture

La prueba declara y carga exactamente las seis capas requeridas:

- `lc_ph_predio`;
- `lc_ph_novedadnumeropredial`;
- `lc_gen_predio`;
- `lc_ph_caracteristicasunidadconstruccion`;
- `lc_gen_unidadconstruccion`;
- `lc_gen_unidadconstruccion_informal`.

El fixture cubre predios PH activos, cancelados y con cambio físico; coincidencia
y ausencia de característica; identificadores distintos y nulos; códigos
nulos, cortos y con `9` en la posición 22; novedades de tipos `5`, `6`, `7` y
`8`, además del control no excluyente de tipo `4`; y multiplicidad tanto dentro
de una tabla como entre unidades formales e informales. Los duplicados idénticos
se someten al `UNION` canónico, mientras que filas que difieren en atributos no
proyectados conservan su multiplicidad en el resultado normalizado.

## Entradas fijadas

| Sujeto | SHA-256 |
| --- | --- |
| Fixture `portable-sig-10-synthetic-v1` | `163AEED9D609252AFA50BEC86A5CBE1D8365819E1B62FCBCC9C1951FBAF2E6E9` |
| SQL canónico, UTF-8 normalizado a LF | `4A58EB9FF0D6320A367824BA4C9430F5B640FE2495736F7DD0EF31AA2CE791AA` |
| Implementación portable aislada | `BB3F970AD6AA2883747D9EB698FE7027E4803F328277FEA680D6368C040999EE` |
| Normalizador de resultados | `CFF7090B047C33D9E373463C0B36E03FD65B990E26E5D29E7963AD97EAD75163` |
| Evidencia JSON | `149C0358F181AF9DDB9FCC46B80F4345757FCE68FD15D6CD553C7DEDC8E48DEB` |

La evidencia versionada está en
`docs/evidence/SIG_10_POSTGIS_GPKG_EQUIVALENCE_2026-07-18.json`. El harness crea
una base temporal con nombre aleatorio seguro, carga únicamente el DDL y los
datos sintéticos, verifica los hashes contra el manifiesto y elimina la base
antes de emitir un resultado correcto. No serializa DSN, contraseña, host ni el
nombre de la base temporal.

## Política fail-closed y límites

La implementación portable rechaza de forma temprana un predio PH elegible con
`fid` o `pk_id` nulo y un mismo `pk_id` asociado a distintos `fk_id` o números
prediales. Ese rechazo puede ocurrir antes de un `JOIN` posterior que, en el SQL
canónico, eventualmente habría descartado la fila. Es una divergencia segura y
deliberada: ante una identidad que no permite trasladar de forma determinista
los centinelas y el `DISTINCT ON` sin orden total, se informa error en vez de
inventar una selección o producir un falso OK.

La certificación cubre exclusivamente este fixture sintético. No afirma
equivalencia productiva, geometría, rendimiento global ni el catálogo completo.
Con `SIG_02`, `SIG_09` y `SIG_10`, Total GPKG y SIG GPKG alcanzan 3/253; RECO,
PH, Jurídico y Económico GPKG permanecen en cero y deben responder
`backend_unsupported`.

La evidencia técnica tampoco concede licencia, procedencia ni autorización de
publicación. Los nueve bloqueos externos de `0.0.12` permanecen activos y no se
ha realizado push, tag ni release.
