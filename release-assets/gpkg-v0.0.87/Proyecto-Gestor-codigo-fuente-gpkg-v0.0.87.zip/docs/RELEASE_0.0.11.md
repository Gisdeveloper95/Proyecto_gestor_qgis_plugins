# Calidad GPKG 0.0.11 - segundo slice local

`0.0.11` amplía exclusivamente la edición Calidad GPKG. Los seis validadores
DBA/PostGIS permanecen en `0.0.9` y conservan su catálogo de 253 reglas; no
reciben selector de archivos ni módulos portables.

| Familia | Plugin DBA local | Plugin GPKG local | Reglas GPKG |
| --- | --- | --- | --- |
| Total | `validador_calidad_total` 0.0.9 | `calidad_gpkg_total` 0.0.11 | `SIG_02`, `SIG_09` |
| RECO | `validador_calidad_reco` 0.0.9 | `calidad_gpkg_reco` 0.0.11 | 0; `backend_unsupported` |
| PH | `validador_calidad_ph` 0.0.9 | `calidad_gpkg_ph` 0.0.11 | 0; `backend_unsupported` |
| Jurídico | `validador_calidad_juridico` 0.0.9 | `calidad_gpkg_juridico` 0.0.11 | 0; `backend_unsupported` |
| SIG | `validador_calidad_sig` 0.0.9 | `calidad_gpkg_sig` 0.0.11 | `SIG_02`, `SIG_09` |
| Económico | `validador_calidad_economico` 0.0.9 | `calidad_gpkg_economico` 0.0.11 | 0; `backend_unsupported` |

## Alcance técnico

- `SIG_09` se implementa de forma independiente; no existe traductor SQL.
- Lee únicamente atributos de cuatro capas explícitamente mapeadas.
- Conserva nulos, duplicados, multiplicidad formal/informal y cambio físico.
- Usa staging SQLite temporal, lotes de 256 y cursor de salida.
- Rechaza identidades de predio para las que el `DISTINCT ON` canónico no tiene
  una selección determinista trasladable.
- El resultado muestra también `planta_unidad_construccion` en tabla y CSV.
- Cada regla tiene fixture CC0 sintético y evidencia PostgreSQL/PostGIS
  independiente. No se usan datos reales.
- El smoke QGIS 3.44.11 ejecuta `SIG_09` tanto desde el GPKG directo como desde
  cuatro capas cargadas y capturadas en un snapshot nuevo.

## Construcción local

```powershell
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9 --dist dist\dba
python tools\build_gpkg_plugin_packages.py --version 0.0.11 --tag gpkg-v0.0.11 --dist dist\gpkg
python tools\test_plugin_portable_integration.py
```

Los hashes de los seis ZIP y el resultado resumido de las pruebas quedan en
`docs/evidence/GPKG_0.0.11_LOCAL_CHECKPOINT_2026-07-18.json`.

## Estado

Diferencia conocida y no bloqueante de este slice: el SQL canónico sí devuelve
`planta_unidad_construccion`, pero el contrato de exportación común de los DBA
`0.0.9` todavía no incluye esa columna. Calidad GPKG `0.0.11` sí la muestra y
exporta, y la evidencia la compara contra PostgreSQL. Homologar la salida DBA
requiere un parche DBA independiente; no se reescribe `0.0.9` dentro de este
release GPKG.

No publicable. `passed_synthetic_fixture_v1` no significa equivalencia
productiva ni 253/253. Faltan licencia first-party aprobada, procedencia,
metadata pública, aprobación versionada y autoridad externa. No debe crearse
tag, push, release ni instalarse en el perfil QGIS del usuario desde este
checkpoint.
