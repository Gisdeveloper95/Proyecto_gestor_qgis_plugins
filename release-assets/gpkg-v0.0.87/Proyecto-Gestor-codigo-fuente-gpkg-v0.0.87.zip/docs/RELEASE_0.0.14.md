# Calidad GPKG 0.0.14 — primer slice Jurídico local

`0.0.14` incorpora siete reglas Jurídicas portables sin ejecutar ni distribuir
SQL PostgreSQL dentro de los plugins GPKG. Los seis plugins DBA/PostGIS siguen
en `0.0.9` y conservan las 253 consultas canónicas.

| Familia | Canónicas | Portables GPKG | Reglas implementadas |
| --- | ---: | ---: | --- |
| Total | 253 | 11 | `SIG_01`, `SIG_02`, `SIG_09`, `SIG_10`, `Jur_05`, `Jur_12–15`, `Jur_17`, `Jur_18` |
| Jurídico | 82 | 7 | `Jur_05`, `Jur_12`, `Jur_13`, `Jur_14`, `Jur_15`, `Jur_17`, `Jur_18` |
| SIG | 16 | 4 | `SIG_01`, `SIG_02`, `SIG_09`, `SIG_10` |
| RECO | 71 | 0 | `backend_unsupported` |
| PH | 77 | 0 | `backend_unsupported` |
| Económico | 7 | 0 | `backend_unsupported` |

## Implementación

Las siete reglas comparten un pipeline SQLite temporal en disco para predios,
destino económico, excepciones, asignaciones de usuario y catálogos de estado.
Cada regla mantiene un wrapper aislado con su ID, descripción, predicado y
`custom_7`; por tanto, agregar una regla futura no cambia el hash ejecutable de
las ya certificadas.

Se preservan:

- predio activo como `juridico_predio_cancelado IS NULL OR false`;
- semántica NULL y booleana de PostgreSQL;
- `substring(..., 22, 1)` y `right(..., 8)` en `Jur_12–15`;
- comparaciones numéricas de matrícula y áreas en `Jur_05/17/18`;
- multiplicidad completa de todos los `LEFT JOIN` de enriquecimiento;
- timestamps no nulos y únicos por corrida;
- cursor de salida, cancelación y limpieza del staging.

El runtime acepta búsquedas como `jur_05`, pero devuelve y registra siempre el
ID canónico `Jur_05`. El manifiesto rechaza IDs que colisionen ignorando
mayúsculas/minúsculas.

Límite de rendimiento conocido: el worker conserva el aislamiento por regla y,
por ello, las siete Jurídicas reconstruyen hoy el staging e índices por cada
regla. El consumo de memoria permanece acotado, pero antes de ampliar este
patrón a lotes grandes se compartirá un único staging inmutable por corrida.

## Evidencia de equivalencia

El fixture compartido contiene 23 predios sintéticos CC0 y expectativas
independientes por regla. PostgreSQL 18.4/PostGIS 3.6.2, el proveedor en memoria
y `GeoPackageDataSource` sobre un archivo `.gpkg` físico coincidieron por
multiconjunto y multiplicidad:

| Regla | Filas | SHA-256 del multiconjunto estable |
| --- | ---: | --- |
| `Jur_05` | 4 | `A56EDFBCE40995A5460735873F94616091F0BE3EAABB7D6CC90FB09E7ACF2170` |
| `Jur_12` | 2 | `B762A0E7DF321026ACF9BAB80138E4E7086B33F22AB67151F72AD833C2FE0FF4` |
| `Jur_13` | 2 | `1072EBEE58C8BCB35B9F59D556653B9A326C8DDEE4432859F3E8756671A08E20` |
| `Jur_14` | 1 | `37FD55D70AD38F14DCB014E3895FF6602FDD891C696733C393AEFAFEF52ECA7F` |
| `Jur_15` | 2 | `A3EA079F9DA0DEDF23FDDDB88FCD5865BA7DB60A85ABB3B83C0F82C303528261` |
| `Jur_17` | 5 | `D8632057F63BBC17A5670A49AA2DAB34080E9A8E9D7F2BBCC47EC5FE65F6F4DB` |
| `Jur_18` | 9 | `68C00C252081E34BBB2A9828DD31FA9C7AB1E01C3D5B66C24CF74C4AE65B1917` |

La afirmación formal continúa limitada al fixture sintético. No implica
equivalencia productiva ni del catálogo completo.

## Construcción local

```powershell
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9 --dist dist\dba
python tools\build_gpkg_plugin_packages.py --version 0.0.14 --tag gpkg-v0.0.14 --dist dist\gpkg
python tools\test_plugin_portable_integration.py
python tools\test_gpkg_reproducible_build.py
```

El tag del comando solo fija rutas internas del build; no crea un tag Git ni
publica artefactos.

## Estado de publicación

El slice permanece local. Los gates técnicos esperan exactamente nueve
bloqueos externos: seis ZIP sin licencia aprobada, metadata pública GPKG,
aprobación versionada `0.0.14` y licencia first-party raíz. No se realizó push,
tag, release, instalación en perfiles del usuario ni despliegue.
