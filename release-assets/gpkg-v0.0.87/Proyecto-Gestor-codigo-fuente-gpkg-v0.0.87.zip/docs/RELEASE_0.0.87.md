# Calidad GPKG 0.0.87 — corrección del selector de filtros

Esta versión corrige dos defectos visuales y funcionales de la interfaz de los
seis plugins padre GPKG y de los perfiles simplificados que se generen desde
ellos.

- El selector **Alcance de predios para esta ejecución** conserva texto oscuro
  sobre fondo blanco y utiliza una selección verde con texto blanco legible.
- La selección de uno o varios grupos de reglas deja de depender de
  `QObject.sender()`. Los clics entregan explícitamente la acción de origen y ya
  no generan `AttributeError` en QGIS.
- Se añadió una prueba QGIS que pulsa directamente las acciones RECO y PH,
  verifica la unión de grupos y comprueba los colores del selector.

No se modificaron SQL, planes `generated_plan_v1`, filtros operativos ni
resultados de las 253 reglas. La serie `0.1.0` continúa bloqueada.
