# Validadores SQL QGIS 0.0.9

`0.0.9` es un slice tecnico local de paginacion y almacenamiento temporal. No
es una publicacion, no tiene tag y no queda autorizada por aparecer en este
documento. Los seis paquetes se generan juntos y fijan el mismo `gestor-rules`
de la linea anterior:

- catalogo: `72DC764C5B821322A844C3506713A7FC2A3C670C214AEC889897877C98627525`;
- arbol SQL: `C538063A81F9DB5CE7CF9D8189D47918E54A456A55D634BFE62E2C6BB3FD5664`;
- postprocesador RECO: `0177F4922CFA01BF64F48F0A1EC0905151FD0E7810CA068B10D9377887A17412`;
- contrato RECO: `load-allowed-predio-ids-once;execute-complete-rule-sql;normalize-rows;filter-reco-by-pk-id-predio-v1`.

No se modifico ninguna de las 253 SQL, no se resolvio ninguna identidad y no se
cambio el veredicto de la auditoria RECO. `SIG_16` continua activa y reporta la
dependencia real faltante; no se crea una tabla vacia.

## Cambio de arquitectura

El worker consume cada `QSqlQuery` en modo `forward-only` y normaliza una fila a
la vez. Un `ResultStore` SQLite temporal recibe lotes de hasta 256 filas dentro
de una transaccion por regla. Solo al agotar correctamente el cursor se confirma
la regla; una cancelacion o error revierte ese bloque completo y conserva las
reglas terminadas con anterioridad.

Los IDs permitidos por el filtro RECO se cargan una sola vez en otra tabla del
mismo SQLite. Cada lote consulta esa tabla y aplica el mismo filtro posterior
por `pk_id_predio`, sin retener el universo permitido en memoria.

La UI consulta paginas de 250 filas con orden estable. El filtro por regla, la
busqueda y los conteos ocurren en SQLite. CSV usa un cursor; XLSX escribe el XML
de cada hoja fila por fila; GPKG se crea mediante paginas y acciones de append.
Mientras el worker esta activo, las senales por regla solo actualizan resumen y
progreso: cualquier lectura o reconstruccion del detalle se difiere hasta que
`finished_all` haya cerrado la conexion escritora. Los cambios de filtro hechos
durante la corrida se aplican en ese refresco final, sin bloquear el event loop
de QGIS detras del `busy_timeout` de SQLite.
Las tres exportaciones usan un temporal hermano y `os.replace`: un error conserva
byte por byte el destino anterior. GPKG verifica los conteos por regla y total
antes del reemplazo. XLSX devuelve un manifiesto de filas realmente escritas en
el detalle global, por regla y por cada hoja fisica; si alcanza el limite de
Excel divide el flujo en hojas consecutivas. El plugin compara estrictamente ese
manifiesto con los conteos del `ResultStore` y valida el contenedor OOXML antes
de `os.replace`. El mapa se alimenta de un GPKG temporal local y carga capas OGR
respaldadas por disco, en lugar de conservar todos los hallazgos en capas QGIS de
memoria. Exportar y crear el mapa quedan deshabilitados mientras el worker esta
activo.

La geometria de este slice sigue proviniendo exclusivamente de
`actualizacion.lc_gen_predio`. La fuente geometrica exacta de cada regla SIG es
una deuda explicita para un parche posterior; `0.0.9` no declara esa paridad.

## Pruebas locales reproducibles

```powershell
python tools\test_result_store.py
python tools\test_qt_cursor_pipeline.py
python tools\test_atomic_output.py
python tools\test_excel_report.py
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9
python tools\test_plugin_paging_integration.py
```

Las pruebas sintéticas comprueban 10.003 filas con buffer maximo de 256,
paginas sin solapes, busqueda, filtro RECO respaldado por disco, rollback total
de una regla cancelada, error de driver despues de filas parciales, cleanup
diferido con dos conexiones y una cota de heap no proporcional al total. El test de
integracion inspecciona los seis ZIP y exige version `0.0.9`, el nuevo modulo de
almacenamiento y los mismos hashes de catalogo/postprocesador. La regresion XLSX
incluye varias reglas, splits forzados y el ataque de un `ResultStore` con tres
filas cuyo iterador termina limpiamente tras una: la salida anterior se conserva
y el temporal se elimina.

El smoke aislado QGIS 3.44 carga y descarga los seis plugins, impide snapshots
durante el worker y verifica con 503 filas tres paginas, busqueda, CSV, XLSX,
GPKG, mapa OGR y cleanup. Tambien inyecta fallos CSV/XLSX y en la segunda pagina
GPKG, y un iterador XLSX que termina limpiamente antes del conteo esperado, para
comprobar que el destino anterior no cambia. Esta evidencia sintetica no
sustituye una corrida autorizada contra PostgreSQL ni vuelve publicable el slice.

## Evidencia funcional real

La candidata definitiva se instalo solo en el perfil aislado `MapingToolDev` y
se ejecuto en QGIS `3.44.11` contra el fixture autorizado PostgreSQL `18.4` /
PostGIS `3.6.2`, mediante `authcfg` y el rol de solo lectura. La corrida termino
las cinco familias sin bloquear el event loop:

| Regla | Filas | Estado |
| --- | ---: | --- |
| `Eco_02` | 0 | correcta |
| `Jur_02` | 3.195 | correcta |
| `PH_02` | 3 | correcta |
| `Reco_50` | 228 | correcta tras postfiltro |
| `SIG_03` | 2.063 | correcta |

El total fue `5.489`. Tambien pasaron busqueda, seleccion, formulario, cuatro
capas de mapa con `5.489` geometrias y las tres exportaciones. El teardown
observo cuatro capas propias antes de descargar el plugin y cero despues;
confirmo que tanto el cache GPKG como el `ResultStore` fueron eliminados por el
plugin. Luego retiro la capa fuente del harness, dejo cero capas y el proyecto
sin cambios, y QGIS termino por si solo. `stderr` quedo vacio y el unico proceso
QGIS restante fue la sesion normal ajena al perfil de pruebas.

| Evidencia | SHA-256 |
| --- | --- |
| `live_workflow_report.json` | `E4717F473D481E0E4A3E925E1BBEE7307D07AAE8D076CA19D8218B6A8B133D2D` |
| `live_workflow.csv` | `B14A5C765AA8EC060148CD8B9C4EC832462A0339985CEFAFA271F456D7B5D4CD` |
| `live_workflow.xlsx` | `57EDB32495E864938465C2D5F42DC65DF3C57552A096FED5365DCA16961E6CC1` |
| `live_workflow.gpkg` | `017E079D65B17A41FE21BBF308A1A67E221AB6B1F3E884975E45411D11EAC195` |
| `cancel_live_report.json` | `065E41DA907AB78AE4B9E686AD66D2FBEA393F5A3B06B664B914F34B0B88FC2C` |
| `plugin_startup_report_0.0.9_livefix.json` | `7B3C6F475705ECFAC2AB1B850F47EE7CC500E912D5E9F3E2FCD872B15C08EBDD` |

La cancelacion real observo el backend de la consulta controlada, envio
`pg_cancel_backend` al mismo PID, termino en `172 ms`, confirmo
`transaction_read_only=on`, no dejo consulta activa y no recibio senales
tardias. Ningun informe contiene una clave literal.

Los ZIP finales sincronizados son:

| Plugin | SHA-256 |
| --- | --- |
| Total | `49B218BEA056A92873AA3410D03E6E60015DF3A76207064A87FABFDC4185AA15` |
| RECO | `5DDB9EB238CCD19D3C5723CFD565394931DF2D6550C23FC606D9B8F13C3483E5` |
| PH | `562ED0C01F5D2DEAD12AA606001400B5DFEE6DB5B58DCE19E031F4086077DDAA` |
| Juridico | `F2F1682D38658DD3883D10B0BC0EFA857CAF2A70CF4D74E89C1CF8891115F988` |
| SIG | `0C570B51B999AA21732FF9CFF420F3ACBBC556858EE5939C89B74731AC6BEC14` |
| Economico | `4AEC90F07C5240FE9F6B3758B03F746FC80768B504635A32AC0D59D43367FB3C` |

No se fija aqui un hash precommit de `plugins.xml`: sus fechas reproducibles se
derivan de `SOURCE_DATE_EPOCH` o del commit construido. Su SHA-256 solo puede
registrarse en el manifiesto generado despues de construir el commit/tag exacto.
Los ZIP usan timestamps internos constantes y los hashes anteriores no dependen
de la fecha del commit.

El requisito nuevo de capas GPKG y otras fuentes abiertas se especifica en
`docs/BACKEND_CAPAS_PORTABLES.md`. Es una capacidad futura y no cambia el
alcance exclusivamente PostGIS de `0.0.9`.

## Estado de gates

- `0.0.8` sigue en la lista permanente de versiones retiradas y nunca debe
  etiquetarse.
- `0.0.9` sigue no publicable mientras falten `LICENSE`, aprobaciones versionadas,
  procedencia autorizada, identidades resueltas, cierre RECO, metadata publica y
  controles externos de firma/autoridad.
- El build local no crea tags, releases ni llamadas remotas.
