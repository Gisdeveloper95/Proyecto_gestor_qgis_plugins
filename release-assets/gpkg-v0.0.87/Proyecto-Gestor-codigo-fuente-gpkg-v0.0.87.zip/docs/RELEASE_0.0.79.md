# Calidad GPKG 0.0.79 - filtros por perfil y plugins hijos

`0.0.79` separa correctamente los filtros generales de los filtros específicos
por grupo de reglas y permite producir perfiles operativos simplificados desde
los seis plugins padre.

## Cambios visibles

- Cancelación y estado de asignación quedan identificados como filtros
  generales.
- NPH, Condominio, PH, PH matriz e Informalidad tienen controles independientes.
- Cada plugin muestra únicamente los perfiles que usa; Total muestra todos e
  indica cuántas reglas corresponden a cada uno.
- Estados y condiciones aceptan combinaciones personalizadas de dígitos `0–9`.
- La configuración queda guardada localmente por edición.
- `Exportar > Plugin hijo bloqueado (ZIP)` genera un plugin instalable con las
  reglas marcadas y los filtros actuales.
- El plugin hijo oculta la edición de filtros, selección de reglas y mapeo;
  conserva ejecución, detalle, navegación y exportaciones.

## Ejecución

Los perfiles se preparan mediante lectura por lotes de `lc_gen_predio` y se
guardan en el almacén SQLite temporal de la corrida. Cada regla se filtra con
su perfil explícito antes de mostrarse o exportarse. Al volver a ejecutar, el
almacén y los perfiles temporales se reconstruyen, evitando residuos de la
corrida anterior.

## Compatibilidad

- Se construyen juntos Total, Económico, Jurídico, PH, RECO y SIG.
- No se modifican las 253 implementaciones portables ni su evidencia de
  equivalencia.
- Los plugins hijos se generan localmente; no incluyen el GPKG del usuario,
  geometrías, credenciales ni rutas absolutas.
- El formato padre continúa siendo compatible con QGIS 3.44.
