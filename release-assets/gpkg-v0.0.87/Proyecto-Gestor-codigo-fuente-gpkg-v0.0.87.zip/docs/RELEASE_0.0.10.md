# Calidad GPKG 0.0.10 - edicion separada

`0.0.10` es el primer slice local de la nueva edicion Calidad GPKG. No modifica
ni reemplaza los seis validadores DBA/PostGIS `0.0.9`.

## Matriz de doce paquetes

| Familia | DBA/PostGIS | Calidad GPKG | Cobertura GPKG |
|---|---|---|---|
| Total | `validador_calidad_total` 0.0.9 | `calidad_gpkg_total` 0.0.10 | `SIG_02` |
| RECO | `validador_calidad_reco` 0.0.9 | `calidad_gpkg_reco` 0.0.10 | 0; `backend_unsupported` |
| PH | `validador_calidad_ph` 0.0.9 | `calidad_gpkg_ph` 0.0.10 | 0; `backend_unsupported` |
| Juridico | `validador_calidad_juridico` 0.0.9 | `calidad_gpkg_juridico` 0.0.10 | 0; `backend_unsupported` |
| SIG | `validador_calidad_sig` 0.0.9 | `calidad_gpkg_sig` 0.0.10 | `SIG_02` |
| Economico | `validador_calidad_economico` 0.0.9 | `calidad_gpkg_economico` 0.0.10 | 0; `backend_unsupported` |

Los IDs QGIS, nombres, carpetas, ZIP, `plugins.xml`, QSettings, menus, toolbars,
temporales, capas de resultado y gates son distintos. Las doce extensiones se
pueden cargar juntas.

## Limite de seguridad entre ediciones

Los ZIP Calidad GPKG no contienen:

- los 253 SQL ni `quality_core/rules`;
- QPSQL o una conexion de base de datos;
- `authcfg`, gestor de autenticacion, usuario, clave o token;
- URI del proveedor de una capa.

La URI solo aporta un SHA-256 al manifiesto del snapshot. Los paquetes GPKG
incluyen exclusivamente el motor portable, la implementacion reimplementada
`SIG_02`, almacenamiento SQLite local y su manifiesto familiar filtrado. Esta
descripcion tecnica no concede autorizacion juridica ni sustituye el gate de
licencia/procedencia.

## Flujo portable real

El usuario puede mapear capas cargadas mediante `layerId` o tablas fisicas de un
GeoPackage parcial entregado por el DBA. Una coincidencia exacta unica se
preselecciona visiblemente; una ausencia o ambiguedad queda sin asignar.

Las capas ya cargadas en QGIS, incluso si proceden de Shapefile, GeoJSON u otro
proveedor vectorial compatible, se capturan a un GPKG temporal. La seleccion
directa de archivo en `0.0.10` admite solamente `.gpkg`; otros formatos deben
cargarse primero como capas. Una entrada GPKG usa
`sqlite3.Connection.backup`, de modo que el snapshot incluye commits presentes
en WAL y no es una copia de archivo inconsistente. El motor abre el resultado
con URI SQLite `mode=ro`, solicita solo atributos declarados y no lee geometria.
Si falla cualquier capa o el backup, elimina el snapshot parcial.

La preparacion muestra progreso y permite cancelar backups por paginas,
calculo SHA-256 y proveedores que respeten `QgsFeedback`. Sigue invocandose en
el hilo UI para no mover objetos `QgsVectorLayer` entre hilos; un proveedor que
ignore `QgsFeedback` puede no interrumpirse hasta terminar la capa actual. El
worker vuelve a calcular el SHA-256 antes de abrir el snapshot y bloquea toda
modificacion posterior a la captura.

`SIG_02` conserva `UNION` distinct, igualdad/NULL de joins, booleanos y la
multiplicidad del `LEFT JOIN`, incluso si un predio coincidente tiene `pk_id`
nulo. Predios, terrenos y ordenamiento se llevan a un staging SQLite temporal
con cache de 4 MiB, lotes de 256 e iteracion por cursor; no se materializan en
listas o diccionarios proporcionales al total. El preflight valida campos y
familias de tipos. Su modulo queda fijado por SHA-256. La regla paso la
comparacion cruzada `passed_synthetic_fixture_v1`: seis filas en cada backend,
las 33 columnas normalizadas iguales y el mismo multiconjunto con
multiplicidad. Esta certificacion se limita al fixture sintetico versionado; no
afirma paridad productiva ni equivalencia de las otras 252 reglas.

## Pruebas locales

```powershell
python tools/test_portable_backend.py
python tools/test_portable_postgis_equivalence.py
python tools/build_plugin_packages.py --version 0.0.9 --tag v0.0.9 --dist dist/dba
python tools/build_gpkg_plugin_packages.py --version 0.0.10 --tag gpkg-v0.0.10 --dist dist/gpkg
python tools/test_plugin_paging_integration.py
python tools/test_plugin_portable_integration.py
& 'C:\Program Files\QGIS 3.44.11\bin\python-qgis-ltr.bat' tools/smoke_qgis_gpkg_editions.py
```

El fixture versionado es JSON sintetico y el generador crea el vector GPKG solo
en un directorio temporal. El harness PostGIS exige variables de entorno
`MT_GPKG_TEST_PG18_*`, solo admite loopback, crea una base aleatoria con prefijo
acotado y la elimina con `DROP DATABASE ... WITH (FORCE)` antes de emitir el
reporte. No se instalo nada en el perfil QGIS `default`.

## Fuera de alcance y gates

- Las otras 252 implementaciones portables y la geometria exacta por regla.
- Paridad con datos productivos o equivalencia general del catalogo 253/253.
- Normalizacion de Shapefile, GeoJSON y FlatGeobuf.
- DuckDB Spatial: aparece `NOT_INSTALLED`; no se ejecuta `INSTALL` ni se usa red.
- Publicacion: el gate GPKG exige licencia, metadata y aprobacion exclusivas.
  Los gates DBA permanecen independientes y cerrados. No hay tag, push ni
  release de ninguna edicion.
- Los disparadores Git quedan separados: `dba-v*` para el workflow DBA y
  `gpkg-v*` para el gate GPKG. Un tag GPKG no puede iniciar el release DBA.

### Estado deliberado del gate de publicacion

Mientras el propietario no apruebe la parte juridica, el comando
`python tools/gpkg_release_gates.py --version 0.0.10 --dist dist/gpkg` debe
terminar bloqueado exclusivamente por:

1. ausencia de `LICENSE` aprobado en cada uno de los seis ZIP;
2. ausencia de `release/gpkg/public_metadata.json` aprobado;
3. ausencia de `release/gpkg/approvals/0.0.10.json` y de la licencia
   first-party raiz aprobada.

Esos nueve mensajes son defensas intencionales de publicacion, no fallos del
motor portable. Cualquier mensaje adicional (payload distinto a la fuente,
SQL, QPSQL, autenticacion, secreto, nombre/ID/version incorrectos o avisos de
terceros diferentes) es un defecto tecnico y debe impedir la entrega. En el
estado verificado de este slice no aparece ninguno de esos defectos tecnicos.
