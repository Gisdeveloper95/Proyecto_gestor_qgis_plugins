# Equivalencia portable RECO_50/RECO_51 — 2026-07-19

`Reco_50` y `Reco_51` quedan en estado
`passed_synthetic_fixture_v1`. La certificación compara tres proveedores sobre
el mismo fixture sintético: PostgreSQL 18.4/PostGIS 3.6.2,
`MappingDataSource` y un GeoPackage SQLite físico.

## Contrato de dos etapas

La ejecución operativa de RECO no termina en el SQL de la regla:

1. La implementación de `Reco_50` o `Reco_51` produce el multiconjunto crudo,
   conservando duplicados y multiplicidad de enriquecimientos.
2. `portable_reco_post_filter.py` calcula de forma independiente el conjunto
   normalizado de `pk_id` habilitados por `reco_post_filter.sql`.
3. El almacén temporal entrega únicamente hallazgos cuyo `pk_id_predio`
   pertenece al alcance, sin deduplicar las filas de resultado.

La normalización elimina espacios exteriores, valores nulos/vacíos y una sola
terminación numérica `.0` de la condición coalescida. Los flags nulos se
interpretan como falsos y la asignación se contrasta como texto exactamente
igual a `2`, reproduciendo el contrato operativo existente.

El plugin GPKG no contiene los SQL PostgreSQL. Los paths y SHA-256 del SQL
canónico se conservan en el manifiesto y se verifican en fuente para demostrar
qué comportamiento fue reimplementado.

## Resultado reproducible

| Métrica | `Reco_50` | `Reco_51` |
| --- | ---: | ---: |
| Filas crudas | 9 | 7 |
| Predios permitidos | 8 | 8 |
| Filas finales | 5 | 3 |
| Filas retiradas | 4 | 4 |
| Columnas estables comparadas | 46 | 46 |

Los tres proveedores coincidieron tanto en el multiconjunto crudo como en el
conjunto de alcance y el multiconjunto final. Se excluyeron únicamente los
valores exactos de `fecha_creacion` y `fecha_modificacion`; cada proveedor
verificó que fueran no nulos y compartidos por las filas de la misma corrida.

| Sujeto | SHA-256 |
| --- | --- |
| Fixture compartido | `98B1C75077B6FEC8F1966F1DBE40BE24CB6B57921103B08FEB398317E94AC30A` |
| Postfiltro portable | `0876038E7902670CD83E375DC3A35DBCFA00EB814DFF635D1503C4ED2E2AEA25` |
| SQL canónico del postfiltro (UTF-8/LF) | `0177F4922CFA01BF64F48F0A1EC0905151FD0E7810CA068B10D9377887A17412` |
| Bundle ejecutable `Reco_50` | `3B3B92189A291E84B69A2FAA34F29F51224E475240479B8E34C22924FB94F217` |
| Bundle ejecutable `Reco_51` | `ED953FB0E4D0EE461C850DFBAFB432C7A45C8875CADD42F5CAF6CD05D644DCF2` |

## Cancelación e integridad

El alcance se construye por lotes en una tabla SQLite temporal con clave
primaria normalizada. El store solo permite filtrar después de confirmar la
transacción. Una cancelación o excepción hace rollback, invalida el estado y
evita reutilizar resultados parciales. La prueba de 20.000 filas confirma
iteración por cursor, lotes acotados y limpieza de temporales.

El runtime verifica antes de importar el wrapper, las primitivas compartidas y
el postfiltro. Si un hash, path, símbolo o contrato del manifiesto diverge, la
regla queda bloqueada; no existe fallback silencioso al SQL PostgreSQL.

## Alcance de la afirmación

Las evidencias autoritativas son:

- `docs/evidence/RECO_50_POSTGIS_GPKG_EQUIVALENCE_2026-07-19.json`;
- `docs/evidence/RECO_51_POSTGIS_GPKG_EQUIVALENCE_2026-07-19.json`;
- `docs/evidence/GPKG_0.0.15_LOCAL_CHECKPOINT_2026-07-19.json`.

La certificación es exclusivamente sintética. No afirma paridad productiva,
equivalencia de las otras 240 reglas ni autorización de publicación.
