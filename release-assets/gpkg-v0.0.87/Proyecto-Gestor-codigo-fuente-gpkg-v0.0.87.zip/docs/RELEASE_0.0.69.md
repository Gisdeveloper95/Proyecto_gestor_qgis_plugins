# Calidad GPKG 0.0.69 — restauración de la interfaz original

`0.0.69` elimina la divergencia visual introducida en las primeras ediciones
GPKG. Las seis variantes vuelven a usar el armazón del plugin PostgreSQL:

- barra superior de ejecución y salidas;
- reglas seleccionables y filtro por grupo;
- resumen por regla;
- detalle paginado, búsqueda y ventana ampliada;
- consola;
- navegación al mapa y formulario;
- exportaciones CSV, XLSX y GeoPackage.

La única sustitución del flujo original es `Conexión PostgreSQL/PostGIS` por
`Fuente de capas / GeoPackage`, con selección entre capas ya cargadas y un
archivo `.gpkg`, más el mapeo explícito de entidades requeridas.

QGIS 3.44.11 aprobó las doce ediciones coexistentes y el workflow GPKG de
selección de regla, ejecución, paginación, mapa y exportaciones CSV/XLSX/GPKG.

Publicado en:

`https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/tag/gpkg-v0.0.69`

Repositorio estable de QGIS:

`https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/latest/download/plugins.xml`
