# Calidad GPKG 0.0.84 — filtros de predio sin fugas

Esta corrección no modifica las 253 SQL canónicas ni los planes
`generated_plan_v1`. Corrige la etapa común que aplica los filtros operativos
a los resultados de todas las reglas.

## Causa comprobada

`0.0.83` dejaba pasar cualquier hallazgo cuando `pk_id_predio` llegaba vacío,
aunque otras columnas demostraran que sí pertenecía a un predio general.

El caso real más claro es `Jur_21`. Su SQL devuelve `pk_id_predio` nulo por la
condición propia de la consulta, aunque conserva el identificador verdadero de
`LC_Gen_Predio` en `pk_tabla_error_1`. En el paquete analizado las 184 filas
crudas —todas fuera de los alcances NPH e Informalidad probados— atravesaban el
filtro de `0.0.83`.

## Corrección

- Se usa `pk_id_predio` cuando está disponible.
- Si está vacío, solo se admite como respaldo una llave de error cuya tabla
  esté identificada explícitamente como `LC_Gen_Predio`.
- Un hallazgo geográfico genuinamente huérfano continúa visible: no representa
  un predio al cual se pueda aplicar NPH, PH, Condominio o Informalidad.
- Editar un bloque específico activa inmediatamente ese perfil para la corrida;
  ya no es necesario editarlo y luego recordar cambiar otro selector.
- Cambiar el grupo visible, buscar reglas o marcar todas las visibles conserva
  el perfil activo.

## Condición del predio verificada

En `pvall_044_nu/actualizacion.gpkg`, los 1.065 registros de
`lc_gen_predio.condicion` coinciden con el carácter 22 de
`numero_predial_nacional`:

- `0`: predio formal/NPH, salvo el tratamiento especial de visita informal.
- `2` y `5`: informalidad.
- `8`: condominio.
- `9`: propiedad horizontal.

Los filtros generales de cancelación y estado de asignación se aplican antes
del perfil específico.

## Verificación

- Regresión del almacén para llave directa, respaldo seguro de
  `LC_Gen_Predio` y hallazgo sin predio resoluble.
- Ejecución local sobre el paquete real: alcance Informalidad sin filtro de
  asignación contiene 37 predios; `Reco_48` conserva 35 hallazgos y `Jur_21`
  conserva 0 de sus 184 filas crudas.
- Smoke QGIS: editar un perfil lo activa; cambiar de grupo y marcar todas las
  reglas visibles no lo desactiva.
- Los plugins hijos conservan la misma política y el mismo runtime de su padre.

`0.1.0` continúa bloqueado hasta autorización expresa del propietario.
