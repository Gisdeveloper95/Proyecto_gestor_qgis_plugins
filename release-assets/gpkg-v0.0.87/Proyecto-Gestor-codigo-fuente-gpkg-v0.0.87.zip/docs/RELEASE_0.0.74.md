# Calidad GPKG 0.0.74 - filtros RECO configurables

`0.0.74` permite controlar desde QGIS los cuatro filtros operativos que se
aplican después de las reglas de Reconocimiento/Calificación.

## Controles

En las ediciones Total y RECO aparece el panel **Filtros de alcance RECO** con
cuatro opciones independientes:

1. excluir predios cancelados;
2. exigir estado de asignación de reconocimiento igual a 2;
3. excluir condiciones 2, 5, 8 y 9;
4. excluir predios marcados para visita informal.

Todas inician activas para conservar el resultado histórico. El usuario puede
apagar o encender cada opción antes de ejecutar. La selección se guarda entre
sesiones y los controles quedan bloqueados mientras una corrida está activa,
por lo que una validación no puede cambiar de criterio a mitad de proceso.

Si se apagan las cuatro opciones, el postfiltro no se ejecuta y se conservan
las filas crudas generadas por cada regla RECO.

## Trazabilidad y compatibilidad

- La consola registra la política exacta usada por la corrida.
- El resumen distingue filas crudas, filas conservadas y descartes RECO.
- PostGIS y GPKG aplican las mismas cuatro decisiones.
- No se modificaron las 253 reglas canónicas ni sus implementaciones
  portables.
- No se alteraron ni regeneraron las evidencias históricas de homologación.
- Los seis ZIP GPKG se construyen juntos y son reproducibles byte a byte.

La edición DBA/PostGIS equivalente se construye localmente como `0.0.10`; no
forma parte de la publicación pública de Calidad GPKG.
