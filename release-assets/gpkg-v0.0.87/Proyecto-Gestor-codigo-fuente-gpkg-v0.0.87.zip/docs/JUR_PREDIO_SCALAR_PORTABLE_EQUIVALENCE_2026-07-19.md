# Equivalencia portable del lote Jurídico predio-scalar

## Alcance

Este documento fija la homologación sintética de `Jur_05`, `Jur_12`, `Jur_13`,
`Jur_14`, `Jur_15`, `Jur_17` y `Jur_18`. No se traduce SQL en tiempo de
ejecución: cada predicado fue reimplementado sobre atributos GPKG y contrastado
contra su SQL canónico en PostgreSQL.

Las siete reglas usan las mismas seis entidades base y un contrato de 48
columnas. `Jur_05` añade `juridico_cambio_juridico`; `Jur_18` añade
`area_terreno_registral`. Ninguna lee geometría.

## Contrato de integridad

- Fixture: `tools/fixtures/portable_jur_predio_scalar_fixture.json`
- SHA-256 del fixture: `6B2EB1DC5F9228653AA407CC0B3831CC5EE32A4ED1B67600DB5C5563F4714DA7`
- Soporte común: `quality_core/portable_predio_scalar.py`
- SHA-256 del soporte: `49E2E1609460A837D62E7337BD85E313EB69547B54AE4968A12360CE048534EF`
- Primitivas: `5D637139EA41938D90635C210DDC481F1F955B32F3A5AA206A510EACF93317B2`

Cada wrapper y su bundle agregado se fijan separadamente en
`quality_core/portable_manifest.json`. Los siete JSON bajo `docs/evidence/`
registran SQL, fixture, normalizador, wrapper, soportes, versiones observadas,
conteos y hashes de comparación.

## Casos cubiertos

El fixture verifica predios activos, cancelados y nulos; matrícula nula, cero y
positiva; áreas nulas, cero y positivas; booleanos nulos/falsos/verdaderos;
números prediales nulos, cortos, códigos `0/2/3/4` y ocho caracteres finales;
claves nulas, excepciones por regla, asignaciones múltiples y catálogos con
multiplicidad.

Los resultados se comparan como multiconjunto de las 46 columnas estables. Los
dos timestamps se excluyen solo por su valor exacto, pero deben ser no nulos,
constantes y compartidos por todas las filas de una corrida.

## Resultado

Las tres ejecuciones —PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y
GeoPackage físico— pasaron para las siete reglas. Los conteos esperados fueron
`4/2/2/1/2/5/9`; la base desechable y los snapshots temporales se eliminaron.

Esta evidencia no autoriza afirmar paridad sobre datos productivos, ni sobre
las otras 242 reglas todavía no homologadas.
