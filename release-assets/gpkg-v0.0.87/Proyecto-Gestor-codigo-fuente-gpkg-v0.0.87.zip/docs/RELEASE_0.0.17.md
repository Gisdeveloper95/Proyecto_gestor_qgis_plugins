# Calidad GPKG 0.0.17 — lote RECO de estados y banderas

`0.0.17` amplía exclusivamente las seis ediciones Calidad/GPKG. Las seis
ediciones DBA/PostGIS siguen en `0.0.9` y conservan las 253 reglas canónicas.

| Familia | Canónicas | Portables GPKG | Incorporadas en 0.0.17 |
|---|---:|---:|---|
| Total | 253 | 32 | 6 |
| Jurídico | 82 | 13 | — |
| RECO | 71 | 15 | `Reco_03`, `Reco_04`, `Reco_05`, `Reco_16`, `Reco_18`, `Reco_48` |
| SIG | 16 | 4 | — |
| PH | 77 | 0 | `backend_unsupported` |
| Económico | 7 | 0 | `backend_unsupported` |

Las seis reglas nuevas ejecutan directamente sobre GPKG/SQLite mediante el
backend portable; no migran el archivo a PostgreSQL ni distribuyen SQL
PostgreSQL en los ZIP. Mantienen semántica de `NULL`, booleanos, subcadenas,
catálogos, excepciones, duplicados y el filtro operativo global RECO.

La suite completa comparó las 32 reglas contra el SQL canónico en PostgreSQL
18.4/PostGIS 3.6.2, `MappingDataSource` y GPKG físico sintético. QGIS 3.44.11
repitió la ejecución con archivo GPKG directo, capas OGR cargadas y proveedor
`memory`. Los seis artefactos `0.0.17` son reproducibles byte por byte.

`Reco_16` merece atención del propietario del catálogo: su predicado crudo
requiere `reconocimiento_estado_asignacion <> 2`, pero el filtro global RECO
solo admite `reconocimiento_estado_asignacion = 2`. El resultado operativo es
por definición vacío. La homologación conserva exactamente ese comportamiento
y la evidencia fija 1 fila cruda y 0 finales; corregir la lógica canónica será
una decisión separada para ambos motores.

También se aisló `Jur_10.sql`, cuyo nombre y entrada de catálogo son `Jur_10`
pero cuyo resultado y unión de excepciones usan `Jur_06`. No se homologó con
esa identidad inconsistente.

Checkpoint técnico:
`docs/evidence/GPKG_0.0.17_LOCAL_CHECKPOINT_2026-07-19.json`.
La afirmación se limita a fixtures sintéticos y no implica paridad productiva
ni 253/253.

No se creó tag, push, release, instalación de perfil ni despliegue. El texto
`gpkg-v0.0.17` empleado en el build es solo metadata interna del artefacto.
