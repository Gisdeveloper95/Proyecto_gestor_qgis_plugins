# Calidad GPKG 0.0.86 — perfiles de producción automatizados

Esta versión convierte los perfiles simplificados en canales administrados. Un
coordinador configura reglas y filtros desde un plugin padre, elige crear o
actualizar un perfil y autoriza su equipo con su cuenta de Mapper GIS. El resto
del proceso es automático.

## Flujo para producción

1. El coordinador marca reglas, grupos y filtros en el plugin padre.
2. Selecciona `Crear o actualizar perfil de producción…`.
3. Crea un canal o elige uno existente.
4. El Centro de Perfiles registra una revisión y dispara el constructor
   confiable.
5. GitHub publica el nuevo ZIP y actualiza el único `plugins.xml` de perfiles.
6. Los trabajadores reciben la actualización desde QGIS sin reinstalaciones
   manuales.

La exportación ZIP local permanece disponible como alternativa independiente.

## Seguridad y persistencia

- QGIS usa el acceso por dispositivo del portal; el coordinador no conoce ni
  almacena tokens GitHub.
- La autorización queda cifrada en QGIS Authentication Manager.
- Turso conserva identidad estable, revisiones, estado de build y auditoría.
- Vercel solo controla el proceso. No recibe GPKG, filas ni geometrías.
- GitHub Actions toma exclusivamente una especificación validada y herramientas
  confiables desde `main`.

## Contrato del perfil

- El identificador `perfil_gpkg_<uuid>` no cambia al actualizar.
- Cada canal sigue su propia serie `0.0.x`.
- El ZIP contiene solo planes `generated_plan_v1` seleccionados.
- Los filtros operativos se versionan junto con las reglas.
- Los perfiles mixtos conservan el selector de sus grupos; los perfiles de una
  familia continúan bloqueados y simplificados.

Repositorio QGIS común:

`https://github.com/Gisdeveloper95/Mapper_GIS_Catastral_QGIS_Perfiles/releases/latest/download/plugins.xml`

Las 253 SQL y los planes canónicos no cambian respecto de `0.0.82`. `0.1.0`
continúa bloqueado hasta autorización expresa del propietario.
