# Calidad GPKG 0.0.13 — cuarto slice local

`0.0.13` amplía únicamente la edición Calidad GPKG con la homologación
independiente de `SIG_01`. Los seis plugins DBA/PostGIS permanecen en `0.0.9`,
conservan las 253 consultas canónicas y sus ZIP siguen byte a byte iguales al
checkpoint anterior.

| Familia | Plugin DBA local | Plugin GPKG local | Reglas GPKG |
| --- | --- | --- | --- |
| Total | `validador_calidad_total` 0.0.9 | `calidad_gpkg_total` 0.0.13 | `SIG_01`, `SIG_02`, `SIG_09`, `SIG_10` |
| RECO | `validador_calidad_reco` 0.0.9 | `calidad_gpkg_reco` 0.0.13 | 0; `backend_unsupported` |
| PH | `validador_calidad_ph` 0.0.9 | `calidad_gpkg_ph` 0.0.13 | 0; `backend_unsupported` |
| Jurídico | `validador_calidad_juridico` 0.0.9 | `calidad_gpkg_juridico` 0.0.13 | 0; `backend_unsupported` |
| SIG | `validador_calidad_sig` 0.0.9 | `calidad_gpkg_sig` 0.0.13 | `SIG_01`, `SIG_02`, `SIG_09`, `SIG_10` |
| Económico | `validador_calidad_economico` 0.0.9 | `calidad_gpkg_economico` 0.0.13 | 0; `backend_unsupported` |

## Cambios técnicos

- `SIG_01` reproduce la selección formal/informal por posición 22, predios
  activos, semántica NULL, `UNION DISTINCT`, excepciones y multiplicidad de
  todos los catálogos asociados.
- La regla usa staging SQLite en disco, lotes de 256, caché de 4 MiB, cursor de
  salida, cancelación y limpieza automática.
- El manifiesto declara las columnas canónicas de salida de las cuatro reglas.
- La tabla paginada y el CSV conservan la proyección heredada y agregan
  dinámicamente toda columna canónica declarada; `SIG_01` no oculta estados,
  asignación, área, usuarios ni timestamps en la presentación.
- Los módulos se importan de forma diferida y solo después de verificar
  implementación, archivos auxiliares y hash agregado del bundle.
- Los seis ZIP verifican esa integridad internamente; las pruebas adversariales
  rechazan alteraciones de `portable_primitives.py` y del bundle.
- Cada edición fragmentada empaqueta únicamente el runtime y las
  implementaciones declaradas en su propio manifiesto. Las cuatro ediciones
  todavía sin reglas no distribuyen módulos SIG ni su helper.
- La herramienta de evidencia permite escribir una regla nueva de forma
  selectiva y rehúsa sobrescribir evidencia histórica divergente.

## Evidencia

Sobre el fixture CC0, PostgreSQL 18.4/PostGIS 3.6.2, el proveedor en memoria y
un `GeoPackageDataSource` respaldado por un `.gpkg` físico produjeron 18/18
filas de `SIG_01`. Coincidieron en las 46 columnas estables y en el multiconjunto
`CC7EF9064D91BAB2022BE6B3B3CB2D4EF1C3DA1FFD69B816762FA10738A35F20`.
Solo se excluyó el valor exacto de los dos timestamps creados con `now()`; se
comprobó que fueran no nulos, constantes y compartidos dentro de cada corrida.

La prueba adicional sobre un GPKG temporal creado desde la restauración local
produjo 9.528/9.528 filas equivalentes. Ese archivo se eliminó y no se usa como
fixture ni amplía la afirmación formal de equivalencia.

QGIS 3.44.11 validó los doce plugins coexistentes y ejecutó `SIG_01`, `SIG_02`,
`SIG_09` y `SIG_10` tanto desde archivo GPKG como desde capas cargadas mediante
snapshot; `SIG_02` también pasó con capas del proveedor QGIS `memory`. Se probó
el cableado del botón Cancelar hasta el worker. Las pruebas puras cubren 20.000
omisiones entregadas por cursor, memoria acotada, cancelación durante staging y
salida, y limpieza.

## Construcción local

```powershell
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9 --dist dist\dba
python tools\build_gpkg_plugin_packages.py --version 0.0.13 --tag gpkg-v0.0.13 --dist dist\gpkg
python tools\test_plugin_portable_integration.py
```

El valor `--tag` solo fija las rutas internas de los artefactos locales; no
crea un tag Git ni publica nada. Los hashes de los doce ZIP están en
`docs/evidence/GPKG_0.0.13_LOCAL_CHECKPOINT_2026-07-19.json`.

## Estado de publicación

Los gates técnicos pasan, pero el checkpoint sigue deliberadamente no
publicable. Permanecen exactamente nueve bloqueos externos:

1. seis ZIP GPKG sin `LICENSE` first-party aprobado;
2. metadata pública exclusiva de Calidad GPKG pendiente;
3. aprobación versionada `0.0.13` pendiente;
4. licencia first-party raíz pendiente.

No se realizó push, tag, release, instalación en el perfil del usuario ni
despliegue.
