# Uso de plugins QGIS SQL - v0.0.9 (desarrollo local)

Esta version es una candidata tecnica local y no esta autorizada para
publicacion. `0.0.8` permanece retirada para siempre; `0.0.9` sigue bloqueada
por los gates de licencia, procedencia, identidad, RECO y autoridad externa de
`docs/RELEASE_GATES.md`.

## Instalacion

Version minima de QGIS declarada por los paquetes: `3.44.0` LTR.

`0.0.9` se instala exclusivamente desde el build local en el perfil aislado de
desarrollo. Genere los seis paquetes sincronizados desde la raiz del repositorio:

```powershell
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9
```

En QGIS use:

```text
Plugins > Administrar e instalar plugins > Instalar desde ZIP
```

Los ZIP quedan en el directorio `dist` de este checkout. No use para esta prueba
la URL publica `releases/latest`: no existe una release autorizada de `0.0.9` y
esa URL no demuestra el contenido local.

El perfil validado es `MapingToolDev`; no copie estos plugins al perfil `default`.

## Conexion

El plugin lee conexiones PostgreSQL guardadas en QGIS. Se recomienda asociar la
conexion con una configuracion `authcfg` del gestor de autenticacion de QGIS. El
plugin resuelve esas credenciales solo en memoria para QtSql y conserva el
identificador `authcfg` en la URI de las capas.

Si una conexion no usa `authcfg`, complete manualmente:

- Host
- Puerto
- Base
- Usuario
- Clave

Para la base local restaurada:

```text
Host: localhost
Puerto: 5432
Base: cartoflow_pruebas
Usuario: gestor_validator_ro
```

El plugin no guarda claves nuevas en sus ajustes. Una clave manual permanece
solo durante la sesion; las conexiones protegidas delegan el almacenamiento al
gestor de autenticacion de QGIS.

Para evitar que un proyecto QGIS guarde una clave dentro de la URI PostgreSQL,
la carga automatica de `lc_gen_predio` exige `authcfg` cuando la conexion usa
contrasena. Con autenticacion sin clave (por ejemplo, un servicio externo) o una
capa ya cargada por el usuario, el visor sigue funcionando sin incrustar secretos.

## Ejecucion

1. Abrir el plugin desde el menu `Reglas de Calidad SQL`.
2. Elegir o completar la conexion.
3. Pulsar `Probar conexion`.
4. Marcar las reglas requeridas.
5. Filtrar por grupo si se usa el plugin maestro.
6. Pulsar `Ejecutar marcadas` o `Ejecutar grupo`.
7. Revisar la tabla `Resumen`.
8. Hacer clic sobre una regla del resumen para filtrar el detalle.
9. Revisar la tabla `Detalle`.
10. Exportar con `CSV`, `Excel` o `GPKG`.

El detalle muestra como maximo 250 hallazgos por pagina. `Anterior`,
`Siguiente`, el filtro por regla y la busqueda consultan el almacen SQLite local
en disco; no ocultan filas de una tabla materializada completa en memoria.

La ejecucion corre en segundo plano para no congelar QGIS. El boton `Cancelar`
solicita a PostgreSQL la interrupcion de la consulta activa y detiene la cola. Si
el servidor no confirma la cancelacion, la consulta queda limitada por el timeout
configurado. Descargar o desactivar el plugin durante una consulta desconecta la
interfaz y conserva el `QThread` hasta que termine; nunca se fuerza
`QThread.terminate()`.

La interfaz usa bloques colapsables para `Conexion`, `Reglas`, `Resumen`, `Detalle` y `Consola`. Si el panel queda largo, use el scroll vertical del dock. El encabezado identifica el catalogo o familia activa mediante texto y color, sin simular un boton.

En reglas RECO, el plugin ejecuta primero la SQL completa y despues aplica automaticamente el alcance operativo heredado del validador de referencia. El resumen distingue `Filas SQL`, filas descartadas y `Predios finales`; el usuario no tiene que activar ningun perfil o filtro previo.

## Navegacion

- Clic en una fila del detalle: selecciona y hace zoom al predio.
- Doble clic en una fila del detalle: abre el formulario nativo de QGIS.
- Si `lc_gen_predio` no esta cargada, el plugin intenta cargar `actualizacion.lc_gen_predio` desde la misma conexion.
- Si una regla no trae `pk_id_predio`, el plugin intenta ubicar el predio por `numero_predial_nacional`.

## Exportaciones

- `CSV`: detalle completo con separador `;`, leido por cursor desde disco.
- `Excel`: libro `.xlsx` escrito fila a fila con hojas de resumen, detalle, una
  hoja por regla con hallazgos y consola. Si una hoja alcanza el limite de Excel,
  continua en un split numerado. Antes de reemplazar el destino se comparan el
  total, los conteos exactos por regla y los conteos de cada split contra SQLite,
  y se comprueba la integridad OOXML.
- `GPKG`: GeoPackage escrito por paginas con resumen y una capa por regla;
  en `0.0.9` solo incorpora la geometria que puede asociar con
  `actualizacion.lc_gen_predio`.

`Anadir al mapa` construye primero un GPKG temporal local por paginas y carga
capas OGR respaldadas por ese archivo. Al reemplazar la corrida o descargar el
plugin se retiran esas capas y se elimina la cache temporal.

La fuente geometrica exacta por regla SIG sigue pendiente de un slice posterior.
`0.0.9` no afirma que la geometria de `lc_gen_predio` sustituya lineas, puntos u
otras entidades causantes del hallazgo. CSV, XLSX y GPKG se escriben primero en
un temporal hermano y solo reemplazan el destino tras completar y verificar sus
conteos. Durante una validacion, mapa y exportaciones permanecen deshabilitados
para impedir snapshots parciales.

## Consola y errores

La consola del plugin muestra inicio, fin, conteos, tiempos y errores completos por regla. Tambien imprime los mismos mensajes en la consola Python/QGIS.

Las reglas pesadas pueden superar el timeout configurado. En la restauracion
canonica de PostgreSQL 18, `SIG_09` necesito unos `203 s` para una muestra; por
eso el timeout por defecto del plugin es `300 s`. Esta latencia queda registrada
como deuda de rendimiento para una version `0.0.x` posterior.

## SIG_16

`SIG_16` queda activa. Si existe `public.perimetro_urbano_20260702`, se ejecuta normalmente.

Si la capa no existe, el plugin marca la regla como `dependencia` y continua con las demas reglas. No crea una tabla vacia ni simula el resultado.

El validador de catalogo `tools/validate_rules_against_db.py` usa la misma
clasificacion. Su reporte esperado registra `252` reglas `ok` y una
`dependencia` (`SIG_16`), no un error generico.

## Alcance de v0.0.9

- Solo lectura sobre PostgreSQL/PostGIS.
- Hallazgos y filtro RECO en un SQLite temporal local, con escrituras atomicas
  por regla y buffers de hasta 256 filas.
- Tabla de detalle paginada en bloques de 250; busqueda y conteos desde disco.
- Exportacion incremental CSV, Excel y GPKG; mapa respaldado por cache GPKG.
- La cancelacion revierte la regla activa y conserva las reglas ya confirmadas.
- No inserta inconsistencias en tablas de la base.
- No almacena credenciales.
