# Calidad GPKG 0.0.76 - navegación y revisión estable

`0.0.76` mejora la experiencia de revisión de los seis plugins Calidad GPKG
sin cambiar el significado ni la implementación de las 253 reglas.

## Cambios visibles

- Cada ejecución elimina automáticamente resultados temporales, capas de
  resultados y cachés de la corrida anterior.
- Los seis plugins ofrecen filtros de procesamiento por grupo, búsqueda y
  selección de reglas visibles.
- El resumen usa nombres comprensibles y observaciones funcionales; ya no
  muestra hashes internos de implementación.
- Un doble clic sobre una regla sin hallazgos informa que no tiene
  inconsistencias. Si tiene hallazgos, abre su detalle filtrado.
- El detalle puede listar únicamente reglas con inconsistencias.
- El plugin maestro usa selectores jerárquicos de grupo y regla.
- La paginación presenta como máximo 100 filas y actualiza las tablas con
  señales y repintado suspendidos para evitar bloqueos de QGIS.
- El detalle ordena primero PK ID, NPN, Proyecto e ID Regla; este último se
  resalta en negrita.
- Un clic selecciona y acerca el predio. Un doble clic conserva el formulario
  nativo de QGIS abierto para su revisión o edición.
- Cuando la fuente es un GeoPackage directo, `lc_gen_predio` se carga
  automáticamente al proyecto para habilitar navegación y formulario.
- La consola distingue errores, advertencias, ejecuciones correctas y mensajes
  informativos mediante colores.

## Compatibilidad y alcance

- Se construyen juntos Total, Económico, Jurídico, PH, RECO y SIG.
- Los filtros operativos RECO siguen siendo configurables y se muestran
  únicamente en ediciones que contienen reglas RECO.
- No se modificaron SQL canónicas, adaptadores portables, evidencia de
  homologación ni contratos de salida.
- No se distribuyen datos reales, geometrías, credenciales ni activos
  heredados.
