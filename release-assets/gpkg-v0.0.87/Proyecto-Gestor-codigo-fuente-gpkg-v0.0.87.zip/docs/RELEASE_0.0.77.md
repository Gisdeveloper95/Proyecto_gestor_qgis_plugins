# Calidad GPKG 0.0.77 - navegación precisa y formulario profesional

`0.0.77` mejora la navegación desde Detalle de Inconsistencias sin cambiar el
catálogo ni el resultado de las 253 reglas portables.

## Cambios visibles

- Un clic sobre una inconsistencia acerca el mapa hasta una escala operativa:
  1:800 para geometrías puntuales y como máximo 1:1500 para predios.
- El registro seleccionado destella seis veces en rojo y amarillo, además de
  conservar la selección normal de QGIS.
- Cuando se trabaja con un GeoPackage directo, el plugin busca un proyecto
  `.qgz` en la misma carpeta.
- Si el proyecto contiene `lc_gen_predio`, se importan sus pestañas, grupos,
  widgets y relaciones al proyecto actual sin reemplazar el trabajo abierto.
- El paquete real `pvall_044_nu` conserva 12 pestañas, 109 campos configurados
  y el grafo de relaciones requerido por sus subformularios.
- Si no se entrega un `.qgz`, el formulario básico de QGIS continúa disponible
  y el plugin explica la causa en la consola.

## Alcance

- Se construyen y publican juntos Total, Económico, Jurídico, PH, RECO y SIG.
- No se distribuye el proyecto o GeoPackage real dentro de los ZIP.
- No se modifican SQL, adaptadores, evidencia de equivalencia ni datos.
- La configuración profesional procede del proyecto QGIS entregado junto al
  paquete de trabajo y se carga únicamente desde el equipo del operador.
