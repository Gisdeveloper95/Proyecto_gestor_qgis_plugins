# Calidad GPKG 0.0.80 - generador múltiple de perfiles

`0.0.80` corrige el flujo de exportación de plugins simplificados y separa
visualmente los perfiles operativos de los seis plugins padre.

## Generación desde Total

`Exportar > Generar perfiles simplificados…` abre un modal con selección
múltiple para:

- Total;
- Económico;
- Jurídico;
- PH;
- RECO;
- SIG.

Cada opción indica cuántas reglas marcadas contiene. Se puede generar una,
varias o las seis salidas en la misma operación. Total conserva todas las
reglas marcadas; cada salida específica conserva únicamente las reglas
marcadas de su familia.

## Generación desde padres específicos

Económico, Jurídico, PH, RECO y SIG ofrecen el mismo comando, pero solo
permiten generar su propia edición simplificada.

## Interfaz de los perfiles

- Se eliminó el botón duplicado situado sobre la tabla de reglas.
- Se eliminó el aviso visual `PERFIL BLOQUEADO`.
- Ya no se solicita un identificador técnico al usuario.
- El nombre opcional se convierte automáticamente en un nombre e identificador
  sencillos.
- Los perfiles se instalan en un menú y barra independientes
  `Perfiles GPKG`.
- Total, Económico, Jurídico, PH, RECO y SIG reciben miniaturas SVG distintas.
- El operador conserva fuente, ejecución, detalle, navegación y exportaciones,
  sin la configuración avanzada de los padres.

## Compatibilidad

- Los perfiles producidos por `0.0.79` continúan siendo legibles.
- Las 253 reglas y su evidencia de equivalencia permanecen sin cambios.
- Los seis plugins GPKG padre se publican juntos como `0.0.80`.
