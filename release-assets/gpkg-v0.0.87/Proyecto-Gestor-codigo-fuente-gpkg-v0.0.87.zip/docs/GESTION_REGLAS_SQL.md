# Gestión del catálogo de reglas SQL

## Arquitectura

Cada regla se administra mediante dos piezas:

- SQL editable: `quality_core/rules/<familia>/<Regla>.sql`
- Metadatos: `quality_core/rules/manifest.json`

Los plugins maestro y fragmentados se generan desde ese único catálogo. No se deben copiar reglas manualmente entre plugins.

## Modificar una regla

1. Consultar la ruta exacta y editar su archivo `.sql`.
2. Confirmar que el encabezado `-- name:` conserva el mismo ID.
3. Validar catálogo y base de pruebas.
4. Construir los paquetes.

```powershell
python tools/manage_rules.py show --id Reco_40
python tools/manage_rules.py validate
python tools/validate_rules_against_db.py --rule Reco_40 --mode compile
python tools/build_plugin_packages.py --version 0.0.9 --tag v0.0.9
```

Las herramientas CLI leen la clave desde `PGPASSWORD` cuando el entorno de
pruebas la necesita. No escriba claves literales en comandos, scripts o
documentacion versionada.

El título, componente o tipo de resultado también se cambian sin editar JSON:

```powershell
python tools/manage_rules.py set --id Reco_40 --title "Nuevo título funcional"
python tools/manage_rules.py set --id Reco_40 --component Calificacion --result-type alfanumerica
```

## Agregar una regla

Crear una plantilla y registrar automáticamente el manifiesto:

```powershell
python tools/manage_rules.py add --id Reco_72 --family reco --component Calificacion --title "Descripción funcional"
```

También puede incorporarse una SQL ya preparada:

```powershell
python tools/manage_rules.py add --id Reco_72 --family reco --component Calificacion --title "Descripción funcional" --from-sql C:\ruta\Reco_72.sql
```

Después se edita `quality_core/rules/reco/Reco_72.sql` y se ejecutan las validaciones.

## Retirar sin borrar

```powershell
python tools/manage_rules.py disable --id Reco_40
```

La regla permanece versionada en el código fuente, pero su SQL deja de incluirse en los seis ZIP y no aparece en la lista ejecutable. Para recuperarla:

```powershell
python tools/manage_rules.py enable --id Reco_40
```

## Consultar y validar

```powershell
python tools/manage_rules.py list
python tools/manage_rules.py list --family sig
python tools/manage_rules.py show --id SIG_16
python tools/manage_rules.py validate
```

`validate` detecta conteo incorrecto, IDs repetidos, formato de ID incompatible con la familia, metadatos vacíos, tipo de resultado inválido, archivo faltante, SQL sin encabezado, encabezado con otro ID y archivos SQL no registrados.

## Alcance operativo RECO

Las 71 reglas RECO se ejecutan completas. Después de cada consulta, el plugin conserva solamente los predios admitidos por `quality_core/reco_post_filter.sql`. Esta política replica los cuatro filtros finales del validador de referencia y no modifica internamente cada regla.

Al cambiar ese archivo se altera el alcance final de todas las reglas RECO, por lo que debe validarse de forma separada. El resumen conserva trazabilidad mostrando filas SQL, descartadas por alcance y predios finales. Para comprobar equivalencia con las reglas Python que tengan contraparte:

```powershell
python tools/audit_helen_vs_sql.py --rule Reco_50 --rule Reco_51
```

## Recomendación operativa

No cambie el ID de una regla publicada para modificar su lógica. Mantenga la llave estable y cambie título o SQL. Si la lógica representa otra validación, cree una regla nueva. Antes de publicar, ejecute validación del catálogo, compilación contra PostgreSQL, construcción de los seis ZIP y verificación de `plugins.xml`.

El smoke test de interfaz debe ejecutarse con el Python de QGIS, no con el Python general del equipo:

```powershell
& "C:\Program Files\QGIS 3.44.11\bin\python-qgis-ltr.bat" tools\smoke_qgis_plugin_ui.py
```

La prueba carga y descarga los seis plugins, verifica el menú y botón compartidos, crea cada dock y confirma las tablas y controles principales.
