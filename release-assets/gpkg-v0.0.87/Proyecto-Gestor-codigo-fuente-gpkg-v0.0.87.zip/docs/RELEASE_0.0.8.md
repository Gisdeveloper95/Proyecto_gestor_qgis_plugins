# Validadores SQL QGIS 0.0.8

## Estado

Borrador local, no publicado y permanentemente no publicable. No se creara el
tag `v0.0.8`: la auditoria RECO no demostro equivalencia general y el contrato
del catalogo conserva seis inconsistencias. Las aprobaciones de licencia y
procedencia siguen siendo necesarias para una version posterior, pero no
reactivaran esta linea base como release.

## Cambios preparados

- Compatibilidad objetivo con QGIS `3.44` LTR y PostgreSQL `18` en el puerto
  estandar `5432`.
- Deteccion local de `psql.exe` de PostgreSQL 18, conservando 17 y 16 como
  alternativas.
- Eliminacion de claves predeterminadas literales en las herramientas de
  validacion y auditoria.
- Uso efectivo de `authcfg`: QtSql obtiene credenciales transitorias del gestor
  de autenticacion y las URI PostgreSQL conservan el identificador protegido.
- Metadatos validos para QGIS: categoria `Database`, limites 3.44--3.99 y
  declaracion explicita de que no existe proveedor Processing.
- Timeout inicial de `300 s`: `SIG_09` necesito aproximadamente `203 s` en el
  fixture restaurado y queda pendiente su optimizacion.
- Cancelacion cooperativa de la consulta activa mediante `pg_cancel_backend` y
  descarga segura: si el backend no termina dentro de la espera acotada, el
  hilo se desconecta de la interfaz y se conserva hasta finalizar.
- Reportes de validacion alineados con la interfaz: la ausencia del perimetro
  urbano se registra como `dependencia` de `SIG_16`, no como error generico.
- Gates de publicacion que verifican licencia, procedencia, alcance de la
  autorizacion y hashes del contenido aprobado antes de cualquier llamada a
  GitHub.
- Gate explicito para confirmar que `repository`, `tracker`, `homepage` y el
  repositorio de distribucion usados por QGIS sean publicos y aprobados.
- Reconstruccion y comparacion byte por byte del `plugins.xml` completo.
- Bundle separado con changelog, avisos, SBOM SPDX JSON, manifiesto,
  copia de la aprobacion y sus evidencias, `SHA256SUMS` y firma detached
  RSA-SHA256 con clave/trust anchor externos.

## Dependencia conocida

`SIG_16` continua habilitada. Si falta `public.perimetro_urbano_20260702`, se
reporta como `dependencia`; no se crea una tabla vacia ni se simula un resultado.

## Evidencia funcional real en QGIS 3.44.11

El perfil activo se recupero en
`%LOCALAPPDATA%/MapingTool/qgis_profiles/profiles/MapingToolDev`, fuera de
OneDrive. El perfil anterior se conserva como evidencia cifrada y no participa
en nuevas pruebas. La recuperacion:

- roto unicamente la clave del rol tecnico `gestor_validator_ro`;
- conservo `default_transaction_read_only=on`, sin privilegios administrativos
  ni `CREATE` sobre `actualizacion`;
- creo un `authcfg` nuevo sin clave literal en `QGIS3.ini`;
- habilito e instalo los seis plugins sincronizados `0.0.8`;
- verifico que la rotacion no modificara el historial de consultas de pgAdmin
  y que la clave generada no apareciera en logs de PostgreSQL o pgAdmin.

El smoke funcional ejecuto una regla acotada por cada familia desde el plugin
total y termino con `5.489` hallazgos:

| Familia | Regla | Filas finales | Estado |
| --- | --- | ---: | --- |
| Economico | `Eco_02` | 0 | correcta |
| Juridico | `Jur_02` | 3.195 | correcta |
| PH | `PH_02` | 3 | correcta |
| RECO | `Reco_50` | 228 | correcta tras filtro posterior |
| SIG | `SIG_03` | 2.063 | correcta |

Tambien se comprobo una busqueda con una sola fila visible, seleccion de un
predio con geometria no vacia, apertura del formulario QGIS, cuatro capas de
resultados con `5.489` geometrias y las tres exportaciones:

| Artefacto | Tamano (bytes) | SHA-256 |
| --- | ---: | --- |
| `live_workflow.csv` | 2.026.650 | `8F3304DD56E4C74D847A28617374A1B15D8F3BC423F16B11786AF349EBDD7571` |
| `live_workflow.xlsx` | 1.611.894 | `72E6E67E53003C05D95C0F89F899F4278096D4E79C8527FCFBD61321AC377916` |
| `live_workflow.gpkg` | 2.740.224 | `25FC5E410E0AADC3F56A72567B9997782EEC689B6466F4879E70ADDA97A27B59` |
| `live_workflow_report.json` | 2.569 | `E4223D0C2700BB71DE42A700595C6A28F41C25F5241166F26D5C17640A5C8F0B` |

La evidencia esta en
`workspaces/qgis_profiles/live_workflow_0.0.8_local_profile`. La navegacion y
las geometrias exportadas corresponden al lookup actual de
`actualizacion.lc_gen_predio`; esto no demuestra aun la fuente geometrica exacta
por cada regla SIG. Ese requisito permanece abierto y no debe declararse como
equivalencia geometrica general.

La cancelacion se probo de extremo a extremo con una consulta controlada de
larga duracion ejecutada por el `ValidationWorker` real. QGIS observo el backend
activo de `gestor_validator_ro`, confirmo la transaccion de solo lectura, solicito
`pg_cancel_backend` sobre ese mismo proceso y obtuvo el estado final `cancelado`
en `187 ms`. No quedaron backends activos ni se emitieron senales tardias. El
informe no contiene una clave literal:

| Artefacto | SHA-256 |
| --- | --- |
| `cancel_live_report.json` | `E6C4028546FC65685D2B0B8B55A5DF0BE18740CC62937036491C52BD16387BD4` |

La evidencia esta en `workspaces/qgis_profiles/cancel_live_0.0.8`.

## Auditoria RECO completa

La corrida corregida ejecuto las 43 reglas comparables sin bloqueos. El resultado
es `23` coincidencias exactas, `5` con los mismos predios pero filas SQL
adicionales y `15` con conjuntos de predios diferentes. `Reco_50=228` y
`Reco_51=123` son exactas. Por ello queda cerrada la cobertura de auditoria, pero
la equivalencia RECO general **no** esta aceptada. Los hashes, listas y limites de
memoria estan en `docs/RECO_FULL_AUDIT_2026-07-18.md`.

## Contrato de catalogo descubierto

El builder restringido `gestor-rules 0.0.0` fijo esta linea base por hashes y
expuso seis inconsistencias de identidad que no se corrigen silenciosamente en
el borrador ya probado: `Jur_10` (ID y excepcion), `Jur_59` (excepcion),
`Jur_60` (ID y excepcion) y `Reco_52` (excepcion). Tambien mantiene sin clasificar
la severidad y sin afirmar una geometria exacta por regla. El detalle y el hash
del artefacto estan en `docs/GESTOR_RULES_ARTIFACT.md`; estos hallazgos deben
resolverse en un slice sincronizado posterior con nueva validacion comparativa.

Los seis ZIP fueron reconstruidos de forma sincronizada con el mismo contrato
de ejecucion `gestor-rules`: catalogo
`72DC764C5B821322A844C3506713A7FC2A3C670C214AEC889897877C98627525` y
postprocesador RECO
`0177F4922CFA01BF64F48F0A1EC0905151FD0E7810CA068B10D9377887A17412`.
Una carga real posterior comprobo las seis versiones y los seis pins:

| Paquete | SHA-256 |
| --- | --- |
| Economico | `F30656CAC9BE151ED6E2049B96EE6BA6DF2696F28A04B5BD78890F8A8F620891` |
| Juridico | `39A036B11B4165AE14F36F150B54911656F267A9E2DE4462B53AF41A1DD00EC6` |
| PH | `2A11EC568640543E00EC8D279D0CD6148CFABD75D529E86BC2A843BDE6E09D77` |
| RECO | `1F7EF9FAFADDD21705224ECB85B1D72ABBB4DC73646B975988E184F71097984E` |
| SIG | `9ECAD84FA1B00F6C2813B0A8C6FB3DFE0B34BB5FBE2CE5BDF4C273A6FC771933` |
| Total | `D4E663A7FB95A48A4DEF7602B31634EFF73207CBD13BB01221FA39EC61B2BE13` |

`plugin_startup_report_0.0.8_runtime_pinned.json` tiene SHA-256
`2B1696C30277EC2937AFA33E0E75EBC0A2DF672F4926D52094560ABDEE85B759`.
El manifiesto de aceptacion consolidado permanece deliberadamente `partial` y
`publication_ready=false`: ejecutar toda la auditoria no elimina sus 20
diferencias RECO ni los gates de contrato y procedencia.

La primera candidata futura debera ser otro parche `0.0.x`, sincronizado en los
seis plugins, con las inconsistencias corregidas y toda la evidencia repetida.
