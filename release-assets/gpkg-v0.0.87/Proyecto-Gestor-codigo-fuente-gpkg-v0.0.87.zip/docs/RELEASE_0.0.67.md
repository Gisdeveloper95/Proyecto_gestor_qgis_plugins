# Calidad GPKG 0.0.67 — catálogo portable completo

Esta entrega local contiene las 253 reglas del catálogo canónico en el backend
directo GeoPackage: Jurídico 82, RECO 71, SIG 16, PH 77 y Económico 7.

La homologación no ejecuta SQL PostgreSQL sobre el GPKG. Cada regla usa una
implementación Python/SQLite o geométrica explícita, con dependencias, hashes,
fixture y evidencia propios. PH_76 conserva sus 463 condiciones de entidades
públicas mediante un AST declarativo. Reco_56 y Reco_57 reutilizan ese criterio
sin empaquetar el SQL fuente.

La auditoría integral obtuvo 253/253 `pass` al comparar PostgreSQL 18.4/PostGIS
3.6.2 con ejecución en memoria y un GPKG físico. Este resultado demuestra
equivalencia sobre los fixtures sintéticos versionados; no constituye todavía
una afirmación de equivalencia productiva para cualquier base real.

QGIS 3.44.11 aprobó la carga conjunta de las seis ediciones DBA y las seis
ediciones GPKG, ejecución desde GPKG/capas cargadas/proveedor `memory`, descarga
y limpieza. Los seis ZIP `0.0.67` se construyeron dos veces con hashes idénticos.

La publicación fue autorizada por el propietario y cerró los nueve requisitos:
los ZIP incluyen `GPL-2.0-or-later`, existen metadata y aprobación versionadas,
y el manifiesto SHA-256 está firmado con RSA-3072. El release público es
`gpkg-v0.0.67`; no se instaló ningún perfil QGIS.

Repositorio estable para QGIS:
`https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/latest/download/plugins.xml`.
