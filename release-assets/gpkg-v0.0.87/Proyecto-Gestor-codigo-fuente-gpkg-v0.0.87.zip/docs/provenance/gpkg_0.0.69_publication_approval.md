# Aprobación de publicación Calidad GPKG 0.0.69

Fecha: 2026-07-19

El propietario del proyecto ordenó restaurar la interfaz original de los
plugins y limitar la variación GPKG al origen de datos. La autorización cubre
los seis plugins GPKG `0.0.69`, su código portable first-party bajo
`GPL-2.0-or-later`, metadatos, XML de repositorio y activos del release.

El armazón visual se obtiene directamente de la plantilla del plugin
PostgreSQL: barra de acciones, reglas, resumen, detalle, consola, mapa,
formulario y exportaciones. El panel PostgreSQL/PostGIS se sustituye por el
selector de capas cargadas o GeoPackage y el mapeo de entidades.

El release no distribuye el catálogo SQL DBA/PostGIS, código de GeoValidaTool,
APEX, CICA, plantillas IGAC, datos reales ni credenciales.
