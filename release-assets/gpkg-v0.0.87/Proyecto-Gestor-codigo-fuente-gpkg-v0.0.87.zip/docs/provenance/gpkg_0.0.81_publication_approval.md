# Aprobación de publicación Calidad GPKG 0.0.81

Fecha: 2026-07-28

El propietario `Gisdeveloper95` solicitó orientar el nombre recomendado de los
plugins simplificados a trabajadores de producción, reemplazar la selección de
carpeta por un diálogo normal de guardado y ubicar los tres controles de
selección/búsqueda debajo de los filtros operativos y encima de la tabla.

También solicitó publicar el release y entregar ZIPs del código fuente.

La publicación implementa exclusivamente interfaz, empaquetado de perfiles y
distribución. No incorpora geometrías, credenciales, datos catastrales, SQL
privado DBA, código ni activos de terceros. Las 253 reglas portables y su
evidencia de equivalencia permanecen sin cambios.
