# Aprobación de publicación Calidad GPKG 0.0.67

Fecha: 2026-07-19

El propietario del proyecto ordenó explícitamente publicar la edición Calidad
GPKG después de recibir el estado de gates pendientes. La autorización cubre
los seis plugins GPKG `0.0.67`, su código portable first-party bajo
`GPL-2.0-or-later`, metadata, XML de repositorio y activos del release.

El release no distribuye el catálogo SQL DBA/PostGIS, código de GeoValidaTool,
APEX, CICA, plantillas IGAC, datos reales ni credenciales. La equivalencia
publicada se limita a fixtures sintéticos y no afirma paridad productiva
universal.
