# Aprobación de publicación Calidad GPKG 0.0.84

Fecha: 2026-07-31

El propietario `Gisdeveloper95` reportó que los filtros continuaban mostrando
predios fuera del alcance al seleccionar grupos de reglas y exigió verificar
el comportamiento real, corregirlo y entregar los plugins operativos.

La autorización comprende:

- corregir la resolución común del predio usada por los filtros;
- impedir que una llave nula omita silenciosamente el alcance cuando el
  hallazgo sí identifica otra llave segura de `LC_Gen_Predio`;
- activar de forma inequívoca el perfil específico que el operador edita;
- conservar el perfil al filtrar o seleccionar grupos de reglas;
- distribuir juntos los seis plugins GPKG y actualizar `plugins.xml`;
- validar localmente contra el paquete de trabajo recibido sin incluirlo en
  Git, ZIP, logs públicos o evidencias con filas.

Las 253 SQL canónicas y sus planes `generated_plan_v1` permanecen sin cambios
funcionales respecto de `0.0.82`. La evidencia de equivalencia SQL de `0.0.82`
continúa como línea base; `0.0.84` cambia únicamente el runtime común posterior
y la interfaz de selección del alcance.

No se autorizan ni se incluyen credenciales, archivos locales de
configuración, geometrías, datos reales, código de GeoValidaTool, ArcPy ni
activos institucionales.

La publicación queda condicionada a pruebas deterministas, ejecución sobre el
paquete real, construcción reproducible de los seis ZIP, smoke QGIS 3.44.11 y
gates de licencia/procedencia. No se autoriza avanzar a `0.1.0`.
