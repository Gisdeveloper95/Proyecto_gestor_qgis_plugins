# Aprobación de publicación Calidad GPKG 0.0.76

Fecha: 2026-07-28

El propietario `Gisdeveloper95` solicitó expresamente implementar y actualizar
mediante GitHub las mejoras de interfaz, limpieza, navegación, paginación y
revisión descritas para los seis plugins Calidad GPKG.

La autorización cubre Total, Económico, Jurídico, PH, RECO y SIG; su código
portable first-party bajo `GPL-2.0-or-later`; metadatos, `plugins.xml`, icono y
activos del release `gpkg-v0.0.76`.

La publicación no cambia las 253 reglas, sus adaptadores, sus hashes de
ejecución ni la evidencia sintética de equivalencia. Tampoco distribuye
GeoPackages reales, geometrías, credenciales, SQL privado DBA, GeoValidaTool,
APEX, CICA, plantillas IGAC ni datos catastrales.
