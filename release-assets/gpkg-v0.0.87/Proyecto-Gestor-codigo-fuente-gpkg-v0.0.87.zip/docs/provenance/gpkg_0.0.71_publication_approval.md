# Aprobación de publicación Calidad GPKG 0.0.71

Fecha: 2026-07-27

El propietario `Gisdeveloper95` autorizó expresamente publicar en GitHub la
edición `0.0.71` y actualizar el repositorio XML consumido por QGIS.

La autorización cubre los seis plugins GPKG, su código portable first-party
bajo `GPL-2.0-or-later`, los metadatos, `plugins.xml`, el icono y los activos
del release `gpkg-v0.0.71`.

La versión incorpora:

- detección y remapeo automático de capas vectoriales cargadas en QGIS;
- reconocimiento del nombre físico desde el URI del proveedor;
- tratamiento de `SIG_16` como `not_applicable` cuando el paquete no incluye
  el perímetro urbano opcional;
- campos de estado con scroll y diálogos resumidos para mensajes extensos.

La ambigüedad entre dos capas sigue bloqueando el mapeo automático. Las
dependencias obligatorias siguen cerrando el preflight de forma segura.

El release no distribuye paquetes GPKG reales, geometrías, credenciales, SQL
del plugin DBA, código de GeoValidaTool, APEX, CICA, plantillas IGAC ni datos
catastrales.

