# Aprobación de publicación Calidad GPKG 0.0.68

Fecha: 2026-07-19

El propietario del proyecto ordenó corregir y volver a publicar el repositorio
después de comprobar que QGIS ocultaba las seis ediciones porque `0.0.67` las
declaraba experimentales. La autorización cubre los seis plugins GPKG
`0.0.68`, su código portable first-party bajo `GPL-2.0-or-later`, metadatos,
XML de repositorio y activos del release.

El release no distribuye el catálogo SQL DBA/PostGIS, código de GeoValidaTool,
APEX, CICA, plantillas IGAC, datos reales ni credenciales. La única diferencia
funcional con `0.0.67` es que las ediciones se publican como estables para que
QGIS las muestre con su configuración predeterminada.
