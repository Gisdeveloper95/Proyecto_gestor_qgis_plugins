# Aprobación de publicación Calidad GPKG 0.0.74

Fecha: 2026-07-28

El propietario `Gisdeveloper95` autorizó la evolución y actualización mediante
GitHub de la edición GPKG, incluyendo el control desde la interfaz de los
filtros operativos RECO.

La autorización cubre los seis plugins GPKG, su código portable first-party
bajo `GPL-2.0-or-later`, los metadatos, `plugins.xml`, el icono y los activos
del release `gpkg-v0.0.74`.

La versión incorpora:

- cuatro interruptores RECO independientes, activos por defecto;
- persistencia por edición y familia;
- bloqueo de los controles durante una corrida;
- registro de la política exacta en consola;
- modo sin postfiltro cuando los cuatro interruptores están apagados;
- conteos de filas crudas, conservadas y descartadas.

La implementación mantiene intactas las 253 reglas, sus adaptadores portables,
los hashes de sus bundles de ejecución y la evidencia sintética de
homologación. El nuevo contrato de UI y alcance se distribuye en módulos
separados y no cambia el significado de una regla.

El release no distribuye paquetes GPKG reales, geometrías, credenciales, SQL
del plugin DBA, código de GeoValidaTool, APEX, CICA, plantillas IGAC ni datos
catastrales.
