# Aprobación de publicación Calidad GPKG 0.0.83

Fecha: 2026-07-30

El propietario `Gisdeveloper95` solicitó corregir el alcance de los filtros de
Informalidad sobre grupos amplios de reglas y ampliar el plugin Total para
generar perfiles simplificados con reglas mixtas de varias familias.

La autorización comprende:

- distribución GPL-2.0-or-later de los seis plugins GPKG sincronizados;
- selector explícito de alcance automático o forzado por perfil;
- persistencia de filtros generales y específicos en perfiles hijos;
- perfiles `Mixto personalizado` con las reglas exactas seleccionadas;
- pruebas de regresión, construcción reproducible y certificación QGIS;
- actualización de `plugins.xml` y publicación del release GitHub.

Las 253 SQL canónicas y sus planes `generated_plan_v1` permanecen sin cambios
funcionales respecto de `0.0.82`. Las evidencias de equivalencia de `0.0.82`
siguen siendo la línea base y esta versión añade pruebas específicas de filtros
y empaquetado.

No se autorizan ni se incluyen credenciales, archivos locales de
configuración, geometrías, datos reales, código de GeoValidaTool, ArcPy ni
activos institucionales.

La aprobación se condiciona a:

- construir juntos los seis ZIP padre;
- conservar las 253 reglas y el runtime SQL/GEOS único;
- verificar el filtro de Informalidad sobre una regla de Calificación;
- verificar perfiles hijos individuales y mixtos;
- superar construcción reproducible, integración y QGIS 3.44.11;
- no avanzar a `0.1.0`.
