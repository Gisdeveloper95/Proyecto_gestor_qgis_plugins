# Aprobación de publicación Calidad GPKG 0.0.80

Fecha: 2026-07-28

El propietario `Gisdeveloper95` solicitó corregir el generador de plugins
simplificados. El padre Total debe permitir elegir y generar en lote perfiles
Total, Económico, Jurídico, PH, RECO y SIG. Cada padre específico debe producir
únicamente un perfil simplificado de su propia familia.

También autorizó eliminar el botón redundante, el aviso visual de bloqueo y el
nombre técnico solicitado al usuario; separar los perfiles en un menú/barra
propios y asignar miniaturas diferenciadas.

La publicación implementa este flujo de manera independiente y conserva
compatibilidad de lectura con los perfiles `0.0.79`. No incorpora geometrías,
credenciales, datos catastrales, SQL privado DBA, código o activos de terceros.
Las 253 reglas portables y su evidencia de equivalencia no cambian.
