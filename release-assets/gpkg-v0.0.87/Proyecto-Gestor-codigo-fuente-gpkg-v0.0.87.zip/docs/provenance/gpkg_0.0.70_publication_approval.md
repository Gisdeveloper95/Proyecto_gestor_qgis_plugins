# Aprobación de publicación Calidad GPKG 0.0.70

Fecha: 2026-07-23

El propietario autorizó continuar mejorando y publicando los seis plugins GPKG.
La autorización cubre `0.0.70`, su código portable first-party bajo
`GPL-2.0-or-later`, metadatos, XML del repositorio y activos del release.

Esta versión incorpora lectura segura de tablas relacionales no registradas,
una entidad auxiliar derivada solo en memoria y alcance explícito o manual por
paquete. El GeoPackage original y la copia base de Mergin no se modifican.

El release no distribuye el paquete real `pvall_044_nu`, SQL del plugin DBA,
código de GeoValidaTool, APEX, CICA, plantillas IGAC, datos reales ni
credenciales.
