# Aprobación de publicación Calidad GPKG 0.0.73

Fecha: 2026-07-27

El propietario `Gisdeveloper95` autorizó la evolución y distribución de la
edición GPKG solicitada para corregir Microsoft Excel, mejorar el CSV y
entregar reportes separados por regla mediante el repositorio GitHub consumido
por QGIS.

La autorización cubre los seis plugins GPKG, su código portable first-party
bajo `GPL-2.0-or-later`, los metadatos, `plugins.xml`, el icono y los activos
del release `gpkg-v0.0.73`.

La versión incorpora:

- corrección del orden OOXML exigido por Microsoft Excel;
- ZIP con reporte general y un Excel por cada regla ejecutada;
- libros explícitos para reglas con cero hallazgos;
- columnas dinámicas compartidas entre Excel y CSV;
- anchos, filtros, congelación de encabezados y ajuste de texto;
- CSV UTF-8 BOM, delimitador `;` y finales CRLF;
- corrección del workflow para no aplicar el checkpoint histórico `0.0.20` a
  releases posteriores.

La exportación sigue leyendo el almacén SQLite paginado mediante cursores y
valida conteos antes de reemplazar el archivo de destino. Un fallo conserva el
archivo anterior.

El release no distribuye paquetes GPKG reales, geometrías, credenciales, SQL
del plugin DBA, código de GeoValidaTool, APEX, CICA, plantillas IGAC ni datos
catastrales.
