# Aprobación de publicación Calidad GPKG 0.0.79

Fecha: 2026-07-28

El propietario `Gisdeveloper95` solicitó expresamente revisar e implementar los
filtros de `filtros.py.txt`, separando controles generales y específicos por
grupo de reglas. También autorizó condiciones personalizables entre `0` y `9`
y la generación de plugins hijos instalables, simplificados y bloqueados a
partir de cualquiera de los seis plugins padre.

La autorización cubre los seis plugins Calidad GPKG: Total, Económico,
Jurídico, PH, RECO y SIG. Los hijos conservan las reglas y filtros elegidos,
pero no permiten al operador modificarlos.

La publicación implementa el comportamiento descrito de forma independiente.
No incorpora el archivo de referencia, código de terceros, geometrías,
credenciales, datos catastrales, SQL privado DBA ni activos de GeoValidaTool.
Tampoco modifica las 253 reglas portables ni su evidencia sintética de
equivalencia.
