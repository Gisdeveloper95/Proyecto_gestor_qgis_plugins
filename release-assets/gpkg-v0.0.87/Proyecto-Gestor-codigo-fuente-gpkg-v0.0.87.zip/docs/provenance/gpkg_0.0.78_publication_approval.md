# Aprobación de publicación Calidad GPKG 0.0.78

Fecha: 2026-07-28

El propietario `Gisdeveloper95` solicitó expresamente incorporar en Detalle de
inconsistencias un contador visible, búsqueda por manzana/NPN y un control para
mostrar u ocultar registros con excepción.

La autorización cubre los seis plugins Calidad GPKG: Total, Económico,
Jurídico, PH, RECO y SIG. El control de excepciones se entrega activado por
defecto y su preferencia se conserva localmente en QGIS.

La publicación no incorpora geometrías, credenciales, datos catastrales, SQL
privado DBA ni activos de GeoValidaTool. Tampoco cambia las 253 reglas, sus
adaptadores o la evidencia sintética de equivalencia.
