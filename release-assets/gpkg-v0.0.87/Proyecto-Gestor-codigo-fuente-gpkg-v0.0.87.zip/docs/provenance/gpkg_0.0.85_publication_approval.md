# Aprobación de publicación Calidad GPKG 0.0.85

Fecha: 2026-07-31

El propietario `Gisdeveloper95` solicitó expresamente modificar y distribuir
los plugins GPKG con los siguientes alcances:

- permitir seleccionar simultáneamente más de un grupo de reglas;
- permitir en los hijos mixtos aplicar filtros por los grupos incluidos;
- reconocer el proyecto desde el paquete/QGZ o listar los proyectos para que
  el operador elija cuál ejecutar;
- conservar la exportación ZIP y añadir un repositorio GitHub independiente
  para perfiles simplificados actualizables desde QGIS.

La autorización comprende los seis plugins padre, sus perfiles simplificados,
la actualización conjunta de `plugins.xml`, el tag `gpkg-v0.0.85`, el release
público y la creación del repositorio público exclusivo de perfiles cuando se
realice su primera publicación autenticada.

Las 253 SQL canónicas y sus planes `generated_plan_v1` no cambian respecto de
la línea base demostrada en `0.0.82`. Esta versión modifica únicamente la
interfaz común, el alcance temporal por proyecto y el mecanismo independiente
de distribución de perfiles.

El paquete real se usa solo para verificación local. No se versionan ni se
publican filas, geometrías, credenciales, rutas locales, `keys.txt`, código de
GeoValidaTool, ArcPy ni activos institucionales. Los tokens permanecen en
memoria o cifrados en QGIS Auth Manager.

La publicación queda condicionada a pruebas deterministas, ejecución sobre el
paquete recibido, construcción reproducible de los seis ZIP, smoke QGIS
3.44.11 y gates de licencia/procedencia. No se autoriza avanzar a `0.1.0`.
