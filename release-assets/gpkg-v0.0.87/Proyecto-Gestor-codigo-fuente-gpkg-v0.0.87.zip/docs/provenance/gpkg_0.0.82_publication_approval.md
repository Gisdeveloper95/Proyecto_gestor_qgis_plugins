# Aprobación de publicación Calidad GPKG 0.0.82

Fecha: 2026-07-29

El propietario `Gisdeveloper95` solicitó migrar completamente los seis plugins
GPKG y todos sus perfiles simplificados al motor SQL/planes JSON, exigir
paridad antes de publicar, entregar fuentes y crear el release inmutable
`gpkg-v0.0.82`.

La autorización comprende:

- distribución GPL-2.0-or-later de los seis plugins GPKG;
- planes generados desde el catálogo canónico autorizado;
- runtime genérico SQLite/GEOS y postfiltros comunes;
- evidencias sintéticas y certificación local sin filas catastrales;
- perfiles simplificados filtrados por regla;
- hashes, manifiesto, SBOM, documentación y archivos fuente;
- actualización de `plugins.xml` y publicación del release GitHub.

No se autorizan ni se incluyen credenciales, archivos locales de
configuración, geometrías, datos reales, código de GeoValidaTool, ArcPy,
QGIS Core como dependencia del motor externo ni activos institucionales.

La aprobación se condiciona a que:

- las 253 reglas tengan plan firmado y evidencia;
- 252 reglas se ejecuten sobre el paquete real sin errores;
- `SIG_16` conserve su estado opcional;
- los seis ZIP se publiquen juntos;
- no exista fallback a adaptadores Python por regla;
- QGIS 3.44.11 y los gates de licencia/procedencia resulten correctos.
