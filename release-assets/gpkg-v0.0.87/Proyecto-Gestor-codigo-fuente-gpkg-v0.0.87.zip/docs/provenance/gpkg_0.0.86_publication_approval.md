# Aprobación de publicación Calidad GPKG 0.0.86

Fecha: 2026-07-31

El propietario `Gisdeveloper95` autorizó expresamente automatizar el canal de
perfiles simplificados para que los responsables de producción puedan crearlos
y actualizarlos sin intervención manual del desarrollador.

La autorización comprende:

- el registro central de perfiles, revisiones, builds y auditoría en Turso;
- la API autenticada en el portal Mapper GIS;
- la autorización del plugin padre mediante el flujo de dispositivo existente;
- el workflow confiable que construye y publica perfiles en el repositorio
  público independiente;
- los seis plugins padre GPKG `0.0.86`, su `plugins.xml`, tag y release;
- la creación del repositorio de perfiles si aún no existe.

Las 253 SQL canónicas y sus planes `generated_plan_v1` permanecen sin cambios
respecto de la línea base `0.0.82`. El constructor únicamente filtra los planes
seleccionados, conserva la política operativa y reemplaza metadatos del perfil.

No se autorizan datos catastrales, filas, geometrías, rutas locales, secretos,
`keys.txt`, ArcPy, GeoValidaTool ni activos institucionales en Vercel, Turso,
GitHub, logs o ZIP. Los coordinadores no reciben credenciales GitHub. La
publicación queda condicionada a build reproducible, pruebas del registro,
verificación de los seis plugins y gates de licencia/procedencia.

No se autoriza avanzar a `0.1.0`.
