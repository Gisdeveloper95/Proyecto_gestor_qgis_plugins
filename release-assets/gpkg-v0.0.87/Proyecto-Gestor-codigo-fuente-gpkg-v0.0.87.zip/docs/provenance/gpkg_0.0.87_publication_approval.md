# Aprobación de publicación Calidad GPKG 0.0.87

Fecha: 2026-08-01

El propietario `Gisdeveloper95` solicitó y autorizó publicar una corrección
rápida para los seis plugins padre GPKG y los perfiles simplificados derivados.

El alcance autorizado comprende exclusivamente:

- corregir el `AttributeError` provocado por el uso de `self.sender()` en la
  selección múltiple de grupos;
- asegurar contraste legible en el selector del alcance de predios;
- incorporar una prueba de regresión QGIS para ambos comportamientos;
- publicar los seis ZIP, `plugins.xml`, código fuente, hashes, SBOM y evidencia
  como versión `0.0.87`.

Las 253 SQL canónicas, los planes `generated_plan_v1`, la paridad `0.0.82`, los
filtros operativos y la procedencia anterior permanecen sin cambios. No se
autorizan datos catastrales, geometrías, secretos, `keys.txt`, ArcPy ni activos
institucionales en los artefactos. No se autoriza avanzar a `0.1.0`.
