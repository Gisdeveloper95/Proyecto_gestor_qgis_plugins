# Calidad GPKG 0.0.73 - Excel compatible y publicación corregida

`0.0.73` entrega íntegramente la mejora de reportes preparada en `0.0.72` y
corrige el gate obsoleto que impedía su publicación automática.

## Paquete Excel

La opción `Paquete Excel (ZIP)` genera:

- `Reporte_general.xlsx`, con Resumen, Detalle/Matriz, hojas por regla y
  Consola;
- `Reglas/<CODIGO>.xlsx`, un libro independiente por cada regla ejecutada,
  incluidas las reglas con cero hallazgos;
- `LEEME.txt`, con la descripción del contenido.

Los libros incluyen encabezados congelados, autofiltros, texto ajustado,
anchos profesionales y todas las columnas dinámicas declaradas por el
catálogo. Si una regla supera el límite de filas de Excel, se divide en hojas
consecutivas sin truncamiento.

## Compatibilidad

- El OOXML usa el orden estricto exigido por Microsoft Excel.
- El CSV usa UTF-8 con BOM, separador `;`, finales CRLF y neutralización de
  fórmulas.
- Microsoft Excel 16.0 abrió el reporte sin reparación y conservó 503 filas
  sintéticas y 33 columnas.
- QGIS 3.44.11 ejecutó el flujo SIG y exportó CSV, ZIP Excel y GPKG.

## Publicación

El checkpoint local `0.0.20` continúa versionado como evidencia histórica,
pero ya no se intenta validar contra versiones nuevas. Los releases actuales
siguen bloqueados por pruebas reproducibles, aprobación versionada,
procedencia, hashes y gates de publicación.

Los seis plugins se construyen y publican siempre juntos: maestro, Económico,
Jurídico, PH, RECO y SIG.
