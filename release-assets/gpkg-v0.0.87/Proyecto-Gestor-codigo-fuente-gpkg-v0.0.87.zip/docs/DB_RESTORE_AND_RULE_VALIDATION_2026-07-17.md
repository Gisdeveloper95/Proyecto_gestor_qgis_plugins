# Restauración canónica PostgreSQL/PostGIS — 2026-07-17

Este es el procedimiento vigente para el fixture local de Proyecto Gestor. Reemplaza
la restauración parcial del 16 de julio y no utiliza sus scripts auxiliares de
secuencias o compatibilidad: esas correcciones ya están dentro del dump canónico.

## Entrada inmutable

- Archivo: `PROYECTO_GESTOR/BASE_DATOS_PORTABLE/cartoflow_pruebas_portable_2026-07-17.dump`
- Tamaño: `426057540` bytes.
- SHA-256: `B30220F91AB9273DD99A934492105F02D46BE993471454BC5AE81285C95AE16F`.
- `pg_restore --list`: `1468` líneas, de las cuales `1453` son entradas de archivo
  (las otras 15 son encabezados/comentarios del formato).

El hash debe verificarse antes de cada restauración. Si no coincide exactamente, el
proceso se detiene y no se intenta reparar el dump.

## Runtime fijado

- PostgreSQL `18.4`.
- PostGIS `3.6.2`.
- Servidor `localhost:5432`.
- Usuario administrativo: `postgres`.
- Base nueva: `cartoflow_pruebas`.

La credencial administrativa no se escribe en comandos, código, logs o documentos.
Debe obtenerse de un prompt seguro o del mecanismo de credenciales local.

## Restauración reproducible

Crear una base vacía desde `template0` y ejecutar el binario de PostgreSQL 18.4:

```powershell
& 'C:\Program Files\PostgreSQL\18\bin\createdb.exe' `
  --host localhost --port 5432 --username postgres `
  --template template0 --encoding UTF8 cartoflow_pruebas

& 'C:\Program Files\PostgreSQL\18\bin\pg_restore.exe' `
  --host localhost --port 5432 --username postgres `
  --dbname cartoflow_pruebas `
  --no-owner --no-acl --exit-on-error `
  '<ruta-segura-al-dump-canonico>'
```

No ejecutar `create_missing_sequences.sql`,
`create_test_compatibility_objects.sql` ni correcciones equivalentes del proceso
histórico. Una restauración que necesite esos pasos no corresponde a este fixture.

## Validación de objetos

La restauración local terminó con código `0` y sin salida de error. Se verificó:

| Control | Resultado |
| --- | ---: |
| Extensión `postgis` | `3.6.2` |
| Tablas en `actualizacion` | 152 |
| Tablas en `general` | 5 |
| Secuencias en `actualizacion` | 152 |
| Secuencias en `general` | 5 |
| Vista `general.determinacion_area_construccion` | presente |

Conteos de aceptación:

| Relación | Filas |
| --- | ---: |
| `actualizacion.lc_gen_predio` | 97.249 |
| `actualizacion.lc_reco_caracteristicasunidadconstruccion` | 97.852 |
| `actualizacion.lc_ph_predio` | 28.737 |
| `actualizacion.lc_jur_interesado` | 113.381 |
| `general.lc_gen_inconsistencias_alfanumericas_historicas` | 5.998.833 |
| `general.lc_gen_inconsistencias_geograficas_historicas` | 318.798 |

## Rol de validación

`gestor_validator_ro` tiene `CONNECT`, `USAGE` y `SELECT` sobre los esquemas
catastrales necesarios, con `default_transaction_read_only=on`. Se comprobó que puede
leer y que un `INSERT` es rechazado. La contraseña se generó fuera del repositorio y
se conserva mediante QGIS Authentication Manager; la conexión guardada solo contiene
un identificador `authcfg`.

El perfil activo fue migrado a
`%LOCALAPPDATA%/MapingTool/qgis_profiles/profiles/MapingToolDev` para evitar que
`qgis-auth.db` se sincronice con OneDrive. El perfil anterior del workspace se
conserva como evidencia cifrada retirada. La rotación del rol y el nuevo
`authcfg` quedaron registrados sin serializar secretos en
`workspaces/qgis_profiles/local_profile_migration_0.0.8/recovery_report.json`.

No usar `postgres` desde el plugin. El rol administrativo queda reservado para
restauración y mantenimiento explícito.

## Catálogo y criterio de aceptación

El reporte canónico está en
`test_reports/restored_pg18/20260717_165513_rules_all_compile.json` y su CSV asociado.
Sobre las 253 reglas:

| Estado | Cantidad |
| --- | ---: |
| Correctas | 252 |
| Dependencia faltante | 1 |
| Timeout | 0 |

La única dependencia es `SIG_16`, porque no existe la capa real
`public.perimetro_urbano_20260702`. Se mantiene visible y no se crea una tabla vacía.
Una muestra posterior confirmó las familias RECO, PH, Jurídico, Económico y SIG; el
caso pesado `SIG_09` terminó en aproximadamente `203 s`, por lo que `300 s` es el
timeout de desarrollo inicial y su optimización sigue pendiente.

La evidencia complementaria del perfil aislado QGIS se guarda en el workspace
`qgis_profiles`: `authcfg_reco_0.0.8_report.json`,
`catalog_acceptance_0.0.8.json`, `sig09_long_0.0.8_report.json` y
`plugin_startup_report_0.0.8.json`. El flujo integral posterior se registra en
`live_workflow_0.0.8_local_profile/live_workflow_report.json` y sus tres
exportaciones asociadas.
