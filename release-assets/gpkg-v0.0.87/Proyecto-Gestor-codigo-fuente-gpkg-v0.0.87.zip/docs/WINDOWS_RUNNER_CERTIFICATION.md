# Certificación Windows de previews

El workflow `certify-rule-release.yml` ejecuta la certificación final en el
runner self-hosted `mapingtool-qgis`. Sus etiquetas obligatorias son:

- `Windows`
- `X64`
- `mapingtool-qgis`
- `qgis-3.44`
- `postgresql-18`

El runner usa Python 3.12 fijado por GitHub Actions y las instalaciones locales
de PostgreSQL 18/PostGIS y QGIS 3.44.11. Las variables operativas permanecen en
el entorno local del runner; no se incorporan a Git, los ZIP ni los artefactos.

## Alcance del gate

1. valida el catálogo, la política SQL y el hash clean-room;
2. compila el catálogo contra PostgreSQL 18 y acepta únicamente la dependencia
   documentada de `SIG_16`;
3. repite la equivalencia PostGIS/GPKG sobre los fixtures autorizados;
4. construye los seis previews DBA/PostGIS y los seis GPKG;
5. instala exactamente los doce ZIP en el perfil aislado `MapingToolDev`;
6. carga y descarga las dos ediciones en QGIS, comprueba los 253 IDs, capas
   GPKG y memoria, y ejecuta el runtime PostGIS de `Reco_50`/`Reco_51`;
7. verifica los cuatro filtros RECO editables en ambas ediciones;
8. verifica CSV, paquete XLSX y GPKG con reemplazo atómico;
9. conserva durante 30 días los doce ZIP y la evidencia de certificación.

El instalador `tools/install_qgis_preview_packages.py` falla ante ZIP corruptos,
rutas que escapen del paquete, enlaces simbólicos, raíces duplicadas o
discordancia entre la versión del archivo y `metadata.txt`. Solo escribe en el
perfil aislado y sustituye cada plugin de forma recuperable.

La certificación no crea tags ni releases. Su entrada es un commit exacto y dos
versiones candidatas `0.0.x`; publicar sigue siendo una acción distinta del
propietario.
