# Línea base recuperada 0.0.7 — 2026-07-17

La etiqueta histórica no fue reescrita. Se recuperó en un worktree separado y
detached:

- tag: `v0.0.7`;
- commit: `b5a611b28bd86db0d137a66f7bba34c96be092c7`;
- worktree: `workspaces/Proyecto_gestor_v0.0.7_baseline`;
- árbol de desarrollo `0.0.8`: `workspaces/Proyecto_gestor`.

## Reconstrucción y comparación

Las seis fuentes se reconstruyeron desde el tag. Cada ZIP tiene exactamente el mismo
conjunto de entradas y el mismo contenido lógico que su ZIP recibido, normalizando
solo finales de línea. Los hashes binarios son distintos porque el builder histórico
incluía timestamps/metadatos ZIP variables; esto motivó el build determinista de
`0.0.8`.

| Paquete | Entradas | SHA-256 reconstruido | SHA-256 recibido | Equivalencia lógica |
| --- | ---: | --- | --- | --- |
| Económico | 17 | `DF35033196A96385415974EA6A9E616C3631DA57783F22FD85DC104D7102351C` | `EB3EFC870A926355A17145925AC47122EF92D7F066E23F0A6813F0FA438888CA` | sí |
| Jurídico | 92 | `C625CD7DEF85AE49BDAFB122A395703DAEC44A34E5A31F9FB92311D79EDDC461` | `EF354807B0DE5883C4E415B2683270AF9DAAD516C1D32BD8F177B6EE780526BC` | sí |
| PH | 87 | `04E243231E8364589AF683A7611F556783F1C7D8B847496D7268AFAA5F44C26C` | `71261117088022D788B570B65EE40258FDE768BB48799F2FBCDA9E2498849E75` | sí |
| RECO | 81 | `BF1C8BC249A6857B8D54779E7ECCF8AABACB87C4D4CE729C4C35ACBFFD12E955` | `7357EB162A1FDB117D4F2D9CAE43E10DEF3C944AA16197804A1D65FEC7B2810A` | sí |
| SIG | 26 | `E62C3DABADC756112C8FDE44DDBE0E2E621372CB0438FCBE517D3409DA4AD03B` | `55D4263578D197E701AC527239831117FA8532ED432E2E6A47AD3E0E0C999A8C` | sí |
| Total | 263 | `4B4C8CEEBB2802028C2943F65D1783D8D3DC230179616D80C0C2073C9399A7FF` | `3DB408638FCEA749AF410590E9491504132DF165AA7738534718A152DAD3B598` | sí |

`plugin_icon.png` sí coincide byte por byte, con SHA-256
`A8F1959082C6BD8FEDCEF93FC20C155925930EE73B6005F956D8E13A31169CDD`.
En `plugins.xml` la única diferencia lógica son `create_date` y `update_date`, que el
builder histórico calculaba en cada ejecución.

## QGIS 3.44.11

Los seis plugins se instalaron en el perfil aislado `MapingToolDev`; el perfil
`default` no se modificó. El smoke de carga/descarga terminó `6/6`. La conexión de
prueba usó el rol `gestor_validator_ro` mediante `authcfg`, sin contraseña en
QSettings. El filtro posterior RECO produjo:

| Regla | SQL | Descartadas | Finales |
| --- | ---: | ---: | ---: |
| `Reco_50` | 297 | 69 | 228 |
| `Reco_51` | 165 | 42 | 123 |

Evidencia local:

- `test_reports/qgis_3.44/ui_smoke_v0.0.7.png` en el worktree detached;
- `workspaces/qgis_profiles/plugin_startup_report_0.0.7.json`;
- validaciones unitarias de catálogo, postfiltro RECO y XLSX verdes.

Esta equivalencia establece la línea base técnica; no resuelve por sí misma la
licencia o procedencia del catálogo y no autoriza una nueva publicación.
