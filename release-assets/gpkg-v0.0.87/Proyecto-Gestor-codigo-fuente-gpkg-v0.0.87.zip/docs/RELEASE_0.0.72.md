# Calidad GPKG 0.0.72 - Excel compatible y reportes por regla

`0.0.72` corrige la interoperabilidad del reporte con Microsoft Excel y
reorganiza la entrega para facilitar el trabajo separado por regla.

## Paquete Excel

La opción `Paquete Excel (ZIP)` genera:

- `Reporte_general.xlsx`, con Resumen, Detalle/Matriz, hojas por regla y
  Consola;
- `Reglas/<CODIGO>.xlsx`, un libro independiente por cada regla ejecutada;
- `LEEME.txt`, con una descripción breve del contenido.

Las reglas con cero hallazgos también reciben su libro individual con
encabezados y sin filas de datos. Así queda evidencia explícita de su ejecución.
Cuando una regla supera el límite físico de filas de Excel, sus datos se
dividen en hojas consecutivas sin truncamiento.

## Compatibilidad Microsoft Excel

El XML interno de cada hoja usa el orden estricto del estándar OOXML:
`sheetViews`, `sheetFormatPr`, `cols` y `sheetData`. La versión anterior usaba
un orden que LibreOffice aceptaba, pero Microsoft Excel podía reparar,
descartar o mostrar como vacío.

También se incorporan:

- encabezados congelados y con autofiltro;
- anchos específicos para identificadores, matrículas, descripciones y
  mensajes;
- ajuste de texto en columnas extensas;
- conservación de ceros iniciales mediante celdas de texto;
- inclusión de todas las columnas dinámicas declaradas por el catálogo GPKG.

## CSV

El CSV mantiene un contrato único:

- UTF-8 con BOM;
- separador `;`;
- saltos de línea CRLF;
- comillas conforme al dialecto Excel;
- encabezado con la misma proyección usada por el reporte Excel;
- protección de identificadores y neutralización de fórmulas.

## Verificación

- Prueba estructural OOXML y apertura con `openpyxl`: correcta.
- Microsoft Excel 16.0 abrió el reporte sin reparación, conservó las 503 filas
  sintéticas y leyó el CSV como 33 columnas y 503 registros.
- Paquete general y libros individuales, incluida una regla con cero filas:
  correctos.
- Construcción reproducible de las seis ediciones `0.0.72`: correcta.
- Smoke QGIS 3.44.11 con ejecución SIG, CSV, paquete Excel y GPKG: correcto.
- Aprobación versionada de licencia, procedencia y hashes: registrada y
  verificada.
