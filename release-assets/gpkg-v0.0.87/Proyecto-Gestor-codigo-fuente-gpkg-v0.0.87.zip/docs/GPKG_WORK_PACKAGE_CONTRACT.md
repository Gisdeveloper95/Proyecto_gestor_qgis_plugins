# Contrato de paquete de trabajo GPKG

Un paquete de trabajo no implica que deban ejecutarse las 253 reglas. El
catálogo completo define las capacidades del producto; el alcance del encargo
define cuáles reglas aplican a un GeoPackage concreto.

## Alcance manual

Si el paquete solo contiene el `.gpkg`, el analista marca en la tabla **Reglas**
las validaciones que corresponden al encargo. **Probar fuente** y **Ejecutar
marcadas** operan únicamente sobre esa selección. Las dependencias de reglas no
seleccionadas no se presentan como errores del paquete.

## Alcance declarado por el coordinador o DBA

El coordinador puede entregar `mapingtool_scope.json` junto al GeoPackage:

```json
{
  "schema_version": 1,
  "profile_id": "pvall-044-calidad-grafica-v1",
  "rule_ids": ["Reco_50", "Reco_51", "SIG_01", "SIG_02"],
  "reason": "Reglas contratadas para el paquete de Valledupar"
}
```

También se acepta `<nombre-del-gpkg>.mapingtool-scope.json`; ese nombre tiene
precedencia sobre el archivo genérico.

El plugin valida el archivo, registra su SHA-256, marca únicamente esas reglas
y bloquea **Ejecutar grupo** para que no incluya reglas fuera del alcance. Las
reglas excluidas siguen visibles, en gris, con el estado conceptual “fuera del
alcance”; no se confunden con una dependencia faltante.

El alcance no puede declarar SQL, rutas, comodines ni código. Los IDs
desconocidos o repetidos bloquean la ejecución. El GeoPackage original y el
archivo de alcance permanecen en solo lectura.

## Modelo relacional del paquete

El lector reconoce tanto las capas registradas en `gpkg_contents` como las
tablas relacionales ordinarias incluidas en el mismo SQLite. Excluye tablas
internas de GeoPackage, mosaicos, RTree, metadatos de snapshot y la copia base
de `.mergin`.

Cuando el paquete contiene las tablas fuente necesarias, el plugin reconstruye
en memoria `determinacion_area_construccion`. No crea tablas ni vistas dentro
del archivo entregado.

## Cambios futuros de SQL

Un cambio de SQL PostgreSQL/PostGIS no debe copiarse directamente al
GeoPackage: los dialectos y las funciones espaciales no son equivalentes. El
flujo seguro será un **rule pack versionado**:

1. el DBA entrega la especificación y el SQL PostgreSQL actualizado;
2. una canalización valida dependencias, licencia y procedencia;
3. se actualiza o genera la implementación portable equivalente;
4. se compara PostgreSQL contra GPKG con fixtures autorizados;
5. se firma y publica una versión nueva del catálogo.

Hasta que ese compilador y su firma estén implementados, las reglas ejecutables
permanecen ligadas a la versión del plugin. El DBA sí puede cambiar de inmediato
el alcance del paquete mediante `mapingtool_scope.json`, pero no inyectar SQL
arbitrario en los equipos de calidad.
