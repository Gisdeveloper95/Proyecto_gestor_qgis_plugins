# Perfiles de filtros operativos GPKG

Los filtros operativos se aplican después de calcular los hallazgos de calidad.
No alteran el catálogo ni el significado de las reglas. Su finalidad es
restringir los resultados al grupo de predios que corresponde al trabajo del
operador.

## Filtros generales

Estos controles aparecen en los seis plugins y se aplican a todos los perfiles:

- excluir predios cancelados;
- exigir estado de asignación;
- elegir uno o varios estados permitidos entre `0` y `9`.

## Perfiles específicos

| Perfil | Alcance predeterminado | Controles |
|---|---|---|
| NPH / predio formal | Reglas generales de Económico, Jurídico, RECO y SIG | Condiciones excluidas `2, 5, 8, 9`; exclusión de visita informal |
| Condominio | `Reco_03`, `Reco_04`, `Reco_30`, `Jur_16` | Condiciones permitidas, por defecto `8` |
| Propiedad horizontal | Reglas PH distintas de las reglas matriz | Condiciones permitidas, por defecto `8, 9` |
| PH matriz | `PH_01`–`PH_09` y `SIG_14` | Perfil PH más condición `9`, torre/piso `0000` y unidad `0000` |
| Informalidad | `Reco_58`, `Reco_59`, `Reco_64`, `Jur_13`, `Jur_27`, `Jur_29`, `Jur_31`, `Jur_33`, `Jur_47` | Condiciones permitidas `2, 5`; condición `0` solo cuando está marcada para visita informal |

Las listas de condiciones son editables y aceptan cualquier combinación de
dígitos `0` a `9`, separados por coma, espacio, punto y coma o barra vertical.
La configuración queda guardada por edición del plugin.

El plugin Total muestra todos los bloques e indica cuántas reglas usan cada
perfil. Los plugins Económico, Jurídico, PH, RECO y SIG muestran solamente los
bloques aplicables a sus propias reglas.

## Perfiles simplificados

Un plugin padre permite marcar reglas, ajustar filtros y elegir
`Exportar > Generar perfiles simplificados`. El padre Total abre un selector
múltiple para producir en una sola operación uno o varios perfiles: Total,
Económico, Jurídico, PH, RECO y SIG. Cada padre específico ofrece únicamente
su propia edición.

Cada ZIP generado:

- es instalable directamente desde QGIS;
- conserva únicamente el conjunto seleccionado como perfil ejecutable;
- congela la política de filtros y el mapeo de capas que estuviera guardado;
- oculta la edición de reglas, filtros y mapeo;
- conserva selección de fuente, ejecución, resumen, detalle, navegación y
  exportación de resultados;
- registra en `child_profile.json` la edición padre, reglas, filtros y fecha de
  generación.

Los perfiles instalados aparecen en el menú y barra independientes
`Perfiles GPKG`, con miniaturas y colores propios por edición. No se mezclan
con los seis plugins padre dentro del menú `Calidad GPKG`.

El hijo no contiene una ruta absoluta al GPKG. Cada operador selecciona su
propio paquete o usa capas ya cargadas en el proyecto.

Cuando se genera una sola edición, el diálogo guarda directamente su ZIP
instalable. Cuando se generan varias, se guarda un único paquete ZIP con los
plugins instalables dentro, un manifiesto y las instrucciones de extracción.

## Comportamiento seguro

El filtrado se prepara una sola vez por corrida y se almacena temporalmente en
SQLite. Los hallazgos con `pk_id_predio` se contrastan con el perfil que
corresponde a su regla. Un hallazgo técnico que no exponga una referencia de
predio se conserva, porque descartarlo sin identidad demostrable produciría un
falso negativo.
