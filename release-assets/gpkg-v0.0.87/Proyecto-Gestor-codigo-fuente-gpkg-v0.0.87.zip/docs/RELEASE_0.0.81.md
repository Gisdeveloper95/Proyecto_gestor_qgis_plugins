# Calidad GPKG 0.0.81 - perfiles de producción y orden visual

`0.0.81` pule el generador de perfiles para el flujo real de producción y
reordena los controles asociados a la tabla de reglas.

## Nombre orientado al trabajador

El modal usa ahora `Nombre visible para los trabajadores` y recomienda un
nombre operativo como `Control de calidad — Equipo Norte`. El texto aclara que
es el nombre que verá el operador en QGIS y que la edición se distingue
automáticamente cuando se generan varios plugins.

## Guardado

- Una sola edición abre un diálogo normal para guardar directamente el ZIP
  instalable.
- Varias ediciones abren el mismo diálogo para guardar un paquete ZIP.
- El paquete múltiple contiene los ZIP instalables individuales,
  `manifest.json` y `LEEME.txt`.
- Ya no se usa el diálogo confuso de selección de carpeta.

## Orden de los filtros

Los controles `Procesar todas las reglas visibles`, `Grupo` y `Buscar` se
movieron debajo del recuadro `Filtros operativos por grupo de reglas` y justo
encima de la tabla a la que pertenecen.

## Compatibilidad

- Total conserva la generación múltiple de Total, Económico, Jurídico, PH,
  RECO y SIG.
- Cada padre específico genera solamente su propia edición.
- Las 253 reglas portables y sus filtros no cambian.
- Los seis padres GPKG se publican juntos como `0.0.81`.

## Código fuente

El release adjunta dos archivos adicionales:

- código fuente completo y versionado de Proyecto Gestor;
- código fuente generado de los seis plugins GPKG, organizado por carpeta.

Ninguno incluye credenciales, archivos locales, datos reales ni el historial
interno `.git`.
