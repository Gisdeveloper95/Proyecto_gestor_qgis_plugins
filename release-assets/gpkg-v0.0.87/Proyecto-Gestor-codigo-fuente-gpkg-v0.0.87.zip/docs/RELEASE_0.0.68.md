# Calidad GPKG 0.0.68 — corrección de visibilidad en QGIS

`0.0.68` corrige el error de publicación de `0.0.67`: los seis complementos
habían quedado con `experimental=True`, por lo que QGIS los ocultaba salvo que
el usuario habilitara explícitamente los complementos experimentales.

La versión declara `experimental=False` en el XML y dentro de cada ZIP. El gate
de release comprueba ambas ubicaciones. No cambian el catálogo portable, las
253 reglas ni sus resultados.

Publicado en:

`https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/tag/gpkg-v0.0.68`

QGIS 3.44.11 descargó el XML remoto con su instalador real, mantuvo desactivada
la opción de complementos experimentales y mostró las seis ediciones estables.

Repositorio estable de QGIS:

`https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/latest/download/plugins.xml`
