# Equivalencia portable SIG_02 - 2026-07-18

## Resultado

`SIG_02` queda en estado `passed_synthetic_fixture_v1`. Sobre el mismo fixture
sintetico autorizado, el SQL canonico en PostgreSQL/PostGIS y la implementacion
Calidad GPKG produjeron:

- estado correcto en ambos backends;
- seis filas en ambos backends;
- las mismas 33 columnas normalizadas;
- el mismo multiconjunto, incluidos los dos hallazgos identicos para `T-7`;
- los mismos valores nulos y decisiones de excepcion;
- SHA-256 semantico
  `1B2ABFB3B9BDAB5B29C8D505728C53A35BD51CD43A1937C7F412354B81421FA1`.

El orden observado tambien coincidio, con SHA-256
`96EF67B69E72EAE011F39769EC653B73858BB3346DF8CD9D33B297F1D44940DE`.
No es el criterio semantico porque el `ORDER BY` canonico no define un
desempate total. La comparacion autorizada conserva filas y multiplicidad como
multiconjunto canonico.

## Entradas fijadas

| Sujeto | SHA-256 |
| --- | --- |
| Fixture `portable-sig-02-synthetic-v1` | `56D1DC331414D5755FD660084FEDE815B597C933E1C4EE6A6AF34A2E62DA87AE` |
| SQL canonico, UTF-8 normalizado a LF | `5E8ECFB7FF31118548D25DF4D238EE1515073C05814CAECA1443CF0D08DBD5C6` |
| Implementacion portable aislada | `4E7FAA3A88053C05901C6E6EE6CD80DF95F65B93142B73381DD1F680CC5CC1EB` |
| Normalizador de resultados | `CFF7090B047C33D9E373463C0B36E03FD65B990E26E5D29E7963AD97EAD75163` |
| Evidencia JSON | `98B326A5227894DE763370CB4F4B34771490110A3BDBF4F7EC933FE8596D0C28` |

La corrida certificada observo PostgreSQL `18.4` y PostGIS `3.6.2` en
`localhost:5432`. El harness exige PostgreSQL 18.4 y la familia PostGIS 3.6.x;
CI repite la prueba con una imagen fijada por digest.

## Reproduccion segura

`tools/test_portable_postgis_equivalence.py` toma host, puerto, base
administrativa, usuario y autenticacion exclusivamente desde variables
`MT_GPKG_TEST_PG18_*`. No serializa DSN, clave, host, nombre aleatorio ni datos
reales. Solo admite loopback.

El script crea una base con el patron
`mt_gpkg_sig02_eq_<16-hex>`, verifica que no exista, carga las tres tablas
sinteticas, ejecuta el SQL exacto, ejecuta el backend portable y elimina
exclusivamente esa base mediante un identificador SQL escapado y
`DROP DATABASE ... WITH (FORCE)`. Si el teardown falla, no emite un reporte
correcto.

La evidencia versionada es
`docs/evidence/SIG_02_POSTGIS_GPKG_EQUIVALENCE_2026-07-18.json`. El harness y el
gate de release contrastan sus hashes y su alcance en cada corrida.

## Limite de la afirmacion

Esta evidencia no certifica datos productivos, geometria, rendimiento general,
las otras 251 reglas ni equivalencia 253/253. Total GPKG y SIG GPKG tienen
cobertura real 2/253 al sumar la evidencia independiente de `SIG_09`; RECO, PH,
Juridico y Economico GPKG conservan cero reglas
portadas y reportan `backend_unsupported`.

La certificacion tecnica tampoco concede licencia, procedencia ni autorizacion
de publicacion. Los nueve bloqueos juridicos y de aprobacion de `0.0.11`
permanecen cerrados.
