# Calidad GPKG 0.0.83 — alcance informal y perfiles mixtos

Esta versión corrige un error de alcance operativo sin modificar las 253 SQL
canónicas ni sus planes `generated_plan_v1`.

## Correcciones

- El nuevo selector **Alcance de predios para esta ejecución** permite mantener
  el modo automático por regla o forzar NPH, Condominio, PH o Informalidad
  sobre todas las reglas marcadas.
- Al elegir **Informalidad**, incluso un grupo amplio como RECO/Calificación se
  limita a las condiciones configuradas y conserva los filtros generales.
- La condición 0 solo entra cuando el predio está marcado para visita informal.
- Las 41 reglas RECO de Calificación declaran `pk_id_predio` en su salida y
  quedan cubiertas por una prueba de regresión.
- Los hallazgos espaciales genuinamente huérfanos, como terrenos sin predio,
  continúan visibles porque no existe un predio al cual aplicar el alcance.

## Perfiles simplificados

El plugin Total puede empaquetar en un solo ZIP hijo una selección arbitraria
de reglas pertenecientes a varias familias. Ese perfil se identifica como
**Mixto personalizado**, usa una miniatura propia y guarda:

- Las reglas exactas seleccionadas.
- Las familias incluidas.
- El alcance operativo y los valores de filtros.
- El mapeo de capas y las preferencias de fuente.

Los plugins padre por familia continúan generando sus propios hijos
simplificados.

## Verificación

- Pruebas deterministas de la política general, NPH, Condominio, PH e
  Informalidad.
- Regresión de `Reco_05` bajo alcance forzado de Informalidad.
- Contrato de `pk_id_predio` para todas las reglas RECO/Calificación.
- Smoke test offscreen con QGIS 3.44.11: ejecución repetida, limpieza, filtros,
  paginación, mapa, formularios, CSV, XLSX, GPKG e hijos individuales/mixtos.
- Construcción reproducible de los seis ZIP padres.

`0.1.0` continúa bloqueado hasta autorización expresa del propietario.
