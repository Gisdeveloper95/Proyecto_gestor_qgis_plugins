# Equivalencia portable SIG_01 — 2026-07-19

## Resultado certificado

`SIG_01` queda en estado `passed_synthetic_fixture_v1`. El SQL canónico se
ejecutó en PostgreSQL 18.4/PostGIS 3.6.2 y la implementación portable se ejecutó
tanto con el proveedor en memoria como con `GeoPackageDataSource` sobre un
archivo `.gpkg` físico creado desde las mismas ocho entidades sintéticas CC0.
Los tres recorridos produjeron 18 filas y el mismo multiconjunto en las 46
columnas estables del resultado.

El SHA-256 semántico común es
`CC7EF9064D91BAB2022BE6B3B3CB2D4EF1C3DA1FFD69B816762FA10738A35F20`.
Las únicas columnas excluidas del valor exacto son `fecha_creacion` y
`fecha_modificacion`, ya que el SQL las genera con `now()` en cada ejecución.
En ambos motores se verificó que fueran no nulas, constantes durante la corrida
y compartieran el mismo valor entre creación y modificación. No se excluyeron las
excepciones, los catálogos, los estados, la asignación, el área ni los campos
`custom_*`.

`ordered_equal=false` es diagnóstico. El `ORDER BY` está dentro del CTE `b5`;
el `SELECT` exterior no declara orden y PostgreSQL no garantiza que lo conserve.
La equivalencia se decide por multiconjunto
normalizado con multiplicidad.

## Semántica homologada

La regla identifica predios activos sin terreno en el proveedor correcto:

- carácter 22 igual a `2` o `5`: terreno informal;
- cualquier otro carácter, incluida una cadena corta: terreno formal;
- número predial nulo: no coincide con ninguno de los dos proveedores;
- predio cancelado: queda fuera de la población;
- `pk_id` nulo: no puede coincidir en el `LEFT JOIN` final y se reporta;
- códigos de terreno repetidos: se comportan como existencia y no multiplican
  resultados, reproduciendo el `UNION DISTINCT` canónico;
- duplicados de predio y multiplicidades de destino, excepción, asignación y
  catálogos: se preservan.
- si dos filas activas comparten `pk_id` y solo una tiene NPN cubierto, el join
  final por `pk_id` suprime ambas, exactamente como el SQL canónico.

El fixture incluye ramas formal, informal `2` e informal `5`, proveedor
equivocado, número nulo y corto, predio cancelado, códigos repetidos, dos
excepciones válidas, dos asignaciones, catálogos duplicados, claves nulas, un
`pk_id` nulo y el caso de `pk_id` compartido entre un NPN cubierto y otro no
cubierto. Los tres recorridos coinciden también en los 18 resultados esperados
declarados en el fixture.

## Ejecución acotada e integridad

La implementación usa SQLite temporal en disco, caché de 4 MiB, lotes de 256,
cursor de salida y cancelación cooperativa durante carga, joins y lectura. Una
prueba de 20.000 omisiones consumidas desde el cursor confirmó memoria Python
inferior a 24 MiB y eliminación del staging después de cancelar tanto durante
la carga como durante la entrega de resultados.

El almacenamiento conserva el diccionario canónico completo. La tabla y el CSV
parten de la proyección heredada y añaden automáticamente las columnas de salida
de cada regla, por lo que los 48 campos declarados de `SIG_01` permanecen
consultables y exportables.

El módulo de la regla y su helper se verifican antes de importar. El manifiesto
fija individualmente ambos archivos y un hash canónico del bundle completo.
Los gates prueban además la misma integridad dentro de los ZIP y rechazan una
alteración del helper o del hash agregado.

| Sujeto | SHA-256 |
| --- | --- |
| Fixture sintético | `6A7EBE6E55075E5BA0231CDD8311209F512D70E3FF5C87BE1A20FCCE99977961` |
| SQL canónico, UTF-8 normalizado a LF | `7734A6F16C6C851FF7A9B207158CEEC1DC5F5A07F4737CB081355AD1D17DE859` |
| Implementación portable | `F0522F4359E9FEB758EFE3C08AF6C4BC32BAED35B1B488FCE864927C75E3061F` |
| Helper portable compartido | `5D637139EA41938D90635C210DDC481F1F955B32F3A5AA206A510EACF93317B2` |
| Bundle de ejecución | `5E7F3EDAE90DD4AD5B89B85365FE6BA7C80F4AF3DAC843F0B82F412269C1680C` |
| Normalizador | `CFF7090B047C33D9E373463C0B36E03FD65B990E26E5D29E7963AD97EAD75163` |
| Evidencia JSON | `9BC5BF6CEF4A1DE32688C73CF5493E75E61900607A2BDB72F63AD524A36A399F` |

La evidencia versionada está en
`docs/evidence/SIG_01_POSTGIS_GPKG_EQUIVALENCE_2026-07-19.json`. El escritor de
evidencia se niega a sobrescribir un artefacto histórico divergente.

## Observación local sobre el volumen restaurado

Como verificación adicional, las ocho tablas requeridas de
`cartoflow_pruebas` se exportaron a un GPKG temporal de 17.911.808 bytes. La
regla produjo 9.528 filas tanto en PostgreSQL como en GPKG y los dos
multiconjuntos de 46 columnas estables coincidieron. El archivo temporal se
eliminó al terminar y no forma parte de Git, fixtures ni paquetes.

Esta observación refuerza la viabilidad técnica, pero no amplía la afirmación
formal más allá del fixture sintético ni convierte el dump en representación
completa de CartoFlow.

## Límite del corte

Con `SIG_01`, `SIG_02`, `SIG_09` y `SIG_10`, Total GPKG y SIG GPKG alcanzan
4/253 reglas. RECO, PH, Jurídico y Económico GPKG siguen en cero y responden
`backend_unsupported`. No se afirma equivalencia productiva del catálogo, no se
ha creado tag y no se ha publicado ningún paquete.
