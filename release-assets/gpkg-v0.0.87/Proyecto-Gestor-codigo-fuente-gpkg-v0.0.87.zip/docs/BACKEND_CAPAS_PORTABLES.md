# Backend de capas portables

## Decision de arquitectura

Existen dos ediciones independientes que pueden instalarse juntas. Los seis
validadores DBA/PostGIS `0.0.9` conservan el catalogo SQL canonico. Los seis
Calidad GPKG `0.0.67` no contienen ese catalogo, conexiones, autenticacion ni
credenciales; solo empaquetan implementaciones portables reimplementadas y
versionadas. Esta expresion tecnica no concede autorizacion juridica. No se
traduce SQL PostgreSQL durante una corrida.

Total GPKG implementa las 253 reglas: Jurídico 82, RECO 71, SIG 16, PH 77 y
Económico 7. PostGIS sigue
siendo el backend canonico y sus seis ZIP
no se renombran ni se hacen pasar por la edicion portable. Cada ZIP fragmentado
incluye solo el runtime y los módulos exigidos por su manifiesto; una familia
con cero reglas no transporta implementaciones SIG inutilizadas.

La proyección de presentación es extensible: conserva las columnas heredadas y
añade la unión ordenada de `output_columns` declarada por las reglas del paquete.
La tabla paginada y el CSV, por tanto, no descartan campos canónicos nuevos.

## Fuentes admitidas

- GeoPackage sera el contrato local primario y podra contener varias entidades
  del modelo en un unico archivo.
- Shapefile, GeoJSON y FlatGeobuf se normalizaran primero a un GeoPackage
  temporal e inmutable para la corrida.
- Las capas en memoria o de otros proveedores cargadas en QGIS se capturaran en
  el mismo snapshot temporal mediante un adaptador del plugin.
- MapingTool realizara la normalizacion con GDAL/pyogrio y no importara QGIS
  Core. El plugin puede usar la API de QGIS solo en su adaptador de entrada.

El snapshot registrara origen, proveedor, CRS, campos, conteos, hashes y el
mapeo entre cada capa y la entidad logica del modelo. Una capa no se asociara
por nombre de forma silenciosa cuando haya ambiguedad.

## Contrato de ejecucion

Se introduciran estas interfaces sin cambiar el resultado comun:

- `DataSource`: descubre entidades, campos, CRS y capacidades de una fuente.
- `LayerMapping`: relaciona capas fisicas con entidades logicas declaradas.
- `RuleBackend`: ejecuta una implementacion portable explicitamente versionada.
- `BackendPreflight`: valida capas, campos, tipos, CRS, dependencias y permisos.

Cada regla declarara al menos:

- backends implementados y estado de equivalencia;
- capas, campos y relaciones requeridas;
- dialecto o funcion portable y su SHA-256;
- columnas canónicas de salida y columnas volátiles excluidas de equivalencia;
- semantica de nulos, duplicados, precision y orden estable;
- fuente geometrica, CRS y tolerancia cuando corresponda.

Si falta una dependencia o la regla aun no tiene implementacion portable, el
resultado sera `dependency_missing` o `backend_unsupported`. Ninguno de esos
estados se contabilizara como regla correcta.

## Motor SQL portable

El candidato preferido es DuckDB con su extension espacial empaquetada y fijada
por version/hash, porque permite consultar GPKG, Shapefile y FlatGeobuf mediante
GDAL y conserva un modelo SQL cercano al catalogo actual. La aplicacion no
ejecutara `INSTALL` ni descargara extensiones en tiempo de uso. Antes de fijarlo
se hara un spike de empaquetado en Python 3.12/QGIS 3.44, licencias, tamano y
operacion totalmente offline. El contrato anterior permite sustituir el motor
sin cambiar las reglas ni los resultados expuestos.

El preflight local de QGIS 3.44.11 encontro DuckDB `1.5.2`, pero su extension
Spatial figura `NOT_INSTALLED`. Por eso `0.0.10` a `0.0.67` usan SQLite en modo
de solo lectura y staging local para las 253 implementaciones actuales. No
ejecutan `INSTALL`, no usan red y no prometen
operaciones espaciales DuckDB.

Las operaciones que no tengan equivalencia exacta en ese dialecto se
implementaran con GDAL/GEOS/Shapely bajo una funcion portable versionada; no se
degradaran a comparaciones aproximadas sin declararlo.

## Medicion inicial del catalogo

El inventario actual contiene 253 SQL. Una inspeccion sintactica reproducible
encuentra funciones `ST_*` en cuatro reglas: `Jur_47`, `PH_67`, `Reco_49` y
`SIG_16`. Tambien encuentra casts PostgreSQL en 250 reglas, `ILIKE` en 27 y
`DISTINCT ON` en 17. Estas cifras sirven para planificar la migracion, no para
afirmar equivalencia: varias reglas sin funciones espaciales consumen tablas
derivadas que deben existir o reconstruirse en el snapshot portable.

## Gate de equivalencia

Una regla solo pasara a estado portable equivalente cuando, sobre fixtures
sinteticos autorizados, ambos backends produzcan:

1. el mismo estado de dependencia;
2. el mismo conjunto de identificadores estables;
3. la misma multiplicidad de filas por identificador;
4. los mismos campos normalizados y decisiones de excepcion;
5. geometria topologicamente equivalente dentro de la tolerancia declarada.

Los manifiestos de corrida fijaran el snapshot y los hashes de ambas
implementaciones. El CI impedira marcar como equivalentes reglas sin evidencia
o mezclar resultados de backends distintos bajo un mismo manifiesto.

Cuando el SQL canonico no define un orden total para empates, el criterio
semantico sera el multiconjunto de las columnas normalizadas: se conservan
duplicados y su multiplicidad. El orden observado se registra como diagnostico,
pero no se convierte en una condicion accidental dependiente del motor.

## Slice real 0.0.10

Se eligio `SIG_02` porque su decision depende exclusivamente de tres entidades
y cinco campos, no de geometria ni tablas derivadas. Su implementacion portable
esta fijada por SHA-256 en `quality_core/portable_manifest.json`. El estado
`passed_synthetic_fixture_v1` certifica solamente esta regla sobre el fixture
sintetico versionado: PostgreSQL 18.4/PostGIS 3.6.2 y el backend portable
produjeron las mismas seis filas, campos normalizados, nulos y multiplicidades.
La evidencia inmutable vive en
`docs/evidence/SIG_02_POSTGIS_GPKG_EQUIVALENCE_2026-07-18.json` y el CI repite
la comparacion en una base PostGIS desechable.

La edicion Calidad GPKG permite mapear explicitamente `lc_gen_predio`, `lc_gen_terreno` y
`lc_gen_terreno_informal` a `layerId` cargados o tablas de un GPKG. Una unica
coincidencia exacta se preselecciona de forma visible; cero o multiples
coincidencias permanecen sin asignar. Las capas cargadas se capturan con OGR a
un snapshot temporal; una entrada GPKG se respalda con la API SQLite backup,
incluyendo commits presentes en WAL. SQLite abre el snapshot con `mode=ro` y
solo selecciona los atributos declarados, nunca el blob geometrico.

La entrada directa se limita a `.gpkg` en este slice. Shapefile, GeoJSON y
otros proveedores pueden usarse si primero se cargan como capas QGIS y se
capturan en el snapshot. La preparacion permanece en el hilo UI por seguridad
de los objetos QGIS, con dialogo de progreso: backup SQLite, hash y los drivers
que respeten `QgsFeedback` son cancelables; un driver que ignore ese feedback
puede terminar su capa antes de atender la cancelacion. El worker revalida el
SHA-256 antes de abrir el snapshot.

`SIG_02` usa un staging SQLite temporal en disco, cache de 4 MiB, lotes de 256,
indices y cursor de salida. Asi la regla no conserva predios, terrenos ni
hallazgos completos en RAM. El preflight comprueba nombres y familias de tipos
declaradas; un tipo incompatible queda `dependency_missing`, nunca `OK`.

Los namespaces de QSettings, menu, toolbar, acciones, temporales y resultados
son distintos de los DBA. La prueba offscreen carga y descarga las doce
extensiones juntas y verifica que desmontar una edicion no retire la otra.

## Segundo slice real 0.0.11

`SIG_09` agrega cuatro entidades y once campos declarados sin leer geometria.
La implementacion reproduce el `UNION DISTINCT` de unidades formales e
informales, el filtro `substring(codigo, 22, 1) <> '9'`, la coincidencia por
codigo e identificador y la supresion posterior por predio con cambio fisico.
Un predio con cambio fisico pero sin caracteristicas RECO no entra al CTE
canonico y, por tanto, no suprime una unidad; ese caso queda fijado en el
fixture.

El staging de `SIG_09` tambien es SQLite temporal en disco, con cache de 4 MiB,
lotes de 256, indices y cursor. Los estados ambiguos que el `DISTINCT ON` sin
orden no permite trasladar de forma determinista se rechazan: `fid` nulo en un
predio activo o un mismo `pk_id` ligado a numeros prediales diferentes. No se
inventa un desempate.

Las funciones de `SIG_02` y `SIG_09` viven en archivos distintos. El manifiesto
fija SHA-256, simbolo y ruta de cada una; el runtime verifica los tres antes de
entregar un iterador. La evidencia sigue limitada a fixtures sinteticos y no
afirma equivalencia productiva ni del catalogo.

## Tercer slice real 0.0.12

`SIG_10` agrega seis entidades PH y de unidades, sin leer geometria. Reproduce
la exclusion de predios PH con novedades 5-8, el join con predio general y
caracteristicas PH, el filtro de codigo con `9` en la posicion 22, el `UNION`
entre unidades formales e informales y los anti-joins que primero detectan una
unidad sin coincidencia y luego la suprimen cuando existe cambio fisico.

El fixture CC0 cubre las cuatro novedades por separado, novedad duplicada y
nula, predio cancelado, cambio fisico con y sin caracteristica, identificador
nulo, unidades formales/informales, duplicados identicos y filas que difieren
solo en columnas ocultas por la proyeccion final. PostgreSQL 18.4/PostGIS 3.6.2
y el motor portable produjeron el mismo multiconjunto de 14 filas.

El staging SQLite conserva cache de 4 MiB, lotes de 256, indices, cursor de
salida, cancelacion y limpieza temporal. La entrada se valida contra tipos
TEXT/BOOLEAN/INTEGER declarados. Un `fid` o `pk_id` PH elegible nulo se rechaza
antes del join de caracteristicas: es una politica fail-closed deliberadamente
mas estricta que ignorar un PH huerfano, documentada para no ocultar la
ambiguedad de los centinelas de los `LEFT JOIN` canonicos.

Las tres funciones portables viven en archivos separados. El manifiesto fija
SHA-256, simbolo y ruta de cada una; el runtime verifica los tres sujetos antes
de entregar un iterador. La equivalencia usa multiconjunto con multiplicidad;
el orden observado no es contractual cuando PostgreSQL y SQLite aplican
collations o desempates no especificados diferentes.

## Cuarto slice real 0.0.13

`SIG_01` agrega ocho entidades alfanuméricas y reproduce la búsqueda de predios
activos sin terreno. La posición 22 selecciona proveedor informal para `2` y
`5`; los demás valores, incluida una cadena corta, seleccionan el formal. Un
número nulo no coincide y un `pk_id` nulo conserva la semántica del `LEFT JOIN`
canónico.

El fixture CC0 prueba proveedores correctos e incorrectos, formal, informal
`2`/`5`, cancelación, números nulos y cortos, códigos repetidos, duplicados de
predio, excepción, asignación y catálogos con multiplicidad. PostgreSQL
18.4/PostGIS 3.6.2 y GPKG produjeron 18/18 filas y el mismo multiconjunto en las
46 columnas estables. Solo se excluyó el valor exacto de los timestamps
generados por `now()`; ambos motores probaron valores no nulos y constantes por
corrida.

La implementación usa las mismas cotas de caché y lote, cursor y cancelación.
Además, el manifiesto fija el helper compartido y un hash agregado del bundle;
ningún módulo de regla se importa antes de verificar todos sus bytes. Los gates
repiten la comprobación dentro de cada ZIP y prueban manipulación adversarial.

Sobre una exportación GPKG temporal de las ocho tablas restauradas se observaron
9.528/9.528 filas equivalentes. El archivo se eliminó y esa observación local no
reemplaza la evidencia sintética ni afirma equivalencia productiva.

## Quinto slice real 0.0.14

Siete controles Jurídicos de predio comparten un pipeline declarativo y seis
entidades base. Los predicados cubren matrícula y cambio jurídico (`Jur_05`),
codificación NPN (`Jur_12–15`), área catastral (`Jur_17`) y área registral
(`Jur_18`). No se lee geometría.

Cada configuración reside en un wrapper separado y fijado por SHA-256. El
pipeline común y las primitivas aparecen como soportes explícitos dentro del
bundle de cada regla. Así, agregar un wrapper nuevo no modifica las evidencias
actuales. La resolución de IDs es case-insensitive, conserva la grafía canónica
`Jur_XX` y rechaza colisiones.

El fixture CC0 compartido contiene 23 predios y una expectativa independiente
por regla. PostgreSQL 18.4/PostGIS 3.6.2, MappingDataSource y un GPKG físico
coincidieron con conteos `4/2/2/1/2/5/9`. El contrato sigue siendo equivalencia
sintética por regla, no paridad productiva ni del catálogo completo.

## Sexto slice real 0.0.15

`Reco_50` y `Reco_51` introducen la primera familia portable cuyo resultado
operativo exige dos etapas. Cada wrapper reproduce primero la consulta cruda de
cambio de destino económico. Después, un postfiltro compartido construye el
conjunto normalizado y distinto de `pk_id` habilitados y retira los hallazgos
fuera de alcance sin deduplicar el multiconjunto crudo.

El alcance se calcula una vez por worker y se guarda en SQLite temporal con
transacción fail-closed, cursor, lotes acotados, cancelación y rollback. El
manifiesto fija por separado wrapper, soportes, postfiltro y SQL canónico del
postfiltro. Los SQL PostgreSQL se contrastan en fuente, pero no entran a los ZIP
GPKG.

El fixture CC0 contiene 19 predios y cinco catálogos/relaciones auxiliares. PostgreSQL
18.4/PostGIS 3.6.2, `MappingDataSource` y un GPKG físico coincidieron en las
tres etapas: `Reco_50` produjo 9 filas crudas y 5 finales; `Reco_51`, 7 crudas y
3 finales; el alcance normalizado común contiene 8 predios. QGIS 3.44.11 repitió
los conteos finales con GPKG directo, capas OGR cargadas y proveedor `memory`.

El contrato interno mantiene una separación explícita: `execute_raw()` produce
filas crudas únicamente para equivalencia y la API normal `execute()` aplica el
pipeline operativo RECO completo. El worker usa la etapa cruda de forma
explícita porque comparte un único alcance entre todas las reglas del lote.

## Octavo slice real 0.0.17

`Reco_03`, `Reco_04`, `Reco_05`, `Reco_16`, `Reco_18` y `Reco_48` amplían los
controles escalares de predio. PostgreSQL, el proveedor en memoria y GPKG físico
coincidieron en consulta cruda, alcance compartido y salida operativa.

El caso `Reco_16` expone una contradicción del catálogo sin esconderla: la regla
busca asignación distinta de 2 y el postfiltro global solo conserva asignación
2. El fixture produce una fila cruda y ninguna final en los tres proveedores.
La corrección semántica debe hacerse en el catálogo canónico antes de propagarse
a ambas ediciones.

## Noveno slice real 0.0.18

Dieciséis controles RECO sobre `determinacion_area_construccion` comparten un
pipeline temporal disk-backed. Cubren usos, plantas, puntajes, año, estado de
conservación, área construida y combinaciones de destino económico, preservando
la salida particular de cada SQL y su filtro operativo global.

El fixture ubica esa entidad en `general` para PostgreSQL y conserva el nombre
lógico sin esquema en GPKG. Las 16 reglas y el catálogo acumulado de 48 pasaron
la equivalencia de multiconjunto y el smoke QGIS en los tres modos de fuente.

## Décimo slice real 0.0.19

`Reco_10`, `Reco_20`, `Reco_23` y `Reco_25` reutilizan el pipeline escalar de
construcción sin ejecutar SQL PostgreSQL dentro del GeoPackage. Se preservan
las proyecciones particulares de los SQL, el equivalente de `ILIKE '{%'`, el
regex ASCII `[0-9]`, el rango de plantas y la multiplicidad del join final
redundante de `Reco_23`.

El lote coincidió fila por fila y por multiconjunto entre PostgreSQL 18.4,
PostGIS 3.6.2, el proveedor en memoria y un GeoPackage físico. El catálogo
portable acumulado queda en 52 reglas y QGIS 3.44.11 volvió a comprobar archivo
directo, capas OGR y proveedor `memory`.

## Undécimo slice real 0.0.20

`Reco_11–15`, `Reco_17`, `Reco_21` y `Reco_69` cubren contactos de visita,
marcas de visita y fotos de predio. Un pipeline relacionado disk-backed
conserva joins internos, anti-joins, nulos, catálogos, excepciones, asignaciones
y la multiplicidad `2×2` de predios duplicados en `Reco_21`.

Las ocho reglas y el catálogo acumulado de 60 coincidieron entre PostgreSQL,
PostGIS, memoria y GeoPackage físico. QGIS 3.44.11 volvió a probar las doce
ediciones y los tres modos de entrada.

Desde `0.0.67` no quedan reglas del catálogo fuera del backend portable. Siguen
pendientes la ampliación de escenarios de geometría, la
normalizacion de Shapefile/GeoJSON/FlatGeobuf, DuckDB Spatial, paridad sobre
datos productivos y equivalencia general del catalogo. Estos faltantes nunca se
presentan como un `OK`.
