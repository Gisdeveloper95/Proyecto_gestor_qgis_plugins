# Calidad GPKG 0.0.20 — contactos y fotos relacionadas

`0.0.20` agrega `Reco_11–15`, `Reco_17`, `Reco_21` y `Reco_69` al backend
directo GeoPackage.

| Familia | Catálogo | Portable | Pendiente |
|---|---:|---:|---:|
| Jurídico | 82 | 13 | 69 |
| RECO | 71 | 43 | 28 |
| SIG | 16 | 4 | 12 |
| PH | 77 | 0 | 77 |
| Económico | 7 | 0 | 7 |
| **Total** | **253** | **60** | **193** |

El lote introduce un pipeline acotado para filas relacionadas que preserva
joins internos, anti-joins, semántica nula y multiplicidad. La evidencia ejecutó
los SQL canónicos en PostgreSQL 18.4/PostGIS 3.6.2 y obtuvo el mismo
multiconjunto en memoria y en un GeoPackage físico.

QGIS 3.44.11 verificó las doce ediciones coexistentes y los tres modos de
entrada. Los seis ZIP locales son reproducibles byte a byte. La publicación
permanece deliberadamente bloqueada por seis licencias de ZIP, metadata pública,
aprobación versionada y licencia first-party. No hubo instalación, tag, push ni
release.

Evidencia consolidada:
`docs/evidence/GPKG_0.0.20_LOCAL_CHECKPOINT_2026-07-19.json`.
