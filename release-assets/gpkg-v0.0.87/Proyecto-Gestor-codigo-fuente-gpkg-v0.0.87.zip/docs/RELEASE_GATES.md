# Gates de publicacion de plugins QGIS

La publicacion es deliberadamente *fail-closed*. El proyecto no presume la
titularidad ni inventa una licencia para el monolito SQL o para el material
derivado de `validador_helen`.

Antes de una version, un responsable autorizado debe:

1. Incorporar el archivo `LICENSE` aprobado para el codigo distribuido.
   La aprobacion debe declarar ademas `spdx_license_expression`; la politica
   fail-closed actual permite unicamente `GPL-2.0-or-later`, que se escribe en el
   SBOM como licencia declarada y concluida.
   Cada ZIP debe incluir tanto `LICENSE` como `THIRD_PARTY_NOTICES.md`; el gate
   reconstruye y compara ambos byte por byte.
2. Aprobar el codigo fuente y la cadena de construccion exactos del plugin.
3. Documentar por separado la decision de procedencia/licencia del catalogo SQL.
4. Documentar la autorizacion aplicable a cualquier derivacion de
   `validador_helen`.
5. Copiar `release/public_metadata.example.json` como
   `release/public_metadata.json`, reemplazar todos los valores y registrar
   quien comprobo que `repository`, `tracker`, `homepage` y el repositorio de
   distribucion son realmente publicos. El repositorio fuente privado actual no
   satisface este gate.
6. Copiar `release/approvals/version.example.json` como
   `release/approvals/<version>.json`, completar responsable y fecha con zona
   horaria, y fijar los hashes SHA-256 de los cinco artefactos y sujetos
   revisados. La forma del registro esta documentada en
   `release/approval.schema.json`.
7. Consultar los hashes compuestos con
   `python tools/check_release_gates.py --version <version> --show-subject-hashes`.
8. Consultar el hash canonico de cada documento de aprobacion con
   `python tools/check_release_gates.py --version <version> --hash-artifact <ruta>`.
9. Ejecutar `python tools/check_release_gates.py --version <version>`.

El gate compara los hashes declarados con `LICENSE`, la plantilla, codigo,
constructor, verificador, publicador, workflow, esquema de aprobacion, icono,
changelog y avisos que forman la cadena de release; tambien cubre el catalogo
exacto (`manifest.json` y sus 253 SQL), el arbol de `validador_helen` y los
endpoints publicos verificados. Cualquier cambio posterior invalida la
aprobacion. Un archivo `.example.json` nunca habilita una publicacion.

El subject del catalogo incluye ademas el monolito apuntado por
`manifest.source` (actualmente `Calidad_v5_python/queries_valledupar.sql`). La
ruta debe existir dentro del repositorio. Tambien incluye el lock, el ledger de
procedencia por regla y sus dos generadores. Asi la aprobacion de procedencia no
puede desligarse silenciosamente de la fuente ni de la forma de comprobar sus
253 extractos exactos.

Los hashes canonicos normalizan finales de linea de texto a LF para producir el
mismo valor en Windows y en el runner Linux de CI; los archivos binarios se
calculan byte por byte.

La verificacion se ejecuta en GitHub Actions y dentro de las herramientas de
bundle/publicacion. `0.0.8` queda permanentemente como evidencia local y no se
etiquetara. `0.0.9` es un parche tecnico posterior, pero continua no publicable
mientras falte cualquiera de estos gates; su implementacion de paginacion no
constituye una aprobacion de licencia, procedencia, RECO o identidad.

El JSON no autentica por si solo la autoridad de quien aprueba. El environment
protegido `qgis-release`, sus revisores, las reglas de tags y la custodia de la
clave son controles externos obligatorios. Mientras no esten configurados y
verificados fuera del repositorio, ningun registro local basta para publicar.

## Gate independiente Calidad GPKG

La edicion Calidad GPKG usa `gpkg_release_gates.py` y el environment separado
`qgis-gpkg-release`. Ademas de licencia, metadata y aprobacion propias, el gate
exige evidencia por cada regla declarada como equivalente. En `0.0.15` recorre
el manifiesto completo y fija por SHA-256 el fixture sintetico, SQL canonico
normalizado a LF, normalizador, archivo de implementacion, archivos auxiliares,
bundle de ejecucion y JSON de comparacion cruzada de las cuatro reglas SIG, las
siete reglas Jurídicas y las dos reglas RECO implementadas. Para RECO también
fija el postfiltro operativo, su contrato y el SQL canónico de alcance. El SQL
canónico se verifica únicamente en fuente y no se distribuye dentro de los
plugins; solo los sujetos distribuibles —wrapper, soportes/postfiltro y
manifiesto— se contrastan contra los bytes dentro de cada ZIP. Rutas duplicadas,
escapes de directorio o manipulación del helper
bloquean el release.

El estado `passed_synthetic_fixture_v1` no habilita equivalencia productiva ni
del catalogo. Los workflows vuelven a ejecutar ambos backends en PostgreSQL
18.4/PostGIS 3.6.x sobre una base desechable. Si cambia cualquier sujeto o el
multiconjunto normalizado declarado por la evidencia, esta y el gate dejan de
coincidir. El conteo esperado se toma del fixture de cada regla, no de una
constante compartida. El escritor permite seleccionar una evidencia nueva y se
niega a sobrescribir un artefacto histórico divergente.

`SIG_01`, las siete reglas `Jur_XX` y las dos reglas `Reco_XX` exigen además una
ejecución mediante
`GeoPackageDataSource` sobre un
archivo físico y registra el proveedor observado. CI construye los seis ZIP dos
veces y exige igualdad byte a byte. Después contrasta nombres, tamaños y hashes
de las ediciones DBA/GPKG contra el checkpoint local versionado; un JSON obsoleto
o una evidencia cuya fecha no coincida con su nombre falla cerrado. El workflow
de tags repite estos controles y no depende de que el workflow de rama haya
corrido antes.

Mientras no exista aprobacion juridica, el resultado esperado de `0.0.15` son
exactamente nueve bloqueos: seis `LICENSE` ausentes en los ZIP, metadata
publica GPKG, aprobacion versionada y licencia first-party raiz. Un decimo
mensaje indica un defecto tecnico nuevo, no un bloqueo intencional.

## Bundle firmado separado

`dist/` sigue siendo un build local, reproducible y sin firma. No se publica.
Despues de pasar todos los gates se crea otro directorio:

```powershell
python -m pip install --require-hashes -r requirements-release.txt
python tools\release_bundle.py prepare --version <version> --dist dist --bundle release-bundles\v<version>
```

El bundle contiene exactamente los seis ZIP, `plugins.xml`, icono,
`CHANGELOG.md`, `THIRD_PARTY_NOTICES.md`, `sbom.spdx.json`,
`release-manifest.json`, `SHA256SUMS` y el directorio `provenance/`. Este ultimo
incluye una copia exacta del JSON de aprobacion y de los cinco documentos que
referencia. El manifiesto conserva tanto la ruta original como la ruta dentro
del bundle, el nombre plano usado como asset de GitHub y el SHA-256 de cada
evidencia. Los nombres planos son unicos; al reconstruir el directorio firmado,
el manifiesto indica que archivos deben ubicarse de nuevo bajo `provenance/`.
El XML, el SBOM, el manifiesto y los
checksums se reconstruyen deterministamente durante cada verificacion.

La firma requiere una clave privada RSA de al menos 2048 bits situada fuera del
repositorio. La herramienta verifica todo el bundle antes de firmar:

```powershell
python tools\release_bundle.py sign --version <version> --bundle release-bundles\v<version> --private-key C:\ruta-segura\release-private.pem
```

La clave publica y el archivo que contiene su trust anchor SHA-256 tambien deben
estar fuera del repositorio. El hash corresponde al DER canonico
SubjectPublicKeyInfo de la clave publica (independiente de saltos de linea PEM) y
se puede calcular por un canal de confianza con:

```powershell
python tools\release_bundle.py trust-anchor --public-key C:\ruta-segura\release-public.pem
python tools\release_bundle.py verify --version <version> --bundle release-bundles\v<version> --public-key C:\ruta-segura\release-public.pem --trust-anchor-file C:\otro-canal\release-trust-anchor.sha256
```

No se versiona ni se embebe ninguna clave o trust anchor. La firma detached es
RSASSA-PKCS1-v1_5 con SHA-256 sobre los bytes canonicos de `SHA256SUMS`.
Ese archivo incluye una entrada SHA-256 exacta para `release-manifest.json` y
para cada artefacto primario. Por tanto, la cadena verificada es
`SHA256SUMS.sig -> SHA256SUMS -> release-manifest.json -> inventario/aprobaciones`:
el manifiesto queda criptograficamente cubierto sin introducir el ciclo que
produciria intentar guardar su propio hash dentro de si mismo. El verificador
reconstruye y compara byte por byte ambos archivos antes de aceptar la firma.
Las copias bajo `provenance/` tambien aparecen individualmente en
`SHA256SUMS`; adulterar o retirar una invalida el bundle.

Cuando todos los gates y la firma pasan, el publicador crea primero un borrador,
carga el bundle completo y solo entonces hace publica la release. Exige las
rutas externas de clave publica y trust anchor antes de leer el token. Una
release ya publica se considera inmutable y no se sobrescribe.

El argumento `--repo` debe coincidir exactamente con el repositorio GitHub
declarado en el metadata publico aprobado. Si se reutiliza un draft, cualquier
asset remoto ajeno al bundle bloquea la operacion. Tras las cargas se vuelve a
consultar el draft y se exigen nombres, tamanos, estado `uploaded` y digests
`sha256:<64-hex>` exactos para todos los assets antes
de finalizarlo. Un asset en estado `starter` o sin digest bloquea la release.

En GitHub Actions, el environment protegido `qgis-release` debe configurarse
fuera del repositorio con revisores requeridos y reglas que solo admitan tags de
release protegidos. Sin esa configuracion y los secretos externos, el workflow
falla cerrado.
