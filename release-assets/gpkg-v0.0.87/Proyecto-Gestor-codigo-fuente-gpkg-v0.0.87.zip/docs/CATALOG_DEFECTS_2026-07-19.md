# Defectos canónicos aislados durante la homologación GPKG

## Jur_10 devuelve la identidad Jur_06

Archivo: `quality_core/rules/juridico/Jur_10.sql`.

La cabecera declara `-- name: Jur_10` y el manifiesto lo cataloga como
`Jur_10`, pero el `SELECT` devuelve el literal `Jur_06` en `id_regla`. La unión
con `lc_gen_excepciones` también consulta `lge.id_regla = 'Jur_06'`.

Impacto: si se ejecuta como estaba, los hallazgos de `Jur_10` se identificaban
como otra regla y podían mezclarse con excepciones de `Jur_06`. Se corrigieron
ambos literales a `Jur_10` antes de homologar y certificar la regla portable.

## Jur_60 devolvía Jur_59 y consultaba excepciones de Jur_58

Archivo: `quality_core/rules/juridico/Jur_60.sql`.

La cabecera declaraba `Jur_60`, pero el resultado proyectaba `Jur_59` y la
unión de excepciones consultaba `Jur_58`. Se corrigieron ambos literales a
`Jur_60`; de otro modo, el ejecutor no podía atribuir ni recuperar excepciones
de esta regla de forma segura.

## Reco_16 queda anulada por el filtro operativo global

Archivos: `quality_core/rules/reco/Reco_16.sql` y
`quality_core/reco_post_filter.sql`.

`Reco_16` exige control igual a 1 y asignación distinta de 2. El filtro global
que se aplica después a todas las reglas RECO exige asignación igual a 2. Por
lo tanto, ningún hallazgo crudo de `Reco_16` puede sobrevivir al resultado
operativo.

Impacto: la consulta sí puede producir hallazgos, pero el plugin muestra cero
después del filtro. `0.0.17` conserva la conducta canónica en PostgreSQL y GPKG
y la deja cubierta por una prueba explícita 1 cruda → 0 finales. Cambiarla
requiere una decisión de catálogo común para las ediciones DBA y GPKG.

## Reco_10 proyecta el catálogo de uso como tipo de unidad

Archivo: `quality_core/rules/reco/Reco_10.sql`.

La consulta une correctamente `lc_reco_unidadconstruccion_tipo` como `lrut`,
pero en la proyección usa `lgut.ilicode` tanto para
`tipo_unidad_construccion` como para `uso_construccion`. El alias `lrut` no se
usa en la salida.

Impacto: el valor presentado como tipo repite el uso. `0.0.19` conserva este
resultado para mantener equivalencia exacta entre DBA y GPKG; corregirlo exige
modificar primero el catálogo canónico y volver a certificar ambas ediciones.
