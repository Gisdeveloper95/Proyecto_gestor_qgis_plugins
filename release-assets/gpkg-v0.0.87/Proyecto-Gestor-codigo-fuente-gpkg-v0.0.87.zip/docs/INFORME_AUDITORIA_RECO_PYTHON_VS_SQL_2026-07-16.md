# Informe de auditoría: reglas RECO Python vs SQL

**Fecha:** 16 de julio de 2026
**Base evaluada:** `cartoflow_pruebas` (`localhost:5433`)
**Fuentes comparadas:** `validador_helen/inconsistencias_reco/reco_*.py` y `quality_core/rules/reco/Reco_*.sql`
**Evidencia reproducible:** `docs/evidence/RECO_Python_vs_SQL_2026-07-16.csv`

> **Actualización del 17 de julio de 2026:** después de seguir el flujo completo del plugin de referencia se confirmó que sus cuatro filtros globales se aplican al resultado de cada regla, no antes de ejecutarla. La versión `0.0.7` y el auditor actualizado usan esa semántica posterior. Las conclusiones de este informe sobre diferencias internas de lógica siguen siendo evidencia histórica, pero su recomendación de alcance pre-SQL de la sección 7 queda reemplazada por `docs/GESTION_REGLAS_SQL.md`. Como control puntual, `Reco_50` y `Reco_51` coinciden exactamente en ambos motores con 228 y 123 predios.

## 1. Resumen ejecutivo

Se compararon exclusivamente las 43 reglas que tienen implementación en ambos lados. Todas las reglas Python se forzaron a estado habilitado, se alimentaron desde las mismas tablas PostgreSQL y se aplicó el mismo universo de predios a ambos motores.

El resultado correcto debe distinguir entre **filas SQL** y **predios distintos**. El plugin Python devuelve normalmente un `set()` de predios; una SQL puede devolver varias unidades, fotos, calificaciones o asignaciones para un mismo predio. Comparar solamente el número de filas produce falsos desacuerdos.

Resultado consolidado:

| Estado | Reglas | Interpretación |
|---|---:|---|
| Mismos predios | 19 | Coincidencia exacta de `pk_id_predio`. |
| Mismos predios, filas SQL adicionales | 5 | La lógica coincide; cambia la granularidad del resultado. |
| Predios realmente diferentes | 12 | Existen condiciones, fuentes o sentidos de comparación distintos. |
| Comparación SQL bloqueada | 7 | La SQL no terminó en este respaldo; no se emite veredicto todavía. |

La conclusión principal es que el cableado de capas no explica las diferencias persistentes. Hay reglas equivalentes, reglas con duplicación de detalle y reglas mal homologadas de forma demostrable.

## 2. Método de comparación

El auditor `tools/audit_helen_vs_sql.py` realizó lo siguiente:

1. Cargó las diez tablas utilizadas por los scripts Python como capas QGIS simuladas con los mismos nombres esperados por el plugin.
2. Ejecutó cada `reco_*.py` con todas las banderas habilitadas.
3. Aplicó los filtros finales del plugin anterior: reconocimiento en estado `2`, no cancelado, condición distinta de `2,5,8,9` y no marcado como informal para visita.
4. Ejecutó la SQL equivalente sobre la misma base y con el mismo alcance previo.
5. Comparó conjuntos distintos de `pk_id_predio`, intersecciones, exclusivos de cada lado y filas SQL duplicadas.

## 3. Reglas con diferencia aparente de conteo

Estas reglas encuentran exactamente los mismos predios. No requieren cambiar la lógica; el resumen del plugin debe mostrar por separado filas SQL y predios afectados.

| Regla | Python | Filas SQL | Predios SQL | Veredicto |
|---|---:|---:|---:|---|
| `Reco_17` | 2374 | 2378 | 2374 | Conservar SQL; eliminar o identificar las 4 filas repetidas. |
| `Reco_20` | 10 | 11 | 10 | Conservar SQL; una fila adicional corresponde a detalle repetido. |
| `Reco_22` | 15 | 17 | 15 | Preferir SQL: soporta secuencias de dos letras; deduplicar resumen. |
| `Reco_26` | 6 | 8 | 6 | Preferir SQL por conservar la calificación causante; resumen por predio. |
| `Reco_39` | 6 | 12 | 6 | Preferir SQL: dos detalles de calificación por cada predio son información útil. |

## 4. Reglas con diferencia real

### `Reco_06` - Python 9514, SQL 49, intersección 49

**Causa:** el Python convierte un nulo en la cadena `"None"`, pero su lista de nulos contiene `"NONE"` y esos campos no se convierten a mayúsculas. Miles de valores nulos terminan interpretados como usos comercial o industrial diligenciados. Además, Python usa columnas `uso_*`, mientras la SQL usa `tipo_unidad_construccion`.

**Veredicto:** descartar la implementación Python actual. La SQL es una base mejor, pero su cálculo de unidad dominante debe reescribirse con `row_number()` o `DISTINCT ON` por área; el CTE actual mezcla suma por tipo con área individual.

### `Reco_07` - Python 189, SQL 112, intersección 108

**Causa:** Python revisa `uso_comercial` de la unidad individual de mayor área. La SQL revisa `tipo_unidad_construccion <> 1` y calcula una suma agrupada por tipo que después compara contra un área individual. No son el mismo algoritmo.

**Veredicto:** ninguna implementación debe declararse definitiva. Recomiendo una nueva SQL que seleccione explícitamente la unidad dominante y valide el uso normalizado contra el catálogo permitido.

### `Reco_21` - Python 20, SQL 21, intersección 20

**Causa:** la SQL considera que existe croquis con cualquier fila `tipo_foto = 0`; Python exige además que el campo `foto` tenga contenido.

**Veredicto:** preferir el criterio Python traducido a SQL. Una fila vacía no demuestra que exista una fotografía utilizable.

### `Reco_27` - Python 25, SQL 15, intersección 14

**Causa:** Python inspecciona cuál columna cruda (`uso_residencial`, `uso_comercial`, etc.) está diligenciada y también marca cero o múltiples columnas. La SQL usa `uso_construccion` normalizado y rangos numéricos según `tipo_unidad_construccion`.

**Veredicto:** preferir SQL como fuente principal porque valida el modelo normalizado. La detección de cero o múltiples columnas debe permanecer en `Reco_28`/`Reco_29`, evitando mezclar responsabilidades.

### `Reco_28` - Python 14, SQL 15, intersección 14

**Causa:** Python trata `999` y `1999` como valores vacíos; la SQL cuenta cualquier valor `IS NOT NULL` como un uso real. La SQL también entrega varias filas por unidad y asignación.

**Veredicto:** conservar SQL, agregando exclusión explícita de valores centinela. El criterio de limpieza del Python es mejor; la salida detallada de la SQL es mejor.

### `Reco_38` - Python 8, SQL 11, intersección 8

**Causa:** Python define unidad nueva como `pk_id` iniciado por `{`; la SQL la define como `uso_anterior IS NULL`.

**Veredicto:** el criterio Python es más consistente con `Reco_20` y con la convención observada de UUID nuevos. Debe traducirse a SQL, salvo que negocio confirme que `uso_anterior IS NULL` es el indicador oficial.

### `Reco_40` - Python 11, SQL 10445, intersección 11

**Causa:** la descripción exige una unidad sin detalle de calificación y sin puntaje anterior. Python comprueba ambas condiciones. La SQL solo evalúa `dac.puntaje IS NULL OR dac.puntaje = 0`; no revisa ausencia de calificación ni utiliza `puntaje_anterior`.

**Veredicto:** la SQL está mal homologada respecto a su propia descripción. Traducir la lógica Python a SQL es prioritario. Esta regla explica una parte importante de los resultados masivos.

### `Reco_42` - Python 13, SQL 8, intersección 0

### `Reco_43` - Python 23, SQL 1, intersección 0

**Causa:** el sentido está intercambiado. Python `Reco_42` busca disminución (`anterior - nuevo` entre 1 y 5); SQL `Reco_42` busca aumento. Python `Reco_43` busca aumento; SQL `Reco_43` busca disminución. Python también usa directamente `tipo_anexo` como puntaje no convencional, mientras SQL obtiene el valor desde el catálogo.

**Veredicto:** corregir las SQL para que el sentido coincida con los IDs y descripciones Python, conservando de SQL la validación de uso sin cambio y el cálculo del anexo mediante catálogo.

### `Reco_54` - Python 9, SQL 25, intersección 3

**Causa:** Python revisa solo la unidad de mayor área y valida dos sentidos: destino educativo sin uso educativo y destino no educativo con uso educativo. La SQL valida solamente el primer sentido, pero marca cualquier unidad no educativa aunque el predio sí tenga otra unidad educativa.

**Veredicto:** ninguna refleja exactamente “destino educativo sin uso educativo”. Recomiendo SQL con `NOT EXISTS` de cualquier uso educativo permitido. La validación inversa, si negocio la requiere, debe ser otra regla.

### `Reco_55` - Python 10, SQL 11, intersección 5

**Causa:** repite el problema de `Reco_54`. Además, Python acepta usos `49,56,57`; SQL acepta `49,56,57,65`.

**Veredicto:** reescribir con `NOT EXISTS` y confirmar funcionalmente si el código `65` es religioso. No mezclar la validación inversa en la misma regla.

### `Reco_60` - Python 1, SQL 240, intersección 1

**Causa:** Python considera incompatibles 10 destinos; SQL contiene 26 códigos. No existe problema de cableado: las listas de negocio son distintas.

**Veredicto:** preferir la lista SQL por ser más completa y provenir del catálogo maestro, pero exigir aprobación funcional de los 26 códigos antes de declararla definitiva.

## 5. Reglas habilitadas que sí coinciden

`Reco_08` y `Reco_14` aparecían antes como diferencias únicamente porque el plugin anterior las deshabilitaba por defecto. Al forzarlas a ejecución, coinciden exactamente (`3=3` y `1=1`).

También coinciden por predio: `Reco_02`, `Reco_09`, `Reco_11`, `Reco_12`, `Reco_15`, `Reco_16`, `Reco_25`, `Reco_29`, `Reco_41`, `Reco_45`, `Reco_50`, `Reco_51`, `Reco_52`, `Reco_53`, `Reco_61`, `Reco_62` y `Reco_71`.

## 6. Reglas pendientes por error SQL

No se emite veredicto para `Reco_32`, `Reco_33`, `Reco_34`, `Reco_56`, `Reco_67`, `Reco_68` y `Reco_69`. El Python sí produjo resultados en varias de ellas, pero la SQL no terminó correctamente en este respaldo. Deben corregirse o probarse en una base completa antes de comparar conjuntos.

## 7. Decisión sobre los “perfiles RECO”

Los perfiles anteriores no son técnicamente confiables:

- “Solo 50/51” reproducía una observación accidental de una sesión QGIS incompleta.
- “Reglas verificadas” se basaba en igualdad de conteos, que podía ser coincidencia por cero o ignorar duplicados y diferencias de conjuntos.
- Los perfiles forzaban filtros de predios y ocultaban reglas sin dejar clara la modificación del universo.

**Decisión:** retirarlos. La interfaz debe ofrecer selección directa y persistente de reglas. El alcance de predios se conserva como una opción independiente, visible y apagada por defecto.

## 8. Evaluación del alcance previo a las SQL

El alcance por estado, cancelación, condición e informalidad sí es útil para ejecuciones operativas de reconocimiento, porque reduce datos antes de la regla y evita procesar predios fuera del flujo de trabajo.

No debe formar parte implícita de la lógica de calidad ni aplicarse por defecto, porque:

- oculta inconsistencias fuera del universo seleccionado;
- impide comparar la SQL original contra otra implementación;
- puede afectar familias distintas de RECO de manera conceptualmente incorrecta;
- convierte una decisión operativa en una modificación silenciosa de todas las consultas.

La configuración recomendada es: alcance completo por defecto; interruptor explícito para activarlo; aplicación solo a RECO en el plugin maestro; persistencia mediante un único guardado general; indicador visible “Filtro activo”.

## 9. Evaluación de la arquitectura Python + SQL

La arquitectura híbrida es apropiada y debe conservarse:

- SQL ejecuta joins, filtros, agregaciones y geometría donde están los datos y donde PostgreSQL puede usar índices y planes de ejecución.
- Python/QGIS administra conexión, ejecución en segundo plano, cancelación, navegación, mapa, consola y exportaciones.
- Cada regla vive en un archivo SQL independiente, lo que permite editarla sin tocar la interfaz.
- El manifiesto aporta ID estable, familia, componente, título, estado habilitado y ruta del archivo.
- Los seis plugins se generan desde el mismo catálogo, evitando seis copias divergentes.

Modificar una regla existente ya es sencillo: editar `quality_core/rules/<familia>/<Regla>.sql`, validar y reconstruir. La parte que era incómoda era agregar o retirar reglas porque exigía editar JSON manualmente.

Se añadió `tools/manage_rules.py` para resolverlo:

```powershell
python tools/manage_rules.py list --family reco
python tools/manage_rules.py show --id Reco_40
python tools/manage_rules.py validate
python tools/manage_rules.py disable --id Reco_40
python tools/manage_rules.py enable --id Reco_40
python tools/manage_rules.py set --id Reco_40 --title "Nueva descripcion funcional"
python tools/manage_rules.py add --id Reco_72 --family reco --component Calificacion --title "Descripcion de la regla"
```

Deshabilitar es preferible a borrar: la regla deja de aparecer en los plugins, pero conserva historia, SQL y posibilidad de reactivación.

## 10. Prioridades recomendadas

1. **Crítica:** corregir `Reco_40`, `Reco_42` y `Reco_43` antes de interpretar sus resultados.
2. **Alta:** corregir el bug Python de `Reco_06` y definir una SQL dominante correcta para `Reco_06/07/08`.
3. **Alta:** separar filas SQL de predios afectados en el resumen del plugin.
4. **Media:** cerrar decisiones funcionales de `Reco_21`, `Reco_27`, `Reco_28`, `Reco_38`, `Reco_54`, `Reco_55` y `Reco_60`.
5. **Media:** resolver las siete SQL bloqueadas y repetir la auditoría.

Este informe no declara automáticamente al plugin anterior ni al catálogo SQL como fuente absoluta. El veredicto se basa en código ejecutado, conjuntos de predios y coherencia con la descripción declarada de cada regla.
