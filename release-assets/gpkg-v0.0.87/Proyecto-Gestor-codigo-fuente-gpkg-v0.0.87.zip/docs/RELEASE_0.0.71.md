# Calidad GPKG 0.0.71 - detección automática y reglas opcionales

`0.0.71` corrige tres problemas de experiencia reportados durante la revisión
real en QGIS:

1. Las capas ya cargadas en el proyecto se descubren automáticamente.
2. La ausencia del perímetro urbano de `SIG_16` se trata como opcional.
3. Los mensajes extensos de estado se pueden desplazar y leer completos.

## Capas cargadas

El plugin escucha altas, bajas y limpieza de capas del proyecto QGIS. Cuando la
fuente seleccionada es `Capas vectoriales cargadas`, actualiza el mapeo sin que
el operador tenga que pulsar `Actualizar mapeo`.

La coincidencia usa:

- nombre visible de la capa;
- nombre corto;
- `layername` o tabla física del URI del proveedor;
- variantes con prefijos del paquete.

Si dos capas tienen la misma mejor coincidencia, la entidad queda sin asignar
para que el usuario decida. No se elige una capa ambigua silenciosamente.

## SIG_16

`perimetro_urbano_20260702` es opcional en los paquetes entregados a calidad.
Si no está presente, pero las demás dependencias de la regla sí son válidas:

- el mapeo muestra `opcional_ausente`;
- el preflight devuelve `not_applicable`;
- la ejecución omite la regla;
- no incrementa el contador de errores;
- no muestra una alerta roja;
- el resumen informa cuántas reglas fueron opcionales/no aplicables.

Si falta cualquier otra dependencia requerida, el resultado sigue siendo
`dependency_missing`.

## Mensajes y scroll

`Estado` y el estado general ahora usan controles de solo lectura con scroll
vertical. La consola conserva el mensaje completo. Cuando un diálogo excede el
tamaño razonable, muestra un resumen y dirige al operador a Estado/Consola.

## Verificación

- Backend portable puro: correcto.
- Construcción sincronizada: seis ZIP `0.0.71`, 253 reglas.
- Smoke QGIS 3.44.11: correcto para doce ediciones coexistentes, GPKG directo,
  capas cargadas, proveedor `memory`, reglas por familia y limpieza.
- Gate estructural: correcto.
- Aprobación versionada del propietario: registrada y verificada.
- GitHub Actions ejecuta en Linux la equivalencia portable/PostGIS de reglas
  que no requieren el runtime geométrico de QGIS; la certificación geométrica
  completa se conserva en el smoke Windows/QGIS 3.44.11.
