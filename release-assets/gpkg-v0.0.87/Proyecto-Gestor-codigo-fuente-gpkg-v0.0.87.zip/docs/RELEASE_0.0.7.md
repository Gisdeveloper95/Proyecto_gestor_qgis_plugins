# Validadores SQL QGIS 0.0.7

## Cambios

- Se elimina de la interfaz el alcance pre-SQL configurable.
- Las reglas RECO se ejecutan completas y reciben automáticamente, después de la consulta, los cuatro filtros operativos del validador de referencia.
- El resumen diferencia filas SQL, descartadas por alcance RECO y predios finales.
- Cabecera renovada con el nombre del catálogo o familia como texto destacado, sin apariencia de botón.
- Barra de acciones reorganizada y adaptable a paneles angostos.
- Acciones renombradas como `Ejecutar marcadas`, `Ejecutar grupo`, `Añadir al mapa`, `Exportar` y `Guardar ajustes`.
- Iconos nativos de QGIS para ejecutar, cancelar, añadir capas, exportar y guardar.
- Excel actualizado con el nuevo resumen y hojas independientes por regla ejecutada.
- El auditor Python-vs-SQL aplica el alcance RECO después del resultado SQL, igual que el plugin.

## Verificación

- `Reco_50`: 297 filas SQL, 228 resultados finales; equivalencia exacta con Python.
- `Reco_51`: 165 filas SQL, 123 resultados finales; equivalencia exacta con Python.
- Seis plugins cargados y descargados mediante QGIS 3.36: OK.
- Interfaz verificada en anchos de 980 y 540 px.
- Reporte XLSX validado como XML y abierto con `openpyxl`.
- Catálogo PostgreSQL: 252/253 reglas compilan en el respaldo parcial.
- `SIG_16`: única dependencia conocida por ausencia de `public.perimetro_urbano_20260702`.

## Compatibilidad

La versión conserva las conexiones y reglas marcadas guardadas. Las preferencias antiguas de alcance se ignoran porque ya no intervienen en la ejecución.
