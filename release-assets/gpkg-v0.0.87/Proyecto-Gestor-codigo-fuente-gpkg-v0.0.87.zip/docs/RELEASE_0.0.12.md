# Calidad GPKG 0.0.12 - tercer slice local

`0.0.12` amplía exclusivamente la edición Calidad GPKG con la implementación
portable independiente de `SIG_10`. Los seis validadores DBA/PostGIS permanecen
en `0.0.9`, conservan su catálogo de 253 reglas y no reciben selector de
archivos, SQLite de staging ni módulos portables.

| Familia | Plugin DBA local | Plugin GPKG local | Reglas GPKG |
| --- | --- | --- | --- |
| Total | `validador_calidad_total` 0.0.9 | `calidad_gpkg_total` 0.0.12 | `SIG_02`, `SIG_09`, `SIG_10` |
| RECO | `validador_calidad_reco` 0.0.9 | `calidad_gpkg_reco` 0.0.12 | 0; `backend_unsupported` |
| PH | `validador_calidad_ph` 0.0.9 | `calidad_gpkg_ph` 0.0.12 | 0; `backend_unsupported` |
| Jurídico | `validador_calidad_juridico` 0.0.9 | `calidad_gpkg_juridico` 0.0.12 | 0; `backend_unsupported` |
| SIG | `validador_calidad_sig` 0.0.9 | `calidad_gpkg_sig` 0.0.12 | `SIG_02`, `SIG_09`, `SIG_10` |
| Económico | `validador_calidad_economico` 0.0.9 | `calidad_gpkg_economico` 0.0.12 | 0; `backend_unsupported` |

## Alcance técnico

- `SIG_10` vive en un módulo aislado y fijado por SHA-256; no existe traductor
  genérico de SQL PostgreSQL a SQLite.
- La regla consume únicamente atributos de seis capas explícitamente mapeadas:
  predio PH, novedad de número predial, predio general, característica PH y
  unidades de construcción formal e informal.
- Se conservan las decisiones canónicas sobre predio cancelado, cambio físico,
  posición 22 del código, identificadores nulos, novedades `5` a `8`, `UNION` y
  multiplicidad formal/informal.
- El motor usa SQLite temporal en disco, caché limitada a 4 MiB, lotes de 256,
  cursor de salida y cancelación durante staging y lectura de resultados.
- Identidades PH nulas o ambiguas se rechazan temprano. Esta divergencia segura
  es intencional: nunca se inventa un desempate para el `DISTINCT ON` canónico ni
  se transforma una entrada incierta en un falso OK.
- El fixture CC0 sintético produjo 14/14 filas en PostgreSQL 18.4/PostGIS 3.6.2
  y en el backend portable, con multiconjunto SHA-256
  `72C2AFD9EB0D48C311B47BADCEE83014C012FD93788E547444204C1A681E96A8`.
- El orden no coincidió por empates sin desempate total y diferencias de
  colación; `ordered_equal=false` es diagnóstico y la equivalencia se decide por
  multiconjunto normalizado con multiplicidad.

Los hashes completos y el alcance de la afirmación están documentados en
`docs/SIG_10_PORTABLE_EQUIVALENCE_2026-07-18.md` y en la evidencia JSON fijada.
Con este slice, Total GPKG y SIG GPKG cubren 3/253 reglas. Las otras cuatro
familias mantienen cero reglas portadas y reportan explícitamente
`backend_unsupported`.

## Construcción local

```powershell
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9 --dist dist\dba
python tools\build_gpkg_plugin_packages.py --version 0.0.12 --tag gpkg-v0.0.12 --dist dist\gpkg
python tools\test_plugin_portable_integration.py
```

El argumento `--tag` de la construcción solo fija las rutas que se escriben en
los artefactos locales; no crea un tag Git ni publica nada.

Los hashes SHA-256 de los doce ZIP coexistentes, las versiones observadas y el
resumen de pruebas quedan fijados en
`docs/evidence/GPKG_0.0.12_LOCAL_CHECKPOINT_2026-07-18.json`.

## Estado y gates externos

Este checkpoint continúa siendo no publicable. El gate devuelve exactamente
nueve bloqueos externos e intencionales:

1. Cada uno de los seis ZIP GPKG carece del `LICENSE` first-party aprobado
   porque todavía no existe una licencia raíz autorizada: seis bloqueos.
2. Falta la metadata pública aprobada y exclusiva de Calidad GPKG: un bloqueo.
3. Falta la aprobación versionada exclusiva para `0.0.12`: un bloqueo.
4. Falta la licencia first-party aprobada en la raíz: un bloqueo.

Los gates técnicos de estructura, separación DBA/GPKG y evidencia por regla no
añaden bloqueos. `passed_synthetic_fixture_v1` no significa equivalencia
productiva ni 253/253.

Permanece además la diferencia conocida de contrato con DBA `0.0.9`: el SQL
canónico devuelve `planta_unidad_construccion`, pero el contrato de exportación
común de los DBA aún no incluye esa columna. Calidad GPKG sí la conserva; la
homologación del DBA requiere un parche independiente y no reescribe `0.0.9`.

No se ha realizado ni se autoriza desde este checkpoint push, tag Git, release,
publicación o despliegue.
