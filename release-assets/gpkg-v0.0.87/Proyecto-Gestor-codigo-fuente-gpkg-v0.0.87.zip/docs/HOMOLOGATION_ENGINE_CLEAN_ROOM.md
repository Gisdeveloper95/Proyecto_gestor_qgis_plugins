# Motor clean-room PostGIS → GPKG

## Contrato

`homologation_engine` es un paquete independiente y sin conocimiento del catálogo.
No importa SQL canónica, adaptadores legacy, evidencias, familias ni IDs de reglas.
El gate `tools/cleanroom_gate.py` verifica esa separación y fija el hash exacto del
motor antes de evaluar el corpus.

Flujo:

```text
PostGIS SQL
  → política SELECT/WITH
  → AST SQLGlot
  → capacidades
  → SQLite SQL | plan SQLite/GEOS | candidato revisable | manual_required
  → verificación diferencial
  → plan firmado y ejecutable por el plugin
```

La compilación nunca implica equivalencia.

## Congelaciones y evaluación ciega

| Motor | Tag | Resultado retenido |
|---|---|---|
| 0.0.1 | `homologation-engine-v0.0.1-freeze` | congelación inicial |
| 0.0.2 | `homologation-engine-v0.0.2-freeze` | ampliación general de escalares/distancia |
| 0.0.3 | `homologation-engine-v0.0.3-freeze` | semántica temporal y booleana/numérica |
| 0.0.4 | `homologation-engine-v0.0.4-freeze` | resolución de tablas consciente del alcance de CTE |
| 0.0.5 | `homologation-engine-v0.0.5-freeze` | tipos de salida portables, incluidos booleanos SQLite |

Hash del motor 0.0.5:

`C9819CBD33648E1AA69FAC85AF21809D3EBFB67CD6571768FBDC5FD38375BF60`

Evaluación ciega de 253 reglas:

- 227 candidatas `sqlite_sql`;
- 26 candidatas `portable_ir`;
- 0 operaciones sin clasificar;
- 0 equivalencias afirmadas antes de verificación.

El informe reproducible está en
`docs/homologation-engine-v0.0.5-blind-report.json`.

## Verificación diferencial

`tools/run_homologation_batch.py` recibe un bundle congelado por el portal. Verifica
el hash del motor y que el SQL recibido coincide con la rama del PR. Después:

1. Usa el fixture versionado declarado por la regla.
2. Lo carga en una base desechable PostgreSQL 18/PostGIS.
3. Crea el mismo GeoPackage.
4. Ejecuta referencia y candidato con semillas 7, 11 y 29.
5. Compara esquema, nulos, tipos, multiplicidades, valores y geometría.
6. Materializa el plan solo si todas las semillas son equivalentes.

Una regla fallida o no demostrada bloquea todo el lote GPKG, pero no los seis
previews PostGIS ni el diagnóstico.

## Runtime del plugin

`quality_core/portable_plan_runtime.py` ejecuta únicamente planes que:

- tengan `equivalence_verified=true`;
- coincidan con todos los hashes del bundle;
- no requieran revisión;
- respeten timeout, límite de filas y cancelación;
- usen funciones SQLite/QGIS registradas explícitamente.

El runtime no contiene condiciones por regla o familia. Las operaciones geométricas
usan la biblioteca GEOS incluida en QGIS; el usuario no necesita instalar SpatiaLite.

## Lock y procedencia

El lock canónico v2 es `quality_core/rules/gestor-rules.lock`. Contiene las 253
reglas, hashes, dependencias, procedencia y estados PostGIS/GPKG. El lock v1
obsoleto se conserva únicamente como evidencia en
`quality_core/rules/history/gestor-rules.lock.v1.json`.

## Workflow

`.github/workflows/homologate-change-set.yml`:

- acepta únicamente una rama `portal/homologation/*`;
- exige commit y merge-base exactos;
- rechaza cualquier aporte distinto de SQL y metadatos autorizados;
- fija imagen PostGIS y actions por digest/commit;
- construye seis ZIP PostGIS siempre;
- construye seis ZIP GPKG solo con paridad total;
- sube artefactos temporales;
- agrega planes/evidencia al PR borrador;
- informa al portal mediante callback autenticado e idempotente.

Los previews locales verificados son DBA/PostGIS 0.0.10 y GPKG 0.0.75. No son
releases estables y no autorizan avanzar a 0.1.0.
