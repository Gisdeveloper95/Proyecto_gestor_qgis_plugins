# Calidad GPKG 0.0.19 — segundo lote escalar de construcción

`0.0.19` agrega `Reco_10`, `Reco_20`, `Reco_23` y `Reco_25` al backend directo
GeoPackage.

| Familia | Catálogo | Portable | Pendiente |
|---|---:|---:|---:|
| Jurídico | 82 | 13 | 69 |
| RECO | 71 | 35 | 36 |
| SIG | 16 | 4 | 12 |
| PH | 77 | 0 | 77 |
| Económico | 7 | 0 | 7 |
| **Total** | **253** | **52** | **201** |

La certificación sintética ejecutó el SQL canónico en PostgreSQL 18.4/PostGIS
3.6.2 y comparó su multiconjunto con `MappingDataSource` y un GeoPackage físico.
Las 52 reglas pasaron. QGIS 3.44.11 probó las doce ediciones coexistentes, GPKG
directo, capas OGR cargadas, proveedor `memory`, filtro RECO compartido y
limpieza de temporales.

Los seis ZIP locales `0.0.19` son reproducibles byte a byte. El gate técnico no
detecta divergencias; la publicación continúa bloqueada deliberadamente por
seis licencias de ZIP, metadata pública aprobada, aprobación versionada y
licencia first-party. No se instaló ningún perfil, no se creó tag y no se hizo
push ni release.

Evidencia consolidada:
`docs/evidence/GPKG_0.0.19_LOCAL_CHECKPOINT_2026-07-19.json`.
