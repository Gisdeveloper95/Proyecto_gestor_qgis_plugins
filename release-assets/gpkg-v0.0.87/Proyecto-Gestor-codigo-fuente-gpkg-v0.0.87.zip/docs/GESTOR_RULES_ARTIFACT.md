# Artefacto restringido `gestor-rules`

`tools/build_gestor_rules.py` genera un ZIP determinista que captura el catalogo
canonico sin convertir una procedencia tecnica en permiso legal. Su version
inicial es `0.0.0` y fija la linea base de plugins `0.0.8` mediante
`quality_core/rules/gestor-rules.lock`. El lock v1 obsoleto se conserva solo
como evidencia en `quality_core/rules/history/gestor-rules.lock.v1.json`.

El artefacto contiene:

- las 253 consultas SQL con rutas y SHA-256 individuales;
- un hash compuesto del manifiesto y del arbol SQL;
- el hash de la fuente monolitica declarada;
- una comprobacion de que cada SQL es un extracto exacto de su bloque en el
  monolito, no una reescritura implicita;
- el postprocesador operativo RECO, su SHA-256 y el orden exacto de aplicacion
  (consulta completa, normalizacion y filtro por `pk_id_predio`);
- un ledger fail-closed de procedencia para las 253 reglas, fijado por hash;
- ID estable, familia, componente, columnas normalizadas y dependencias por regla;
- campos explicitos de severidad y geometria, aunque todavia esten pendientes de
  revision autorizada;
- estado de procedencia y distribucion cerrado por defecto.

Construccion local:

```powershell
python tools\build_gestor_rules.py
python tools\test_gestor_rules_artifact.py
```

El lockfile no se actualiza implicitamente. `--write-lock` solo se usa despues de
revisar deliberadamente un cambio del catalogo. El gate
`--require-identity-clean` falla mientras una consulta devuelva o consulte una
excepcion con otro ID; `--require-publishable` tambien falla mientras no esten
cerradas identidad, severidad, geometria exacta y autorizacion externa.

## Hallazgos de la linea base

El artefacto local reproducible tiene SHA-256
`2CAF895E78E8D78BDF8B69E57A4513F92E12EBB2892F6A99039A67B3478A2502` y 255
entradas (manifiesto, 253 SQL y postprocesador RECO). Detecta seis
inconsistencias de contrato:

| Regla | Hallazgo |
| --- | --- |
| `Jur_10` | devuelve `Jur_06` y consulta excepciones de `Jur_06` |
| `Jur_59` | consulta excepciones de `Jur_58` |
| `Jur_60` | devuelve `Jur_59` y consulta excepciones de `Jur_58` |
| `Reco_52` | consulta excepciones de `Reco_51` |

No se modifican estas reglas dentro de la linea base ya probada de `0.0.8`.
Esa version queda permanentemente como evidencia local no publicable. La
correccion debe entrar como un slice sincronizado posterior, ejecutar nuevamente
las 253 reglas y comparar los conjuntos de filas afectados; solo esa version
posterior podra volver a ser candidata a publicacion.

La dependencia no satisfecha de `SIG_16` queda declarada como
`public.perimetro_urbano_20260702`; no se crea ni se sustituye. La geometria
operativa actual de los plugins sigue siendo el contexto de predio y no se marca
como fuente exacta por regla.

## Limite de autorizacion

El lock registra bytes e identidad; no declara titularidad, licencia ni permiso
de distribucion. `quality_core/rules/provenance-ledger.json` mantiene las 253
reglas como `pending-owner-confirmation`, con uso privado y distribucion GPL en
`false`. `Reco_71` registra una posible relacion con
`validador_helen/inconsistencias_reco/reco_71.py`, pero la marca expresamente
como no confirmada. Los gates versionados de licencia/procedencia siguen siendo
obligatorios tanto para la distribucion GPL de los plugins como para el consumo
privado del catalogo por MapingTool.
