# Validadores SQL QGIS 0.0.6

## Cambios

- Interfaz compacta con secciones plegables, consola, estado visible de conexión y distintivo de familia.
- Un único botón de guardado para conexión, timeout, alcance, grupo, reglas seleccionadas y secciones abiertas. La contraseña no se guarda.
- Eliminación de los perfiles RECO que alteraban silenciosamente reglas y alcance.
- Alcance pre-SQL explícito, apagado por defecto y visible mediante el indicador `Filtro activo`.
- Resumen separado por filas SQL y predios distintos.
- Botón `Ver detalle`, filtro de inconsistencias y navegación QGIS conservada.
- Exportación Excel corregida y validada, con hojas `Resumen`, `Detalle`, una por regla ejecutada y `Consola`.
- Reglas deshabilitadas excluidas realmente de todos los ZIP.
- Nueva utilidad `tools/manage_rules.py` para consultar, agregar, editar metadatos, habilitar, deshabilitar y validar reglas sin editar el manifiesto manualmente.
- Auditoría reproducible Python vs SQL con evidencia por conjuntos de predios.

## Verificación

- Seis plugins cargados y descargados con QGIS 3.36 mediante smoke test: OK.
- Python generado: 36 archivos compilados correctamente.
- Catálogo: 253 reglas consistentes.
- PostgreSQL `cartoflow_pruebas`: 252/253 SQL compilan.
- `SIG_16`: dependencia conocida `public.perimetro_urbano_20260702` ausente en el respaldo parcial; el plugin la reporta como dependencia sin detener las demás reglas.
- XLSX abierto con `openpyxl` y todas sus hojas verificadas.

## Pendiente funcional conocido

La auditoría detectó reglas RECO cuya lógica Python y SQL no es equivalente. Esta versión documenta el problema, pero no cambia unilateralmente reglas de negocio. Prioridad de revisión: `Reco_40`, `Reco_42`, `Reco_43`, `Reco_06` y `Reco_07`.
