# Calidad GPKG 0.0.18 — lote de características de construcción

`0.0.18` agrega 16 reglas RECO al backend directo GPKG:
`Reco_29–37`, `Reco_40`, `Reco_45`, `Reco_54`, `Reco_55`, `Reco_64`,
`Reco_66` y `Reco_67`.

| Familia | Canónicas | Portables GPKG | Pendientes |
|---|---:|---:|---:|
| Total | 253 | 48 | 205 |
| Jurídico | 82 | 13 | 69 |
| RECO | 71 | 31 | 40 |
| SIG | 16 | 4 | 12 |
| PH | 77 | 0 | 77 |
| Económico | 7 | 0 | 7 |

El nuevo pipeline procesa predios y
`general.determinacion_area_construccion` con staging SQLite temporal,
cursores, lotes acotados y cancelación. Mantiene multiplicidad de joins,
catálogos de tipo/uso, excepciones, asignaciones, semántica de `NULL`, valores
crudos de uso donde el SQL así los devuelve y las dos tablas de error en las
reglas que las declaran.

La suite completa de 48 reglas pasó contra PostgreSQL 18.4/PostGIS 3.6.2,
`MappingDataSource` y GPKG físico sintético. QGIS 3.44.11 verificó las doce
ediciones coexistentes con archivo GPKG directo, capas OGR cargadas y proveedor
`memory`. Los seis ZIP GPKG son reproducibles byte por byte y los ZIP DBA
`0.0.9` conservan sus hashes.

Checkpoint:
`docs/evidence/GPKG_0.0.18_LOCAL_CHECKPOINT_2026-07-19.json`.
La evidencia se limita a fixtures sintéticos; no afirma paridad productiva ni
253/253.

No se creó tag, push, release, instalación de perfil, publicación ni
despliegue. Persisten nueve bloqueos externos de licencia, metadata y aprobación.
