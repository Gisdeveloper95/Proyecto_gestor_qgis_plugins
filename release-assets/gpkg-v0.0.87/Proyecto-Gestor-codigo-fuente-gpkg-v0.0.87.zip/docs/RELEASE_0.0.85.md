# Calidad GPKG 0.0.85 — grupos múltiples, proyecto y perfiles actualizables

Esta versión mantiene sin cambios las 253 SQL canónicas y sus planes
`generated_plan_v1`. Amplía la selección operativa, añade un alcance explícito
por proyecto y permite distribuir perfiles simplificados por un repositorio
QGIS independiente.

## Selección simultánea de grupos

- El plugin Total permite marcar uno o varios grupos a la vez.
- La tabla muestra la unión de los grupos elegidos y `Ejecutar grupo` procesa
  exactamente esa unión.
- La selección queda guardada y no altera los filtros NPH, Condominio, PH o
  Informalidad ya configurados.
- Los hijos de una sola familia siguen simplificados y sin controles de
  configuración. Solo un hijo mixto muestra el selector de grupos, limitado a
  las familias que fueron incluidas al generarlo.

## Proyecto de trabajo

- El plugin obtiene los proyectos distintos desde
  `lc_gen_predio.nombre_proyecto`.
- Compara esos valores con el nombre de la carpeta contenedora, el archivo
  QGZ, el directorio principal y el nombre del proyecto QGIS.
- Si existe una coincidencia —por ejemplo `pvall_044_nu`— la selecciona
  automáticamente; si hay varios proyectos sin coincidencia, obliga al
  operador a elegir uno.
- También existe una opción explícita para procesar todos los proyectos.
- El alcance se materializa en el almacén temporal de resultados y nunca
  escribe en el GeoPackage de entrada.

## Perfiles simplificados actualizables

La exportación ZIP continúa disponible y funciona sin GitHub. Adicionalmente,
los plugins padre incorporan `Publicar perfil actualizable en GitHub…`:

- publica una selección por vez con versión propia `0.0.x`;
- mantiene versiones y ZIP anteriores inmutables;
- regenera un `plugins.xml` que conserva todos los perfiles vigentes;
- crea el repositorio público exclusivo en la primera publicación si todavía
  no existe y la credencial pertenece al propietario configurado;
- almacena opcionalmente el token cifrado en QGIS Auth Manager y nunca lo
  incluye en archivos, consola, ZIP ni metadatos.

Repositorio predeterminado de perfiles:
`Gisdeveloper95/Mapper_GIS_Catastral_QGIS_Perfiles`.

URL estable después de la primera publicación:
`https://github.com/Gisdeveloper95/Mapper_GIS_Catastral_QGIS_Perfiles/releases/latest/download/plugins.xml`.

## Verificación

- Pruebas unitarias del alcance de proyecto y del publicador GitHub sin fuga
  de credenciales.
- Regresión completa de filtros operativos generales y por perfil.
- Smoke QGIS 3.44.11 con selección RECO+PH, hijo normal bloqueado e hijo mixto
  Jurídico+PH filtrable.
- Reconocimiento real de `pvall_044_nu` desde su carpeta y los 1.065 predios
  asociados en `actualizacion.gpkg`.
- Construcción reproducible y gates conjuntos para los seis plugins padre.

`0.1.0` continúa bloqueado hasta autorización expresa del propietario.
