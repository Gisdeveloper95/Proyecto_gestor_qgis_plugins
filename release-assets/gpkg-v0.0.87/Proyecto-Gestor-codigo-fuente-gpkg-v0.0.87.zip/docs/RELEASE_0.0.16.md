# Calidad GPKG 0.0.16 — lote escalar y foco exclusivo en plugins

`0.0.16` amplía únicamente las seis ediciones Calidad/GPKG. Las seis ediciones
DBA/PostGIS permanecen en `0.0.9` con su catálogo canónico de 253 reglas.

| Familia | Canónicas | Portables GPKG | Incorporadas en 0.0.16 |
|---|---:|---:|---|
| Total | 253 | 26 | 13 |
| Jurídico | 82 | 13 | `Jur_01`, `Jur_04`, `Jur_07–09`, `Jur_16` |
| RECO | 71 | 9 | `Reco_52`, `Reco_53`, `Reco_58`, `Reco_60–63` |
| SIG | 16 | 4 | — |
| PH | 77 | 0 | `backend_unsupported` |
| Económico | 7 | 0 | `backend_unsupported` |

Las 13 reglas nuevas comparten el pipeline acotado de predio, pero cada una
mantiene un wrapper independiente y fijado por SHA-256. Las nueve RECO portadas
declaran el mismo filtro operativo global; `PortableRuleBackend.execute()` lo
aplica siempre y `execute_raw()` queda reservado para contrastar la etapa SQL
canónica. En el fixture del lote, `Reco_60` produce 3 filas crudas y 2 finales.

PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y un GPKG físico produjeron el
mismo multiconjunto para las 26 reglas. QGIS 3.44.11 repitió los resultados con
archivo GPKG, capas OGR cargadas y proveedor `memory`. Las seis ediciones GPKG
se construyeron de forma reproducible y coexistieron con los seis plugins DBA.

El checkpoint está en
`docs/evidence/GPKG_0.0.16_LOCAL_CHECKPOINT_2026-07-19.json`. La afirmación se
limita a fixtures sintéticos y no equivale a paridad productiva o 253/253.

La decisión vigente congela portal web y aplicación desktop. El orden de motores
queda documentado en `docs/PLUGIN_ONLY_ARCHITECTURE_DECISION_2026-07-19.md`:
GPKG directo obligatorio, SpatiaLite sujeto a benchmark espacial y PostgreSQL
temporal como fallback opcional para estaciones controladas.

No se creó tag, push, release, instalación de perfil ni despliegue. El texto
`gpkg-v0.0.16` usado al construir solo fija metadatos internos del artefacto.
