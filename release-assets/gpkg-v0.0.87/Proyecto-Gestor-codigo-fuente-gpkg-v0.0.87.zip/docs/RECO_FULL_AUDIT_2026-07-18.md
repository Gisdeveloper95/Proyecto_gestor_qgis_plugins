# Auditoria RECO completa con postfiltro — 2026-07-18

La auditoria se ejecuto en QGIS `3.44.11` contra PostgreSQL `18.4`/PostGIS
`3.6.2`, usando el perfil aislado activo, `authcfg` y el rol
`gestor_validator_ro` con `transaction_read_only=on`. Para cada regla se ejecuto
primero el SQL completo y despues se aplico el conjunto permitido por el
postfiltro RECO, que es el orden operativo corregido.

La corrida termino las 43 reglas comparables, incluidas las siete que antes no
tenian veredicto. Esto cierra la cobertura de auditoria, pero **no demuestra
equivalencia general**:

| Veredicto | Reglas |
| --- | ---: |
| Coincidencia exacta | 23 |
| Mismos predios, filas SQL adicionales | 5 |
| Conjunto de predios diferente | 15 |
| Bloqueadas | 0 |

Coincidencias exactas: `Reco_02`, `Reco_08`, `Reco_09`, `Reco_11`, `Reco_12`,
`Reco_14`, `Reco_15`, `Reco_16`, `Reco_25`, `Reco_29`, `Reco_32`, `Reco_33`,
`Reco_41`, `Reco_45`, `Reco_50`, `Reco_51`, `Reco_52`, `Reco_53`, `Reco_61`,
`Reco_62`, `Reco_67`, `Reco_68` y `Reco_71`.

Mismos predios con filas adicionales: `Reco_17`, `Reco_20`, `Reco_22`,
`Reco_26` y `Reco_39`.

Conjuntos diferentes: `Reco_06`, `Reco_07`, `Reco_21`, `Reco_27`, `Reco_28`,
`Reco_34`, `Reco_38`, `Reco_40`, `Reco_42`, `Reco_43`, `Reco_54`, `Reco_55`,
`Reco_56`, `Reco_60` y `Reco_69`.

Los dos controles fijados expresamente si coinciden: `Reco_50` produce 228
filas finales y `Reco_51` produce 123.

## Evidencia local sin identificadores

| Artefacto | SHA-256 |
| --- | --- |
| `reco_postfilter_audit_20260718T005926Z.json` | `A38D8D9CED6177B2491A480CF2AFEF683725E99D6E5CA65098626DBB3FECAFCD` |
| `reco_postfilter_audit_20260718T005926Z.csv` | `B0A399FCFAAF4B25FF19E5A0F4EDA45BCEE29AA0ACE954D238C41CEF2940752C` |

Los archivos viven en `test_reports/`, que permanece ignorado por Git. Solo
contienen conteos agregados, clasificaciones y hashes de las 43 fuentes Helen y
los 43 SQL; no serializan `pk_id`, numero predial, matricula, ID de `authcfg` ni
credenciales. Los harness reproducibles son
`tools/audit_reco_qgis_authcfg.py` y `tools/run_reco_audit_qgis_profile.py`.

## Consecuencia

Las 20 reglas no exactas requieren revision semantica individual antes de una
declaracion de paridad. El harness de referencia carga diez relaciones completas
en memoria para reproducir el comportamiento Helen; por tanto, esta corrida no
satisface el criterio de memoria acotada y refuerza la necesidad de cursores,
paginacion y almacenamiento temporal en los slices posteriores.
