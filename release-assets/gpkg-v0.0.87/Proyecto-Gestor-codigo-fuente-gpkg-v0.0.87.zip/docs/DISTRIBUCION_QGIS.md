# Distribucion QGIS del Proyecto Gestor

## Modelo elegido

El repositorio de desarrollo permanece privado:

```text
https://github.com/Gisdeveloper95/Proyecto_gestor
```

La distribucion publica vive en:

```text
https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins
```

Antes de una publicacion oficial, `release/public_metadata.json` debe apuntar a
un repositorio fuente y tracker publicos verificados. El enlace privado anterior
no se incorporara a metadata publicable. El repositorio publico de distribucion
contiene releases con:

- seis ZIP sincronizados,
- `plugins.xml` e icono,
- changelog y avisos de terceros,
- SBOM SPDX JSON, manifiesto y `SHA256SUMS`,
- firma detached `SHA256SUMS.sig`.

## URL para usuarios QGIS

Cuando exista una release publicada, los usuarios agregan este repositorio en QGIS:

```text
https://github.com/Gisdeveloper95/Proyecto_gestor_qgis_plugins/releases/latest/download/plugins.xml
```

Ruta en QGIS:

```text
Plugins > Administrar e instalar plugins > Configuracion > Agregar
```

## Plugins publicados

- `Validador Calidad Total`: todas las reglas.
- `Validador Calidad Reco`: reglas `Reco`.
- `Validador Calidad PH`: reglas `PH`.
- `Validador Calidad Juridico`: reglas `Jur`.
- `Validador Calidad SIG`: reglas `SIG`.
- `Validador Calidad Economico`: reglas `Eco`.

## Build local sin publicacion

La construccion local no autoriza una publicacion. Antes de usar el publicador,
deben pasar los gates fail-closed descritos en `docs/RELEASE_GATES.md`; mientras
falten `LICENSE` o aprobaciones de procedencia, la herramienta termina antes de
leer el token o realizar una llamada a GitHub.

Para generar paquetes localmente:

```powershell
python tools\build_plugin_packages.py --version 0.0.9 --tag v0.0.9
```

El build no crea tags, releases ni llamadas remotas. La preparacion y verificacion
del bundle tambien pueden ensayarse localmente solo despues de contar con los
materiales externos aprobados:

```powershell
python tools\check_release_gates.py --version 0.0.9
python tools\release_bundle.py prepare --version <version> --dist dist --bundle release-bundles\v<version>
python tools\release_bundle.py sign --version <version> --bundle release-bundles\v<version> --private-key C:\ruta-segura\release-private.pem
python tools\release_bundle.py verify --version <version> --bundle release-bundles\v<version> --public-key C:\ruta-segura\release-public.pem --trust-anchor-file C:\otro-canal\release-trust-anchor.sha256
```

No existe fallback de publicacion manual. El publicador queda reservado al
environment protegido de CI y vuelve a comprobar gates, bundle, firma, trust
anchor y assets remotos antes de hacer visible una release.

## Release automatico con GitHub Actions

El workflow `.github/workflows/release-plugins.yml` se activa con tags `v*`, pero
el propietario no ha autorizado ningun tag nuevo. `v0.0.8` esta prohibido de
forma permanente y `v0.0.9` no debe crearse ni enviarse como forma de probar el
workflow. La autorizacion explicita, los gates y los revisores del environment
protegido deben existir primero.

El workflow:

1. Valida catalogo, pruebas y gates versionados.
2. Genera seis plugins QGIS y el `plugins.xml` determinista.
3. Prepara el bundle, materializa las claves desde secretos protegidos fuera del
   checkout, firma y verifica contra el trust anchor externo.
4. Publica el bundle completo como borrador atomico y solo al final lo hace
   visible.

## Secreto necesario

El repositorio privado debe tener un secret llamado:

```text
DIST_REPO_TOKEN
```

Ese token debe poder crear releases y subir assets en:

```text
Gisdeveloper95/Proyecto_gestor_qgis_plugins
```

Recomendado:

- token fine-grained,
- solo para el repo publico de distribucion,
- permisos minimos de Contents read/write,
- expiracion corta o controlada.

El workflow tambien exige `RELEASE_PRIVATE_KEY_PEM_BASE64`,
`RELEASE_PUBLIC_KEY_PEM_BASE64` y `RELEASE_TRUST_ANCHOR_SHA256`. No deben existir
copias de esos materiales dentro del repositorio. Los pasos reutilizables de
GitHub Actions estan fijados por SHA completo y el workflow solo recibe
`contents: read`; la publicacion se hace exclusivamente mediante el token de
distribucion de alcance minimo.

## Nota sobre prereleases

Para que la URL estable `/releases/latest/download/plugins.xml` funcione bien en QGIS, una futura version autorizada debe ser una release normal (por ejemplo, un `v0.0.x` posterior que supere los gates).

El estado experimental se marca dentro de `metadata.txt` con:

```ini
experimental=False
```

## Estado de la version 0.0.9

La candidata local `0.0.9` mantiene los seis plugins sincronizados sobre el
mismo `gestor-rules` y agrega almacenamiento SQLite temporal, cursores QtSql,
paginacion de UI, exportaciones incrementales y cache cartografica GPKG. Su
detalle tecnico y pruebas estan en `docs/RELEASE_0.0.9.md`.

No es publicable: siguen faltando licencia, aprobaciones versionadas,
procedencia autorizada, cierre de identidades/RECO, metadata publica y controles
externos de firma y autoridad. No se debe crear `v0.0.9`, hacer push ni usar el
publicador.

## Estado de la version 0.0.8

La version local `0.0.8` prepara plugins funcionales con:

- seleccion de conexion PostgreSQL/PostGIS guardada en QGIS o manual,
- prueba de conexion,
- ejecucion de reglas SQL en segundo plano,
- toolbar compartido con un solo icono desplegable,
- interfaz con scroll y bloques colapsables,
- filtro por grupo en el plugin maestro,
- resumen por regla,
- detalle por inconsistencia,
- consola visible con logs completos,
- zoom y seleccion sobre `actualizacion.lc_gen_predio`,
- apertura del formulario nativo de QGIS,
- exportacion CSV, Excel y GPKG por regla.

`SIG_16` queda habilitada, pero si falta `public.perimetro_urbano_20260702` se reporta como dependencia faltante y el resto de reglas continua.

No existe ni existira release publica `0.0.8`: se conserva como evidencia local
por sus diferencias RECO y contratos abiertos. `LICENSE`, procedencia, endpoints
publicos, aprobacion versionada y materiales externos de firma/confianza seran
gates obligatorios para la siguiente candidata `0.0.x`.
