# Calidad GPKG 0.0.78 - filtros de detalle y contador visible

`0.0.78` mejora la revisión de hallazgos en los seis plugins Calidad GPKG sin
modificar el catálogo ni el resultado calculado por las 253 reglas portables.

## Cambios visibles

- El panel y la ventana separada de Detalle de inconsistencias muestran un
  contador azul con el número de inconsistencias visibles.
- El buscador permite localizar por fragmentos de manzana dentro del NPN, por
  NPN completo o por identificadores PK.
- El nuevo control `Ocultar registros con excepción` se activa por defecto.
- La preferencia del control queda guardada por edición del plugin y se
  recupera al volver a abrir QGIS.
- La búsqueda, el contador y el control de excepciones permanecen
  sincronizados entre el panel principal y la ventana de detalle.
- El filtro se ejecuta en el almacén SQLite antes de paginar, evitando
  materializar todos los resultados en la interfaz.

## Alcance

- Se construyen y publican juntos Total, Económico, Jurídico, PH, RECO y SIG.
- El filtro cambia únicamente la vista interactiva. CSV, Excel y GPKG siguen
  exportando la corrida completa para conservar trazabilidad.
- No se modifican SQL, adaptadores, hashes de reglas ni evidencia de
  equivalencia.
- No se incorporan geometrías, datos catastrales, credenciales ni archivos del
  paquete real de trabajo.
