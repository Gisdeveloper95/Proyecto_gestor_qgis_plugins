# Calidad GPKG 0.0.82 — motor SQL/GEOS unificado

`0.0.82` sustituye la arquitectura mixta de `0.0.81` por un único motor
genérico. Las 253 SQL canónicas se compilan a planes JSON y se ejecutan sobre
GeoPackage mediante SQLite y las operaciones geométricas GEOS de QGIS.

## Arquitectura distribuida

- Los 253 manifiestos declaran `execution_mode=generated_plan_v1`.
- Cada regla tiene un plan `generated_plans/<regla>.json` con SQL SQLite,
  dependencias, funciones, contrato de salida y hashes.
- `portable_plan_runtime.py` es el único ejecutor de reglas.
- Los ZIP no contienen `portable_rule_*.py`, `portable_rules.py` ni motores
  familiares específicos.
- Los postfiltros RECO y filtros operativos permanecen como una etapa común,
  posterior a la ejecución cruda.

## Contrato y ejecución

- El contrato PostgreSQL/GPKG contiene 152 tablas físicas con sus columnas.
- `determinacion_area_construccion` se materializa temporalmente sin modificar
  el archivo recibido.
- `perimetro_urbano_20260702` permanece como dependencia externa opcional de
  `SIG_16`.
- El runtime abre el GPKG en solo lectura, usa almacenamiento temporal en
  disco, respeta timeout/cancelación y no deja residuos en el paquete.

## Evidencia

- 253 reglas compilaron y superaron fixtures sintéticos deterministas con
  semillas 7, 11 y 29; cada fixture produjo al menos un hallazgo de control.
- El paquete real `pvall_044_nu/actualizacion.gpkg` se copió a una base
  PostgreSQL temporal con 152 tablas, columnas y conteos idénticos.
- PostgreSQL 18/PostGIS ejecutó 252 reglas; `SIG_16` quedó `not_applicable`.
- El motor nuevo ejecutó las mismas 252 reglas sin errores y coincidió tanto
  con las SQL canónicas como con `0.0.81`.
- Para `PH_67` y `Reco_49`, tres campos derivados de área se compararon con
  tolerancia absoluta de `0,02 m²`; el informe conserva únicamente hashes,
  conteos y diferencias máximas agregadas.
- El SHA-256 del GPKG antes y después de las pruebas fue idéntico.

## Plugins padre e hijos

Se publican juntos Total, Económico, Jurídico, PH, RECO y SIG. Los perfiles
simplificados copian el mismo runtime y únicamente los planes seleccionados;
el generador rechaza cualquier modo mixto o archivo Python legado.

QGIS 3.44.11 verificó capas cargadas y GPKG directo, preflight, repetición
limpia, filtros, paginación, mapa, formulario profesional, excepciones,
CSV/XLSX/GPKG y generación individual/múltiple de perfiles.

## Compatibilidad y alcance

- Los plugins PostGIS no cambian.
- `0.0.81` permanece inmutable como referencia histórica.
- El portal web continúa congelado durante esta entrega.
- No se incluye el GPKG real, geometrías, credenciales, rutas locales ni
  `data_Base_postgres.txt`.
