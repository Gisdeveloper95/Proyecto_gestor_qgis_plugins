# Calidad GPKG 0.0.15 — primer slice RECO local

`0.0.15` incorpora `Reco_50` y `Reco_51` como implementaciones portables con
postfiltro operativo, sin incluir el catálogo SQL PostgreSQL ni conexiones DBA
en los plugins de Calidad. Los seis plugins DBA/PostGIS permanecen en `0.0.9`
y conservan las 253 consultas canónicas.

| Familia | Canónicas | Portables GPKG | Reglas implementadas |
| --- | ---: | ---: | --- |
| Total | 253 | 13 | `SIG_01`, `SIG_02`, `SIG_09`, `SIG_10`, `Jur_05`, `Jur_12–15`, `Jur_17`, `Jur_18`, `Reco_50`, `Reco_51` |
| Jurídico | 82 | 7 | `Jur_05`, `Jur_12`, `Jur_13`, `Jur_14`, `Jur_15`, `Jur_17`, `Jur_18` |
| SIG | 16 | 4 | `SIG_01`, `SIG_02`, `SIG_09`, `SIG_10` |
| RECO | 71 | 2 | `Reco_50`, `Reco_51` |
| PH | 77 | 0 | `backend_unsupported` |
| Económico | 7 | 0 | `backend_unsupported` |

## Implementación RECO

Cada regla ejecuta primero su condición canónica reimplementada. Después, el
worker calcula una sola vez por corrida el alcance compartido equivalente a
`quality_core/reco_post_filter.sql`: normaliza `pk_id`, excluye nulos/vacíos y
conserva una sola entrada de alcance por PK; al filtrar mantiene toda la
multiplicidad de los hallazgos crudos. El SQL canónico solo sirve como sujeto de contraste y hash;
no se distribuye en los ZIP GPKG.

El alcance se almacena en SQLite temporal y se consulta por cursor. La
transacción queda fail-closed: cancelación, fallo de iterador o cierre anómalo
provocan rollback e invalidan el estado del postfiltro. Una regla RECO fallida
no impide que otra regla elegible use el alcance ya verificado.

El fixture CC0 compartido cubre claves con espacios, claves nulas o vacías,
duplicados, multiplicidad de `LEFT JOIN`, flags nulos, asignación textual,
condición numérica/textual y filas con el mismo `pk_id` que habilitan el alcance
de forma conjunta.

## Evidencia de equivalencia

PostgreSQL 18.4/PostGIS 3.6.2, `MappingDataSource` y
`GeoPackageDataSource` sobre un `.gpkg` físico produjeron los mismos
multiconjuntos crudos, el mismo conjunto de alcance y los mismos resultados
finales:

| Regla | Crudas | Alcance común | Finales | Filtradas | SHA-256 final |
| --- | ---: | ---: | ---: | ---: | --- |
| `Reco_50` | 9 | 8 | 5 | 4 | `65CF54870ADF094C9C76443DF28B65744752B0EF2F77EBCE5C89974D61BCE1E6` |
| `Reco_51` | 7 | 8 | 3 | 4 | `2CB2FB59D556805A8BEBDE8B49993E2134542CAB4E0F2FFF9211200F5F2CE9C6` |

Las evidencias inmutables están en
`docs/evidence/RECO_50_POSTGIS_GPKG_EQUIVALENCE_2026-07-19.json` y
`docs/evidence/RECO_51_POSTGIS_GPKG_EQUIVALENCE_2026-07-19.json`. El checkpoint
`docs/evidence/GPKG_0.0.15_LOCAL_CHECKPOINT_2026-07-19.json` fija también los
seis ZIP, los hashes DBA preservados y las 13 reglas certificadas.

La afirmación formal continúa limitada al fixture sintético. No implica
equivalencia productiva ni del catálogo completo.

## Construcción y verificación local

```powershell
python tools\build_gpkg_plugin_packages.py --version 0.0.15 --tag gpkg-v0.0.15 --dist dist\gpkg
python tools\test_portable_reco_50_51.py
python tools\test_plugin_portable_integration.py
python tools\test_gpkg_reproducible_build.py
python tools\test_gpkg_local_checkpoint.py --version 0.0.15
```

El smoke offscreen de QGIS 3.44.11 verificó las doce extensiones coexistentes,
GPKG directo, capas cargadas mediante OGR y proveedor `memory`. Total y RECO
entregaron los resultados finales 5/3, no los conteos crudos 9/7.

Límite P2 conocido: `PortableRuleBackend.execute()` representa deliberadamente
la etapa cruda. El plugin aplica el postfiltro mediante su worker operativo. Un
consumidor futuro —incluido MapingTool— no debe invocar solo esa etapa para
RECO; antes de integrarlo se expondrá un pipeline operativo único o un contrato
de tipos que haga imposible confundir 9/7 crudas con 5/3 finales.

El tag del comando de build solo fija rutas internas; no crea un tag Git ni
publica artefactos.

## Estado de publicación

El slice permanece local. Los gates técnicos terminan sin defectos y reportan
exactamente nueve bloqueos externos intencionales: seis ZIP sin `LICENSE`
aprobada, metadata pública GPKG, aprobación versionada `0.0.15` y licencia
first-party raíz. No se realizó push, tag, release, instalación en perfiles del
usuario ni despliegue.
