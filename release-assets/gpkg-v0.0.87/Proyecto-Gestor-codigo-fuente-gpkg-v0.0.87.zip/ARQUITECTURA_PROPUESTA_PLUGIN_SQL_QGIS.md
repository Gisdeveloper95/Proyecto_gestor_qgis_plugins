# Arquitectura propuesta - Plugin QGIS + reglas SQL

Fecha: 2026-07-16

## Decision principal

La mejor ruta es una combinacion Python + SQL:

- SQL queda como fuente de verdad de las reglas.
- Python/QGIS queda como capa de interfaz, ejecucion, seleccion, zoom, formularios, exportacion, excepciones y experiencia de usuario.
- Las reglas se administran por llave estable: `Reco_64`, `PH_01`, `Jur_10`, `SIG_02`, `Eco_07`, etc.

No recomiendo meter todas las reglas en un super `.py`. Tampoco recomiendo JSON como contenedor principal del SQL porque obliga a escapar saltos, comillas y comentarios, y vuelve incomodo revisar cambios.

La opcion mas mantenible es:

- Un archivo `.sql` por regla.
- Un manifiesto `.yml` o `.json` liviano con metadatos.
- Un cargador Python que arme el diccionario en memoria.

## Estructura recomendada

```text
Proyecto_gestor/
  quality_core/
    __init__.py
    registry.py
    executor.py
    result_model.py
    exceptions.py
    qgis_bridge.py
    rules/
      manifest.yml
      reco/
        Reco_01.sql
        Reco_02.sql
        Reco_64.sql
      ph/
        PH_01.sql
      jur/
        Jur_01.sql
      sig/
        SIG_01.sql
      eco/
        Eco_01.sql
  plugins/
    validador_calidad_total/
    validador_calidad_reco/
    validador_calidad_ph/
    validador_calidad_juridico/
    validador_calidad_sig/
    validador_calidad_economico/
  tools/
    split_legacy_sql.py
    validate_rule_contracts.py
    build_plugins.py
```

## Ejemplo de manifest.yml

```yaml
rules:
  - id: Reco_64
    family: reco
    component: Calificacion
    title: Predios informales con calificacion mayor a 50 puntos
    sql: reco/Reco_64.sql
    result_type: alfanumerica
    enabled: true
    tags: [reconocimiento, calificacion, informal]

  - id: SIG_02
    family: sig
    component: Digitalizacion
    title: Terrenos en comision
    sql: sig/SIG_02.sql
    result_type: geografica
    enabled: true
    tags: [geografico, comision]
```

## Diccionario en Python

El plugin no debe tener reglas quemadas en codigo. Debe cargar algo equivalente a:

```python
registry.get("Reco_64").sql
registry.list(family="reco")
registry.list(result_type="geografica")
```

Asi se puede editar una sentencia SQL sin tocar la UI ni recompilar logica.

## Plugins separados sin duplicar mantenimiento

La idea buena no es mantener 6 codigos distintos. La idea es mantener un solo nucleo y generar varios paquetes:

- `validador_calidad_total`: todas las reglas.
- `validador_calidad_reco`: solo `family = reco`.
- `validador_calidad_ph`: solo `family = ph`.
- `validador_calidad_juridico`: solo `family = jur`.
- `validador_calidad_sig`: solo `family = sig`.
- `validador_calidad_economico`: solo `family = eco`.

Cada plugin seria un "wrapper" del mismo motor:

```python
PLUGIN_RULE_FILTER = {"family": "reco"}
```

Esto permite entregar plugins especificos a usuarios distintos, pero sin reescribir reglas.

## Flujo del plugin QGIS

1. Cargar manifiesto de reglas.
2. Mostrar arbol por grupos: Reco, PH, Juridico, SIG, Eco.
3. Permitir ejecutar una regla, un grupo o todo.
4. Ejecutar SQL contra PostgreSQL/PostGIS.
5. Recibir resultados con contrato comun: `id_regla`, `componente`, `descripcion_regla`, `pk_id_predio`, `numero_predial_nacional`, `tiene_excepcion`, etc.
6. Mostrar conteos y detalle.
7. Hacer zoom/seleccion usando `pk_id_predio` contra la capa QGIS correspondiente.
8. Abrir formulario QGIS del predio o entidad afectada.
9. Exportar CSV/XLSX.
10. Opcional: insertar en historicos.

## Contrato de salida

Todas las reglas deben devolver columnas estandar. Eso es mas importante que el lenguaje.

Minimo:

- `id_regla`
- `componente`
- `descripcion_regla`
- `proyecto`
- `pk_id_predio`
- `tabla_error_1`
- `pk_tabla_error_1`
- `tabla_error_2`
- `pk_tabla_error_2`
- `numero_predial_nacional`
- `matricula_inmobiliaria`
- `tiene_excepcion`
- `descripcion_excepcion`

Las columnas extra pueden ir como `custom_1` a `custom_12`.

## Actualizaciones por GitHub

Ruta recomendada:

1. Repositorio GitHub con el codigo fuente.
2. GitHub Actions valida y empaqueta cada version.
3. Al subir un tag, se genera ZIP del plugin.
4. Se publica release.
5. Se publica `plugins.xml` para que QGIS detecte actualizaciones.
6. El usuario agrega una sola vez el repositorio personalizado en QGIS.
7. Cuando sube la version en `metadata.txt`, QGIS muestra actualizacion disponible.

Para publico general tambien se puede publicar en el repositorio oficial de plugins QGIS, pero requiere cuenta OSGeo y aprobacion.

## Recomendacion de seguridad

No usar tokens personales pegados en chat ni guardados en archivos del proyecto.

Preferible:

- GitHub connector autorizado por OAuth.
- GitHub CLI con login local.
- GitHub Actions con `GITHUB_TOKEN` interno.
- Si toca PAT, que sea fine-grained, de corta duracion, limitado a un solo repositorio y guardado como secret.

## Ruta de implementacion sugerida

1. Corregir el motor actual para cargar `queries_valledupar.sql`.
2. Crear script que parta el SQL legado en archivos por regla.
3. Crear `manifest.yml` automaticamente desde los encabezados `-- name:`.
4. Corregir IDs inconsistentes (`Jur_10`, `Jur_60`, excepciones cruzadas).
5. Crear `quality_core`.
6. Crear plugin nuevo total.
7. Agregar filtros por grupo.
8. Generar plugins separados desde el mismo nucleo.
9. Empaquetar con CI.
10. Publicar via GitHub Releases o repositorio oficial QGIS.

