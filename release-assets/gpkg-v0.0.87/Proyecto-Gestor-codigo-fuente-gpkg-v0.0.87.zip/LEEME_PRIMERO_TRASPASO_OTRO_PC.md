# Relevo seguro del Proyecto Gestor

El relevo extenso anterior queda conservado en la historia Git hasta `v0.0.7`,
pero sus comandos operativos fueron retirados. Incluía versiones, puertos,
credenciales administrativas y rutas de publicación que ya no son válidos.

## Estado vigente

- `v0.0.7` es el último tag histórico publicado.
- `0.0.8` es evidencia local permanentemente no publicable. No cree ni envíe
  `v0.0.8`, aunque en el futuro existan licencia o aprobaciones.
- El entorno validado usa QGIS `3.44.11`, PostgreSQL `18.4`, PostGIS `3.6.2` y
  `localhost:5432`.
- Las pruebas con credenciales se ejecutan exclusivamente en el perfil aislado
  `%LOCALAPPDATA%/MapingTool/qgis_profiles/profiles/MapingToolDev`, mediante
  `authcfg` y el rol `gestor_validator_ro`.
- No existe fallback manual de publicación. Una versión posterior `0.0.x` solo
  puede avanzar por el workflow protegido y todos los gates fail-closed.
- `SIG_16` debe seguir visible como dependencia faltante; no cree una tabla
  vacía ni simule el perímetro urbano.

## Documentos que sustituyen el relevo antiguo

Lea, en este orden:

1. `docs/BASELINE_0.0.7_RECOVERY_2026-07-17.md`
2. `docs/DB_RESTORE_AND_RULE_VALIDATION_2026-07-17.md`
3. `docs/RECO_FULL_AUDIT_2026-07-18.md`
4. `docs/GESTOR_RULES_ARTIFACT.md`
5. `docs/RELEASE_0.0.8.md`
6. `docs/RELEASE_GATES.md`
7. `docs/DISTRIBUCION_QGIS.md`

Antes de trabajar en otro equipo, recupere el bundle Git en un worktree nuevo,
mantenga intacta la evidencia recibida y cree un perfil QGIS de desarrollo
separado de `default`. No copie bases de autenticación, contraseñas, dumps ni
datos reales al repositorio.
