# Plan de releases - Plugin maestro y plugins fragmentados QGIS

Fecha: 2026-07-16

## Respuesta corta

Si se puede hacer como se pidio:

- Un plugin maestro con todas las reglas SQL.
- Plugins fragmentados por grupo: Reco, PH, Juridico, SIG, Economico.
- Todos usando el mismo nucleo tecnico y el mismo catalogo de reglas.
- Releases versionados por GitHub.
- Notificacion de actualizacion en QGIS mediante `metadata.txt` + `plugins.xml`.

## Principio clave

No se deben mantener varios codigos independientes.

La arquitectura correcta es:

```text
Nucleo comun + catalogo SQL + empaquetadores
              |
              +-- Plugin maestro
              +-- Plugin Reco
              +-- Plugin PH
              +-- Plugin Juridico
              +-- Plugin SIG
              +-- Plugin Economico
```

Cada plugin seria una distribucion distinta, pero el motor seria el mismo.

## Componentes

### 1. quality_core

Motor comun:

- Carga reglas desde un manifiesto.
- Carga SQL desde archivos `.sql`.
- Ejecuta reglas contra PostgreSQL/PostGIS.
- Normaliza resultados.
- Maneja errores, logs y tiempos.
- Entrega resultados al plugin QGIS.

### 2. rules

Catalogo real:

```text
rules/
  manifest.yml
  reco/Reco_01.sql
  reco/Reco_02.sql
  ph/PH_01.sql
  jur/Jur_01.sql
  sig/SIG_01.sql
  eco/Eco_01.sql
```

### 3. plugins

Plugins distribuidos:

```text
plugins/
  validador_calidad_total/
  validador_calidad_reco/
  validador_calidad_ph/
  validador_calidad_juridico/
  validador_calidad_sig/
  validador_calidad_economico/
```

Cada plugin trae su propio `metadata.txt` y su propio filtro:

```python
PLUGIN_RULE_FILTER = {"family": "reco"}
```

El maestro tendria:

```python
PLUGIN_RULE_FILTER = {"family": "*"}
```

## Como funcionaria el release

### Versionamiento

Usar version semantica:

- `1.0.0`: primera version estable.
- `1.0.1`: correccion menor.
- `1.1.0`: nuevas reglas o mejoras compatibles.
- `2.0.0`: cambio grande de contrato o interfaz.

Cada plugin tiene version en su `metadata.txt`.

Ejemplo:

```ini
[general]
name=Validador Calidad Reco
version=1.0.0
qgisMinimumVersion=3.28
repository=https://github.com/Gisdeveloper95/Proyecto_gestor
tracker=https://github.com/Gisdeveloper95/Proyecto_gestor/issues
```

### Empaquetado

Para cada release se generan ZIPs:

```text
validador_calidad_total.1.0.0.zip
validador_calidad_reco.1.0.0.zip
validador_calidad_ph.1.0.0.zip
validador_calidad_juridico.1.0.0.zip
validador_calidad_sig.1.0.0.zip
validador_calidad_economico.1.0.0.zip
plugins.xml
```

### Publicacion

Se publica todo en GitHub Releases.

El archivo clave para actualizaciones es:

```text
https://github.com/Gisdeveloper95/Proyecto_gestor/releases/latest/download/plugins.xml
```

Ese `plugins.xml` lista todos los plugins disponibles y sus versiones.

### Instalacion de usuarios

El usuario agrega una vez el repositorio personalizado en QGIS:

```text
Plugins > Administrar e instalar plugins > Configuracion > Agregar
```

URL:

```text
https://github.com/Gisdeveloper95/Proyecto_gestor/releases/latest/download/plugins.xml
```

Despues QGIS compara la version instalada contra la version publicada.

Si subimos de `1.0.0` a `1.0.1`, QGIS muestra actualizacion disponible.

## Flujo de trabajo para publicar una nueva version

1. Editar o crear reglas SQL.
2. Actualizar `manifest.yml`.
3. Correr pruebas de contrato:
   - regla existe,
   - SQL compila,
   - columnas esperadas,
   - `id_regla` coincide con la llave,
   - tipo `alfanumerica` o `geografica` correcto.
4. Probar en QGIS local.
5. Subir version en los `metadata.txt`.
6. Crear tag:

```text
v1.0.1
```

7. GitHub Actions genera ZIPs.
8. GitHub Actions publica release.
9. GitHub Actions actualiza/genera `plugins.xml`.
10. Usuarios reciben actualizacion en QGIS.

## Releases separados o release unico

Recomiendo release unico por version.

Ejemplo: `v1.0.0` contiene todos los ZIPs.

Ventajas:

- Todos los plugins quedan sincronizados.
- El catalogo SQL tiene una version unica.
- Es mas facil saber que reglas tenia cada entrega.
- Si cambia una regla base, se recompilan todos los plugins afectados.

Tambien se podria versionar cada plugin por separado, pero para este proyecto seria mas desordenado.

## Que pasa si solo cambia una regla Reco

Aunque cambie solo `Reco_64`, el release puede incluir:

- ZIP nuevo del maestro.
- ZIP nuevo del fragmentado Reco.
- `plugins.xml` actualizado.

Los plugins PH, SIG, Juridico y Economico pueden conservar la version anterior si no cambiaron.

Pero para simplicidad operativa inicial, recomiendo subir todos con la misma version hasta que el sistema madure.

## Oficial QGIS vs repositorio propio GitHub

### Repositorio propio GitHub

Mejor para empezar.

- Control total.
- Sin aprobacion externa.
- Ideal para plugins privados o de proyecto.
- Permite distribuir varios plugins desde un mismo `plugins.xml`.

### Repositorio oficial QGIS

Bueno cuando ya este estable.

- Mayor visibilidad.
- Requiere cuenta OSGeo.
- Cada version pasa por validacion/aprobacion.
- Hay reglas de metadata, estructura y calidad.

## Decision recomendada

Fase 1:

- Repositorio propio en GitHub Releases.
- `plugins.xml` propio.
- Plugins privados para pruebas.

Fase 2:

- Publicacion oficial QGIS si se quiere abrir a mas usuarios.

## Primera version real sugerida

`v0.1.0-alpha`

Contenido:

- Motor `quality_core`.
- Cargador de reglas SQL.
- Plugin maestro minimo.
- Solo grupo `Reco` o 5 reglas piloto para probar contrato.
- Conexion PostgreSQL configurable.
- Tabla resumen.
- Detalle por regla.
- Zoom a predio.

`v0.2.0-alpha`

- Mas reglas Reco.
- Excepciones.
- Exportacion.
- Validacion de contrato SQL.

`v0.3.0-alpha`

- Plugins fragmentados generados.
- `plugins.xml`.
- Release GitHub.

`v1.0.0`

- Maestro + fragmentados estables.
- Catalogo completo probado.
- Documentacion de instalacion.

