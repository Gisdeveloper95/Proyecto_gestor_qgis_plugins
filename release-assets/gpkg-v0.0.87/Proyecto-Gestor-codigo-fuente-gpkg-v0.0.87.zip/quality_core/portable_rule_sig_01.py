"""Independent portable implementation of the canonical SIG_01 rule."""

from __future__ import annotations

from collections.abc import Iterator
from datetime import datetime
from typing import Any

from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    postgres_substring,
    raise_if_cancelled,
    sqlite_staging,
    typed_union_token,
)


_PREDIO_FIELDS = (
    "pk_id",
    "numero_predial_nacional",
    "juridico_predio_cancelado",
    "nombre_proyecto",
    "matricula_inmobiliaria",
    "destinacion_economica",
    "area_catastral_terreno",
    "juridico_estado_asignacion",
    "juridico_estado_control",
    "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control",
    "informal_estado_asignacion",
    "informal_estado_control",
    "geografico_estado_asignacion",
    "geografico_estado_control",
)


def _join_token(value: Any) -> str | None:
    """Return a typed equality token while preserving SQL NULL semantics."""

    if value is None:
        return None
    return typed_union_token((value,))


def _terrain_class(numero_predial_nacional: Any) -> str | None:
    suffix = postgres_substring(numero_predial_nacional, 22, 1)
    if suffix is None:
        return None
    if suffix in {"2", "5"}:
        return "informal"
    return "formal"


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE active_predio (
            row_token INTEGER PRIMARY KEY,
            pk_id TEXT,
            pk_key TEXT,
            numero_predial_nacional TEXT,
            number_key TEXT,
            terrain_class TEXT,
            proyecto TEXT,
            matricula_inmobiliaria INTEGER,
            destination_key TEXT,
            area_catastral_terreno REAL,
            juridico_assignment_key TEXT,
            juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT,
            informal_assignment_key TEXT,
            informal_control_key TEXT,
            geografico_assignment_key TEXT,
            geografico_control_key TEXT
        );
        CREATE TABLE formal_terrain (
            code_key TEXT PRIMARY KEY
        ) WITHOUT ROWID;
        CREATE TABLE informal_terrain (
            code_key TEXT PRIMARY KEY
        ) WITHOUT ROWID;
        CREATE TABLE matched_predio_pk (
            pk_key TEXT PRIMARY KEY
        ) WITHOUT ROWID;
        CREATE TABLE destination_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode TEXT
        );
        CREATE TABLE exception_lookup (
            row_token INTEGER PRIMARY KEY,
            fk_token TEXT,
            fid INTEGER,
            descripcion_excepcion TEXT
        );
        CREATE TABLE user_assignment (
            row_token INTEGER PRIMARY KEY,
            fk_token TEXT,
            pk_id TEXT
        );
        CREATE TABLE assignment_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode TEXT
        );
        CREATE TABLE control_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode TEXT
        );
        """
    )


def _ingest_terrain(data_source, layer_mapping, db, cancel_check) -> None:
    for logical_name, table_name in (
        ("lc_gen_terreno", "formal_terrain"),
        ("lc_gen_terreno_informal", "informal_terrain"),
    ):
        physical_name = layer_mapping.resolve(logical_name)
        with BatchInserter(
            db,
            "INSERT OR IGNORE INTO {0}(code_key) VALUES (?)".format(table_name),
            cancel_check=cancel_check,
        ) as inserter:
            for row in data_source.iter_rows(physical_name, ("codigo",)):
                raise_if_cancelled(cancel_check)
                code_key = _join_token(row.get("codigo"))
                if code_key is not None:
                    inserter.add((code_key,))


def _ingest_predios(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("lc_gen_predio")
    insert_sql = (
        "INSERT INTO active_predio("
        "pk_id, pk_key, numero_predial_nacional, number_key, terrain_class, "
        "proyecto, matricula_inmobiliaria, destination_key, "
        "area_catastral_terreno, juridico_assignment_key, "
        "juridico_control_key, reconocimiento_assignment_key, "
        "reconocimiento_control_key, informal_assignment_key, "
        "informal_control_key, geografico_assignment_key, "
        "geografico_control_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    )
    with BatchInserter(db, insert_sql, cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical_name, _PREDIO_FIELDS):
            raise_if_cancelled(cancel_check)
            if not postgres_boolean_is_false_or_null(
                row.get("juridico_predio_cancelado")
            ):
                continue
            number = row.get("numero_predial_nacional")
            inserter.add(
                (
                    row.get("pk_id"),
                    _join_token(row.get("pk_id")),
                    number,
                    _join_token(number),
                    _terrain_class(number),
                    row.get("nombre_proyecto"),
                    row.get("matricula_inmobiliaria"),
                    _join_token(row.get("destinacion_economica")),
                    row.get("area_catastral_terreno"),
                    _join_token(row.get("juridico_estado_asignacion")),
                    _join_token(row.get("juridico_estado_control")),
                    _join_token(row.get("reconocimiento_estado_asignacion")),
                    _join_token(row.get("reconocimiento_estado_control")),
                    _join_token(row.get("informal_estado_asignacion")),
                    _join_token(row.get("informal_estado_control")),
                    _join_token(row.get("geografico_estado_asignacion")),
                    _join_token(row.get("geografico_estado_control")),
                )
            )


def _ingest_simple_lookup(
    data_source,
    layer_mapping,
    db,
    cancel_check,
    logical_name: str,
    table_name: str,
) -> None:
    physical_name = layer_mapping.resolve(logical_name)
    with BatchInserter(
        db,
        "INSERT INTO {0}(key_token, ilicode) VALUES (?, ?)".format(table_name),
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("itfcode", "ilicode")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("itfcode")), row.get("ilicode")))


def _ingest_enrichment(data_source, layer_mapping, db, cancel_check) -> None:
    _ingest_simple_lookup(
        data_source,
        layer_mapping,
        db,
        cancel_check,
        "lc_gen_destinacioneconomica_tipo",
        "destination_lookup",
    )
    _ingest_simple_lookup(
        data_source,
        layer_mapping,
        db,
        cancel_check,
        "lc_gen_asignacion_tipo",
        "assignment_lookup",
    )
    _ingest_simple_lookup(
        data_source,
        layer_mapping,
        db,
        cancel_check,
        "lc_gen_estadocontrol_tipo",
        "control_lookup",
    )

    physical_name = layer_mapping.resolve("lc_gen_excepciones")
    with BatchInserter(
        db,
        "INSERT INTO exception_lookup("
        "fk_token, fid, descripcion_excepcion) VALUES (?, ?, ?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(
            physical_name,
            ("fid", "fk_id", "id_regla", "descripcion_excepcion"),
        ):
            raise_if_cancelled(cancel_check)
            if row.get("id_regla") == "SIG_01":
                inserter.add(
                    (
                        _join_token(row.get("fk_id")),
                        row.get("fid"),
                        row.get("descripcion_excepcion"),
                    )
                )

    physical_name = layer_mapping.resolve("lc_gen_predio_usuarioasignacion")
    with BatchInserter(
        db,
        "INSERT INTO user_assignment(fk_token, pk_id) VALUES (?, ?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("pk_id", "fk_id")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("fk_id")), row.get("pk_id")))


def _prepare_matches_and_indexes(db) -> None:
    db.executescript(
        """
        CREATE INDEX idx_active_predio_number
            ON active_predio(terrain_class, number_key);
        CREATE INDEX idx_active_predio_pk ON active_predio(pk_key);
        INSERT OR IGNORE INTO matched_predio_pk(pk_key)
        SELECT p.pk_key
        FROM active_predio p
        JOIN formal_terrain t ON t.code_key = p.number_key
        WHERE p.terrain_class = 'formal' AND p.pk_key IS NOT NULL;
        INSERT OR IGNORE INTO matched_predio_pk(pk_key)
        SELECT p.pk_key
        FROM active_predio p
        JOIN informal_terrain t ON t.code_key = p.number_key
        WHERE p.terrain_class = 'informal' AND p.pk_key IS NOT NULL;
        CREATE INDEX idx_destination_key ON destination_lookup(key_token);
        CREATE INDEX idx_exception_fk ON exception_lookup(fk_token);
        CREATE INDEX idx_user_assignment_fk ON user_assignment(fk_token);
        CREATE INDEX idx_assignment_key ON assignment_lookup(key_token);
        CREATE INDEX idx_control_key ON control_lookup(key_token);
        """
    )


_RESULT_SQL = """
    SELECT
        p.pk_id,
        p.numero_predial_nacional,
        p.proyecto,
        p.matricula_inmobiliaria,
        d.ilicode,
        p.area_catastral_terreno,
        e.fid,
        e.descripcion_excepcion,
        jur_asig.ilicode,
        jur_ctrl.ilicode,
        reco_asig.ilicode,
        reco_ctrl.ilicode,
        info_asig.ilicode,
        info_ctrl.ilicode,
        geo_asig.ilicode,
        geo_ctrl.ilicode,
        ua.pk_id
    FROM active_predio p
    LEFT JOIN matched_predio_pk matched ON matched.pk_key = p.pk_key
    LEFT JOIN destination_lookup d ON d.key_token = p.destination_key
    LEFT JOIN exception_lookup e ON e.fk_token = p.pk_key
    LEFT JOIN user_assignment ua ON ua.fk_token = p.pk_key
    LEFT JOIN assignment_lookup jur_asig
        ON jur_asig.key_token = p.juridico_assignment_key
    LEFT JOIN control_lookup jur_ctrl
        ON jur_ctrl.key_token = p.juridico_control_key
    LEFT JOIN assignment_lookup reco_asig
        ON reco_asig.key_token = p.reconocimiento_assignment_key
    LEFT JOIN control_lookup reco_ctrl
        ON reco_ctrl.key_token = p.reconocimiento_control_key
    LEFT JOIN assignment_lookup info_asig
        ON info_asig.key_token = p.informal_assignment_key
    LEFT JOIN control_lookup info_ctrl
        ON info_ctrl.key_token = p.informal_control_key
    LEFT JOIN assignment_lookup geo_asig
        ON geo_asig.key_token = p.geografico_assignment_key
    LEFT JOIN control_lookup geo_ctrl
        ON geo_ctrl.key_token = p.geografico_control_key
    WHERE matched.pk_key IS NULL
    ORDER BY
        p.numero_predial_nacional IS NULL,
        p.numero_predial_nacional,
        p.proyecto IS NULL,
        p.proyecto,
        p.row_token,
        d.row_token,
        e.row_token,
        ua.row_token,
        jur_asig.row_token,
        jur_ctrl.row_token,
        reco_asig.row_token,
        reco_ctrl.row_token,
        info_asig.row_token,
        info_ctrl.row_token,
        geo_asig.row_token,
        geo_ctrl.row_token
"""


def execute_sig_01(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield SIG_01 omissions using bounded, disk-backed attribute joins."""

    execution_timestamp = datetime.now()
    with sqlite_staging(cancel_check, prefix="mapingtool-calidad-gpkg-sig01-") as db:
        _create_stage(db)
        _ingest_terrain(data_source, layer_mapping, db, cancel_check)
        _ingest_predios(data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(data_source, layer_mapping, db, cancel_check)
        _prepare_matches_and_indexes(db)
        db.commit()
        raise_if_cancelled(cancel_check)

        cursor = db.execute(_RESULT_SQL)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                (
                    pk_id,
                    numero_predial_nacional,
                    proyecto,
                    matricula_inmobiliaria,
                    destino_economico,
                    area_catastral_terreno,
                    exception_fid,
                    descripcion_excepcion,
                    juridico_estado_asignacion,
                    juridico_estado_control,
                    reconocimiento_estado_asignacion,
                    reconocimiento_estado_control,
                    informal_estado_asignacion,
                    informal_estado_control,
                    geografico_estado_asignacion,
                    geografico_estado_control,
                    assignment_pk,
                ) = values
                yield {
                    "id_regla": "SIG_01",
                    "componente": "Digitalizacion",
                    "descripcion_regla": "Predios en Omision",
                    "proyecto": proyecto,
                    "pk_id_predio": pk_id,
                    "tabla_error_1": "LC_Gen_Predio",
                    "pk_tabla_error_1": pk_id,
                    "tabla_error_2": None,
                    "pk_tabla_error_2": None,
                    "numero_predial_nacional": numero_predial_nacional,
                    "matricula_inmobiliaria": matricula_inmobiliaria,
                    "destino_economico": destino_economico,
                    "area_catastral_terreno": area_catastral_terreno,
                    "identificador_caracteristica_unidad_construccion": None,
                    "total_plantas": None,
                    "tipo_unidad_construccion": None,
                    "uso_construccion": None,
                    "area_construida": None,
                    "puntaje_calificacion": None,
                    "tipo_novedad": None,
                    "numero_predial_nacional_novedad": None,
                    "tiene_excepcion": exception_fid is not None,
                    "descripcion_excepcion": descripcion_excepcion,
                    "juridico_estado_asignacion": juridico_estado_asignacion,
                    "juridico_estado_control": juridico_estado_control,
                    "reconocimiento_estado_asignacion": (
                        reconocimiento_estado_asignacion
                    ),
                    "reconocimiento_estado_control": reconocimiento_estado_control,
                    "informal_estado_asignacion": informal_estado_asignacion,
                    "informal_estado_control": informal_estado_control,
                    "geografico_estado_asignacion": geografico_estado_asignacion,
                    "geografico_estado_control": geografico_estado_control,
                    "pk_lc_gen_predio_usuarioasignacion": assignment_pk,
                    "usuario_creacion": "admin",
                    "fecha_creacion": execution_timestamp,
                    "usuario_modificacion": "admin",
                    "fecha_modificacion": execution_timestamp,
                    "custom_1": None,
                    "custom_2": None,
                    "custom_3": None,
                    "custom_4": None,
                    "custom_5": None,
                    "custom_6": None,
                    "custom_7": False,
                    "custom_8": None,
                    "custom_9": None,
                    "custom_10": None,
                    "custom_11": None,
                    "custom_12": None,
                }
        finally:
            cursor.close()
