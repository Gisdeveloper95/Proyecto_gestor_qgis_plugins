"""Disk-backed portable engine for PH construction scalar rules."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_boolean_is_true, raise_if_cancelled, sqlite_staging


@dataclass(frozen=True)
class Rule:
    canonical_id: str
    description: str
    predicate: str
    component: str = "PH"
    custom_7: bool = False


RULES={
 "PH_69":Rule("PH_69","Caracteristica Unidad de Construccion PH con calificacion total superior a 60 puntos","c.score > 60"),
 "PH_70":Rule("PH_70","Caracteristica Unidad de Construccion PH con calificacion total menor a 20 puntos","c.score < 20"),
 "PH_71":Rule("PH_71","Caracteristica Unidad de Construccion PH con uso de apartamentos menor a 30 metros y mayor a 80 metros","c.usage IN (0,1) AND (c.built_area < 30 OR c.built_area > 80)"),
 "PH_72":Rule("PH_72","Caracteristica Unidad de Construccion PH con uso de parqueaderos menor a 10 metros y mayor a 25 metros","c.usage IN (5,6,32,33) AND (c.built_area < 10 OR c.built_area > 25)"),
 "PH_73":Rule("PH_73","Caracteristica Unidad de Construccion PH con uso de depositos mayor a 10 metros","c.usage IN (4,23) AND c.built_area > 10"),
 "PH_74":Rule("PH_74","Caracteristica Unidad de Construccion PH con uso comercial menor a 30 metros y mayor a 80 metros","lower(u.ilicode) LIKE 'comercial%' AND (c.built_area < 30 OR c.built_area > 80)"),
 "PH_75":Rule("PH_75","Caracteristica Unidad de Construccion PH con uso de depositos mayor a 10 metros","c.usage IN (7,10,17,20,27,31,34,35,40) AND c.built_area > 10"),
}
GF=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
CF=("pk_id","identificador","total_plantas","tipo_unidad_construccion","uso_construccion","area_construida","puntaje")

def _create(db):
 db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,cancelled,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE excluded_ph(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE excluded_gen(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE construction(row_token INTEGER PRIMARY KEY,pk_key TEXT,identifier,total_floors,unit_type,unit_type_key TEXT,usage,usage_key TEXT,built_area,score);CREATE TABLE unit_type_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE usage_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,ph_key TEXT,npn,project,registration,destination_key TEXT,area,identifier,total_floors,unit_type_key TEXT,usage_key TEXT,built_area,score,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")

def _ingest(source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,npn,cancelled,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):
   raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("juridico_predio_cancelado"),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 with BatchInserter(db,"INSERT INTO excluded_ph(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
 with BatchInserter(db,"INSERT INTO excluded_gen(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
  for key,npn,cancelled in db.execute("SELECT pk_key,npn,cancelled FROM gen"):
   if postgres_boolean_is_true(cancelled)and npn is not None and len(npn)>=22 and npn[21:22]=="9":ins.add((key,))
 with BatchInserter(db,"INSERT INTO construction(pk_key,identifier,total_floors,unit_type,unit_type_key,usage,usage_key,built_area,score)VALUES(?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("determinacion_area_construccion"),CF):raise_if_cancelled(cancel);ins.add((_join_token(r.get("pk_id")),r.get("identificador"),r.get("total_plantas"),r.get("tipo_unidad_construccion"),_join_token(r.get("tipo_unidad_construccion")),r.get("uso_construccion"),_join_token(r.get("uso_construccion")),r.get("area_construida"),r.get("puntaje")))
 for logical,table in(("lc_reco_unidadconstruccion_tipo","unit_type_lookup"),("lc_gen_usouconstruccion_tipo","usage_lookup")):
  with BatchInserter(db,f"INSERT INTO {table}(key_token,ilicode)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve(logical),("itfcode","ilicode")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))

def _prepare(definition,db):
 db.execute("""INSERT INTO selected(general_pk,ph_pk,ph_key,npn,project,registration,destination_key,area,identifier,total_floors,unit_type_key,usage_key,built_area,score,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)SELECT g.pk_id,p.pk_id,p.pk_key,p.npn,g.project,p.registration,p.destination_key,p.area,c.identifier,c.total_floors,c.unit_type_key,c.usage_key,c.built_area,c.score,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c FROM ph p LEFT JOIN gen g ON p.parent_key=g.pk_key JOIN construction c ON c.pk_key=p.pk_key LEFT JOIN usage_lookup u ON u.key_token=c.usage_key WHERE NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.key_token=p.pk_key)AND NOT EXISTS(SELECT 1 FROM excluded_gen x WHERE x.key_token=p.parent_key)AND """+definition.predicate)

RESULT="""SELECT DISTINCT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.identifier,s.total_floors,t.ilicode,u.ilicode,s.built_area,s.score FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key LEFT JOIN unit_type_lookup t ON t.key_token=s.unit_type_key LEFT JOIN usage_lookup u ON u.key_token=s.usage_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c"""

def execute_scalar(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]="LC_PH_Predio";row["pk_tabla_error_1"]=v[17];row["identificador_caracteristica_unidad_construccion"]=v[18];row["total_plantas"]=v[19];row["tipo_unidad_construccion"]=v[20];row["uso_construccion"]=v[21];row["area_construida"]=v[22];row["puntaje_calificacion"]=v[23];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_scalar(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_69=_entry("PH_69");execute_ph_70=_entry("PH_70");execute_ph_71=_entry("PH_71");execute_ph_72=_entry("PH_72");execute_ph_73=_entry("PH_73");execute_ph_74=_entry("PH_74");execute_ph_75=_entry("PH_75")
