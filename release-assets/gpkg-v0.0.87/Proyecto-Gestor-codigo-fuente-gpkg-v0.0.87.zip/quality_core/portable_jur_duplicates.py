"""Portable duplicate-key rules for general and PH predios."""
from datetime import datetime
from types import SimpleNamespace
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import raise_if_cancelled,sqlite_staging
from .portable_rule_reco_02 import _create_stage,_ingest

RULES={"Jur_02":("matricula_inmobiliaria","Predios con matricula inmobiliaria repetida o duplicada"),"Jur_11":("numero_predial_nacional","Predios con numero predial repetido")}
def execute_duplicate(rid,data_source,mapping,cancel_check=None):
 key,description=RULES[rid]; definition=SimpleNamespace(canonical_id=rid,component="Juridico",description=description,custom_7=False); timestamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-") as db:
  _create_stage(db);_ingest(data_source,mapping,db,cancel_check);_ingest_enrichment(definition,data_source,mapping,db,cancel_check)
  db.executescript(f"""CREATE INDEX idx_predio_key ON predio(pk_key);CREATE INDEX idx_ph_matrix ON ph_predio(matrix_key);CREATE INDEX idx_excluded_ph ON excluded_ph(ph_key);
  CREATE TABLE candidate AS WITH gd AS(SELECT {key} k FROM predio WHERE active=1 AND {key} IS NOT NULL GROUP BY {key} HAVING count(*)>1),eligible AS(SELECT ph.* FROM ph_predio ph WHERE NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.ph_key=ph.pk_key)),expanded AS(SELECT ph.*,m.pk_id matrix_pk,m.pk_key matrix_actual,m.proyecto FROM eligible ph JOIN predio m ON m.pk_key=ph.matrix_key WHERE m.active=1),pd AS(SELECT {key} k FROM expanded WHERE {key} IS NOT NULL GROUP BY {key} HAVING count(*)>1)
  SELECT 'LC_Gen_Predio' table_name,p.pk_id matrix_pk,p.pk_key matrix_key,p.proyecto,p.matricula_inmobiliaria,p.destination_key,p.area_catastral_terreno,p.numero_predial_nacional npn_output,p.pk_id error_pk FROM predio p JOIN gd ON p.{key}=gd.k WHERE p.active=1
  UNION SELECT 'LC_PH_Predio',x.matrix_pk,x.matrix_actual,x.proyecto,x.matricula_inmobiliaria,x.destination_key,x.area_catastral_terreno,x.numero_predial_nacional,x.pk_id FROM expanded x JOIN pd ON x.{key}=pd.k;ALTER TABLE candidate ADD COLUMN error_key TEXT;""")
  for rowid,error_pk in db.execute("SELECT rowid,error_pk FROM candidate"):db.execute("UPDATE candidate SET error_key=? WHERE rowid=?",(_join_token(error_pk),rowid))
  sql="""SELECT c.matrix_pk,c.npn_output,c.proyecto,c.matricula_inmobiliaria,d.ilicode,c.area_catastral_terreno,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.table_name,c.error_pk FROM candidate c JOIN predio s ON s.pk_key=c.matrix_key LEFT JOIN destination_lookup d ON d.key_token=c.destination_key LEFT JOIN exception_lookup e ON e.fk_token=c.error_key LEFT JOIN user_assignment ua ON ua.fk_token=c.error_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.juridico_assignment_key LEFT JOIN control_lookup jc ON jc.key_token=s.juridico_control_key LEFT JOIN assignment_lookup ra ON ra.key_token=s.reconocimiento_assignment_key LEFT JOIN control_lookup rc ON rc.key_token=s.reconocimiento_control_key LEFT JOIN assignment_lookup ia ON ia.key_token=s.informal_assignment_key LEFT JOIN control_lookup ic ON ic.key_token=s.informal_control_key LEFT JOIN assignment_lookup ga ON ga.key_token=s.geografico_assignment_key LEFT JOIN control_lookup gc ON gc.key_token=s.geografico_control_key"""
  db.commit();cur=db.execute(sql)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);base=_result_row(definition,timestamp,v[:17]);base["tabla_error_1"]=v[17];base["pk_tabla_error_1"]=v[18];yield base
  finally:cur.close()
def execute_jur_02(data_source,layer_mapping,cancel_check=None):return execute_duplicate("Jur_02",data_source,layer_mapping,cancel_check)
def execute_jur_11(data_source,layer_mapping,cancel_check=None):return execute_duplicate("Jur_11",data_source,layer_mapping,cancel_check)
