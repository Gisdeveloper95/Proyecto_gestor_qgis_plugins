"""Independent portable implementation of the canonical Reco_18 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_boolean_is_true


def _matches(row: Mapping[str, Any]) -> bool:
    return (
        postgres_boolean_is_true(row.get("predio_tiene_cambio_fisico"))
        and postgres_boolean_is_true(row.get("reconocimiento_predio_completo"))
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_18",
    component="Reconocimiento",
    description=(
        "Predios con cambio fisico y marcado como predio completo en la etapa "
        "de reconocimiento"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=(
        "predio_tiene_cambio_fisico",
        "reconocimiento_predio_completo",
    ),
)


def execute_reco_18(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_18 findings before the operational filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
