"""Independent portable implementation of the canonical Reco_16 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    assignment = row.get("reconocimiento_estado_asignacion")
    return (
        row.get("reconocimiento_estado_control") == 1
        and assignment is not None
        and assignment != 2
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_16",
    component="Reconocimiento",
    description=(
        "Predios con marca de aprobado por control sin haber sido tramitado "
        "por el usuario de reconocimiento"
    ),
    predicate=_matches,
    custom_7=False,
)


def execute_reco_16(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_16 findings before the operational filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
