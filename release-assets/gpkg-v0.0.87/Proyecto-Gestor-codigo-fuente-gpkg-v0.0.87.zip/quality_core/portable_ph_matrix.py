"""Portable PH matrix/unit consistency and missing-relation rules."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,postgres_boolean_is_false_or_null,postgres_boolean_is_true,raise_if_cancelled,sqlite_staging
@dataclass(frozen=True)
class Rule:
 canonical_id:str;component:str;description:str;mode:str;custom_7:bool=False
RULES={"PH_01":Rule("PH_01","Juridico","Predios PH Matriz con el numero predial diferente a los numeros prediales de las unidades verificandolos hasta la posicion 22","prefix"),"PH_04":Rule("PH_04","PH","Predios PH Matriz con cambio fisico de mas de 10 unidades prediales","many"),"PH_09":Rule("PH_09","PH","Predios PH Matriz con codificacion diferente a 00000000 en las posiciones 23 a 30","matrix_code"),"PH_65":Rule("PH_65","PH","Predios PH Matrices sin PH predio","missing_ph"),"PH_66":Rule("PH_66","PH","Predios PH sin PH matriz","missing_matrix")}
GF=("pk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_predio_cancelado","predio_tiene_cambio_fisico","ph_predio_matriz_menor_10_unidades","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control");PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,registration,destination_key TEXT,area,cancelled,physical_change,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE excluded_ph(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE excluded_gen(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE candidate(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,exception_key TEXT,assignment_key TEXT,error_table_1,error_pk_1,error_table_2,error_pk_2,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(definition,source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,npn,registration,destination_key,area,cancelled,physical_change,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),r.get("juridico_predio_cancelado"),r.get("predio_tiene_cambio_fisico"),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 if definition.mode in("missing_ph","missing_matrix"):
  if definition.mode=="missing_matrix":
   with BatchInserter(db,"INSERT INTO excluded_ph(key_token)VALUES(?)",cancel_check=cancel)as ins:
    for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
     raise_if_cancelled(cancel)
     if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
  with BatchInserter(db,"INSERT INTO excluded_gen(key_token)VALUES(?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"),("fk_id","tipo_novedad")):
    raise_if_cancelled(cancel)
    if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
   for k,npn,cancelled in db.execute("SELECT pk_key,npn,cancelled FROM gen"):
    if postgres_boolean_is_true(cancelled)and npn is not None and len(npn)>=22 and npn[21:22]=='9':ins.add((k,))
def _prepare(definition,db):
 ins="INSERT INTO candidate(general_pk,ph_pk,exception_key,assignment_key,error_table_1,error_pk_1,error_table_2,error_pk_2,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)"
 states="g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c"
 if definition.mode=="prefix":q=f"SELECT p.pk_id,p.pk_id,g.pk_key,g.pk_key,'LC_Gen_Predio',g.pk_id,'LC_Ph_Predio',p.pk_id,p.npn,g.project,p.registration,p.destination_key,p.area,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL FROM gen g JOIN ph p ON p.parent_key=g.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND substr(g.npn,1,22)<>substr(p.npn,1,22)"
 elif definition.mode=="many":q=f"SELECT g.pk_id,NULL,g.pk_key,g.pk_key,'LC_Gen_Predio',g.pk_id,NULL,NULL,g.npn,g.project,g.registration,g.destination_key,g.area,{states} FROM gen g JOIN(SELECT parent_key FROM ph GROUP BY parent_key HAVING count(*)>10)p ON p.parent_key=g.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND g.physical_change=1"
 elif definition.mode=="matrix_code":q=f"SELECT g.pk_id,NULL,p.pk_key,p.pk_key,'LC_Gen_Predio',g.pk_id,NULL,NULL,g.npn,g.project,g.registration,g.destination_key,g.area,{states} FROM gen g JOIN ph p ON p.parent_key=g.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND substr(g.npn,22,9)<>'900000000' GROUP BY g.npn"
 elif definition.mode=="missing_ph":q=f"SELECT g.pk_id,NULL,g.pk_key,g.pk_key,'LC_Gen_Predio',g.pk_id,NULL,NULL,g.npn,g.project,g.registration,g.destination_key,g.area,{states} FROM gen g WHERE substr(g.npn,22,1)='9' AND NOT EXISTS(SELECT 1 FROM excluded_gen x WHERE x.key_token=g.pk_key)AND NOT EXISTS(SELECT 1 FROM ph p WHERE p.parent_key=g.pk_key)"
 else:q="SELECT NULL,p.pk_id,p.pk_key,p.pk_key,'LC_PH_Predio',p.pk_id,NULL,NULL,p.npn,NULL,p.registration,p.destination_key,p.area,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL FROM ph p WHERE NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.key_token=p.pk_key)AND NOT EXISTS(SELECT 1 FROM excluded_gen x WHERE x.key_token=p.parent_key)AND NOT EXISTS(SELECT 1 FROM gen g WHERE g.pk_key=p.parent_key)"
 db.execute(ins+q)
RESULT="""SELECT DISTINCT c.general_pk,c.npn,c.project,c.registration,d.ilicode,c.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.ph_pk,c.error_table_1,c.error_pk_1,c.error_table_2,c.error_pk_2 FROM candidate c LEFT JOIN destination_lookup d ON d.key_token=c.destination_key LEFT JOIN exception_lookup e ON e.fk_token=c.exception_key LEFT JOIN user_assignment ua ON ua.fk_token=c.assignment_key LEFT JOIN assignment_lookup ja ON ja.key_token=c.jur_a LEFT JOIN control_lookup jc ON jc.key_token=c.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=c.reco_a LEFT JOIN control_lookup rc ON rc.key_token=c.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=c.info_a LEFT JOIN control_lookup ic ON ic.key_token=c.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=c.geo_a LEFT JOIN control_lookup gc ON gc.key_token=c.geo_c ORDER BY c.npn IS NULL,c.npn,c.project IS NULL,c.project"""
def execute_matrix(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(definition,source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]=v[18];row["pk_tabla_error_1"]=v[19];row["tabla_error_2"]=v[20];row["pk_tabla_error_2"]=v[21];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_matrix(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_01=_entry("PH_01");execute_ph_04=_entry("PH_04");execute_ph_09=_entry("PH_09");execute_ph_65=_entry("PH_65");execute_ph_66=_entry("PH_66")
