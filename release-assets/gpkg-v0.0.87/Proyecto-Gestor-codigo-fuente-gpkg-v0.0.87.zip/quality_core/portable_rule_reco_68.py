"""Independent portable implementation of canonical Reco_68."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_68", "Reconocimiento",
    "Predios con contacto de Visita con nombres que tienen números o numeros de documento con letras",
    "lc_vis_contactovisita",
    ("pk_id", "fk_id", "nombre_quien_atendio", "numero_documento_quien_atendio"),
    "inner", "1=1",
    "r.nombre_quien_atendio GLOB '*[^A-Za-zÁÉÍÓÚáéíóúÑñ ]*' "
    "OR r.numero_documento_quien_atendio GLOB '*[A-Za-zÁÉÍÓÚáéíóúÑñ]*'",
    "LC_Vis_ContactoVisita", "related",
)

def execute_reco_68(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
