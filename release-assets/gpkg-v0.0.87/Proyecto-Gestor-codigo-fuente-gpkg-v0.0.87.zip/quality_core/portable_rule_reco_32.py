"""Independent portable implementation of canonical Reco_32."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_32", "Calificacion",
    "Caracteristica Unidad de Construccion con uso de construccion residencial vivienda hasta 3 pisos y un total de plantas mayor\u00a0a\u00a03",
    "c.uso_construccion = 11 AND c.total_plantas > 3", False,
)

def execute_reco_32(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
