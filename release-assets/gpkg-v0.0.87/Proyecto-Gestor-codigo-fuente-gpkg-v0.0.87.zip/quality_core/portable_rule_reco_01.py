"""Independent portable implementation of canonical Reco_01."""
from .portable_reco_history import execute_reco_01 as _execute


def execute_reco_01(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
