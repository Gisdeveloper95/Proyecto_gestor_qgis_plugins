"""Independent portable implementation of canonical Reco_13."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_13", "Juridico",
    "Predios marcados para visita en la etapa juridica con el contacto de visita pero sin el resultado de la visita definido",
    "lc_vis_contactovisita", ("pk_id", "fk_id", "resultado_visita"),
    "inner", "1=1",
    "p.juridico_predio_para_visita = 1 AND r.resultado_visita IS NULL",
    "LC_Gen_Predio", "predio", "LC_Vis_ContactoVisita", "related",
    predio_filter_fields=("juridico_predio_para_visita",),
)

def execute_reco_13(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
