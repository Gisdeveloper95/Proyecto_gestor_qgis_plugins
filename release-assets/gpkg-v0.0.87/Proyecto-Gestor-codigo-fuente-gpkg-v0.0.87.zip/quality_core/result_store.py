"""Bounded-memory, disk-backed storage for validator findings.

The QGIS worker and the UI open independent connections to the same SQLite
file.  A rule is committed atomically only after its PostgreSQL cursor has
been consumed completely; cancellation therefore never exposes a partial
rule.  Result payloads remain local to the workstation and are removed when
the plugin run is replaced or unloaded.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from dataclasses import dataclass
import json
from pathlib import Path
import sqlite3
import tempfile
import threading
from typing import Any, Callable

from .atomic_output import remove_with_retry
from .sql_runtime import EXPORT_COLUMNS, is_truthy


WRITE_BATCH_SIZE = 256
DEFAULT_PAGE_SIZE = 250
MAX_PAGE_SIZE = 2000
SEARCH_COLUMNS = (
    "numero_predial_nacional",
    "pk_id_predio",
    "pk_tabla_error_1",
    "proyecto",
)


class ResultStoreCancelled(RuntimeError):
    """Raised when a cooperative cancellation rolls back the active rule."""


@dataclass(frozen=True)
class RuleWriteResult:
    raw_total: int
    stored_total: int
    filtered_out: int
    predios: int
    exceptions: int
    peak_buffered_rows: int


def _storage_value(value: Any) -> Any:
    """Reduce Qt/PostgreSQL values to JSON-safe scalar values."""

    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    return str(value)


def _normalized_payload(row: dict[str, Any]) -> dict[str, Any]:
    return {column: _storage_value(row.get(column)) for column in EXPORT_COLUMNS}


def _search_text(payload: dict[str, Any]) -> str:
    return " ".join(
        str(payload.get(column) or "").casefold() for column in SEARCH_COLUMNS
    )


def _cancelled(cancel_check: Callable[[], bool] | None) -> bool:
    return bool(cancel_check is not None and cancel_check())


class ResultStore:
    """SQLite-backed findings with stable keyset order and paged reads."""

    _registry_lock = threading.RLock()
    _open_counts: dict[str, int] = {}
    _pending_cleanup: set[str] = set()

    def __init__(self, path: str | Path, *, initialize: bool = False):
        self.path = Path(path).resolve()
        self._connection = sqlite3.connect(str(self.path), timeout=30.0)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA busy_timeout = 30000")
        self._connection.execute("PRAGMA synchronous = NORMAL")
        self._connection.execute("PRAGMA temp_store = FILE")
        if initialize:
            self._initialize()
        key = str(self.path)
        with self._registry_lock:
            self._open_counts[key] = self._open_counts.get(key, 0) + 1

    @classmethod
    def create(cls, directory: str | Path | None = None) -> "ResultStore":
        root = Path(directory).resolve() if directory is not None else None
        if root is not None:
            root.mkdir(parents=True, exist_ok=True)
        handle = tempfile.NamedTemporaryFile(
            prefix="mapingtool-validator-",
            suffix=".sqlite3",
            dir=str(root) if root is not None else None,
            delete=False,
        )
        path = Path(handle.name)
        handle.close()
        return cls(path, initialize=True)

    @classmethod
    def open(cls, path: str | Path) -> "ResultStore":
        resolved = Path(path).resolve()
        if not resolved.is_file():
            raise FileNotFoundError(resolved)
        return cls(resolved)

    def _initialize(self) -> None:
        self._connection.execute("PRAGMA journal_mode = WAL")
        self._connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS result_rows (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                rule_id TEXT NOT NULL,
                pk_id_predio TEXT,
                tiene_excepcion INTEGER NOT NULL,
                search_text TEXT NOT NULL,
                payload_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS result_rows_rule_sequence
                ON result_rows(rule_id, sequence);
            CREATE INDEX IF NOT EXISTS result_rows_predio
                ON result_rows(rule_id, pk_id_predio);
            CREATE TABLE IF NOT EXISTS reco_allowed_predio (
                pk_id_predio TEXT PRIMARY KEY
            ) WITHOUT ROWID;
            """
        )
        self._connection.commit()

    def close(self) -> None:
        connection = self._connection
        if connection is None:
            return
        connection.close()
        self._connection = None
        key = str(self.path)
        should_cleanup = False
        with self._registry_lock:
            count = self._open_counts.get(key, 0)
            if count <= 1:
                self._open_counts.pop(key, None)
                should_cleanup = key in self._pending_cleanup
            else:
                self._open_counts[key] = count - 1
        if should_cleanup:
            self._cleanup_registered_path(key)

    @classmethod
    def _cleanup_registered_path(cls, key: str) -> bool:
        with cls._registry_lock:
            if cls._open_counts.get(key, 0):
                cls._pending_cleanup.add(key)
                return False
            try:
                for suffix in ("-wal", "-shm", ""):
                    remove_with_retry(Path(key + suffix))
            except PermissionError:
                cls._pending_cleanup.add(key)
                raise
            cls._pending_cleanup.discard(key)
            return True

    def remove(self) -> bool:
        key = str(self.path)
        with self._registry_lock:
            self._pending_cleanup.add(key)
        self.close()
        with self._registry_lock:
            if self._open_counts.get(key, 0):
                return False
            pending = key in self._pending_cleanup
        if pending:
            return self._cleanup_registered_path(key)
        return True

    @classmethod
    def pending_cleanup_paths(cls) -> tuple[str, ...]:
        with cls._registry_lock:
            return tuple(sorted(cls._pending_cleanup))

    @classmethod
    def retry_pending_cleanup(cls) -> dict[str, str]:
        failures = {}
        for key in cls.pending_cleanup_paths():
            try:
                cls._cleanup_registered_path(key)
            except PermissionError as exc:
                failures[key] = str(exc)
        return failures

    def clear_results(self) -> None:
        self._connection.execute("DELETE FROM result_rows")
        self._connection.commit()

    def replace_reco_allowed(
        self,
        rows: Iterable[dict[str, Any]],
        *,
        cancel_check: Callable[[], bool] | None = None,
    ) -> tuple[int, int]:
        """Persist allowed RECO predio IDs without retaining the full set."""

        inserted = 0
        peak_buffered = 0
        iterator = iter(rows)
        try:
            self._connection.execute("BEGIN IMMEDIATE")
            self._connection.execute("DELETE FROM reco_allowed_predio")
            while True:
                batch: list[tuple[str]] = []
                exhausted = False
                for _index in range(WRITE_BATCH_SIZE):
                    if _cancelled(cancel_check):
                        raise ResultStoreCancelled(
                            "Consulta cancelada durante la lectura del filtro RECO."
                        )
                    try:
                        row = next(iterator)
                    except StopIteration:
                        exhausted = True
                        break
                    value = row.get("pk_id_predio")
                    normalized = str(value).strip() if value not in (None, "") else ""
                    if normalized:
                        batch.append((normalized,))
                if batch:
                    peak_buffered = max(peak_buffered, len(batch))
                    before = self._connection.total_changes
                    self._connection.executemany(
                        "INSERT OR IGNORE INTO reco_allowed_predio(pk_id_predio) VALUES (?)",
                        batch,
                    )
                    inserted += self._connection.total_changes - before
                if exhausted:
                    break
            if _cancelled(cancel_check):
                raise ResultStoreCancelled(
                    "Consulta cancelada antes de confirmar el filtro RECO."
                )
            self._connection.commit()
            return inserted, peak_buffered
        except Exception:
            self._connection.rollback()
            raise
        finally:
            close = getattr(iterator, "close", None)
            if callable(close):
                close()

    def write_rule_rows(
        self,
        rule_id: str,
        rows: Iterable[dict[str, Any]],
        *,
        apply_reco_filter: bool = False,
        cancel_check: Callable[[], bool] | None = None,
    ) -> RuleWriteResult:
        """Replace one rule atomically while consuming at most one bounded batch."""

        normalized_rule_id = str(rule_id)
        raw_total = 0
        stored_total = 0
        peak_buffered = 0
        iterator = iter(rows)
        try:
            self._connection.execute("BEGIN IMMEDIATE")
            self._connection.execute(
                "DELETE FROM result_rows WHERE rule_id = ?", (normalized_rule_id,)
            )
            while True:
                batch: list[dict[str, Any]] = []
                for _index in range(WRITE_BATCH_SIZE):
                    if _cancelled(cancel_check):
                        raise ResultStoreCancelled(
                            "Consulta cancelada durante la lectura de resultados."
                        )
                    try:
                        row = next(iterator)
                    except StopIteration:
                        break
                    raw_total += 1
                    batch.append(_normalized_payload(row))
                if not batch:
                    break
                peak_buffered = max(peak_buffered, len(batch))

                allowed: set[str] | None = None
                if apply_reco_filter:
                    predio_ids = sorted(
                        {
                            str(row.get("pk_id_predio")).strip()
                            for row in batch
                            if row.get("pk_id_predio") not in (None, "")
                        }
                    )
                    allowed = set()
                    if predio_ids:
                        placeholders = ",".join("?" for _value in predio_ids)
                        allowed = {
                            str(record[0])
                            for record in self._connection.execute(
                                "SELECT pk_id_predio FROM reco_allowed_predio "
                                "WHERE pk_id_predio IN ({0})".format(placeholders),
                                predio_ids,
                            )
                        }

                inserts = []
                for payload in batch:
                    predio = payload.get("pk_id_predio")
                    predio_text = (
                        str(predio).strip() if predio not in (None, "") else None
                    )
                    if apply_reco_filter and (
                        predio_text is None or predio_text not in (allowed or set())
                    ):
                        continue
                    inserts.append(
                        (
                            normalized_rule_id,
                            predio_text,
                            1 if is_truthy(payload.get("tiene_excepcion")) else 0,
                            _search_text(payload),
                            json.dumps(
                                payload,
                                ensure_ascii=False,
                                sort_keys=True,
                                separators=(",", ":"),
                            ),
                        )
                    )
                if inserts:
                    self._connection.executemany(
                        "INSERT INTO result_rows("
                        "rule_id, pk_id_predio, tiene_excepcion, search_text, payload_json"
                        ") VALUES (?, ?, ?, ?, ?)",
                        inserts,
                    )
                    stored_total += len(inserts)

            if _cancelled(cancel_check):
                raise ResultStoreCancelled(
                    "Consulta cancelada antes de confirmar los resultados."
                )
            metrics = self._connection.execute(
                "SELECT COUNT(DISTINCT NULLIF(TRIM(pk_id_predio), '')), "
                "COALESCE(SUM(tiene_excepcion), 0) "
                "FROM result_rows WHERE rule_id = ?",
                (normalized_rule_id,),
            ).fetchone()
            self._connection.commit()
            return RuleWriteResult(
                raw_total=raw_total,
                stored_total=stored_total,
                filtered_out=raw_total - stored_total,
                predios=int(metrics[0] or 0),
                exceptions=int(metrics[1] or 0),
                peak_buffered_rows=peak_buffered,
            )
        except Exception:
            self._connection.rollback()
            raise
        finally:
            close = getattr(iterator, "close", None)
            if callable(close):
                close()

    @staticmethod
    def _validated_page_size(page_size: int) -> int:
        size = int(page_size)
        if size < 1 or size > MAX_PAGE_SIZE:
            raise ValueError(
                "page_size debe estar entre 1 y {0}.".format(MAX_PAGE_SIZE)
            )
        return size

    @staticmethod
    def _where(rule_id: str | None, search: str | None) -> tuple[str, list[Any]]:
        clauses = []
        parameters: list[Any] = []
        if rule_id:
            clauses.append("rule_id = ?")
            parameters.append(str(rule_id))
        if search:
            clauses.append("search_text LIKE ? ESCAPE '\\'")
            escaped = (
                str(search)
                .casefold()
                .replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_")
            )
            parameters.append("%" + escaped + "%")
        return (" WHERE " + " AND ".join(clauses) if clauses else "", parameters)

    def count(self, *, rule_id: str | None = None, search: str | None = None) -> int:
        where, parameters = self._where(rule_id, search)
        row = self._connection.execute(
            "SELECT COUNT(*) FROM result_rows" + where, parameters
        ).fetchone()
        return int(row[0])

    def page(
        self,
        page_number: int,
        *,
        page_size: int = DEFAULT_PAGE_SIZE,
        rule_id: str | None = None,
        search: str | None = None,
    ) -> list[dict[str, Any]]:
        size = self._validated_page_size(page_size)
        number = max(int(page_number), 0)
        where, parameters = self._where(rule_id, search)
        records = self._connection.execute(
            "SELECT payload_json FROM result_rows"
            + where
            + " ORDER BY sequence LIMIT ? OFFSET ?",
            [*parameters, size, number * size],
        ).fetchall()
        return [json.loads(str(record[0])) for record in records]

    def iter_rows(
        self,
        *,
        rule_id: str | None = None,
        search: str | None = None,
        fetch_size: int = WRITE_BATCH_SIZE,
    ) -> Iterator[dict[str, Any]]:
        size = self._validated_page_size(fetch_size)
        where, parameters = self._where(rule_id, search)
        cursor = self._connection.execute(
            "SELECT payload_json FROM result_rows" + where + " ORDER BY sequence",
            parameters,
        )
        while True:
            records = cursor.fetchmany(size)
            if not records:
                break
            for record in records:
                yield json.loads(str(record[0]))

    def iter_pages(
        self,
        *,
        rule_id: str | None = None,
        search: str | None = None,
        page_size: int = DEFAULT_PAGE_SIZE,
    ) -> Iterator[list[dict[str, Any]]]:
        size = self._validated_page_size(page_size)
        page_number = 0
        while True:
            rows = self.page(
                page_number,
                page_size=size,
                rule_id=rule_id,
                search=search,
            )
            if not rows:
                break
            yield rows
            page_number += 1

    def rule_ids(self) -> list[str]:
        return [
            str(row[0])
            for row in self._connection.execute(
                "SELECT rule_id FROM result_rows GROUP BY rule_id ORDER BY MIN(sequence)"
            )
        ]

    def rule_counts(self) -> dict[str, int]:
        return {
            str(row[0]): int(row[1])
            for row in self._connection.execute(
                "SELECT rule_id, COUNT(*) FROM result_rows "
                "GROUP BY rule_id ORDER BY MIN(sequence)"
            )
        }

    def reco_allowed_count(self) -> int:
        row = self._connection.execute(
            "SELECT COUNT(*) FROM reco_allowed_predio"
        ).fetchone()
        return int(row[0])

    def __enter__(self) -> "ResultStore":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.close()
