"""Portable PH matrix photo, visit, novelty and history relations."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,raise_if_cancelled,sqlite_staging

@dataclass(frozen=True)
class Rule:
 canonical_id:str;component:str;description:str;mode:str;custom_7:bool=False
RULES={
 "PH_05":Rule("PH_05","PH","Predios PH Matriz con cambio fisico y sin foto croquis","photo"),
 "PH_06":Rule("PH_06","PH","Predios PH Matriz nuevos sin novedad de desenglobe o englobe","novelty"),
 "PH_07":Rule("PH_07","PH","Predios PH Matriz con mas de 10 de unidades prediales sin contacto de visita o sin resultado de visita","visit"),
 "PH_10":Rule("PH_10","Juridico","Predios PH iniciales no existentes en la base de datos","history"),
}
GF=("pk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_predio_cancelado","predio_tiene_cambio_fisico","ph_predio_matriz_menor_10_unidades","numero_predial_nacional_anterior","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,registration,destination_key TEXT,area,cancelled,physical,small,previous_number,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE aux(row_token INTEGER PRIMARY KEY,key_token TEXT,value,key2 TEXT);CREATE TABLE prior(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,error_pk,enrichment_key TEXT,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _gen(source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,npn,registration,destination_key,area,cancelled,physical,small,previous_number,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),r.get("juridico_predio_cancelado"),r.get("predio_tiene_cambio_fisico"),r.get("ph_predio_matriz_menor_10_unidades"),r.get("numero_predial_nacional_anterior"),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
def _ph(source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
def _ingest(definition,source,mapping,db,cancel):
 _gen(source,mapping,db,cancel)
 if definition.mode in("novelty","visit","history"):_ph(source,mapping,db,cancel)
 if definition.mode=="photo":
  with BatchInserter(db,"INSERT INTO aux(key_token,value)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_fotos_predio"),("fk_id","tipo_foto")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("fk_id")),r.get("tipo_foto")))
 elif definition.mode=="novelty":
  types={_join_token(r.get("itfcode")):r.get("ilicode") for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial_tipo"),("itfcode","ilicode"))}
  with BatchInserter(db,"INSERT INTO aux(key_token,value)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"),("pk_id","fk_id","tipo_novedad")):
    raise_if_cancelled(cancel);label=types.get(_join_token(r.get("tipo_novedad")))
    if label is not None and "englobe" in str(label).lower():ins.add((_join_token(r.get("fk_id")),r.get("pk_id")))
 elif definition.mode=="visit":
  with BatchInserter(db,"INSERT INTO aux(key_token,value)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_vis_contactovisita"),("pk_id","fk_id","resultado_visita")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("fk_id")),r.get("resultado_visita")))
 else:
  with BatchInserter(db,"INSERT INTO prior(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_ph_predio_anterior"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
def _prepare(definition,db):
 pre="INSERT INTO selected(general_pk,error_pk,enrichment_key,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)";states="g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c"
 if definition.mode=="photo":q=f"SELECT g.pk_id,g.pk_id,g.pk_key,g.npn,g.project,g.registration,g.destination_key,g.area,{states} FROM gen g WHERE substr(g.npn,22,1)='9'AND(g.cancelled IS NULL OR g.cancelled=0)AND g.physical=1 AND NOT EXISTS(SELECT 1 FROM aux a WHERE a.key_token=g.pk_key AND a.value=0)"
 elif definition.mode=="novelty":q=f"SELECT g.pk_id,p.pk_id,p.pk_key,g.npn,g.project,g.registration,g.destination_key,g.area,{states} FROM gen g JOIN ph p ON p.parent_key=g.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND g.previous_number IS NULL AND substr(p.npn,22,1)='9'AND NOT EXISTS(SELECT 1 FROM aux a WHERE a.key_token=p.pk_key) GROUP BY g.npn"
 elif definition.mode=="visit":q=f"SELECT g.pk_id,p.pk_id,p.pk_key,g.npn,g.project,g.registration,g.destination_key,g.area,{states} FROM gen g JOIN ph p ON p.parent_key=g.pk_key LEFT JOIN aux a ON a.key_token=p.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND(g.small IS NULL OR g.small=0)AND(a.row_token IS NULL OR a.value IS NULL) GROUP BY g.npn"
 else:q=f"SELECT g.pk_id,r.pk_id,g.pk_key,r.npn,g.project,r.registration,r.destination_key,r.area,{states} FROM prior r LEFT JOIN ph p ON p.pk_key=r.pk_key LEFT JOIN gen g ON g.pk_key=r.parent_key WHERE p.pk_id IS NULL"
 db.execute(pre+q)
RESULT="""SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.error_pk FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.enrichment_key LEFT JOIN user_assignment ua ON ua.fk_token=s.enrichment_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c ORDER BY s.npn IS NULL,s.npn,s.general_pk IS NULL,s.general_pk"""
def execute_relations(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(definition,source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]="LC_PH_Predio"if rid=="PH_10"else"LC_Gen_Predio";row["pk_tabla_error_1"]=v[17]if rid=="PH_10"else v[0];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_relations(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_05=_entry("PH_05");execute_ph_06=_entry("PH_06");execute_ph_07=_entry("PH_07");execute_ph_10=_entry("PH_10")
