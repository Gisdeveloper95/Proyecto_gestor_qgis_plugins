"""Independent portable implementation of the canonical Jur_16 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    numero = row.get("numero_predial_nacional")
    condicion = row.get("condicion_predio")
    return (
        postgres_substring(numero, 22, 1) == "8"
        and numero is not None
        and str(numero)[-4:] == "0000"
        and condicion is not None
        and condicion != 3
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_16",
    component="Juridico",
    description=(
        "Predios Condominio Unidad Predial con codificacion igual a 0000 "
        "en las posiciones 27 a 30"
    ),
    predicate=_matches,
    custom_7=True,
    filter_fields=("condicion_predio",),
)


def execute_jur_16(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_16 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
