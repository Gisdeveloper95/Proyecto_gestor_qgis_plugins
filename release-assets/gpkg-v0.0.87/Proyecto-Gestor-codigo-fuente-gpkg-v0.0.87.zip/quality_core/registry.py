"""Rule registry backed by SQL files and a JSON manifest."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class QualityRule:
    id: str
    family: str
    component: str
    title: str
    sql_path: Path
    result_type: str
    enabled: bool = True

    def load_sql(self) -> str:
        return self.sql_path.read_text(encoding="utf-8")


class RuleRegistry:
    """Loads rule metadata and gives stable access by rule id."""

    def __init__(self, rules_root: str | Path | None = None):
        if rules_root is None:
            rules_root = Path(__file__).resolve().parent / "rules"
        self.rules_root = Path(rules_root)
        self.manifest_path = self.rules_root / "manifest.json"
        self._rules = self._load_rules()

    def _load_rules(self) -> dict[str, QualityRule]:
        data = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        rules: dict[str, QualityRule] = {}
        for item in data["rules"]:
            rule = QualityRule(
                id=item["id"],
                family=item["family"],
                component=item.get("component", ""),
                title=item.get("title", ""),
                sql_path=self.rules_root / item["sql"],
                result_type=item.get("result_type", "alfanumerica"),
                enabled=bool(item.get("enabled", True)),
            )
            rules[rule.id.upper()] = rule
        return rules

    def get(self, rule_id: str) -> QualityRule:
        return self._rules[rule_id.upper()]

    def all(self, *, enabled_only: bool = True) -> list[QualityRule]:
        rules = list(self._rules.values())
        if enabled_only:
            rules = [rule for rule in rules if rule.enabled]
        return sorted(rules, key=lambda rule: self._sort_key(rule.id))

    def list(
        self,
        *,
        family: str | None = None,
        result_type: str | None = None,
        enabled_only: bool = True,
    ) -> list[QualityRule]:
        rules: Iterable[QualityRule] = self.all(enabled_only=enabled_only)
        if family and family != "*":
            rules = [rule for rule in rules if rule.family.lower() == family.lower()]
        if result_type:
            rules = [rule for rule in rules if rule.result_type.lower() == result_type.lower()]
        return list(rules)

    def as_sql_dict(self, *, family: str | None = None) -> dict[str, str]:
        return {rule.id: rule.load_sql() for rule in self.list(family=family)}

    def families(self) -> list[str]:
        return sorted({rule.family for rule in self._rules.values()})

    @staticmethod
    def _sort_key(rule_id: str) -> tuple[str, int, str]:
        prefix, _, suffix = rule_id.partition("_")
        if suffix.isdigit():
            return prefix, int(suffix), rule_id
        return prefix, 999999, rule_id
