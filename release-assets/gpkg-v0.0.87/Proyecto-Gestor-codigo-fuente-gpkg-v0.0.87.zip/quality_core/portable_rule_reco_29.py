"""Independent portable implementation of canonical Reco_29."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_29", "Calificacion",
    "Caracteristica Unidad de Construccion sin uso de construccion",
    "c.uso_construccion IS NULL", True,
    use_output="null", join_use_lookup=False,
)

def execute_reco_29(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
