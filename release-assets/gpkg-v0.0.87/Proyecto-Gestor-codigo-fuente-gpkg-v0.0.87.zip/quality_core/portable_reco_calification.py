"""Disk-backed engine for the remaining non-spatial RECO calification rules."""

from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

from .portable_construction_scalar import (
    _CONSTRUCTION_BASE_FIELDS,
    _create_stage,
    _ingest_enrichment,
    _ingest_predios,
    _join_token,
    _result_row,
)
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging


_CHARACTERISTIC_FIELDS = (
    "pk_id", "fk_id", "uso_residencial", "uso_comercial", "uso_industrial",
    "uso_institucional", "uso_anexo", "uso_anterior", "puntaje_anterior",
)
_COMMON_NEGATIVE = (
    "armazon", "muros", "cubierta", "conservacion_cubierta", "fachada",
    "cubrimiento_muros", "piso", "conservacion_acabados",
    "mobiliario_banio", "mobiliario_cocina",
)
_RESIDENTIAL_EXTRA = (
    "tamanio_banio", "enchape_banio", "conservacion_banio",
    "tamanio_cocina", "enchape_cocina", "conservacion_cocina",
)
_CAL_TABLES = (
    ("commercial", "lc_reco_cal_calificacioncomercial", "LC_Reco_Cal_CalificacionComercial", _COMMON_NEGATIVE),
    ("industrial", "lc_reco_cal_calificacionindustrial", "LC_Reco_Cal_CalificacionIndustrial", _COMMON_NEGATIVE + ("cerchas_complemento_industria",)),
    ("nonconventional", "lc_reco_cal_calificacionnoconvencional", "LC_Reco_Cal_CalificacionNoConvencional", ()),
    ("residential", "lc_reco_cal_calificacionresidencial", "LC_Reco_Cal_CalificacionResidencial", _COMMON_NEGATIVE + _RESIDENTIAL_EXTRA),
)
_DESCRIPTIONS = {
    "Reco_26": "Caracteristica Unidad de Construccion con el tipo de unidad de construccion diferente a la calificacion asignada",
    "Reco_28": "Caracteristica Unidad de Construccion con multiples usos",
    "Reco_38": "Caracteristica Unidad de Construccion nuevas sin calificacion asociada",
    "Reco_39": "Caracteristica Unidad de Construccion con multiples calificaciones",
    "Reco_41": "Caracteristica Unidad de Construccion con al menos un elemento de la calificacion en valores negativos, es decir, \nerrores en el detalle de la calificacion",
    "Reco_42": "Caracteristica Unidad de Construccion con puntaje anterior mayor 5 puntos comparado con el puntaje nuevo",
    "Reco_43": "Caracteristica Unidad de Construccion con puntaje anterior menor 5 puntos comparado con el puntaje nuevo",
    "Reco_44": "Caracteristica Unidad de Construccion con puntajes de calificaciones anexas diferentes a los definidos \nen el estudio economico",
}


def _extend_stage(db):
    db.executescript("""
      ALTER TABLE construction ADD COLUMN pk_carac_key TEXT;
      ALTER TABLE construction ADD COLUMN uso_anterior;
      ALTER TABLE selected ADD COLUMN table_error_2;
      ALTER TABLE selected ADD COLUMN cal_pk;
      CREATE TABLE characteristic(row_token INTEGER PRIMARY KEY,pk_key TEXT,predio_key TEXT,
        usage_residential,usage_commercial,usage_industrial,usage_institutional,usage_annex,
        previous_use,previous_score,multiple_usage INTEGER);
      CREATE TABLE calification(row_token INTEGER PRIMARY KEY,kind TEXT,table_name TEXT,pk_id,
        pk_key TEXT,fk_key TEXT,fid,total_score,type_annex_key TEXT,negative INTEGER);
      CREATE TABLE annex_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode,score INTEGER);
      CREATE TABLE construction_value(row_token INTEGER PRIMARY KEY,use_text TEXT,score);
    """)


def _ingest_constructions(data_source, layer_mapping, db, cancel_check):
    fields = (*_CONSTRUCTION_BASE_FIELDS, "uso_anterior")
    sql = "INSERT INTO construction(predio_key,pk_carac,identificador,total_plantas,type_key,use_key,uso_construccion,area_construida,puntaje,puntaje_masivo,anio_construccion,estado_conservacion,pk_carac_key,uso_anterior) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    with BatchInserter(db, sql, cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("determinacion_area_construccion"), fields):
            raise_if_cancelled(cancel_check)
            ins.add((_join_token(r.get("pk_id")),r.get("pk_carac"),r.get("identificador"),r.get("total_plantas"),_join_token(r.get("tipo_unidad_construccion")),_join_token(r.get("uso_construccion")),r.get("uso_construccion"),r.get("area_construida"),r.get("puntaje"),r.get("puntaje_masivo"),r.get("anio_construccion"),r.get("estado_conservacion"),_join_token(r.get("pk_carac")),r.get("uso_anterior")))


def _ingest_characteristics(data_source, layer_mapping, db, cancel_check):
    sql="INSERT INTO characteristic(pk_key,predio_key,usage_residential,usage_commercial,usage_industrial,usage_institutional,usage_annex,previous_use,previous_score,multiple_usage) VALUES (?,?,?,?,?,?,?,?,?,?)"
    with BatchInserter(db,sql,cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_reco_caracteristicasunidadconstruccion"),_CHARACTERISTIC_FIELDS):
            raise_if_cancelled(cancel_check)
            uses=[r.get(n) for n in ("uso_residencial","uso_comercial","uso_industrial","uso_institucional","uso_anexo")]
            distinct={_join_token(v) for v in uses if v is not None}
            ins.add((_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),*uses,r.get("uso_anterior"),r.get("puntaje_anterior"),int(len(distinct)>1)))


def _ingest_califications(data_source, layer_mapping, db, cancel_check):
    sql="INSERT INTO calification(kind,table_name,pk_id,pk_key,fk_key,fid,total_score,type_annex_key,negative) VALUES (?,?,?,?,?,?,?,?,?)"
    with BatchInserter(db,sql,cancel_check=cancel_check) as ins:
        for kind,logical,table_name,negative_fields in _CAL_TABLES:
            specific = ("tipo_anexo",) if kind == "nonconventional" else ("total_calificacion",)
            fields=("pk_id","fk_id","fid",*specific,*negative_fields)
            for r in data_source.iter_rows(layer_mapping.resolve(logical),fields):
                raise_if_cancelled(cancel_check)
                negative=any(r.get(field)==-1 for field in negative_fields)
                ins.add((kind,table_name,r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("fid"),r.get("total_calificacion"),_join_token(r.get("tipo_anexo")),int(negative)))

    with BatchInserter(db,"INSERT INTO annex_lookup(key_token,ilicode,score) VALUES (?,?,?)",cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_reco_cal_anexo_tipo"),("itfcode","ilicode")):
            raise_if_cancelled(cancel_check); code=r.get("ilicode"); score=None
            if code is not None:
                try: score=int(str(code).split("_",1)[1])
                except (ValueError,IndexError): score=None
            ins.add((_join_token(r.get("itfcode")),code,score))
    with BatchInserter(db,"INSERT INTO construction_value(use_text,score) VALUES (?,?)",cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_valoresconstruccion"),("tabla_usos_construccion","puntaje_calificacion")):
            raise_if_cancelled(cancel_check); ins.add((r.get("tabla_usos_construccion"),r.get("puntaje_calificacion")))


def _candidate_sql(rule_id):
    base="SELECT p.row_token predio_row_token,c.row_token construction_row_token,{table2} table_error_2,{calpk} cal_pk FROM predio p JOIN construction c ON c.predio_key=p.pk_key {joins} WHERE {where}"
    if rule_id=="Reco_26":
        tokens={value:_join_token(value) for value in range(5)}
        predicate=(
            f"(q.kind='commercial' AND c.type_key NOT IN ({tokens[1]!r},{tokens[3]!r})) OR "
            f"(q.kind='industrial' AND c.type_key<>{tokens[2]!r}) OR "
            f"(q.kind='residential' AND c.type_key<>{tokens[0]!r}) OR "
            f"(q.kind='nonconventional' AND c.type_key<>{tokens[4]!r})"
        )
        # The canonical SQL labels all four branches as Comercial, including
        # Industrial/Residencial/NoConvencional; preserve that observable bug.
        return base.format(table2="'LC_Reco_Cal_CalificacionComercial'",calpk="q.pk_id",joins="JOIN calification q ON q.fk_key=c.pk_carac_key",where=predicate)
    if rule_id=="Reco_28":
        return base.format(table2="NULL",calpk="NULL",joins="JOIN characteristic h ON h.pk_key=c.pk_carac_key",where="h.multiple_usage=1")
    if rule_id=="Reco_38":
        return base.format(table2="NULL",calpk="NULL",joins="",where="c.uso_anterior IS NULL AND NOT EXISTS(SELECT 1 FROM calification q WHERE q.fk_key=c.pk_carac_key AND q.fid IS NOT NULL)")
    if rule_id=="Reco_39":
        return base.format(table2="q.table_name",calpk="q.pk_id",joins="JOIN characteristic h ON h.pk_key=c.pk_carac_key JOIN calification q ON q.fk_key=h.pk_key",where="(SELECT COUNT(*) FROM calification q2 WHERE q2.fk_key=h.pk_key)>1")
    if rule_id=="Reco_41":
        return base.format(table2="q.table_name",calpk="q.pk_id",joins="JOIN calification q ON q.fk_key=c.pk_carac_key",where="q.kind IN ('commercial','industrial','residential') AND q.negative=1")
    usage="CASE q.kind WHEN 'commercial' THEN CASE WHEN h.usage_commercial IS NOT NULL THEN h.usage_commercial ELSE h.usage_institutional END WHEN 'industrial' THEN h.usage_industrial WHEN 'nonconventional' THEN h.usage_annex ELSE h.usage_residential END"
    score="CASE WHEN q.kind='nonconventional' THEN annex.score ELSE q.total_score END"
    prev="CAST(CASE WHEN INSTR(CAST(h.previous_use AS TEXT),'-')>0 THEN SUBSTR(CAST(h.previous_use AS TEXT),1,INSTR(CAST(h.previous_use AS TEXT),'-')-1) ELSE CAST(h.previous_use AS TEXT) END AS INTEGER)"
    joins="JOIN characteristic h ON h.pk_key=c.pk_carac_key JOIN calification q ON q.fk_key=h.pk_key LEFT JOIN annex_lookup annex ON annex.key_token=q.type_annex_key"
    if rule_id in {"Reco_42","Reco_43"}:
        diff=f"({score}-CAST(h.previous_score AS INTEGER))"; interval=f"{diff}>0 AND {diff}<=5" if rule_id=="Reco_42" else f"{diff}>=-5 AND {diff}<0"
        return base.format(table2="q.table_name",calpk="q.pk_id",joins=joins,where=f"({interval}) AND ({usage})={prev}")
    return base.format(table2="NULL",calpk="NULL",joins=joins,where="q.kind='nonconventional' AND c.uso_construccion>68 AND (NOT EXISTS(SELECT 1 FROM use_lookup u WHERE u.key_token=c.use_key) OR NOT EXISTS(SELECT 1 FROM construction_value v WHERE v.use_text=CAST(c.uso_construccion AS TEXT) AND v.score=annex.score))")


def _prepare_selected(rule_id,db):
    db.execute("CREATE TEMP TABLE candidate AS "+_candidate_sql(rule_id))
    db.execute("""INSERT INTO selected(predio_row_token,construction_row_token,pk_id,pk_key,numero_predial_nacional,proyecto,matricula_inmobiliaria,destinacion_economica,destination_key,area_catastral_terreno,juridico_assignment_key,juridico_control_key,reconocimiento_assignment_key,reconocimiento_control_key,informal_assignment_key,informal_control_key,geografico_assignment_key,geografico_control_key,pk_carac,identificador,total_plantas,type_key,use_key,uso_construccion,area_construida,puntaje,table_error_2,cal_pk)
      SELECT p.row_token,c.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,p.proyecto,p.matricula_inmobiliaria,p.destinacion_economica,p.destination_key,p.area_catastral_terreno,p.juridico_assignment_key,p.juridico_control_key,p.reconocimiento_assignment_key,p.reconocimiento_control_key,p.informal_assignment_key,p.informal_control_key,p.geografico_assignment_key,p.geografico_control_key,c.pk_carac,c.identificador,c.total_plantas,c.type_key,c.use_key,c.uso_construccion,c.area_construida,c.puntaje,x.table_error_2,x.cal_pk
      FROM candidate x JOIN predio p ON p.row_token=x.predio_row_token JOIN construction c ON c.row_token=x.construction_row_token""")


def _result_sql(rule_id):
    use_output="NULL" if rule_id=="Reco_28" else "uu.ilicode"
    return f"""SELECT s.pk_id,s.numero_predial_nacional,s.proyecto,s.matricula_inmobiliaria,d.ilicode,s.area_catastral_terreno,s.pk_carac,s.identificador,s.total_plantas,ut.ilicode,{use_output},s.area_construida,s.puntaje,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.table_error_2,s.cal_pk
      FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN unit_type_lookup ut ON ut.key_token=s.type_key LEFT JOIN use_lookup uu ON uu.key_token=s.use_key
      LEFT JOIN exception_lookup e ON e.fk_token=s.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=s.pk_key
      LEFT JOIN assignment_lookup ja ON ja.key_token=s.juridico_assignment_key LEFT JOIN control_lookup jc ON jc.key_token=s.juridico_control_key
      LEFT JOIN assignment_lookup ra ON ra.key_token=s.reconocimiento_assignment_key LEFT JOIN control_lookup rc ON rc.key_token=s.reconocimiento_control_key
      LEFT JOIN assignment_lookup ia ON ia.key_token=s.informal_assignment_key LEFT JOIN control_lookup ic ON ic.key_token=s.informal_control_key
      LEFT JOIN assignment_lookup ga ON ga.key_token=s.geografico_assignment_key LEFT JOIN control_lookup gc ON gc.key_token=s.geografico_control_key
      ORDER BY s.numero_predial_nacional IS NULL,s.numero_predial_nacional,s.proyecto IS NULL,s.proyecto,s.identificador IS NULL,s.identificador,s.predio_row_token,s.construction_row_token"""


def execute_calification_rule(rule_id,data_source,layer_mapping,cancel_check=None):
    definition=SimpleNamespace(canonical_id=rule_id,component="Calificacion",description=_DESCRIPTIONS[rule_id],custom_7=False,predio_filter_fields=(),construction_filter_fields=(),table_error_1="LC_Reco_Caracteristicasunidadconstruccion",table_error_1_source="construction",table_error_2=None,use_output="lookup",join_use_lookup=True,duplicate_predio_join=False)
    timestamp=datetime.now()
    with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        _create_stage(db);_extend_stage(db);_ingest_predios(definition,data_source,layer_mapping,db,cancel_check);_ingest_constructions(data_source,layer_mapping,db,cancel_check);_ingest_characteristics(data_source,layer_mapping,db,cancel_check);_ingest_califications(data_source,layer_mapping,db,cancel_check);_ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
        db.executescript("CREATE INDEX idx_predio_pk2 ON predio(pk_key);CREATE INDEX idx_construction_predio2 ON construction(predio_key);CREATE INDEX idx_construction_carac ON construction(pk_carac_key);CREATE INDEX idx_characteristic_pk2 ON characteristic(pk_key);CREATE INDEX idx_cal_fk ON calification(fk_key);CREATE INDEX idx_annex_key ON annex_lookup(key_token);CREATE INDEX idx_value_use ON construction_value(use_text,score);CREATE INDEX idx_dest2 ON destination_lookup(key_token);CREATE INDEX idx_unit2 ON unit_type_lookup(key_token);CREATE INDEX idx_use2 ON use_lookup(key_token);CREATE INDEX idx_exc2 ON exception_lookup(fk_token);CREATE INDEX idx_user2 ON user_assignment(fk_token);CREATE INDEX idx_asig2 ON assignment_lookup(key_token);CREATE INDEX idx_ctrl2 ON control_lookup(key_token);")
        _prepare_selected(rule_id,db);db.commit();cur=db.execute(_result_sql(rule_id))
        try:
            for values in cur:
                raise_if_cancelled(cancel_check);base=_result_row(definition,timestamp,values[:24]);base["tabla_error_2"]=values[24];base["pk_tabla_error_2"]=values[25];yield base
        finally:cur.close()
