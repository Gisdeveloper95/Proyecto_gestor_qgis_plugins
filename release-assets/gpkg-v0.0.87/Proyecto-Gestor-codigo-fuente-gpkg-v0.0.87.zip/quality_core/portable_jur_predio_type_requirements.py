"""Portable anti-join engine for juridical predio/right/type requirements."""
from dataclasses import dataclass
from datetime import datetime
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,postgres_boolean_is_false_or_null,raise_if_cancelled,sqlite_staging
@dataclass(frozen=True)
class Rule:
 canonical_id:str;description:str;target_type:str;formal:bool|None;mode:str;custom_7:bool=True;component:str="Juridico"
RULES={
"Jur_26":Rule("Jur_26","Predios formales de tipo baldío sin derecho de dominio, urbano, sin FMI, o Interesado diferente a la Nacion o ANT","Predio.Publico.Baldio",True,"baldio_formal"),
"Jur_27":Rule("Jur_27","Predios informales de tipo baldío sin derecho de ocupacion, urbanos, sin FMI, o Interesado igual a la Nacion o ANT","Predio.Publico.Baldio",False,"baldio_informal"),
"Jur_28":Rule("Jur_28","Predios formales de tipo fiscal patrimonial sin derecho de dominio, sin FMI, o interesado diferente a una EDP","Predio.Publico.Fiscal_Patrimonial",True,"fiscal_formal"),
"Jur_29":Rule("Jur_29","Predios informales de tipo fiscal patrimonial con derecho diferente a ocupacion","Predio.Publico.Fiscal_Patrimonial",False,"occupation"),
"Jur_30":Rule("Jur_30","Predios formales de tipo Uso Publico sin derecho de dominio, destino economico diferente a Uso Publico o Interesado diferente a una EDP","Predio.Publico.Uso_Publico",True,"public_formal"),
"Jur_31":Rule("Jur_31","Predios informales de tipo Uso Publico con derecho diferente a Ocupacion","Predio.Publico.Uso_Publico",False,"occupation"),
"Jur_32":Rule("Jur_32","Predios formales de tipo presunto baldio con o sin derecho de dominio, rural e interesado diferente a la Nacion o urbano e interesado diferente al municipio","Predio.Publico.Presunto_Baldio",True,"presumed_formal"),
"Jur_33":Rule("Jur_33","Predios informales de tipo presunto baldio con o sin derecho de ocupacion, rural e interesado igual a la nacion o urbano e interesado igual al municipio","Predio.Publico.Presunto_Baldio",False,"presumed_informal"),
"Jur_35":Rule("Jur_35","Predios con derecho Posesion de tipo diferente a Privado","",None,"possession_type"),
"Jur_36":Rule("Jur_36","Predios con derecho Ocupacion de tipo diferente a Baldío, Presunto Baldio, Fiscal_Patrimonial o Uso Publico","",None,"occupation_type"),}
_PF=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","tipo_predio","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
def _create(db):db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,proyecto,matricula,destination_key TEXT,area,predio_type_key TEXT,jur_asig TEXT,jur_ctrl TEXT,reco_asig TEXT,reco_ctrl TEXT,info_asig TEXT,info_ctrl TEXT,geo_asig TEXT,geo_ctrl TEXT);CREATE TABLE ptype(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,fk_key TEXT,type_key TEXT);CREATE TABLE rtype(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE interesado(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,nombre);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,predio_row INTEGER,pk_id,pk_key TEXT,npn,proyecto,matricula,destination_key TEXT,area,jur_asig TEXT,jur_ctrl TEXT,reco_asig TEXT,reco_ctrl TEXT,info_asig TEXT,info_ctrl TEXT,geo_asig TEXT,geo_ctrl TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(data_source,m,db,cancel):
 with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,proyecto,matricula,destination_key,area,predio_type_key,jur_asig,jur_ctrl,reco_asig,reco_ctrl,info_asig,info_ctrl,geo_asig,geo_ctrl)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in data_source.iter_rows(m.resolve("lc_gen_predio"),_PF):
   raise_if_cancelled(cancel)
   if not postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado")):continue
   ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("tipo_predio")),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 for logical,table in (("lc_gen_predio_tipo","ptype"),("lc_jur_derecho_tipo","rtype")):
  with BatchInserter(db,f"INSERT INTO {table}(key_token,ilicode)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in data_source.iter_rows(m.resolve(logical),("itfcode","ilicode")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
 with BatchInserter(db,"INSERT INTO derecho(pk_id,pk_key,fk_key,type_key)VALUES(?,?,?,?)",cancel_check=cancel)as ins:
  for r in data_source.iter_rows(m.resolve("lc_jur_derecho"),("pk_id","fk_id","tipo_derecho")):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),_join_token(r.get("tipo_derecho"))))
 with BatchInserter(db,"INSERT INTO interesado(pk_id,fk_key,nombre)VALUES(?,?,?)",cancel_check=cancel)as ins:
  for r in data_source.iter_rows(m.resolve("lc_jur_interesado"),("pk_id","fk_id","nombre_completo_propietario")):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),r.get("nombre_completo_propietario")))
def _prepare(rule,db):
 base="SELECT p.row_token,p.pk_id,p.pk_key,p.npn,p.proyecto,p.matricula,p.destination_key,p.area,p.jur_asig,p.jur_ctrl,p.reco_asig,p.reco_ctrl,p.info_asig,p.info_ctrl,p.geo_asig,p.geo_ctrl FROM predio p "
 if rule.mode in{"possession_type","occupation_type"}:
  right="Posesion"if rule.mode=="possession_type"else"Ocupacion";allowed="('Predio.Privado')"if rule.mode=="possession_type"else"('Predio.Publico.Baldio','Predio.Publico.Fiscal_Patrimonial','Predio.Publico.Uso_Publico','Predio.Publico.Presunto_Baldio')";tail=f"JOIN derecho r ON r.fk_key=p.pk_key JOIN rtype rt ON rt.key_token=r.type_key AND rt.ilicode='{right}' WHERE NOT EXISTS(SELECT 1 FROM ptype pt WHERE pt.key_token=p.predio_type_key AND pt.ilicode IN {allowed})"
 else:
  pos="substr(p.npn,22,1)<>'2'"if rule.formal else"substr(p.npn,22,1)='2'";prefix=f"JOIN ptype pt ON pt.key_token=p.predio_type_key AND pt.ilicode='{rule.target_type}' WHERE {pos} AND NOT EXISTS(";joins="SELECT 1 FROM derecho r JOIN rtype rt ON rt.key_token=r.type_key ";end=" AND r.fk_key=p.pk_key)"
  if rule.mode=="occupation":cond="rt.ilicode='Ocupacion'"
  else:
   joins+="JOIN interesado i ON i.fk_key=r.pk_key "; n="lower(i.nombre)"
   if rule.mode=="baldio_formal":cond=f"rt.ilicode='Dominio' AND substr(p.npn,6,2)='00' AND p.matricula IS NOT NULL AND ({n} LIKE '%la nacion%' OR {n} LIKE '%agencia nacional de tierras%' OR {n} LIKE '%ant%')"
   elif rule.mode=="baldio_informal":cond=f"rt.ilicode='Ocupacion' AND substr(p.npn,6,2)='00' AND {n} NOT LIKE '%la nacion%' AND {n} NOT LIKE '%agencia nacional de tierras%' AND {n} NOT LIKE '%ant%'"
   elif rule.mode=="fiscal_formal":cond=f"rt.ilicode='Dominio' AND p.matricula IS NOT NULL AND ({n} LIKE '%municipio%' OR {n} LIKE '%alcaldia%' OR {n} LIKE '%gobernacion%' OR {n} LIKE '%nacion%')"
   elif rule.mode=="public_formal":cond=f"rt.ilicode='Dominio' AND EXISTS(SELECT 1 FROM destination_lookup dx WHERE dx.key_token=p.destination_key AND dx.ilicode NOT IN('Uso_Publico')) AND ({n} LIKE '%municipio%' OR {n} LIKE '%alcaldia%' OR {n} LIKE '%gobernacion%' OR {n} LIKE '%nacion%')"
   elif rule.mode=="presumed_formal":cond=f"rt.ilicode='Dominio' AND ((substr(p.npn,6,2)='00' AND {n} LIKE '%la nacion%') OR (substr(p.npn,6,2)<>'00' AND {n} LIKE '%municipio%'))"
   elif rule.mode=="presumed_informal":cond=f"rt.ilicode='Ocupacion' AND ((substr(p.npn,6,2)='00' AND {n} NOT LIKE '%la nacion%') OR (substr(p.npn,6,2)<>'00' AND {n} NOT LIKE '%municipio%'))"
  tail=prefix+joins+"WHERE "+cond+end
 db.execute("INSERT INTO selected(predio_row,pk_id,pk_key,npn,proyecto,matricula,destination_key,area,jur_asig,jur_ctrl,reco_asig,reco_ctrl,info_asig,info_ctrl,geo_asig,geo_ctrl) "+base+tail)
_RESULT="""SELECT s.pk_id,s.npn,s.proyecto,s.matricula,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=s.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_asig LEFT JOIN control_lookup jc ON jc.key_token=s.jur_ctrl LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_asig LEFT JOIN control_lookup rc ON rc.key_token=s.reco_ctrl LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_asig LEFT JOIN control_lookup ic ON ic.key_token=s.info_ctrl LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_asig LEFT JOIN control_lookup gc ON gc.key_token=s.geo_ctrl"""
def execute_requirement(rid,data_source,m,cancel_check=None):
 rule=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(data_source,m,db,cancel_check);_ingest_enrichment(rule,data_source,m,db,cancel_check);_prepare(rule,db);db.commit();cur=db.execute(_RESULT)
  try:
   for v in cur:raise_if_cancelled(cancel_check);yield _result_row(rule,stamp,v)
  finally:cur.close()
def _e(rid):
 def execute(data_source,layer_mapping,cancel_check=None):return execute_requirement(rid,data_source,layer_mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_jur_26=_e("Jur_26");execute_jur_27=_e("Jur_27");execute_jur_28=_e("Jur_28");execute_jur_29=_e("Jur_29");execute_jur_30=_e("Jur_30");execute_jur_31=_e("Jur_31");execute_jur_32=_e("Jur_32");execute_jur_33=_e("Jur_33");execute_jur_35=_e("Jur_35");execute_jur_36=_e("Jur_36")
