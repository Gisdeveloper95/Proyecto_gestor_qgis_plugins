"""Disk-backed portable engine for scalar PH novelty rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging


@dataclass(frozen=True)
class PHNovedadRule:
    canonical_id: str
    component: str
    description: str
    predicate_sql: str
    table_error_2: str = "LC_PH_NovedadNumeroPredial"
    custom_7: bool = False


RULES = {
    "PH_55": PHNovedadRule(
        "PH_55",
        "Novedad_Desenglobe_Division_Material",
        "Predios con numero predial igual al numero predial de la novedad",
        "t.ilicode = 'Desenglobe_Division_Material' AND g.npn = n.reference_number",
    ),
    "PH_57": PHNovedadRule(
        "PH_57",
        "Cancelacion",
        "Predios con numero predial diferente al relacionado en la novedad",
        "lower(t.ilicode) LIKE 'cancelacion%' AND p.npn <> n.reference_number",
    ),
    "PH_59": PHNovedadRule(
        "PH_59",
        "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de numero predial con numero predial anterior diferente al de la novedad",
        "lower(t.ilicode) LIKE 'cambio%' AND p.previous_npn <> n.reference_number",
    ),
    # The canonical SQL says "igual" in its description but deliberately uses <>.
    "PH_60": PHNovedadRule(
        "PH_60",
        "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de numero predial con numero predial de la novedad igual al numero predial nacional",
        "lower(t.ilicode) LIKE 'cambio%' AND p.npn <> n.reference_number",
    ),
    "PH_61": PHNovedadRule(
        "PH_61",
        "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de Condominio a PH, PH a PH o de NPH a PH donde la posicion 22 del numero predial es diferente a 9",
        "t.ilicode IN ('Cambio_PH_PH','Cambio_Condominio_PH','Cambio_NPH_PH') AND substr(p.npn,22,1) <> '9'",
    ),
    "PH_62": PHNovedadRule(
        "PH_62",
        "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de urbano a rural donde la posicion 7 es igual a 1",
        "t.ilicode = 'Cambio_Urbano_Rural' AND substr(p.npn,7,1) = '1'",
    ),
    # LC_Jur_NovedadNumeroPredial is the literal emitted by canonical PH_63.
    "PH_63": PHNovedadRule(
        "PH_63",
        "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de rural a urbano donde la posicion 7 es diferente a 1",
        "t.ilicode = 'Cambio_Rural_Urbano' AND substr(p.npn,7,1) <> '1'",
        "LC_Jur_NovedadNumeroPredial",
    ),
}


_GENERAL_FIELDS = (
    "pk_id", "numero_predial_nacional", "nombre_proyecto",
    "juridico_estado_asignacion", "juridico_estado_control",
    "reconocimiento_estado_asignacion", "reconocimiento_estado_control",
    "informal_estado_asignacion", "informal_estado_control",
    "geografico_estado_asignacion", "geografico_estado_control",
)
_PH_FIELDS = (
    "pk_id", "fk_id", "numero_predial_nacional",
    "numero_predial_nacional_anterior", "matricula_inmobiliaria",
    "destinacion_economica", "area_catastral_terreno",
)


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE general_predio(
          row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,project,
          jur_assignment TEXT,jur_control TEXT,reco_assignment TEXT,reco_control TEXT,
          info_assignment TEXT,info_control TEXT,geo_assignment TEXT,geo_control TEXT);
        CREATE TABLE ph_predio(
          row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,
          previous_npn,registration,destination_key TEXT,area);
        CREATE TABLE novelty(
          row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,type_key TEXT,reference_number);
        CREATE TABLE novelty_type(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE selected(
          row_token INTEGER PRIMARY KEY,general_row INTEGER,ph_row INTEGER,
          novelty_row INTEGER,general_pk,ph_pk,ph_key TEXT,novelty_pk,npn,project,
          registration,destination_key TEXT,area,jur_assignment TEXT,jur_control TEXT,
          reco_assignment TEXT,reco_control TEXT,info_assignment TEXT,info_control TEXT,
          geo_assignment TEXT,geo_control TEXT,novelty_type,reference_number);
        CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
        CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
        CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        """
    )


def _ingest(source, mapping, db, cancel_check) -> None:
    sql = """INSERT INTO general_predio(
      pk_id,pk_key,npn,project,jur_assignment,jur_control,reco_assignment,reco_control,
      info_assignment,info_control,geo_assignment,geo_control)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?)"""
    with BatchInserter(db, sql, cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_gen_predio"), _GENERAL_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                row.get("numero_predial_nacional"), row.get("nombre_proyecto"),
                _join_token(row.get("juridico_estado_asignacion")),
                _join_token(row.get("juridico_estado_control")),
                _join_token(row.get("reconocimiento_estado_asignacion")),
                _join_token(row.get("reconocimiento_estado_control")),
                _join_token(row.get("informal_estado_asignacion")),
                _join_token(row.get("informal_estado_control")),
                _join_token(row.get("geografico_estado_asignacion")),
                _join_token(row.get("geografico_estado_control")),
            ))
    with BatchInserter(
        db,
        "INSERT INTO ph_predio(pk_id,pk_key,parent_key,npn,previous_npn,registration,destination_key,area) VALUES(?,?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_ph_predio"), _PH_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                _join_token(row.get("fk_id")), row.get("numero_predial_nacional"),
                row.get("numero_predial_nacional_anterior"),
                row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),
                row.get("area_catastral_terreno"),
            ))
    with BatchInserter(
        db,
        "INSERT INTO novelty(pk_id,fk_key,type_key,reference_number) VALUES(?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in source.iter_rows(
            mapping.resolve("lc_ph_novedadnumeropredial"),
            ("pk_id", "fk_id", "tipo_novedad", "numero_predial_nacional_novedad"),
        ):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("fk_id")),
                _join_token(row.get("tipo_novedad")),
                row.get("numero_predial_nacional_novedad"),
            ))
    with BatchInserter(
        db,
        "INSERT INTO novelty_type(key_token,ilicode) VALUES(?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in source.iter_rows(
            mapping.resolve("lc_jur_novedadnumeropredial_tipo"), ("itfcode", "ilicode")
        ):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("itfcode")), row.get("ilicode")))


def _prepare(definition: PHNovedadRule, db) -> None:
    db.execute(
        """INSERT INTO selected(
          general_row,ph_row,novelty_row,general_pk,ph_pk,ph_key,novelty_pk,npn,
          project,registration,destination_key,area,jur_assignment,jur_control,
          reco_assignment,reco_control,info_assignment,info_control,geo_assignment,
          geo_control,novelty_type,reference_number)
          SELECT g.row_token,p.row_token,n.row_token,g.pk_id,p.pk_id,p.pk_key,n.pk_id,
          p.npn,g.project,p.registration,p.destination_key,p.area,g.jur_assignment,
          g.jur_control,g.reco_assignment,g.reco_control,g.info_assignment,g.info_control,
          g.geo_assignment,g.geo_control,t.ilicode,n.reference_number
          FROM general_predio g JOIN ph_predio p ON p.parent_key=g.pk_key
          JOIN novelty n ON n.fk_key=p.pk_key
          JOIN novelty_type t ON t.key_token=n.type_key
          WHERE """ + definition.predicate_sql
    )


_RESULT_SQL = """SELECT DISTINCT
  s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,
  e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,
  ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.novelty_pk,
  s.novelty_type,s.reference_number
  FROM selected s
  LEFT JOIN destination_lookup d ON d.key_token=s.destination_key
  LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key
  LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key
  LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_assignment
  LEFT JOIN control_lookup jc ON jc.key_token=s.jur_control
  LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_assignment
  LEFT JOIN control_lookup rc ON rc.key_token=s.reco_control
  LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_assignment
  LEFT JOIN control_lookup ic ON ic.key_token=s.info_control
  LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_assignment
  LEFT JOIN control_lookup gc ON gc.key_token=s.geo_control
  ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project"""


def execute_ph_novedad_scalar(
    rule_id: str, source, mapping, cancel_check=None
) -> Iterator[dict[str, Any]]:
    definition = RULES[rule_id]
    timestamp = datetime.now()
    with sqlite_staging(
        cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-"
    ) as db:
        _create_stage(db)
        _ingest(source, mapping, db, cancel_check)
        _ingest_enrichment(definition, source, mapping, db, cancel_check)
        _prepare(definition, db)
        db.commit()
        cursor = db.execute(_RESULT_SQL)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                row = _result_row(definition, timestamp, values[:17])
                row["tabla_error_1"] = "LC_PH_Predio"
                row["pk_tabla_error_1"] = values[17]
                row["tabla_error_2"] = definition.table_error_2
                row["pk_tabla_error_2"] = values[18]
                row["tipo_novedad"] = values[19]
                row["numero_predial_nacional_novedad"] = values[20]
                yield row
        finally:
            cursor.close()


def _entrypoint(rule_id: str):
    def execute(source, mapping, cancel_check=None):
        return execute_ph_novedad_scalar(rule_id, source, mapping, cancel_check)

    execute.__name__ = f"execute_{rule_id.lower()}"
    return execute


execute_ph_55 = _entrypoint("PH_55")
execute_ph_57 = _entrypoint("PH_57")
execute_ph_59 = _entrypoint("PH_59")
execute_ph_60 = _entrypoint("PH_60")
execute_ph_61 = _entrypoint("PH_61")
execute_ph_62 = _entrypoint("PH_62")
execute_ph_63 = _entrypoint("PH_63")
