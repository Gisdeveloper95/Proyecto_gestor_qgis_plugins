"""Portable owner classification shared by canonical Reco_56 and Reco_57."""

from datetime import datetime
import json
from functools import lru_cache
from pathlib import Path
import re
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_boolean_is_false_or_null, raise_if_cancelled, sqlite_staging


_PREDIO_FIELDS=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
_DESCRIPTIONS={"Reco_56":"Predios con destino economico conservacion y proteccion ambiental e institucional con propietarios privados","Reco_57":"Predios con destino economico habitacional con propietarios publicos"}


def _like_regex(pattern):
    pieces=[];index=0
    while index<len(pattern):
        char=pattern[index]
        if char=="\\" and index+1<len(pattern):index+=1;pieces.append(re.escape(pattern[index]))
        elif char=="%":pieces.append(".*")
        elif char=="_":pieces.append(".")
        else:pieces.append(re.escape(char))
        index+=1
    return re.compile("^"+"".join(pieces)+"$",re.IGNORECASE|re.DOTALL)


def _compile_ast(node):
    operator=node[0]
    if operator=="ilike":return(operator,_like_regex(node[1]))
    if operator=="eq":return(operator,node[1])
    return(operator,*(_compile_ast(child) for child in node[1:]))


@lru_cache(maxsize=1)
def _public_predicate():
    path=Path(__file__).resolve().parent/"specs"/"ph_76_public_name_predicate.json"
    payload=json.loads(path.read_text(encoding="utf-8"))
    if payload.get("format")!="mapingtool.ph76-public-name-ast.v1":raise RuntimeError("Unsupported public-entity name specification")
    return _compile_ast(payload["ast"])


def _matches(node,value):
    operator=node[0]
    if operator=="ilike":return node[1].match(value)is not None
    if operator=="eq":return value==node[1]
    if operator=="and":return all(_matches(child,value)for child in node[1:])
    return any(_matches(child,value)for child in node[1:])


def execute_owner_rule(rule_id,data_source,layer_mapping,cancel_check=None):
    definition=SimpleNamespace(canonical_id=rule_id,component="Reconocimiento",description=_DESCRIPTIONS[rule_id],custom_7=False);timestamp=datetime.now()
    with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,number,project,registration,destination,destination_key TEXT,terrain_area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,predio_key TEXT);CREATE TABLE interesado(row_token INTEGER PRIMARY KEY,pk_id,derecho_key TEXT,estado_propietario,nombre_completo_propietario,publico INTEGER);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
        with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,number,project,registration,destination,destination_key,terrain_area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel_check) as ins:
            for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),_PREDIO_FIELDS):
                raise_if_cancelled(cancel_check)
                if not postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado")):continue
                ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),r.get("destinacion_economica"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
        with BatchInserter(db,"INSERT INTO derecho(pk_id,pk_key,predio_key) VALUES (?,?,?)",cancel_check=cancel_check) as ins:
            for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_derecho"),("pk_id","fk_id")):
                raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id"))))
        predicate=_public_predicate()
        with BatchInserter(db,"INSERT INTO interesado(pk_id,derecho_key,estado_propietario,nombre_completo_propietario,publico) VALUES (?,?,?,?,?)",cancel_check=cancel_check) as ins:
            for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_interesado"),("pk_id","fk_id","estado_propietario","nombre_completo_propietario")):
                raise_if_cancelled(cancel_check);state=r.get("estado_propietario");name=r.get("nombre_completo_propietario");publico=int(state is not None and state!=0 and name is not None and _matches(predicate,str(name)));ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),state,name,publico))
        _ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
        db.executescript("CREATE INDEX idx_pred_owner ON predio(pk_key);CREATE INDEX idx_der_pred ON derecho(predio_key);CREATE INDEX idx_int_der ON interesado(derecho_key,publico);CREATE INDEX idx_dest_owner ON destination_lookup(key_token);CREATE INDEX idx_exc_owner ON exception_lookup(fk_token);CREATE INDEX idx_user_owner ON user_assignment(fk_token);CREATE INDEX idx_asig_owner ON assignment_lookup(key_token);CREATE INDEX idx_ctrl_owner ON control_lookup(key_token);")
        if rule_id=="Reco_56":candidate="SELECT p.row_token predio_row,d.row_token derecho_row FROM predio p LEFT JOIN derecho d ON d.predio_key=p.pk_key WHERE p.destination IN (5,18) AND NOT EXISTS(SELECT 1 FROM derecho pd JOIN interesado i ON i.derecho_key=pd.pk_key AND i.publico=1 WHERE pd.predio_key=p.pk_key)"
        else:candidate="SELECT p.row_token predio_row,d.row_token derecho_row FROM predio p JOIN derecho d ON d.predio_key=p.pk_key JOIN interesado i ON i.derecho_key=d.pk_key AND i.publico=1 WHERE p.destination=10"
        db.execute("CREATE TEMP TABLE raw_candidate AS "+candidate)
        db.execute("CREATE TEMP TABLE candidate AS SELECT predio_row,derecho_row FROM (SELECT x.*,ROW_NUMBER() OVER(PARTITION BY p.number ORDER BY x.predio_row,x.derecho_row) rn FROM raw_candidate x JOIN predio p ON p.row_token=x.predio_row) WHERE rn=1")
        db.commit();cur=db.execute("""SELECT p.pk_id,p.number,p.project,p.registration,dest.ilicode,p.terrain_area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,d.pk_id FROM candidate x JOIN predio p ON p.row_token=x.predio_row LEFT JOIN derecho d ON d.row_token=x.derecho_row LEFT JOIN destination_lookup dest ON dest.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.number IS NULL,p.number,p.project IS NULL,p.project""")
        try:
            for values in cur:
                raise_if_cancelled(cancel_check);base=_result_row(definition,timestamp,values[:17]);base["tabla_error_1"]="LC_Jur_Derecho";base["pk_tabla_error_1"]=values[17];yield base
        finally:cur.close()


def execute_reco_56(data_source,layer_mapping,cancel_check=None):return execute_owner_rule("Reco_56",data_source,layer_mapping,cancel_check)
def execute_reco_57(data_source,layer_mapping,cancel_check=None):return execute_owner_rule("Reco_57",data_source,layer_mapping,cancel_check)
