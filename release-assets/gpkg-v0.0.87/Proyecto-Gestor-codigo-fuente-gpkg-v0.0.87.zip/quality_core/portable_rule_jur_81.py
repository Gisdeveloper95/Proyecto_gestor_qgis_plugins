"""Independent portable adapter for canonical Jur_81."""
from .portable_jur_interested_scalar import InterestedRule,RULES,execute_interested_scalar
_RULE=InterestedRule("Jur_81","Predios con interesados con corchete sin estado de propietario nuevo","i.pk_id LIKE '{%' AND i.estado_propietario <> 1",False)
def execute_jur_81(data_source,layer_mapping,cancel_check=None):
 RULES.setdefault("Jur_81",_RULE)
 return execute_interested_scalar("Jur_81",data_source,layer_mapping,cancel_check)
