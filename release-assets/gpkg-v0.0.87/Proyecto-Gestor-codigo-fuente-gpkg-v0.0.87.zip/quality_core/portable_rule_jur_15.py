"""Independent portable implementation of the canonical Jur_15 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    numero = row.get("numero_predial_nacional")
    return (
        postgres_substring(numero, 22, 1) == "4"
        and numero is not None
        and str(numero)[-8:] != "00000000"
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_15",
    component="Juridico",
    description=(
        "Predios Via con codificacion diferente a 00000000 en las posiciones 23 a 30"
    ),
    predicate=_matches,
    custom_7=True,
)


def execute_jur_15(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_15 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
