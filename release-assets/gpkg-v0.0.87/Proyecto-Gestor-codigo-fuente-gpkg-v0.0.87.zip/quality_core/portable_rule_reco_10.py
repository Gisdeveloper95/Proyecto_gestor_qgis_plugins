"""Independent portable implementation of canonical Reco_10."""

from .portable_construction_scalar import (
    ConstructionScalarRule,
    execute_construction_scalar,
)


_RULE = ConstructionScalarRule(
    "Reco_10",
    "Calificacion",
    "Predios con destino economico Lote y con Caracteristica Unidad de Construccion",
    "p.destinacion_economica IN (20,21,22,23,30) AND c.pk_carac IS NOT NULL",
    False,
    table_error_1="LC_Gen_Predio",
    table_error_1_source="predio",
    table_error_2="LC_Reco_Caracteristicasunidadconstruccion",
)


def _canonical_rows(data_source, layer_mapping, cancel_check):
    for row in execute_construction_scalar(
        _RULE, data_source, layer_mapping, cancel_check
    ):
        # The canonical SQL selects lgut.ilicode for both columns.  Preserve the
        # published behavior instead of silently replacing the first value with
        # lrut.ilicode.
        row["tipo_unidad_construccion"] = row["uso_construccion"]
        yield row


def execute_reco_10(data_source, layer_mapping, cancel_check=None):
    return _canonical_rows(data_source, layer_mapping, cancel_check)
