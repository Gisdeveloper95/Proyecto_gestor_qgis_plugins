-- Filtro operativo aplicado despues de ejecutar cada regla RECO.
-- Replica los cuatro filtros globales del plugin de referencia.
SELECT p.pk_id::text AS pk_id_predio
FROM actualizacion.lc_gen_predio AS p
WHERE coalesce(p.juridico_predio_cancelado, false) = false
  AND btrim(p.reconocimiento_estado_asignacion::text) = '2'
  AND regexp_replace(
        btrim(coalesce(p.condicion::text, '')),
        '\.0$',
        ''
      ) NOT IN ('2', '5', '8', '9')
  AND coalesce(p.informal_predio_para_visita, false) = false;
