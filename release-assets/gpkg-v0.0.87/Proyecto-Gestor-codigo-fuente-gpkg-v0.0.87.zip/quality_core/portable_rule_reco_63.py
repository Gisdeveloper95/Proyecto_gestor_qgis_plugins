"""Independent portable implementation of the canonical Reco_63 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    area = row.get("area_catastral_terreno")
    return (
        postgres_substring(row.get("numero_predial_nacional"), 6, 2) == "01"
        and area is not None
        and (area > 10000 or area < 20)
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_63",
    component="Reconocimiento",
    description=(
        "Predios urbanos con area catastral de terreno mayor a 1 hectarea "
        "y menor a 20 metros"
    ),
    predicate=_matches,
    custom_7=False,
)


def execute_reco_63(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_63 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
