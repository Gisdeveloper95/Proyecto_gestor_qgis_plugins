"""Independent portable implementation of canonical Reco_34."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_34", "Calificacion",
    "Caracteristica Unidad de Construccion sin a\u00f1o de construccion",
    "c.anio_construccion IS NULL OR c.anio_construccion <= 1900", True,
    construction_filter_fields=("anio_construccion",),
)

def execute_reco_34(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
