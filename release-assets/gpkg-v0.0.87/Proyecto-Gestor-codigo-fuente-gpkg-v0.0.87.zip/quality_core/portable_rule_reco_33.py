"""Independent portable implementation of canonical Reco_33."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_33", "Calificacion",
    "Caracteristica Unidad de Construccion con a\u00f1o de construccion mayor a 2025",
    "c.anio_construccion > 2025", True,
    construction_filter_fields=("anio_construccion",),
)

def execute_reco_33(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
