"""Independent portable implementation of canonical Reco_66."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_66", "Reconocimiento",
    "Caracter\u00edsticas unidad de construcci\u00f3n con area construida menor a 10 metros",
    "c.area_construida < 10", False,
    table_error_1="LC_Reco_CaracteristicasUnidadConstruccion", use_output="raw",
)

def execute_reco_66(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
