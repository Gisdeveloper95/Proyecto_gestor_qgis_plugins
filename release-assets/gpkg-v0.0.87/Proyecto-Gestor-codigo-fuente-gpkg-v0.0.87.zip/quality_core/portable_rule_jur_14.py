"""Independent portable implementation of the canonical Jur_14 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    numero = row.get("numero_predial_nacional")
    return (
        postgres_substring(numero, 22, 1) == "3"
        and numero is not None
        and str(numero)[-8:] != "00000000"
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_14",
    component="Juridico",
    description=(
        "Predios Bien de Uso Publico con codificacion diferente a 00000000 "
        "en las posiciones 23 a 30"
    ),
    predicate=_matches,
    custom_7=True,
)


def execute_jur_14(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_14 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
