"""Independent pure-Python/GPKG implementation of canonical Reco_49."""

from datetime import datetime
import struct
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_substring, raise_if_cancelled, sqlite_staging


_PREDIO_FIELDS=("pk_id","numero_predial_nacional","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")


def _wkb_area(payload):
    if payload is None:return None
    data=bytes(payload);offset=0
    if data[:2]==b"GP":
        flags=data[3];envelope=(flags>>1)&7;env_bytes={0:0,1:32,2:48,3:48,4:64}.get(envelope,0);offset=8+env_bytes
    def read_geom(pos):
        endian="<" if data[pos]==1 else ">";pos+=1;raw_type=struct.unpack_from(endian+"I",data,pos)[0];pos+=4
        dims=2
        if raw_type&0x80000000:dims+=1
        if raw_type&0x40000000:dims+=1
        if raw_type&0x20000000:pos+=4
        base=raw_type&0xFF
        if 1000<=raw_type<4000:dims=2+raw_type//1000;base=raw_type%1000
        if base==3:
            rings=struct.unpack_from(endian+"I",data,pos)[0];pos+=4;areas=[]
            for _ in range(rings):
                count=struct.unpack_from(endian+"I",data,pos)[0];pos+=4;points=[]
                for _ in range(count):
                    coords=struct.unpack_from(endian+("d"*dims),data,pos);pos+=8*dims;points.append(coords[:2])
                signed=sum(points[i][0]*points[i+1][1]-points[i+1][0]*points[i][1] for i in range(len(points)-1))/2.0;areas.append(abs(signed))
            return ((areas[0]-sum(areas[1:])) if areas else 0.0),pos
        if base in (6,7):
            count=struct.unpack_from(endian+"I",data,pos)[0];pos+=4;total=0.0
            for _ in range(count):a,pos=read_geom(pos);total+=a
            return total,pos
        if base==1:return 0.0,pos+8*dims
        raise ValueError("Tipo WKB no soportado para Reco_49: {0}".format(raw_type))
    return read_geom(offset)[0]


def _threshold(number,area):
    rural=postgres_substring(number,6,2)=="00"
    if rural:
        if area<=2000:return .10
        if area<=10000:return .09
        if area<=100000:return .07
        if area<=500000:return .04
        return .02
    if postgres_substring(number,6,2) is None:return None
    if area<=80:return .07
    if area<=250:return .06
    if area<=500:return .04
    return .03


def _pg_float_text(value):
    return format(float(value),".15g")


def execute_reco_49(data_source,layer_mapping,cancel_check=None):
    definition=SimpleNamespace(canonical_id="Reco_49",component="Reconocimiento",description="Predios con area de terreno fuera del rango de tolerancia segun la Resolucion 1040",custom_7=True)
    timestamp=datetime.now()
    with sqlite_staging(cancel_check,prefix="mapingtool-calidad-gpkg-reco_49-") as db:
        db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,number,number_key TEXT,project,registration,destination_key TEXT,cadastral_area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE terrain(row_token INTEGER PRIMARY KEY,code_key TEXT,pk_id,fid,geometry_area);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,predio_row INTEGER,terrain_row INTEGER,needed_area);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
        with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,number,number_key,project,registration,destination_key,cadastral_area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel_check) as ins:
            for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),_PREDIO_FIELDS):
                raise_if_cancelled(cancel_check);area=0 if r.get("area_catastral_terreno") in (None,0) else r.get("area_catastral_terreno")
                ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),_join_token(r.get("numero_predial_nacional")),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),area,_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
        terrain_name=layer_mapping.resolve("lc_gen_terreno");fields=set(data_source.describe(terrain_name).fields);geometry_field="geom" if "geom" in fields else "geom_area";requested=("fid","pk_id","codigo",geometry_field)
        with BatchInserter(db,"INSERT INTO terrain(code_key,pk_id,fid,geometry_area) VALUES (?,?,?,?)",cancel_check=cancel_check) as ins:
            for r in data_source.iter_rows(terrain_name,requested):
                raise_if_cancelled(cancel_check);area=_wkb_area(r.get("geom")) if geometry_field=="geom" else r.get("geom_area");ins.add((_join_token(r.get("codigo")),r.get("pk_id"),r.get("fid"),area))
        _ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
        db.executescript("CREATE INDEX idx_pnum ON predio(number_key);CREATE INDEX idx_tcode ON terrain(code_key);CREATE INDEX idx_dest49 ON destination_lookup(key_token);CREATE INDEX idx_exc49 ON exception_lookup(fk_token);CREATE INDEX idx_user49 ON user_assignment(fk_token);CREATE INDEX idx_a49 ON assignment_lookup(key_token);CREATE INDEX idx_c49 ON control_lookup(key_token);")
        for p_row,number,cadastral,t_row,fid,geom in db.execute("SELECT p.row_token,p.number,p.cadastral_area,t.row_token,t.fid,t.geometry_area FROM predio p LEFT JOIN terrain t ON t.code_key=p.number_key"):
            geometric=0 if fid is None else geom
            if cadastral>0 and geometric in (None,0):variation=1
            elif cadastral==0 and geometric in (None,0):variation=0
            elif geometric is None:continue
            else:variation=abs(cadastral-geometric)/geometric
            tolerance=_threshold(number,cadastral)
            suffix=postgres_substring(number,22,9)
            if tolerance is None or variation<=tolerance or suffix is None or suffix in {"700000000","800000000","900000000"}:continue
            upper=cadastral*(1+tolerance);lower=cadastral*(1-tolerance);needed=(upper-geometric) if geometric>upper else (lower-geometric)
            db.execute("INSERT INTO selected(predio_row,terrain_row,needed_area) VALUES (?,?,?)",(p_row,t_row,needed))
        db.commit();cur=db.execute("""SELECT p.pk_id,p.number,p.project,p.registration,d.ilicode,p.cadastral_area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,t.pk_id,s.needed_area FROM selected s JOIN predio p ON p.row_token=s.predio_row LEFT JOIN terrain t ON t.row_token=s.terrain_row LEFT JOIN destination_lookup d ON d.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.number IS NULL,p.number,p.project IS NULL,p.project""")
        try:
            for values in cur:
                raise_if_cancelled(cancel_check);base=_result_row(definition,timestamp,values[:17]);base["tabla_error_2"]="LC_Gen_Terreno";base["pk_tabla_error_2"]=values[17];base["custom_1"]=_pg_float_text(values[18]);yield base
        finally:cur.close()
