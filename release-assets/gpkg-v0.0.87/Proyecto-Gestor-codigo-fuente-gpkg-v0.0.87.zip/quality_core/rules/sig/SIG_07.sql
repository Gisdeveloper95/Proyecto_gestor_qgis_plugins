-- name: SIG_07
with b as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
and lgp.predio_tiene_cambio_fisico = true
), b2 as(select l.pk_id, l.codigo, l.planta, l.tipo_construccion, l.etiqueta, l.identificador, 'LC_Gen_UnidadConstruccion' tabla 
from actualizacion.lc_gen_unidadconstruccion l WHERE pk_id NOT IN (SELECT pk_id from actualizacion.lc_gen_unidadconstruccion l 
WHERE substring(l.codigo,22,1) = '9' AND substring(l.codigo,27,4) <> '0000') 
union 
select l.pk_id, l.codigo, l.planta, l.tipo_construccion, l.etiqueta, l.identificador, 'LC_Gen_UnidadConstruccion_Informal' tabla 
from actualizacion.lc_gen_unidadconstruccion_informal l WHERE pk_id NOT IN (SELECT pk_id from actualizacion.lc_gen_unidadconstruccion_informal l 
WHERE substring(l.codigo,22,1) = '9' AND substring(l.codigo,27,4) <> '0000') 
), b3 as(select b2.*, b.pk_id pk_id_predio, b.nombre_proyecto proyecto, b.matricula_inmobiliaria, b.destinacion_economica, b.area_catastral_terreno 
from b2 join b on b2.codigo = b.numero_predial_nacional
)
select 'SIG_07' id_regla, 'Digitalizacion' componente, 'Unidad de Construccion en comision con cambio fisico' descripcion_regla, b3.proyecto, 
b3.pk_id_predio, tabla tabla_error_1, b3.pk_id pk_tabla_error_1, 'LC_Gen_Predio' tabla_error_2, b3.pk_id_predio pk_tabla_error_2, 
b3.codigo numero_predial_nacional, b3.matricula_inmobiliaria, lgdt.ilicode destino_economico, b3.area_catastral_terreno, 
b3.identificador identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, 
null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from b3 left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on b3.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_reco_caracteristicasunidadconstruccion lrc on b3.pk_id_predio = lrc.fk_id and b3.identificador = lrc.identificador 
left join actualizacion.lc_gen_excepciones lge on b3.pk_id_predio = lge.fk_id and 'SIG_07' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on b3.pk_id_predio = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on b3.pk_id_predio = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where lrc.pk_id is NULL order by 10,4,14;
