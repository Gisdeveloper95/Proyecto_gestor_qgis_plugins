-- name: SIG_01
with b as(
select * from actualizacion.lc_gen_predio lgp where lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false
), b2 as(select b.* from b join actualizacion.lc_gen_terreno lgt on b.numero_predial_nacional = lgt.codigo AND substring(b.numero_predial_nacional,22,1) not in ('5','2')
), b3 as(select b.* from b join actualizacion.lc_gen_terreno_informal lgt on b.numero_predial_nacional = lgt.codigo AND substring(b.numero_predial_nacional,22,1) in ('5','2')
), b4 as(select b2.* from b2 UNION SELECT b3.* FROM b3
), b5 as(
select 'SIG_01' id_regla, 'Digitalizacion' componente, 'Predios en Omision' descripcion_regla, b.nombre_proyecto proyecto, b.pk_id pk_id_predio, 
'LC_Gen_Predio' tabla_error_1, b.pk_id pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, b.numero_predial_nacional, b.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, b.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, 
null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from b left join b4 on b.pk_id = b4.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on b.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on b.pk_id = lge.fk_id and 'SIG_01' = lge.id_regla  
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on b.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON b.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON b.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON b.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON b.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON b.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON b.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON b.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON b.geografico_estado_control = lgec_geo_ctrl.itfcode
where b4.pk_id is null order by 10,4,14
)
select b5.id_regla, b5.componente, b5.descripcion_regla, b5.proyecto, b5.pk_id_predio, b5.tabla_error_1, b5.pk_tabla_error_1, b5.tabla_error_2, 
b5.pk_tabla_error_2, b5.numero_predial_nacional, b5.matricula_inmobiliaria, b5.destino_economico, b5.area_catastral_terreno, 
b5.identificador_caracteristica_unidad_construccion, b5.total_plantas, b5.tipo_unidad_construccion, b5.uso_construccion, b5.area_construida, 
b5.puntaje_calificacion, b5.tipo_novedad, b5.numero_predial_nacional_novedad, b5.tiene_excepcion, b5.descripcion_excepcion, b5.juridico_estado_asignacion, 
b5.juridico_estado_control, b5.reconocimiento_estado_asignacion, b5.reconocimiento_estado_control, b5.informal_estado_asignacion, b5.informal_estado_control, 
b5.geografico_estado_asignacion, b5.geografico_estado_control, b5.pk_lc_gen_predio_usuarioasignacion, b5.usuario_creacion, 
b5.fecha_creacion, b5.usuario_modificacion, b5.fecha_modificacion, b5.custom_1, b5.custom_2, b5.custom_3, b5.custom_4, b5.custom_5, b5.custom_6, 
b5.custom_7, b5.custom_8, b5.custom_9, b5.custom_10, b5.custom_11, b5.custom_12
from b5;
