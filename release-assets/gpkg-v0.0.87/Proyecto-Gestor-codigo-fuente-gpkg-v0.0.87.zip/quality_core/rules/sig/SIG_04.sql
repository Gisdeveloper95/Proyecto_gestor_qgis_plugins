-- name: SIG_04
with b as(
select lpp.* from actualizacion.lc_ph_predio lpp join actualizacion.lc_ph_novedadnumeropredial lpn on lpp.pk_id = lpn.fk_id where lpn.tipo_novedad in (5,6,7,8)
), b2 as(select lpp.* from actualizacion.lc_ph_predio lpp left join b on lpp.pk_id = b.pk_id where b.pk_id is null
), b3 as(select b2.*, lgp.nombre_proyecto proyecto, lgp.predio_tiene_cambio_fisico from b2 join actualizacion.lc_gen_predio lgp on b2.fk_id = lgp.pk_id 
where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) and lgp.predio_tiene_cambio_fisico = true
), b4 as(SELECT * FROM actualizacion.lc_gen_unidadconstruccion lgu2 UNION SELECT * FROM actualizacion.lc_gen_unidadconstruccion_informal lgui 
)
select 'SIG_04' id_regla, 'Digitalizacion' componente, 'Caracteristica Unidad de Construccion PH en omision con cambio fisico' descripcion_regla, 
b3.proyecto, b3.fk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, b3.pk_id pk_tabla_error_1, 'LC_PH_CaracteristicasUnidadConstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, b3.numero_predial_nacional, b3.matricula_inmobiliaria, lgdt.ilicode destino_economico, 
b3.area_catastral_terreno, dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas, lru.ilicode tipo_unidad_construccion, 
lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, true custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from b3 join general.determinacion_area_construccion dac on b3.pk_id = dac.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on b3.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lru on dac.tipo_unidad_construccion = lru.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join b4 on b3.numero_predial_nacional = b4.codigo and dac.identificador = b4.identificador
left join actualizacion.lc_gen_excepciones lge on b3.pk_id = lge.fk_id and 'SIG_04' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on b3.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on b3.fk_id = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where b4.pk_id is null and b3.predio_tiene_cambio_fisico = true order by 10,4,14;
