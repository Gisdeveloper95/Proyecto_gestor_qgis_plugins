-- name: SIG_02
with b as(
select * from actualizacion.lc_gen_predio lgp where lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false
), b2 as(select lgt.pk_id, lgt.codigo, 'LC_Gen_Terreno' tabla from actualizacion.lc_gen_terreno lgt UNION 
select lgt2.pk_id, lgt2.codigo, 'LC_Gen_Terreno' tabla from actualizacion.lc_gen_terreno_informal lgt2
)
select 'SIG_02' id_regla, 'Terrenos en comision' descripcion_regla, tabla tabla_error, b2.pk_id pk_tabla_error, b2.codigo, 
null identificador_unidad_construccion, null planta_unidad_construccion, null tiene_excepcion from b2 
LEFT JOIN b ON b2.codigo = b.numero_predial_nacional
WHERE b.pk_id IS NULL order by 5,6;
