-- name: Jur_63
with c as(
select lgp.pk_id, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgp.destinacion_economica, 
lgp.area_catastral_terreno, lgp.nombre_proyecto, ljn.pk_id pk_id_novedad,
ljnt.ilicode tipo_novedad, ljn.numero_predial_nacional_novedad
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_jur_novedadnumeropredial ljn on lgp.pk_id = ljn.fk_id 
join actualizacion.lc_jur_novedadnumeropredial_tipo ljnt on ljn.tipo_novedad = ljnt.itfcode
where ljnt.ilicode in ('Cancelacion_por_Englobe','Cancelacion_por_Desenglobe')
), c2 as(
select lgp.pk_id, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgp.destinacion_economica, 
lgp.area_catastral_terreno, lgp.nombre_proyecto, ljn.pk_id pk_id_novedad,
ljnt.ilicode tipo_novedad, ljn.numero_predial_nacional_novedad
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_jur_novedadnumeropredial ljn on lgp.pk_id = ljn.fk_id 
join actualizacion.lc_jur_novedadnumeropredial_tipo ljnt on ljn.tipo_novedad = ljnt.itfcode
where ljnt.ilicode in ('Desenglobe_Division_Material','Englobe_Nuevo_FMI','Englobe_Mantiene_FMI')
)
select distinct 'Jur_63' id_regla, 'Cancelacion_Desenglobe_Englobe' componente, 
'Predios cancelados por englobe o desenglobe que no tienen novedad de englobe o desenglobe' descripcion_regla, 
c.nombre_proyecto proyecto, c.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, c.pk_id pk_tabla_error_1, 
'LC_Jur_NovedadNumeroPredial' tabla_error_2, c.pk_id_novedad pk_tabla_error_2, c.numero_predial_nacional, 
c.matricula_inmobiliaria, lgdt.ilicode destino_economico, c.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, 
null uso_construccion, null area_construida, null puntaje_calificacion, c.tipo_novedad, c.numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, 
lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from c left join c2 on c.numero_predial_nacional = c2.numero_predial_nacional_novedad
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on c.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on c.pk_id = lge.fk_id and 'Jur_63' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on c.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on c.pk_id = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where c2.pk_id is null order by 10,4,14;
