-- name: Jur_36
with c as(
select lgp.* from actualizacion.lc_gen_predio lgp join actualizacion.lc_jur_derecho ljd on lgp.pk_id = ljd.fk_id 
join actualizacion.lc_jur_derecho_tipo ljdt on ljd.tipo_derecho = ljdt.itfcode 
where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false)  
and ljdt.ilicode = 'Ocupacion'
), c2 as(
select c.* from c join actualizacion.lc_gen_predio_tipo l on c.tipo_predio = l.itfcode
where l.ilicode in ('Predio.Publico.Baldio','Predio.Publico.Fiscal_Patrimonial','Predio.Publico.Uso_Publico','Predio.Publico.Presunto_Baldio')
)
select 'Jur_36' id_regla, 'Juridico' componente, 'Predios con derecho Ocupacion de tipo diferente a Baldío, Presunto Baldio, Fiscal_Patrimonial o Uso Publico' descripcion_regla, 
c.nombre_proyecto proyecto, c.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, c.pk_id pk_tabla_error_1, 
null tabla_error_2, null pk_tabla_error_2, c.numero_predial_nacional, c.matricula_inmobiliaria, lgdt.ilicode destino_economico, 
c.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, null total_plantas, 
null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, 
null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, 
lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, true custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from c
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on c.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on c.pk_id = lge.fk_id and 'Jur_36' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on c.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON c.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON c.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON c.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON c.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON c.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON c.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON c.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON c.geografico_estado_control = lgec_geo_ctrl.itfcode
left join c2 on c.pk_id = c2.pk_id 
where c2.pk_id is null
order by 10,4,14;
