-- name: Jur_47
with c as(
select lgp.*, lgt.geom geom_terreno, left(lgp.numero_predial_nacional,21) numero_predio, 
lji.documento_identidad, lji.nombre_completo_propietario 
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_gen_terreno lgt on lgp.numero_predial_nacional = lgt.codigo
join actualizacion.lc_jur_derecho ljd on lgp.pk_id = ljd.fk_id 
join actualizacion.lc_jur_interesado lji on ljd.pk_id = lji.fk_id 
where substring(lgp.numero_predial_nacional,22,1) = '0'
), c2 as(
select lgp.*, lgt.geom geom_terreno_informal, left(lgp.numero_predial_nacional,21) numero_predio, 
lji.documento_identidad, lji.nombre_completo_propietario 
from actualizacion.lc_gen_predio lgp
join actualizacion.lc_gen_terreno_informal lgt on lgp.numero_predial_nacional = lgt.codigo
join actualizacion.lc_jur_derecho ljd on lgp.pk_id = ljd.fk_id 
join actualizacion.lc_jur_interesado lji on ljd.pk_id = lji.fk_id 
where substring(lgp.numero_predial_nacional,22,1) = '2'
), c3 as(
select c.nombre_proyecto, c.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, c.pk_id pk_tabla_error_1, 
'LC_Gen_Predio' tabla_error_2, c2.pk_id pk_tabla_error_2, c.numero_predial_nacional, 
c.matricula_inmobiliaria, c.destinacion_economica, c.area_catastral_terreno
from c, c2
where ST_Overlaps(c.geom_terreno, c2.geom_terreno_informal) = true and (c.documento_identidad = c2.documento_identidad 
or c.nombre_completo_propietario = c2.nombre_completo_propietario)
)
select 'Jur_47' id_regla, 'Juridico' componente, 'Interesados existentes en la informalidad y existentes en los predios formales' descripcion_regla, 
c3.nombre_proyecto proyecto, c3.pk_id_predio, c3.tabla_error_1, c3.pk_tabla_error_1, 
'LC_Gen_Predio' tabla_error_2, c3.pk_tabla_error_2, c3.numero_predial_nacional, 
c3.matricula_inmobiliaria, lgdt.ilicode destino_economico, c3.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, 
null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, 
null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, 
lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, 
now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from c3
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on c3.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on c3.pk_id_predio = lge.fk_id and 'Jur_47' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on c3.pk_id_predio = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on c3.pk_id_predio = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
order by 10,4,14;
