-- name: Jur_82
with c as(
select * from actualizacion.lc_gen_predio lgp 
where lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false
), c2 as(
select lgp.pk_id pk_predio, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, 
ljd.pk_id pk_derecho, lji.pk_id pk_interesado
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_jur_derecho ljd on lgp.pk_id = ljd.fk_id 
join actualizacion.lc_jur_interesado lji on ljd.pk_id = lji.fk_id 
WHERE lji.estado_propietario <> 0 AND 
(nombre_completo_propietario ILIKE '%la nacio%' OR nombre_completo_propietario ILIKE '%EMPRESA NACIONAL%'
OR nombre_completo_propietario ILIKE '%TELEVISION NACIONA%' OR nombre_completo_propietario ILIKE '%SERVICIO NACIONAL DE APRENDIZAJE%'
OR nombre_completo_propietario ILIKE '%SENA%' OR nombre_completo_propietario ILIKE '%SERVICIO NACIONAL APRENDIZAJE%'
OR nombre_completo_propietario ILIKE '%RADIO CADENA NACIONAL%' OR nombre_completo_propietario ILIKE '%RADIO AFICIONADO NACIONALES%'
OR nombre_completo_propietario ILIKE '%POLICIA NACIONAL%' OR nombre_completo_propietario ILIKE '%PENITENCIERIA NACIONAL%'
OR nombre_completo_propietario ILIKE '%MINISTERIO DE DEFENSA NACIONAL%' OR nombre_completo_propietario ILIKE '%MINISTERIO DEFENSA NACIONAL%'
OR nombre_completo_propietario ILIKE '%caja de vivienda%' OR nombre_completo_propietario ILIKE '%CAJA VIVIENDAPOPULAR%'
OR nombre_completo_propietario ILIKE '%CAMARA DE COMERCIO%' OR nombre_completo_propietario ILIKE '%CASA DEL NINO%'
OR nombre_completo_propietario ILIKE '%CASA DE VIVIENDA%' OR nombre_completo_propietario ILIKE '%CAVIBAGUE%'
OR nombre_completo_propietario ILIKE '%CUERPO BOMBEROS%' OR nombre_completo_propietario ILIKE '%DIOCESIS DE IBAGUE%'
OR nombre_completo_propietario ILIKE '%DIOSECIS DE IBAGUE%' OR nombre_completo_propietario ILIKE '%IRVIS%'
OR nombre_completo_propietario ILIKE '%SALUD DE IBAGUE%' OR nombre_completo_propietario ILIKE '%UNIVERSIDAD DE IBAGUE%'
OR nombre_completo_propietario ILIKE '%BALDIOS%' OR nombre_completo_propietario ILIKE '%ICBF%'
OR nombre_completo_propietario ILIKE '%INSTITUTO COLOMBIANO%' OR nombre_completo_propietario ILIKE '%ENERTOLIMA%'
OR nombre_completo_propietario ILIKE '%EMPRESA DE SERVICIOS PUBLI%' OR nombre_completo_propietario ILIKE '%FEDERACION NACIONAL%'
OR nombre_completo_propietario ILIKE '%FERROCARRILES NACION%' OR nombre_completo_propietario ILIKE '%FONDO %'
OR nombre_completo_propietario ILIKE '%INSTITUTO IBAGUERE%' OR nombre_completo_propietario ILIKE '%INSTITUTO NACIO%'
OR nombre_completo_propietario ILIKE '%JUNTA ACCION COMUNAL%' OR nombre_completo_propietario ILIKE '%JUNTA DE ACCION COMUNAL%'
OR nombre_completo_propietario ILIKE '%MUNICIPIO DEL ESPINAL%' OR nombre_completo_propietario ILIKE '%SECRETARIA DE DESARROLLO RURAL%'
OR nombre_completo_propietario ILIKE '%SECRETARIA DE SALUD%' OR nombre_completo_propietario ILIKE '%SOCIEDAD DE ACTIVOS ESPECIALES%'
OR nombre_completo_propietario ILIKE '%TERMINAL DE TRANSPORTE%' OR nombre_completo_propietario ILIKE '%TELECOM%'
OR nombre_completo_propietario ILIKE '%TELETOLIMA%' OR nombre_completo_propietario ILIKE '%TRANSPORTADORA REGIONAL%'
OR nombre_completo_propietario ILIKE '%UNIVERSIDAD DEL TOLIMA%' OR nombre_completo_propietario ILIKE '%DEPARTAM%' 
OR nombre_completo_propietario ILIKE '%GOBERNAC%' OR nombre_completo_propietario ILIKE '% ANT' 
OR nombre_completo_propietario ILIKE '%AGENCIA NACIONAL DE TIERRAS%' OR nombre_completo_propietario ILIKE '%AGENCIA NACIONAL TIERRAS%' 
OR nombre_completo_propietario ILIKE '%INCORA%' OR nombre_completo_propietario ILIKE '%INCODER%'
OR nombre_completo_propietario ILIKE '%INFI%' OR nombre_completo_propietario ILIKE '%EMPRESA DE DESARROLLO%'
OR nombre_completo_propietario ILIKE '%DESARROLLO URBANO%' OR nombre_completo_propietario ILIKE '%GESTORA URBANA%' 
OR nombre_completo_propietario ILIKE '%GSTORA URBANA%' OR nombre_completo_propietario ILIKE '%IMDRI%' 
OR nombre_completo_propietario ILIKE '%MUNICIPAL PARA EL DEP%' OR nombre_completo_propietario ILIKE '%DEPORTE Y LA RECR%'
OR nombre_completo_propietario ILIKE '%acueducto y alcantar%' OR nombre_completo_propietario ILIKE '%acuedu%'
OR nombre_completo_propietario ILIKE '%alcantarilla%' OR nombre_completo_propietario ILIKE '%IBAL%'
OR nombre_completo_propietario ILIKE '%cortolima%' OR nombre_completo_propietario ILIKE '%corporacion autonoma%'
OR nombre_completo_propietario ILIKE '%municipio de ibague%' OR nombre_completo_propietario ILIKE '%minicipio de ibague%' 
OR nombre_completo_propietario ILIKE '%minicipio ibague%' OR nombre_completo_propietario ILIKE '%minicipio de ibague%'
OR nombre_completo_propietario ILIKE '%alcaldia ibague%' OR nombre_completo_propietario ILIKE '%alcaldia municipal%' 
OR nombre_completo_propietario ILIKE '%ARQUIDIOCESIS%' OR nombre_completo_propietario ILIKE '%EMPOIBAGUE%' 
OR nombre_completo_propietario ILIKE '%IBAGUÉ LIMPIA%' OR nombre_completo_propietario ILIKE '%INFIBAGUE%'
OR nombre_completo_propietario ILIKE '%Instituto de Financiamiento%' OR nombre_completo_propietario ILIKE '%Promoción y Desarrollo%'
OR ((nombre_completo_propietario ILIKE '%MUNICIPIO DE%')) 
OR ((nombre_completo_propietario ILIKE '%DEPARTAMENTO DE%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUCION%') AND (nombre_completo_propietario ILIKE '%DISTRITAL%')) 
OR ((nombre_completo_propietario ILIKE '%ADMINISTRACION PUBLICA AGUAS DE%')) 
OR ((nombre_completo_propietario ILIKE '%ADMINISTRACION PUBLICA%')) 
OR ((nombre_completo_propietario ILIKE '%AEROPUERTO%')) 
OR ((nombre_completo_propietario ILIKE '%AGENCIA DE DESARROLLO%')) 
OR ((nombre_completo_propietario ILIKE '%AGENCIA NACIONAL DE %')) 
OR ((nombre_completo_propietario ILIKE '%AGENCIA PRESIDENCIAL DE COOPERACION INTERNACIONAL%')) 
OR ((nombre_completo_propietario ILIKE '%AGENCIA COLOMBIANA PARA LA REINTEGRACION DE PERSONAS%')) 
OR ((nombre_completo_propietario = 'ARMADA NACIONAL')) 
OR ((nombre_completo_propietario = 'AGENCIA LOGISTICA DE LAS FUERZAS MILITARES')) 
OR ((nombre_completo_propietario = 'AUTORIDAD NACIONAL DE AGRICULTURA Y PESCA')) 
OR ((nombre_completo_propietario ILIKE '%AUTORIDAD NACIONAL DE%')) 
OR ((nombre_completo_propietario ILIKE '%BAN%') AND (nombre_completo_propietario ILIKE '%AGRARIO%')) 
OR ((nombre_completo_propietario ILIKE '%BANCO DE COMERCIO EXTERIOR DE COLOMBIA%')) 
OR ((nombre_completo_propietario ILIKE '%DE LA REPUBLICA%')) 
OR ((nombre_completo_propietario ILIKE '%CAJA DE RETIRO DE LAS F%')) 
OR ((nombre_completo_propietario ILIKE '%CAJA PROMOTORA DE VIVIENDA M%')) 
OR ((nombre_completo_propietario ILIKE '%CANAL REGIONAL DE TELEVISION%')) 
OR ((nombre_completo_propietario ILIKE '%CENTRAL DE INVERSIONES%')) 
OR ((nombre_completo_propietario ILIKE '% CISA %') OR (nombre_completo_propietario = 'CISA')) 
OR ((nombre_completo_propietario ILIKE '%CENTRALES ELECTRICAS%') AND (nombre_completo_propietario ILIKE '%NARI%')) 
OR ((nombre_completo_propietario ILIKE '%CENTRALES ELECTRICAS%') AND (nombre_completo_propietario ILIKE '%CAUCA%')) 
OR ((nombre_completo_propietario ILIKE '%CLUB MILITAR%')) 
OR ((nombre_completo_propietario ILIKE '%COMANDO GENERAL DE%')) 
OR ((nombre_completo_propietario ILIKE '%COMISION DE REGULACION DE%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION AUTONOMA REGIONAL DE%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION COLOMBIANA INTERNACIONAL%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION COLOMBIANA DE INVESTIGACION AGROPECUARIA%')) 
OR ((nombre_completo_propietario ILIKE '%CORPOICA%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION DE CIENCIA Y TECNOLOGIA PARA%') AND (nombre_completo_propietario ILIKE '%NAVAL%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION DE%') AND (nombre_completo_propietario ILIKE '%AERONAUTICA%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION NACIONAL PARA LA RECONST%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION PARA EL DESARROLLO SOS%')) 
OR ((nombre_completo_propietario ILIKE '%ECOPETROL%')) 
OR ((nombre_completo_propietario ILIKE '%EJER%') AND (nombre_completo_propietario ILIKE '%NACIO%')) 
OR ((nombre_completo_propietario ILIKE '%ELECTRIFICADORA%') AND ((nombre_completo_propietario ILIKE '%CAQUETA%') OR (nombre_completo_propietario ILIKE '%HUILA%') OR (nombre_completo_propietario ILIKE '%META%'))) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA DE ENERGIA%') AND ((nombre_completo_propietario ILIKE '%SAN ANDRES%') OR (nombre_completo_propietario ILIKE '%AMAZONAS%'))) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA DE TELECOMUNICACIONES DE BUCARAMANGA%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA DISTRIBUIDORA%') AND (nombre_completo_propietario ILIKE '%PACIFICO%')) 
OR ((nombre_completo_propietario ILIKE '%FOGANSA%')) 
OR ((nombre_completo_propietario ILIKE '%FONDO GANADERO DE ANTIOQUIA%')) 
OR ((nombre_completo_propietario = 'FIDUCIARIA COLOMBIANA DE COMERCIO EXTERIOR')) 
OR ((nombre_completo_propietario = 'FIDUCIARIA LA PREVISORA')) 
OR ((nombre_completo_propietario = 'FINANCIERA DE DESARROLLO NACIONAL')) 
OR ((nombre_completo_propietario ILIKE '%FINANCIERA%') AND (nombre_completo_propietario ILIKE '%DESARROLLO%') AND ((nombre_completo_propietario ILIKE '%NAL%') OR (nombre_completo_propietario ILIKE '%RIAL%'))) 
OR ((nombre_completo_propietario ILIKE '%FINANCIERA%') AND (nombre_completo_propietario ILIKE '%DLLO%') AND ((nombre_completo_propietario ILIKE '%ONAL%') OR (nombre_completo_propietario ILIKE '%RIAL%'))) 
OR ((nombre_completo_propietario = 'FINANCIERA DE DESARROLLO TERRITORIAL')) 
OR ((nombre_completo_propietario = 'FONDO ADAPTACION')) 
OR ((nombre_completo_propietario ILIKE '%FONDO GANADERO%') AND ((nombre_completo_propietario ILIKE '%BOYACA%') OR (nombre_completo_propietario ILIKE '%ATLANTICO%') OR (nombre_completo_propietario ILIKE '%CAUCA%') OR (nombre_completo_propietario ILIKE '%CORDOBA%') OR (nombre_completo_propietario ILIKE '%CESAR%') OR (nombre_completo_propietario ILIKE '%HUILA%') OR (nombre_completo_propietario ILIKE '%MAGDALENA%') OR (nombre_completo_propietario ILIKE '%META%') OR (nombre_completo_propietario ILIKE '%TOLIMA%'))) 
OR ((nombre_completo_propietario ILIKE '%FONDO%') AND (nombre_completo_propietario ILIKE '%FINANC%') AND (nombre_completo_propietario ILIKE '%AGROPECUARIO%')) 
OR ((nombre_completo_propietario ILIKE '%FONDO%') AND (nombre_completo_propietario ILIKE '%ROT%') AND (nombre_completo_propietario ILIKE '%POLI%') AND (nombre_completo_propietario ILIKE '%NAL%')) 
OR ((nombre_completo_propietario = 'FUERZA AEREA COLOMBIANA')) 
OR ((nombre_completo_propietario = 'FAC')) 
OR ((nombre_completo_propietario ILIKE '%GENERADORA Y COMERCIALIZADORA DE ENERGIA%') AND (nombre_completo_propietario ILIKE '%CARIBE%')) 
OR ((nombre_completo_propietario ILIKE '%GESTION ENERGETICA%')) 
OR ((nombre_completo_propietario = 'INDUSTRIA MILITAR')) 
OR ((nombre_completo_propietario = 'INDUMIL')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO AMAZONICO DE INVESTIGACIONES CIENTIFICAS%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO COLOMBIANO AGROPECUARIO%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO COLOMBIANO DE%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO DE HIDROLOGIA%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO DE INVESTIGACION DE RECURSOS BIOLOGICOS ALEX%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO DE INVESTIGACIONES AMBIENTALES DEL PACIFICO%')) 
OR ((nombre_completo_propietario = 'IAVH')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO DE INVESTIGACIONES MARINAS Y COSTERAS%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO DE PLANIFICACION Y PROMOCION DE SOLUCIONES ENERG%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO GEOGRAFICO AGUSTIN CODAZZI%')) 
OR ((nombre_completo_propietario = 'IGAC')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO NACIONAL DE%')) 
OR ((nombre_completo_propietario = 'INVIAS')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO NACIONAL PARA%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO NACIONAL PENI%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO TOLIMENSE DE FORMACION TEC%')) 
OR ((nombre_completo_propietario ILIKE '%INTERCONEXION ELEC%')) 
OR ((nombre_completo_propietario ILIKE '%ISAGEN%')) 
OR ((nombre_completo_propietario ILIKE '%MINISTERIO DE%')) 
OR ((nombre_completo_propietario ILIKE '%PARQUES NACIONALES NATURALES DE COLOMBIA%')) 
OR ((nombre_completo_propietario ILIKE '%PNN%')) 
OR ((nombre_completo_propietario ILIKE '%SERVICIO GEOLOGICO COLOMBIANO%')) 
OR ((nombre_completo_propietario ILIKE '%SERVICIO NACIONAL DE APRENDIZAJE%')) 
OR ((nombre_completo_propietario = 'SENA')) 
OR ((nombre_completo_propietario ILIKE '%SOCIEDAD DE ACTIVOS ESPECIALES%')) 
OR ((nombre_completo_propietario = 'SAE')) 
OR ((nombre_completo_propietario ILIKE '%SOCIEDAD FIDUCIARIA DE DESARROLLO AGRO%')) 
OR ((nombre_completo_propietario ILIKE '%SUPERINTENDENCIA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIDAD ADMINISTRATIVA ESPECIAL%')) 
OR ((nombre_completo_propietario ILIKE '%UNIDAD DE PLANEACION%')) 
OR ((nombre_completo_propietario ILIKE '%UNIDAD DE PLANIFICACION%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD COLEGIO MAYOR DE CUNDINAMARCA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD DE CALDAS%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD DE CORDOBA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD DE LA AMAZONIA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD DE LOS LLANOS%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD DEL CAUCA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD DEL PACIFICO%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD MILITAR NUEVA GRANADA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD NACIONAL ABIERTA Y A DISTANCIA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD NACIONAL DE COLOMBIA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD PEDAGOGICA NACIONAL%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD PEDAGOGICA Y TECNOLOGICA DE COLOMBIA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD POPULAR DEL CESAR%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD SURCOLOMBIANA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD TECNOLOGICA DE PEREIRA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD TECNOLOGICA DEL CHOCO DIEGO LUIS CORDOBA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIVERSIDAD%') AND ((nombre_completo_propietario ILIKE '%ANTIO%') OR (nombre_completo_propietario ILIKE '%CARTAGENA%') OR (nombre_completo_propietario ILIKE '%CUNDINAMARCA%') OR (nombre_completo_propietario ILIKE '%GUAJIRA%') OR (nombre_completo_propietario ILIKE '%NARI%') OR (nombre_completo_propietario ILIKE '%PAMPLONA%') OR (nombre_completo_propietario ILIKE '%SUCRE%') OR (nombre_completo_propietario ILIKE '%ATLANTICO%') OR (nombre_completo_propietario ILIKE '%MAGDALENA%') OR (nombre_completo_propietario ILIKE '%QUINDIO%') OR (nombre_completo_propietario ILIKE '%TOLIMA%') OR (nombre_completo_propietario ILIKE '%VALLE%') OR (nombre_completo_propietario ILIKE '%DISTRITAL%'))) 
OR ((nombre_completo_propietario ILIKE '%ZONA FRANCA ANDINA MANIZALES%')) 
OR ((nombre_completo_propietario = 'UNAD')) 
OR ((nombre_completo_propietario ILIKE '%UPTC%')) 
OR (((nombre_completo_propietario ILIKE '%DISTRITO%') OR (nombre_completo_propietario ILIKE '%DISTRITAL%')) AND ((nombre_completo_propietario ILIKE '%BARRANQUILLA%') OR (nombre_completo_propietario ILIKE '%BUENAVENTURA%') OR (nombre_completo_propietario ILIKE '%CARTAGENA%') OR (nombre_completo_propietario ILIKE '%SANTA MARTA%') OR (nombre_completo_propietario ILIKE '%RIOHACHA%'))) 
OR ((nombre_completo_propietario ILIKE '%COOPERATIVA AGROPECUARIA%') AND (nombre_completo_propietario ILIKE '%GINEBRA%')) 
OR ((nombre_completo_propietario ILIKE '%COOPERATIVA%') AND (nombre_completo_propietario ILIKE '%ENTIDADES%') AND (nombre_completo_propietario ILIKE '%SALUD%') AND (nombre_completo_propietario ILIKE '%RISARALDA%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION CULTURAL%') AND (nombre_completo_propietario ILIKE '%MUNIC%') AND (nombre_completo_propietario ILIKE '%VILLAV%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION FORESTAL%') AND (nombre_completo_propietario ILIKE '%NARIN%')) 
OR ((nombre_completo_propietario ILIKE '%COROPORACION%') AND (nombre_completo_propietario ILIKE '%NACIONA%') AND (nombre_completo_propietario ILIKE '%INV%') AND (nombre_completo_propietario ILIKE '%FORESTAL%')) 
OR ((nombre_completo_propietario ILIKE '%DEPARTAMENTO ADMINISTRATIVO DE%')) 
OR ((nombre_completo_propietario ILIKE '%DEPARTAMENTO%') AND (nombre_completo_propietario ILIKE '%ADMINISTRATIVO%') AND (nombre_completo_propietario ILIKE '%AMBIENTE%') AND (nombre_completo_propietario ILIKE '%BARR%')) 
OR ((nombre_completo_propietario ILIKE '%DIRECCION%') AND (nombre_completo_propietario ILIKE '%TERRITORIAL%') AND (nombre_completo_propietario ILIKE '%SALUD%') AND (nombre_completo_propietario ILIKE '%CALDAS%')) 
OR ((nombre_completo_propietario ILIKE '%E%') AND (nombre_completo_propietario ILIKE '%CENTRO DE SALUD%')) 
OR ((nombre_completo_propietario ILIKE '%E.S.E%') AND (nombre_completo_propietario ILIKE '%CENTRO DE SALUD%')) 
OR ((nombre_completo_propietario ILIKE '%I%') AND (nombre_completo_propietario ILIKE '%CENTRO DE SALUD%')) 
OR ((nombre_completo_propietario ILIKE '%I%') AND (nombre_completo_propietario ILIKE '%PUESTO%') AND (nombre_completo_propietario ILIKE '%SALUD%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA SOCIAL DEL ESTADO%')) 
OR ((nombre_completo_propietario ILIKE '%ESE HOSPITAL%')) 
OR ((nombre_completo_propietario ILIKE '%E.S.E%') AND (nombre_completo_propietario ILIKE '%HOSPITAL%')) 
OR ((nombre_completo_propietario ILIKE '%HOSPITAL LOCAL%')) 
OR ((nombre_completo_propietario ILIKE '%HOSPITAL REGIONAL%')) 
OR ((nombre_completo_propietario ILIKE '%E%') AND (nombre_completo_propietario ILIKE '%AGUAS DE%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA%') AND (nombre_completo_propietario ILIKE '%PUBLIC%')) 
OR ((nombre_completo_propietario ILIKE '%EMSERCOTA%')) 
OR ((nombre_completo_propietario ILIKE '%MUNICIPAL DE SERV%')) 
OR ((nombre_completo_propietario ILIKE '%ACUEDUCTO Y ALCANTARILLADO%')) 
OR ((nombre_completo_propietario ILIKE '%E%') AND (nombre_completo_propietario ILIKE '%ACUEDUCTO%')) 
OR ((nombre_completo_propietario ILIKE '%AGUAS Y ASEO%')) 
OR ((nombre_completo_propietario ILIKE '%AGUA POTABLE%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA DE ENERGIA%')) 
OR ((nombre_completo_propietario ILIKE '%SERVICIOS PUBLICOS%')) 
OR ((nombre_completo_propietario ILIKE '%GOBERNACI%')) 
OR ((nombre_completo_propietario ILIKE '%EMSIRVA%')) 
OR ((nombre_completo_propietario ILIKE '%ENVIASEO%')) 
OR ((nombre_completo_propietario ILIKE '%EPM TELEC%')) 
OR ((nombre_completo_propietario ILIKE '%HIDROELECTRICA PESCAD%')) 
OR ((nombre_completo_propietario ILIKE '%E%') AND (nombre_completo_propietario ILIKE '%HYDROS%')) 
OR ((nombre_completo_propietario ILIKE '%ALCANTARILLADO Y ASEO%')) 
OR ((nombre_completo_propietario ILIKE '%PLANTA DE TRATAMIENTO%')) 
OR ((nombre_completo_propietario ILIKE '%AGROINDUSTRIAL CASANARE%') AND (nombre_completo_propietario ILIKE '%LACTEOS%')) 
OR ((nombre_completo_propietario ILIKE '%AGROINDUSTRIAL%') AND (nombre_completo_propietario ILIKE '%ORIENTE%')) 
OR ((nombre_completo_propietario ILIKE '%AGROPECUARIA%') AND (nombre_completo_propietario ILIKE '%YONDO%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA%') AND (nombre_completo_propietario ILIKE '%LICORE%') AND (nombre_completo_propietario ILIKE '%CUNDIN%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA%') AND (nombre_completo_propietario ILIKE '%LICORE%') AND (nombre_completo_propietario ILIKE '%CAQUET%')) 
OR ((nombre_completo_propietario ILIKE '%OBRAS SANITARIAS DE%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA%') AND (nombre_completo_propietario ILIKE '%LICORE%') AND (nombre_completo_propietario ILIKE '%NARI%')) 
OR ((nombre_completo_propietario ILIKE '%DEPORT%') AND (nombre_completo_propietario ILIKE '%MUNICIP%')) 
OR ((nombre_completo_propietario ILIKE '%FONDO%') AND (nombre_completo_propietario ILIKE '%FOMEN%') AND ((nombre_completo_propietario ILIKE '%MINER%') OR (nombre_completo_propietario ILIKE '%AGROPEC%'))) 
OR ((nombre_completo_propietario ILIKE '%INSTIT%') AND (nombre_completo_propietario ILIKE '%EDUC%') AND ((nombre_completo_propietario ILIKE '%GUAJIRA%') OR (nombre_completo_propietario ILIKE '%FLORIDA%') OR (nombre_completo_propietario ILIKE '%DAGUA%') OR (nombre_completo_propietario ILIKE '%RURAL%') OR (nombre_completo_propietario ILIKE '%AGROPEC%'))) 
OR ((nombre_completo_propietario ILIKE '%INST%') AND (nombre_completo_propietario ILIKE '%CULT%') AND (nombre_completo_propietario ILIKE '%TURIS%')) 
OR ((nombre_completo_propietario ILIKE '%INST%') AND (nombre_completo_propietario ILIKE '%DEP%') AND (nombre_completo_propietario ILIKE '%RECR%')) 
OR ((nombre_completo_propietario ILIKE '%NEPOM%')) 
OR ((nombre_completo_propietario ILIKE '%INDER%')) 
OR ((nombre_completo_propietario ILIKE '%IMDERCUT%')) 
OR ((nombre_completo_propietario ILIKE '%REFORESTADORA INDUSTRIAL%') AND (nombre_completo_propietario ILIKE '%ANTIOQUIA%')) 
OR ((nombre_completo_propietario ILIKE '%MUNICIPIO%')) 
OR ((nombre_completo_propietario ILIKE '%VACANTE%')) 
OR ((nombre_completo_propietario ILIKE '%CATASTRAL%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO COLOMBIANO DE%')) 
OR ((nombre_completo_propietario ILIKE '%ICBF%')) 
OR ((nombre_completo_propietario ILIKE '%DEPARTAMENTO %')) 
OR ((nombre_completo_propietario ILIKE '% SAE %')) 
OR ((nombre_completo_propietario ILIKE '%SOCIEDAD DE ACTIVOS ESPECIALES%')) 
OR ((nombre_completo_propietario ILIKE '%INVIAS%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUTO NACIONAL DE%')) 
OR ((nombre_completo_propietario ILIKE '%DESARROLLO RURAL%')) 
OR ((nombre_completo_propietario ILIKE '%MINISTERIO%')) 
OR (((nombre_completo_propietario ILIKE '%INSTITUTO%') OR (nombre_completo_propietario ILIKE '%INSTITUCION%')) AND (nombre_completo_propietario ILIKE '%DISTRITAL%')) 
OR ((nombre_completo_propietario ILIKE '%SECRETARIA DE OBRAS PUBLICAS%')) 
OR ((nombre_completo_propietario = 'BANCO DE TIERRAS DEL MUNICIPIO')) 
OR ((nombre_completo_propietario = 'DEPARTAMENTO')) 
OR ((nombre_completo_propietario ILIKE '%ADUANA%')) 
OR ((nombre_completo_propietario ILIKE '%AGRARIA%')) 
OR ((nombre_completo_propietario ILIKE '%ALCALDIA%')) 
OR ((nombre_completo_propietario ILIKE '%VIVIENDA MILITAR%')) 
OR ((nombre_completo_propietario ILIKE '%BANC%') AND (nombre_completo_propietario ILIKE '%CENTR%') AND (nombre_completo_propietario ILIKE '%HIPOTE%')) 
OR ((nombre_completo_propietario ILIKE '%AHORRO%')) 
OR ((nombre_completo_propietario ILIKE '%BOMBERO%')) 
OR ((nombre_completo_propietario ILIKE '%COMIT%') AND (nombre_completo_propietario ILIKE '%DEPARTA%')) 
OR ((nombre_completo_propietario ILIKE '%COMIT%') AND (nombre_completo_propietario ILIKE '%JUSTICI%')) 
OR ((nombre_completo_propietario ILIKE '%COMIT%') AND (nombre_completo_propietario ILIKE '%MUNICI%')) 
OR ((nombre_completo_propietario ILIKE '%CONTRALOR%')) 
OR ((nombre_completo_propietario = 'DIAN')) 
OR ((nombre_completo_propietario ILIKE '%D.I.A.N%') OR (nombre_completo_propietario ILIKE '% DIAN %')) 
OR ((nombre_completo_propietario ILIKE '%DIREC%') AND (nombre_completo_propietario ILIKE '%NAC%')) 
OR ((nombre_completo_propietario ILIKE '%DIREC%') AND (nombre_completo_propietario ILIKE '%GEN%')) 
OR ((nombre_completo_propietario ILIKE '%EDUC%') AND (nombre_completo_propietario ILIKE '%NACIO%')) 
OR ((nombre_completo_propietario ILIKE '%EMPRESA COLOMBIANA%')) 
OR ((nombre_completo_propietario ILIKE '%FEDE%') AND (nombre_completo_propietario ILIKE '%NACI%')) 
OR ((nombre_completo_propietario ILIKE '%FISCALIA%')) 
OR ((nombre_completo_propietario ILIKE '%FONDO%') AND (nombre_completo_propietario ILIKE '%NACIO%')) 
OR ((nombre_completo_propietario ILIKE '%DIR%') AND (nombre_completo_propietario ILIKE '%IMPU%') AND (nombre_completo_propietario ILIKE '%ADU%')) 
OR ((nombre_completo_propietario ILIKE '%INSCREDIAL%')) 
OR ((nombre_completo_propietario ILIKE '%INSTI%') AND (nombre_completo_propietario ILIKE '%CREDI%')) 
OR ((nombre_completo_propietario ILIKE '%INSTI%') AND (nombre_completo_propietario ILIKE '%GEO%')) 
OR ((nombre_completo_propietario ILIKE '%INSTI%') AND (nombre_completo_propietario ILIKE '%NACI%')) 
OR ((nombre_completo_propietario ILIKE '%INURBE%')) 
OR ((nombre_completo_propietario ILIKE '%JUZGADO%')) 
OR ((nombre_completo_propietario ILIKE '%MUNICIPAL%')) 
OR ((nombre_completo_propietario ILIKE '%OBRA%') AND (nombre_completo_propietario ILIKE '%PUBLIC%')) 
OR ((nombre_completo_propietario ILIKE '%POLICIA%')) 
OR ((nombre_completo_propietario ILIKE '%REGISTRADU%')) 
OR ((nombre_completo_propietario ILIKE '%SENA%') AND (nombre_completo_propietario ILIKE '%SERV%') AND (nombre_completo_propietario ILIKE '%NAC%')) 
OR ((nombre_completo_propietario ILIKE '%TESORERIA%')) 
OR ((nombre_completo_propietario ILIKE '%UNIDA%') AND (nombre_completo_propietario ILIKE '%TIERRA%')) 
OR ((nombre_completo_propietario ILIKE '%TRIBUNAL%')) 
OR ((nombre_completo_propietario ILIKE '%TELEVI%') AND (nombre_completo_propietario ILIKE '%NAC%')) 
OR ((nombre_completo_propietario ILIKE '%GOB%') AND (nombre_completo_propietario ILIKE '%NAC%')) 
OR ((nombre_completo_propietario ILIKE '%TELECOM%')) 
OR ((nombre_completo_propietario ILIKE '%INRAVISION%')) 
OR ((nombre_completo_propietario ILIKE '%FERRO%') AND (nombre_completo_propietario ILIKE '%NAC%')) 
OR ((nombre_completo_propietario ILIKE '%SERV%') AND (nombre_completo_propietario ILIKE '%NAC%') AND (nombre_completo_propietario ILIKE '%APRE%')) 
OR ((nombre_completo_propietario ILIKE '%INVISAN%')) 
OR ((nombre_completo_propietario ILIKE '%INST%') AND (nombre_completo_propietario ILIKE '%DIST%')) 
OR ((nombre_completo_propietario ILIKE '%INDERENA%')) 
OR ((nombre_completo_propietario ILIKE '%INDUNAL%')) 
OR ((nombre_completo_propietario ILIKE '%INDU%') AND (nombre_completo_propietario ILIKE '%NAC%') AND (nombre_completo_propietario ILIKE '%ALI%')) 
OR ((nombre_completo_propietario ILIKE '%C V C CORPORACION AUTONOMA REGION%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION AUTONOMA REGIONAL%')) 
OR ((nombre_completo_propietario ILIKE '%CORPORACION AUTONOMA REGION%')) 
OR ((nombre_completo_propietario ILIKE '%INSTITUCION EDUCATIVA%')) 
OR ((nombre_completo_propietario ILIKE '%CAJA DE CREDITO AGRARIO%')) 
OR ((nombre_completo_propietario ILIKE '%MUNICIPO%')) 
OR ((nombre_completo_propietario ILIKE '%DEPARTAMENTO DE%')) 
OR ((nombre_completo_propietario ILIKE '%AGENC%') AND (nombre_completo_propietario ILIKE '%NAC%') AND (nombre_completo_propietario ILIKE '%INFRA%')) 
OR ((nombre_completo_propietario = 'ANI')) 
OR ((nombre_completo_propietario = 'INSTITUTO COLOMBIANO DE DESARROLLO RURAL'))
OR ((nombre_completo_propietario ILIKE '%INST%' AND nombre_completo_propietario ILIKE '%COL%' 
	AND nombre_completo_propietario ILIKE '%DESAR%' AND nombre_completo_propietario ILIKE '%RURAL%'))
OR ((nombre_completo_propietario = 'ANT'))
OR ((nombre_completo_propietario ILIKE '%INCODER%'))
OR ((nombre_completo_propietario ILIKE '%INCORA%'))
OR ((nombre_completo_propietario ILIKE '% ANT %'))
OR ((nombre_completo_propietario ILIKE '%AGENCIA NACIONAL DE TIERRAS%'))
OR ((nombre_completo_propietario ILIKE '%ANT AGENCIA NACIONAL DE TIERRA%'))
OR ((nombre_completo_propietario = 'INSTITUTO COLOMBIANO DE LA REFORMA AGRARIA'))
OR ((nombre_completo_propietario ILIKE '%INST%' AND nombre_completo_propietario ILIKE '%COL%' 
	AND nombre_completo_propietario ILIKE '%REFO%' AND nombre_completo_propietario ILIKE '%AGRA%')))
), c3 AS(
SELECT DISTINCT c2.pk_predio, c2.numero_predial_nacional FROM c2
), c4 as(
SELECT c3.pk_predio, count(*) FROM c3 
JOIN actualizacion.lc_jur_derecho ljd ON c3.pk_predio = ljd.fk_id 
JOIN actualizacion.lc_jur_interesado lji ON ljd.pk_id = lji.fk_id
WHERE lji.estado_propietario <> 0 GROUP BY 1 HAVING count(*) > 1
)
SELECT DISTINCT ON (lgp.numero_predial_nacional) 'Jur_82' id_regla, 'Interesado' componente, 
'Predios con interesados publicos y con interesados privados activos' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_Jur_Derecho' tabla_error_1, 
ljd.pk_id pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, lgp.numero_predial_nacional, 
lgp.matricula_inmobiliaria, lgdt.ilicode destino_economico, lgp.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, 
null tipo_unidad_construccion, null uso_construccion, null area_construida, 
null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, 
lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from c4 JOIN actualizacion.lc_gen_predio lgp ON c4.pk_predio = lgp.pk_id
LEFT JOIN actualizacion.lc_jur_derecho ljd ON lgp.pk_id = ljd.fk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on lgp.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on lgp.pk_id = lge.fk_id and 'Jur_82' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on lgp.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
order by 10,4,14;
