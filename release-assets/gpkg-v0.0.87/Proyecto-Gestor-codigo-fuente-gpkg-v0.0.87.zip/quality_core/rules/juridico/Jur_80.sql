-- name: Jur_80
with c as(
select lgp.* from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false)  
), c2 as(
SELECT c.*, ljd.pk_id pk_derecho FROM c JOIN actualizacion.lc_jur_derecho ljd ON c.pk_id = ljd.fk_id 
JOIN actualizacion.lc_jur_interesado lji ON ljd.pk_id = lji.fk_id 
WHERE lji.estado_propietario = 1
), c3 as(
SELECT c.*, ljd.pk_id pk_derecho FROM c JOIN actualizacion.lc_jur_derecho ljd ON c.pk_id = ljd.fk_id 
JOIN actualizacion.lc_jur_interesado lji ON ljd.pk_id = lji.fk_id 
WHERE lji.estado_propietario = 0
)
SELECT DISTINCT 'Jur_80' id_regla, 'Juridico' componente, 'Predios con interesados nuevos sin propietarios con cambio de propietario' descripcion_regla, 
c2.nombre_proyecto proyecto, c2.pk_id pk_id_predio, 'LC_Jur_Derecho' tabla_error_1, 
c2.pk_derecho pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, c2.numero_predial_nacional, 
c2.matricula_inmobiliaria, lgdt.ilicode destino_economico, c2.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, 
null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, 
null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, 
lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, 
null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, null custom_6, 
true custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
FROM c2 LEFT JOIN c3 ON c2.pk_id = c3.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on c2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on c2.pk_id = lge.fk_id and 'Jur_80' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on c2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON c2.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON c2.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON c2.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON c2.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON c2.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON c2.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON c2.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON c2.geografico_estado_control = lgec_geo_ctrl.itfcode
where c3.pk_id IS NULL AND c2.destinacion_economica_anterior IS NOT NULL
order by 10,4,14;
