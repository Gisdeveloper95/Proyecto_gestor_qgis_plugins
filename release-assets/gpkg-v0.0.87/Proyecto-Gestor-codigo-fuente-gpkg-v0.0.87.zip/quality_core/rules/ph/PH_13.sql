-- name: PH_13
with p as(
select lpp.* from actualizacion.lc_ph_predio lpp join actualizacion.lc_ph_novedadnumeropredial lpn on lpp.pk_id = lpn.fk_id where lpn.tipo_novedad in (5,6,7,8)
), p2 as(select lpp.* from actualizacion.lc_ph_predio lpp left join p on lpp.pk_id = p.pk_id where p.pk_id is null
)
select 'PH_13' id_regla, 'Juridico' componente, 'Predios PH sin matricula inmobiliaria o en 0' descripcion_regla, lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 
'LC_Ph_Predio' tabla_error_1, p2.pk_id pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, p2.numero_predial_nacional, p2.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, p2.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, 
null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, null custom_6, 
false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p2 join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on p2.pk_id = lge.fk_id and 'PH_13' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where p2.matricula_inmobiliaria = 0 or p2.matricula_inmobiliaria is null order by 10,4,14;
