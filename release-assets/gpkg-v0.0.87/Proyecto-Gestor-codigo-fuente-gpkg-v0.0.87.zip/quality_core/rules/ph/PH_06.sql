-- name: PH_06
with a as(
select lgp.pk_id pk_gen_predio, lgp.numero_predial_nacional numero_predial_gen_matriz, lgp.nombre_proyecto, lgp.matricula_inmobiliaria fmi_matriz, 
lgp.destinacion_economica destino_matriz, lgp.area_catastral_terreno area_matriz, lgp.predio_tiene_cambio_fisico, lgp.ph_predio_matriz_menor_10_unidades, 
lgp.numero_predial_nacional_anterior numero_predial_matriz_anterior, 
lpp.* from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_ph_predio lpp on lgp.pk_id = lpp.fk_id 
where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
), a2 as(select a.* from a where a.numero_predial_matriz_anterior is null and substring(a.numero_predial_nacional,22,1) = '9'
), a3 as(select a2.*, ljn.pk_id pk_id_novedad from a2 join actualizacion.lc_jur_novedadnumeropredial ljn on a2.pk_id = ljn.fk_id
join actualizacion.lc_jur_novedadnumeropredial_tipo ljnt on ljn.tipo_novedad = ljnt.itfcode where ljnt.ilicode ilike '%englobe%'
)
select distinct on (a2.numero_predial_gen_matriz) 'PH_06' id_regla, 'PH' componente, 'Predios PH Matriz nuevos sin novedad de desenglobe o englobe' descripcion_regla, 
a2.nombre_proyecto proyecto, a2.pk_gen_predio pk_id_predio, 'LC_Gen_Predio' tabla_error_1, a2.pk_gen_predio pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, 
a2.numero_predial_gen_matriz numero_predial_nacional, a2.fmi_matriz matricula_inmobiliaria, lgdt.ilicode destino_economico, a2.area_matriz area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, 
null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from a2 left join a3 on a2.pk_id = a3.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a2.destino_matriz = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on a2.pk_id = lge.fk_id and 'PH_06' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a2.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on a2.pk_gen_predio = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where a3.pk_id is null order by 10,4,14;
