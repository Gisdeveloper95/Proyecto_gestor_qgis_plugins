-- name: PH_17
with a as(
select lpp.* from actualizacion.lc_ph_predio lpp join actualizacion.lc_ph_novedadnumeropredial lpn on lpp.pk_id = lpn.fk_id where lpn.tipo_novedad in (5,6,7,8)
), a2 as(select lpp.* from actualizacion.lc_ph_predio lpp left join a on lpp.pk_id = a.pk_id where a.pk_id is null
), p as(select dac.nombre_proyecto, dac.pk_id pk_id_predio, dac.numero_predial_nacional, dac.pk_carac pk_id_caracteristicaconstruccion, dac.identificador, 
dac.tipo_unidad_construccion, dac.uso_construccion, dac.area_construida, dac.total_plantas, dac.puntaje from general.determinacion_area_construccion dac 
where dac.tipo_unidad_construccion is not null and dac.tipo_unidad_construccion <> 4
), p2 as(select p.pk_id_predio, p.tipo_unidad_construccion, sum(area_construida) sum_area_construida from p group by 1,2
), p3 as(select p2.pk_id_predio, max(sum_area_construida) max_area_construida from p2 group by 1
), p4 as(select p.*, p3.max_area_construida from p join p3 on p.pk_id_predio = p3.pk_id_predio and p.area_construida = p3.max_area_construida
)
select 'PH_17' id_regla, 'PH' componente, 
'Predios PH con destino economico Industrial con la Caracteristica Unidad de Construccion de mayor área diferente a un uso de construcción de tipo industrial' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, a2.pk_id pk_tabla_error_1, 'LC_PH_Caracteristicasunidadconstruccion' tabla_error_2, 
p4.pk_id_caracteristicaconstruccion pk_tabla_error_2, a2.numero_predial_nacional, a2.matricula_inmobiliaria, lgdt.ilicode destino_economico, a2.area_catastral_terreno, 
p4.identificador identificador_caracteristica_unidad_construccion, p4.total_plantas, lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, p4.area_construida, 
p4.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from a2 
join p4 on a2.pk_id = p4.pk_id_predio 
join actualizacion.lc_gen_predio lgp on a2.fk_id = lgp.pk_id
join actualizacion.lc_reco_unidadconstruccion_tipo ltut on p4.tipo_unidad_construccion = ltut.itfcode
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a2.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on p4.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on p4.uso_construccion = lgut.itfcode 
left join actualizacion.lc_gen_excepciones lge on a2.pk_id = lge.fk_id and 'PH_17' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where a2.destinacion_economica = 11 and p4.tipo_unidad_construccion <> 2 order by 10,4,14;
