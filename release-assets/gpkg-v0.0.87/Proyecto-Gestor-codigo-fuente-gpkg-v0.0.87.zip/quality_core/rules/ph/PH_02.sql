-- name: PH_02
WITH predios_cancelados as(
select lgp.pk_id, lgp.numero_predial_nacional
from actualizacion.lc_gen_predio lgp join actualizacion.lc_jur_novedadnumeropredial ljn on lgp.pk_id = ljn.fk_id
where ljn.tipo_novedad in (5,6,7,8) OR lgp.juridico_predio_cancelado = true
union
select lgp.pk_id, lgp.numero_predial_nacional 
from actualizacion.lc_ph_predio lgp join actualizacion.lc_ph_novedadnumeropredial ljn on lgp.pk_id = ljn.fk_id
where ljn.tipo_novedad in (5,6,7,8)
), p as(
SELECT lgp.pk_id, lgp.numero_predial_nacional numero_predial_matriz, lgp.matricula_inmobiliaria matricula_inmobiliaria_matriz, 
lgp.nombre_proyecto, lgp.destinacion_economica destino_matriz, lgp.area_catastral_terreno area_matriz
FROM actualizacion.lc_gen_predio lgp LEFT JOIN predios_cancelados pc ON lgp.pk_id = pc.pk_id
WHERE pc.pk_id IS NULL ORDER BY 2
), p2 as(
SELECT lgp.pk_id pk_ph_predio, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgp.coeficiente, lgp.fk_id
FROM actualizacion.lc_ph_predio lgp LEFT JOIN predios_cancelados pc ON lgp.pk_id = pc.pk_id
WHERE pc.pk_id IS NULL ORDER BY 2
), p3 as(
SELECT p.*, p2.* FROM p2 JOIN p ON p2.fk_id = p.pk_id
), p4 as(
SELECT p3.pk_id, p3.numero_predial_matriz, p3.matricula_inmobiliaria_matriz, p3.nombre_proyecto, p3.destino_matriz, p3.area_matriz,
sum(p3.coeficiente) coeficiente_total 
FROM p3 GROUP BY 1,2,3,4,5,6 HAVING sum(p3.coeficiente) < 97 OR sum(p3.coeficiente) > 103
)
select 'PH_02' id_regla, 'Juridico' componente, 'Predios PH Matriz con un coeficiente total diferente a 100%' descripcion_regla, 
p4.nombre_proyecto proyecto, p4.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, p4.pk_id pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, 
p4.numero_predial_matriz numero_predial_nacional, p4.matricula_inmobiliaria_matriz matricula_inmobiliaria, lgdt.ilicode destino_economico, p4.area_matriz area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, 
null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p4 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p4.destino_matriz = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on p4.pk_id = lge.fk_id and 'PH_02' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p4.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on p4.pk_id = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
order by numero_predial_matriz,10,4,14;
