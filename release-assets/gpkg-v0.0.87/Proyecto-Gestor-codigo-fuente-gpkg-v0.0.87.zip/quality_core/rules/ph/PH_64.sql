-- name: PH_64
WITH p AS(
SELECT lpp.* FROM actualizacion.lc_ph_predio lpp JOIN actualizacion.lc_ph_novedadnumeropredial lpn ON lpp.pk_id = lpn.fk_id WHERE lpn.tipo_novedad in (5,6,7,8)
), p2 AS(SELECT lpp.* from actualizacion.lc_ph_predio lpp LEFT JOIN p on lpp.pk_id = p.pk_id WHERE p.pk_id IS  NULL
), p3 AS(
SELECT lgp.pk_id FROM actualizacion.lc_gen_predio lgp JOIN actualizacion.lc_jur_novedadnumeropredial ljn ON lgp.pk_id = ljn.fk_id WHERE ljn.tipo_novedad IN (5,6,7,8)
UNION 
SELECT lgp.pk_id FROM actualizacion.lc_gen_predio lgp WHERE lgp.juridico_predio_cancelado = TRUE AND substring(lgp.numero_predial_nacional,22,1) = '9' 
), p4 as(
SELECT p2.* FROM p2 LEFT JOIN p3 ON p2.fk_id = p3.pk_id WHERE p3.pk_id IS NULL
), p5 as(
SELECT fk_id, numero_predial_matriz, destinacion_economica, count(*) cantidad_predios FROM p4 GROUP BY 1,2,3 ORDER BY 2
), p6 as(
SELECT fk_id, numero_predial_matriz, count(*) FROM p5 GROUP BY 1,2 HAVING count(*) > 1
), p7 as(
SELECT p5.fk_id pk_matriz, p5.numero_predial_matriz, p5.destinacion_economica, p5.cantidad_predios 
FROM p6 JOIN p5 ON p6.fk_id = p5.fk_id 
ORDER BY 2,3
)
select distinct 'PH_64' id_regla, 'PH' componente, 'Predios PH Matrices con mas de un Destino Economico' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, lgp.pk_id pk_tabla_error_1, null tabla_error_2, 
null pk_tabla_error_2, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgdt.ilicode destino_economico, lgp.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, 
null puntaje_calificacion, NULL tipo_novedad, NULL numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, 
lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, 
now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, 
null custom_8, null custom_9, p7.cantidad_predios custom_10, null custom_11, null custom_12 
from p7 LEFT JOIN actualizacion.lc_gen_predio lgp ON p7.pk_matriz = lgp.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p7.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on lgp.pk_id = lge.fk_id and 'PH_64' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on lgp.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
order by 10,4,14;
