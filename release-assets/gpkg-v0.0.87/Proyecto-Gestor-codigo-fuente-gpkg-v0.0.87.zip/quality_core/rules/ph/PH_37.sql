-- name: PH_37
with p as(
select lpp.* from actualizacion.lc_ph_predio lpp join actualizacion.lc_ph_novedadnumeropredial lpn on lpp.pk_id = lpn.fk_id where lpn.tipo_novedad in (5,6,7,8)
), p2 as(select lpp.* from actualizacion.lc_ph_predio lpp left join p on lpp.pk_id = p.pk_id where p.pk_id is null
), p3 as(select p2.*, lgp.nombre_proyecto from p2 join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id where lgp.predio_tiene_cambio_fisico = true 
and (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false)
)
select 'PH_37' id_regla, 'PH' componente, 'Caracteristica Unidad de Construccion PH sin area construida con cambio fisico' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, p3.pk_id pk_tabla_error_1, 
'LC_PH_CaracteristicasUnidadConstruccion' tabla_error_2, dac.pk_carac pk_tabla_error_2, p3.numero_predial_nacional, p3.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, p3.area_catastral_terreno, dac.identificador identificador_caracteristica_unidad_construccion, 
dac.total_plantas total_plantas, lru.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, 
null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p3 join general.determinacion_area_construccion dac on p3.pk_id = dac.pk_id 
join actualizacion.lc_gen_predio lgp on p3.fk_id = lgp.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p3.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_reco_unidadconstruccion_tipo lru on dac.tipo_unidad_construccion = lru.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_gen_excepciones lge on p3.pk_id = lge.fk_id and 'PH_37' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p3.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where dac.area_construida is null order by 10,4,14;
