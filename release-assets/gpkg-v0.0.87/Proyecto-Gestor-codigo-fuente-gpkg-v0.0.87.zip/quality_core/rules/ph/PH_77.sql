-- name: PH_77
WITH p AS(
SELECT lpp.* FROM actualizacion.lc_ph_predio lpp JOIN actualizacion.lc_ph_novedadnumeropredial lpn ON lpp.pk_id = lpn.fk_id WHERE lpn.tipo_novedad in (5,6,7,8)
), p2 AS(SELECT lpp.* from actualizacion.lc_ph_predio lpp LEFT JOIN p on lpp.pk_id = p.pk_id WHERE p.pk_id IS  NULL
), p3 AS(
SELECT lgp.pk_id FROM actualizacion.lc_gen_predio lgp JOIN actualizacion.lc_jur_novedadnumeropredial ljn ON lgp.pk_id = ljn.fk_id WHERE ljn.tipo_novedad IN (5,6,7,8)
UNION 
SELECT lgp.pk_id FROM actualizacion.lc_gen_predio lgp WHERE lgp.juridico_predio_cancelado = TRUE AND substring(lgp.numero_predial_nacional,22,1) = '9' 
), p4 as(
SELECT p2.* FROM p2 LEFT JOIN p3 ON p2.fk_id = p3.pk_id WHERE p3.pk_id IS NULL
), p5 as(
select p4.*, lgp.nombre_proyecto, lgp.pk_id pk_predio, lpd.pk_id pk_derecho, lpi.pk_id pk_interesado
from p4 LEFT JOIN actualizacion.lc_gen_predio lgp ON p4.fk_id = lgp.pk_id
join actualizacion.lc_ph_derecho lpd on p4.pk_id = lpd.fk_id 
join actualizacion.lc_ph_interesado lpi on lpd.pk_id = lpi.fk_id 
WHERE lpi.estado_propietario <> 0
), p6 as(
SELECT DISTINCT ON(p4.pk_id) p4.* FROM p4 LEFT JOIN p5 ON p4.pk_id = p5.pk_id WHERE p5.pk_id IS NULL
)
select 'PH_77' id_regla, 'PH' componente, 'Predios PH sin interesados activos' descripcion_regla, lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 
'LC_PH_Predio' tabla_error_1, p6.pk_id pk_tabla_error_1, 'LC_PH_Derecho' tabla_error_2, lpd.pk_id pk_tabla_error_2, 
p6.numero_predial_nacional, p6.matricula_inmobiliaria, lgdt.ilicode destino_economico, p6.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, null uso_construccion, 
null area_construida, null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p6 
LEFT JOIN actualizacion.lc_gen_predio lgp ON p6.fk_id = lgp.pk_id
LEFT JOIN actualizacion.lc_ph_derecho lpd ON p6.pk_id = lpd.fk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p6.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on p6.pk_id = lge.fk_id and 'PH_77' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p6.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
order by 10,4,14;
