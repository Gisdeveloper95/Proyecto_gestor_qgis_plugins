-- name: PH_54
with p as(
select lgp.pk_id pk_matriz, lgp.numero_predial_nacional numero_matriz, lgp.matricula_inmobiliaria matricula_matriz, lgp.destinacion_economica destino_matriz, 
lgp.nombre_proyecto, lpp.pk_id, lpp.numero_predial_nacional, lpp.matricula_inmobiliaria, lpp.destinacion_economica, lpp.area_catastral_terreno, 
ljn.pk_id pk_id_novedad, ljnt.ilicode tipo_novedad, ljn.numero_predial_nacional_novedad
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_ph_predio lpp on lgp.pk_id = lpp.fk_id
join actualizacion.lc_ph_novedadnumeropredial ljn on lpp.pk_id = ljn.fk_id
join actualizacion.lc_jur_novedadnumeropredial_tipo ljnt on ljn.tipo_novedad = ljnt.itfcode 
where ljnt.ilicode = 'Desenglobe_Division_Material'
), p2 as(
select lgp.pk_id, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgp.destinacion_economica, lgp.area_catastral_terreno, lgp.nombre_proyecto, 
ljn.pk_id pk_id_novedad, ljnt.ilicode tipo_novedad, ljn.numero_predial_nacional_novedad
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_jur_novedadnumeropredial ljn on lgp.pk_id = ljn.fk_id
join actualizacion.lc_jur_novedadnumeropredial_tipo ljnt on ljn.tipo_novedad = ljnt.itfcode 
where ljnt.ilicode = 'Cancelacion_por_Desenglobe'
union
select lgp.pk_id, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgp.destinacion_economica, lgp.area_catastral_terreno, lgp.nombre_proyecto, 
ljn.pk_id pk_id_novedad, ljnt.ilicode tipo_novedad, ljn.numero_predial_nacional_novedad
from actualizacion.lc_gen_predio lgp 
join actualizacion.lc_ph_predio lpp on lgp.pk_id = lpp.fk_id
join actualizacion.lc_ph_novedadnumeropredial ljn on lpp.pk_id = ljn.fk_id
join actualizacion.lc_jur_novedadnumeropredial_tipo ljnt on ljn.tipo_novedad = ljnt.itfcode 
where ljnt.ilicode = 'Cancelacion_por_Desenglobe'
), p3 as(
select p.pk_id pk_matriz, p.numero_matriz, p.matricula_matriz, p.destino_matriz, p.nombre_proyecto, p.pk_id, p.numero_predial_nacional, p.matricula_inmobiliaria, 
p.destinacion_economica, p.area_catastral_terreno, p.pk_id_novedad, p.tipo_novedad, p.numero_predial_nacional_novedad
from p
left join p2 on p.numero_predial_nacional_novedad = p2.numero_predial_nacional
where p2.numero_predial_nacional is null
), p4 as(
select p.numero_predial_nacional_novedad, count(*) from p group by 1 having count(*) = 1
), p5 as(
select p.pk_id pk_matriz, p.numero_matriz, p.matricula_matriz, p.destino_matriz, p.nombre_proyecto, p.pk_id, p.numero_predial_nacional, p.matricula_inmobiliaria, 
p.destinacion_economica, p.area_catastral_terreno, p.pk_id_novedad, p.tipo_novedad, p.numero_predial_nacional_novedad
from p 
join p4 on p.numero_predial_nacional = p4.numero_predial_nacional_novedad or p.numero_predial_nacional = p4.numero_predial_nacional_novedad
), p6 as(
select * from p3 union select * from p5 order by 2,7
)
select distinct 'PH_54' id_regla, 'Novedad_Desenglobe_Division_Material' componente, 
'Si el tipo de novedad es desenglobe division material, minimo 2 predios deben tener el mismo numero predial de referencia con la misma novedad y el predio de referencia debe 
estar cancelado por desenglobe' descripcion_regla, p6.nombre_proyecto proyecto, p6.pk_matriz pk_id_predio, 'LC_PH_Predio' tabla_error_1, 
p6.pk_id pk_tabla_error_1, 'LC_PH_NovedadNumeroPredial' tabla_error_2, p6.pk_id_novedad pk_tabla_error_2, p6.numero_predial_nacional, 
p6.matricula_inmobiliaria, lgdt.ilicode destino_economico, p6.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, 
null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, p6.tipo_novedad, 
p6.numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p6
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p6.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on p6.pk_id = lge.fk_id and 'PH_54' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p6.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on p6.pk_matriz = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
order by 10,4,14;
