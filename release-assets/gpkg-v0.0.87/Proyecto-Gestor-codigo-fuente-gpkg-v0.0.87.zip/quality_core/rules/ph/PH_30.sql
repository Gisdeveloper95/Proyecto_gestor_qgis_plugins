-- name: PH_30
with p as(
select lpp.* from actualizacion.lc_ph_predio lpp join actualizacion.lc_ph_novedadnumeropredial lpn on lpp.pk_id = lpn.fk_id where lpn.tipo_novedad in (5,6,7,8)
), p2 as(select lpp.* from actualizacion.lc_ph_predio lpp left join p on lpp.pk_id = p.pk_id where p.pk_id is null
), p3 as(
select 'PH_30' id_regla, 'PH' componente, 
'Caracteristica Unidad de Construccion PH con el tipo de unidad de construccion diferente al uso de construccion asignado' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, p2.pk_id pk_tabla_error_1, 'LC_PH_Caracteristicasunidadconstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, p2.numero_predial_nacional, p2.matricula_inmobiliaria, lgdt.ilicode destino_economico, p2.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, 
dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p2 join general.determinacion_area_construccion dac on p2.pk_id = dac.pk_id
join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_excepciones lge on p2.pk_id = lge.fk_id and 'PH_30' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where dac.tipo_unidad_construccion = 0 and dac.uso_construccion > 14
union
select 'PH_30' id_regla, 'PH' componente, 
'Caracteristica Unidad de Construccion PH con el tipo de unidad de construccion diferente al uso de construccion asignado' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, p2.pk_id pk_tabla_error_1, 'LC_PH_Caracteristicasunidadconstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, p2.numero_predial_nacional, p2.matricula_inmobiliaria, lgdt.ilicode destino_economico, p2.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, 
lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, null custom_6, 
false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p2 join general.determinacion_area_construccion dac on p2.pk_id = dac.pk_id
join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_excepciones lge on p2.pk_id = lge.fk_id and 'PH_30' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where dac.tipo_unidad_construccion = 1 and (dac.uso_construccion < 15 or dac.uso_construccion > 40)
union
select 'PH_30' id_regla, 'PH' componente, 
'Caracteristica Unidad de Construccion PH con el tipo de unidad de construccion diferente al uso de construccion asignado' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, p2.pk_id pk_tabla_error_1, 'LC_PH_Caracteristicasunidadconstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, p2.numero_predial_nacional, p2.matricula_inmobiliaria, lgdt.ilicode destino_economico, p2.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, 
dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p2 join general.determinacion_area_construccion dac on p2.pk_id = dac.pk_id
join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_excepciones lge on p2.pk_id = lge.fk_id and 'PH_30' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where dac.tipo_unidad_construccion = 2 and (dac.uso_construccion < 41 or dac.uso_construccion > 45)
union
select 'PH_30' id_regla, 'PH' componente, 
'Caracteristica Unidad de Construccion PH con el tipo de unidad de construccion diferente al uso de construccion asignado' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, p2.pk_id pk_tabla_error_1, 'LC_PH_Caracteristicasunidadconstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, p2.numero_predial_nacional, p2.matricula_inmobiliaria, lgdt.ilicode destino_economico, p2.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, 
lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p2 join general.determinacion_area_construccion dac on p2.pk_id = dac.pk_id
join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_excepciones lge on p2.pk_id = lge.fk_id and 'PH_30' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where dac.tipo_unidad_construccion = 3 and (dac.uso_construccion < 46 or dac.uso_construccion > 68)
union
select 'PH_30' id_regla, 'PH' componente, 
'Caracteristica Unidad de Construccion PH con el tipo de unidad de construccion diferente al uso de construccion asignado' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, p2.pk_id pk_tabla_error_1, 'LC_PH_Caracteristicasunidadconstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, p2.numero_predial_nacional, p2.matricula_inmobiliaria, lgdt.ilicode destino_economico, p2.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, 
dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from p2 join general.determinacion_area_construccion dac on p2.pk_id = dac.pk_id
join actualizacion.lc_gen_predio lgp on p2.fk_id = lgp.pk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p2.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_excepciones lge on p2.pk_id = lge.fk_id and 'PH_30' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p2.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
where dac.tipo_unidad_construccion = 4 and dac.uso_construccion < 69 order by 10,4,14
)
select p3.id_regla, p3.componente, p3.descripcion_regla, p3.proyecto, p3.pk_id_predio, p3.tabla_error_1, p3.pk_tabla_error_1, p3.tabla_error_2, 
p3.pk_tabla_error_2, p3.numero_predial_nacional, p3.matricula_inmobiliaria, p3.destino_economico, p3.area_catastral_terreno, 
p3.identificador_caracteristica_unidad_construccion, p3.total_plantas, p3.tipo_unidad_construccion, p3.uso_construccion, p3.area_construida, 
p3.puntaje_calificacion, p3.tipo_novedad, p3.numero_predial_nacional_novedad, p3.tiene_excepcion, p3.descripcion_excepcion, p3.juridico_estado_asignacion, 
p3.juridico_estado_control, p3.reconocimiento_estado_asignacion, p3.reconocimiento_estado_control, p3.informal_estado_asignacion, p3.informal_estado_control, 
p3.geografico_estado_asignacion, p3.geografico_estado_control, p3.pk_lc_gen_predio_usuarioasignacion, p3.usuario_creacion, 
p3.fecha_creacion, p3.usuario_modificacion, p3.fecha_modificacion, p3.custom_1, p3.custom_2, p3.custom_3, p3.custom_4, p3.custom_5, p3.custom_6, 
p3.custom_7, p3.custom_8, p3.custom_9, p3.custom_10, p3.custom_11, p3.custom_12
from p3;
