-- name: Reco_49
with p as(
select lgp.pk_id, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, lgp.destinacion_economica, lgp.nombre_proyecto, 
case
	when lgp.area_catastral_terreno is null or lgp.area_catastral_terreno = 0 then 0
	else lgp.area_catastral_terreno
end area_catastral_terreno,
case
	when lgt.fid is null then 0
	else st_area(lgt.geom)
end area_geometrica_terreno, lgt.pk_id pk_terreno
from actualizacion.lc_gen_predio lgp left join actualizacion.lc_gen_terreno lgt on lgp.numero_predial_nacional = lgt.codigo
), p2 as(
select p.*,
case
	when p.area_catastral_terreno > 0 and (p.area_geometrica_terreno is null or p.area_geometrica_terreno = 0) then 1
	when p.area_catastral_terreno = 0 and (p.area_geometrica_terreno is null or p.area_geometrica_terreno = 0) then 0
	else abs(p.area_catastral_terreno-p.area_geometrica_terreno)/p.area_geometrica_terreno 
end coeficiente_variacion from p
), p3 as(
select p2.*,
case
	when substring(numero_predial_nacional,6,2) <> '00' and area_catastral_terreno <= 80 and coeficiente_variacion > 0.07 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) <> '00' and (area_catastral_terreno > 80 and area_catastral_terreno <= 250) and coeficiente_variacion > 0.06 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) <> '00' and (area_catastral_terreno > 250 and area_catastral_terreno <= 500) and coeficiente_variacion > 0.04 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) <> '00' and area_catastral_terreno > 500 and coeficiente_variacion > 0.03 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) = '00' and area_catastral_terreno <= 2000 and coeficiente_variacion > 0.10 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 2000 and area_catastral_terreno <= 10000) and coeficiente_variacion > 0.09 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 10000 and area_catastral_terreno <= 100000) and coeficiente_variacion > 0.07 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 100000 and area_catastral_terreno <= 500000) and coeficiente_variacion > 0.04 then 'No_Cumple'
	when substring(numero_predial_nacional,6,2) = '00' and area_catastral_terreno > 500000 and coeficiente_variacion > 0.02 then 'No_Cumple'
	else 'Cumple'
end cumple_coeficientevariacion from p2
), p4 AS(
SELECT *, 
CASE
	when substring(numero_predial_nacional,6,2) <> '00' and area_catastral_terreno <= 80 THEN area_catastral_terreno*1.07
	when substring(numero_predial_nacional,6,2) <> '00' and (area_catastral_terreno > 80 and area_catastral_terreno <= 250) THEN area_catastral_terreno*1.06
	when substring(numero_predial_nacional,6,2) <> '00' and (area_catastral_terreno > 250 and area_catastral_terreno <= 500) THEN area_catastral_terreno*1.04
	when substring(numero_predial_nacional,6,2) <> '00' and area_catastral_terreno > 500 THEN area_catastral_terreno*1.03
	when substring(numero_predial_nacional,6,2) = '00' and area_catastral_terreno <= 2000 THEN area_catastral_terreno*1.1
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 2000 and area_catastral_terreno <= 10000) THEN area_catastral_terreno*1.09
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 10000 and area_catastral_terreno <= 100000) THEN area_catastral_terreno*1.07
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 100000 and area_catastral_terreno <= 500000) THEN area_catastral_terreno*1.04
	when substring(numero_predial_nacional,6,2) = '00' and area_catastral_terreno > 500000 THEN area_catastral_terreno*1.02
END limite_superior,
CASE
	when substring(numero_predial_nacional,6,2) <> '00' and area_catastral_terreno <= 80 THEN area_catastral_terreno*0.93
	when substring(numero_predial_nacional,6,2) <> '00' and (area_catastral_terreno > 80 and area_catastral_terreno <= 250) THEN area_catastral_terreno*0.94
	when substring(numero_predial_nacional,6,2) <> '00' and (area_catastral_terreno > 250 and area_catastral_terreno <= 500) THEN area_catastral_terreno*0.96
	when substring(numero_predial_nacional,6,2) <> '00' and area_catastral_terreno > 500 THEN area_catastral_terreno*0.97
	when substring(numero_predial_nacional,6,2) = '00' and area_catastral_terreno <= 2000 THEN area_catastral_terreno*0.9
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 2000 and area_catastral_terreno <= 10000) THEN area_catastral_terreno*0.91
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 10000 and area_catastral_terreno <= 100000) THEN area_catastral_terreno*0.93
	when substring(numero_predial_nacional,6,2) = '00' and (area_catastral_terreno > 100000 and area_catastral_terreno <= 500000) THEN area_catastral_terreno*0.96
	when substring(numero_predial_nacional,6,2) = '00' and area_catastral_terreno > 500000 THEN area_catastral_terreno*0.98
END limite_inferior FROM p3 WHERE cumple_coeficientevariacion= 'No_Cumple'
), p5 as(
SELECT *,
CASE
	WHEN area_geometrica_terreno > limite_superior THEN limite_superior-area_geometrica_terreno
	ELSE limite_inferior-area_geometrica_terreno
END area_necesaria_para_cumplir FROM p4
)
select 'Reco_49' id_regla, 'Reconocimiento' componente, 'Predios con area de terreno fuera del rango de tolerancia segun la Resolucion 1040' descripcion_regla, 
p5.nombre_proyecto proyecto, p5.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, p5.pk_id pk_tabla_error_1, 'LC_Gen_Terreno' tabla_error_2, 
p5.pk_terreno pk_tabla_error_2, p5.numero_predial_nacional, p5.matricula_inmobiliaria, lgdt.ilicode destino_economico, p5.area_catastral_terreno, 
null identificador_caracteristica_unidad_construccion, null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, 
null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, 
lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, 
lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, 
now()::timestamp fecha_modificacion, area_necesaria_para_cumplir::varchar custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, true custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from p5 left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p5.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on p5.pk_id = lge.fk_id and 'Reco_49' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p5.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on p5.pk_id = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where substring(p5.numero_predial_nacional,22,9) not in ('700000000','800000000','900000000')
order by 10,4,14;
