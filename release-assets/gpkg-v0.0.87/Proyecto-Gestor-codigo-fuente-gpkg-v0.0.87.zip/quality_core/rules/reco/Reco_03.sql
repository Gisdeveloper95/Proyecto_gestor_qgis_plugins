-- name: Reco_03
with p as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
)
select 'Reco_03' id_regla, 'Juridico' componente, 'Predios en condicion de condominio sin coeficiente de copropiedad' descripcion_regla, 
p.nombre_proyecto proyecto, p.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, p.pk_id pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, 
p.numero_predial_nacional, p.matricula_inmobiliaria, lgdt.ilicode destino_economico, p.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, 
null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, 
null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, 
now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from p left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on p.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on p.pk_id = lge.fk_id and 'Reco_03' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on p.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON p.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON p.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON p.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON p.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON p.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON p.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON p.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON p.geografico_estado_control = lgec_geo_ctrl.itfcode
where (substring(p.numero_predial_nacional,22,1) = '8' and substring(p.numero_predial_nacional,27,4) <> '0000') 
and (p.coeficiente_condominio is null or p.coeficiente_condominio = 0)
order by 10,4,14;
