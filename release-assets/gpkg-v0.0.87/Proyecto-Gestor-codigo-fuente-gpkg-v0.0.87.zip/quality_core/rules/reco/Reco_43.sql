-- name: Reco_43
with a as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
), a2 as(
select a.pk_id, lrc.pk_id pk_carac, a.numero_predial_nacional, a.matricula_inmobiliaria, case when lrc.uso_comercial is not null then lrc.uso_comercial
when lrc.uso_institucional is not null then lrc.uso_institucional end uso_construccion, lrcc.pk_id pk_calif, 'LC_Reco_Cal_CalificacionComercial' tipo_calif from a 
join actualizacion.lc_reco_caracteristicasunidadconstruccion lrc on a.pk_id = lrc.fk_id join actualizacion.lc_reco_cal_calificacioncomercial lrcc on lrc.pk_id = lrcc.fk_id
where (lrcc.total_calificacion - lrc.puntaje_anterior::int) >= -5 and (lrcc.total_calificacion - lrc.puntaje_anterior::int) < 0 and 
(lrc.uso_comercial = split_part(lrc.uso_anterior,'-',1)::bigint or lrc.uso_institucional = split_part(lrc.uso_anterior,'-',1)::bigint)
union 
select a.pk_id, lrc.pk_id pk_carac, a.numero_predial_nacional, a.matricula_inmobiliaria, lrc.uso_industrial, lrcc2.pk_id pk_calif, 'LC_Reco_Cal_CalificacionIndustrial' tipo_calif 
from a 
join actualizacion.	lc_reco_caracteristicasunidadconstruccion lrc on a.pk_id = lrc.fk_id join actualizacion.lc_reco_cal_calificacionindustrial lrcc2 on lrc.pk_id = lrcc2.fk_id
where (lrcc2.total_calificacion - lrc.puntaje_anterior::int) >= -5 and (lrcc2.total_calificacion - lrc.puntaje_anterior::int) < 0 and 
lrc.uso_industrial = split_part(lrc.uso_anterior,'-',1)::bigint
union 
select a.pk_id, lrc.pk_id pk_carac, a.numero_predial_nacional, a.matricula_inmobiliaria, lrc.uso_anexo, lrcc3.pk_id pk_calif, 'LC_Reco_Cal_CalificacionNoConvencional' tipo_calif 
from a 
join actualizacion.lc_reco_caracteristicasunidadconstruccion lrc on a.pk_id = lrc.fk_id join actualizacion.lc_reco_cal_calificacionnoconvencional lrcc3 on lrc.pk_id = lrcc3.fk_id
join actualizacion.lc_reco_cal_anexo_tipo lta on lrcc3.tipo_anexo = lta.itfcode 
where (split_part(lta.ilicode,'_',2)::int - lrc.puntaje_anterior::int) >= -5 and (split_part(lta.ilicode,'_',2)::int - lrc.puntaje_anterior::int) < 0 and 
lrc.uso_anexo = split_part(lrc.uso_anterior,'-',1)::bigint
union 
select a.pk_id, lrc.pk_id pk_carac, a.numero_predial_nacional, a.matricula_inmobiliaria, lrc.uso_residencial, lrcc4.pk_id pk_calif, 'LC_Reco_Cal_CalificacionResidencial' tipo_calif 
from a 
join actualizacion.lc_reco_caracteristicasunidadconstruccion lrc on a.pk_id = lrc.fk_id join actualizacion.lc_reco_cal_calificacionresidencial lrcc4 on lrc.pk_id = lrcc4.fk_id
where (lrcc4.total_calificacion - lrc.puntaje_anterior::int) >= -5 and (lrcc4.total_calificacion - lrc.puntaje_anterior::int) < 0 and 
lrc.uso_residencial = split_part(lrc.uso_anterior,'-',1)::bigint
order by 2
)
select distinct on (dac.pk_carac, a2.pk_calif) 'Reco_43' id_regla, 'Calificacion' componente, 
'Caracteristica Unidad de Construccion con puntaje anterior menor 5 puntos comparado con el puntaje nuevo' descripcion_regla, 
a.nombre_proyecto proyecto, a.pk_id pk_id_predio, 'LC_Reco_Caracteristicasunidadconstruccion' tabla_error_1, dac.pk_carac pk_tabla_error_1, a2.tipo_calif tabla_error_2, 
a2.pk_calif pk_tabla_error_2, a.numero_predial_nacional, a.matricula_inmobiliaria, lgdt.ilicode destino_economico, a.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, 
dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from a join general.determinacion_area_construccion dac on a.pk_id = dac.pk_id join a2 on dac.pk_carac = a2.pk_carac 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_gen_excepciones lge on a.pk_id = lge.fk_id and 'Reco_43' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON a.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON a.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON a.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON a.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON a.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON a.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON a.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON a.geografico_estado_control = lgec_geo_ctrl.itfcode
order by dac.pk_carac, a2.pk_calif,10;
