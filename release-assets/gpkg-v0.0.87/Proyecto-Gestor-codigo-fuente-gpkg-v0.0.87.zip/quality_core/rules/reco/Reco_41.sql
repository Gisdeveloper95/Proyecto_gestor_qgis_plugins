-- name: Reco_41
with a as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
), a2 as(
select 'Reco_41' id_regla, 'Calificacion' componente, 'Caracteristica Unidad de Construccion con al menos un elemento de la calificacion en valores negativos, es decir, 
errores en el detalle de la calificacion' descripcion_regla, a.nombre_proyecto proyecto, a.pk_id pk_id_predio, 'LC_Reco_Caracteristicasunidadconstruccion' tabla_error_1, 
dac.pk_carac pk_tabla_error_1, 'LC_Reco_Cal_CalificacionComercial' tabla_error_2, ltc2.pk_id pk_tabla_error_2, a.numero_predial_nacional, a.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, a.area_catastral_terreno, dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, 
lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, null custom_6, 
false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from a join general.determinacion_area_construccion dac on a.pk_id = dac.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
join actualizacion.lc_reco_cal_calificacioncomercial ltc2 on dac.pk_carac = ltc2.fk_id
left join actualizacion.lc_gen_excepciones lge on a.pk_id = lge.fk_id and 'Reco_41' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON a.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON a.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON a.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON a.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON a.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON a.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON a.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON a.geografico_estado_control = lgec_geo_ctrl.itfcode
where ltc2.armazon = -1 or ltc2.muros = -1 or ltc2.cubierta = -1 or ltc2.conservacion_cubierta = -1 or ltc2.fachada = -1 or ltc2.cubrimiento_muros = -1 or
ltc2.piso = -1 or ltc2.conservacion_acabados = -1 or ltc2.mobiliario_banio = -1 or ltc2.mobiliario_cocina = -1
union 
select 'Reco_41' id_regla, 'Calificacion' componente, 'Caracteristica Unidad de Construccion con al menos un elemento de la calificacion en valores negativos, es decir, 
errores en el detalle de la calificacion' descripcion_regla, a.nombre_proyecto proyecto, a.pk_id pk_id_predio, 'LC_Reco_Caracteristicasunidadconstruccion' tabla_error_1, 
dac.pk_carac pk_tabla_error_1, 'LC_Reco_Cal_CalificacionIndustrial' tabla_error_2, ltc3.pk_id pk_tabla_error_2, a.numero_predial_nacional, a.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, a.area_catastral_terreno, dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, 
lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, 
null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from a join general.determinacion_area_construccion dac on a.pk_id = dac.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
join actualizacion.lc_reco_cal_calificacionindustrial ltc3 on dac.pk_carac = ltc3.fk_id
left join actualizacion.lc_gen_excepciones lge on a.pk_id = lge.fk_id and 'Reco_41' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON a.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON a.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON a.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON a.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON a.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON a.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON a.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON a.geografico_estado_control = lgec_geo_ctrl.itfcode
where ltc3.armazon = -1 or ltc3.muros = -1 or ltc3.cubierta = -1 or ltc3.conservacion_cubierta = -1 or ltc3.fachada = -1 or ltc3.cubrimiento_muros = -1 or
ltc3.piso = -1 or ltc3.conservacion_acabados = -1 or ltc3.mobiliario_banio = -1 or ltc3.mobiliario_cocina = -1 or ltc3.cerchas_complemento_industria = -1
union 
select 'Reco_41' id_regla, 'Calificacion' componente, 'Caracteristica Unidad de Construccion con al menos un elemento de la calificacion en valores negativos, es decir, 
errores en el detalle de la calificacion' descripcion_regla, a.nombre_proyecto proyecto, a.pk_id pk_id_predio, 'LC_Reco_Caracteristicasunidadconstruccion' tabla_error_1, 
dac.pk_carac pk_tabla_error_1, 'LC_Reco_Cal_CalificacionResidencial' tabla_error_2, ltc4.pk_id pk_tabla_error_2, a.numero_predial_nacional, a.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, a.area_catastral_terreno, dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, 
lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, dac.area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, null custom_6, 
false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from a join general.determinacion_area_construccion dac on a.pk_id = dac.pk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_usouconstruccion_tipo lgut on dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_reco_unidadconstruccion_tipo lrut on dac.tipo_unidad_construccion = lrut.itfcode 
join actualizacion.lc_reco_cal_calificacionresidencial ltc4 on dac.pk_carac = ltc4.fk_id
left join actualizacion.lc_gen_excepciones lge on a.pk_id = lge.fk_id and 'Reco_41' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON a.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON a.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON a.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON a.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON a.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON a.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON a.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON a.geografico_estado_control = lgec_geo_ctrl.itfcode
where ltc4.armazon = -1 or ltc4.muros = -1 or ltc4.cubierta = -1 or ltc4.conservacion_cubierta = -1 or ltc4.fachada = -1 or ltc4.cubrimiento_muros = -1 or
ltc4.piso = -1 or ltc4.conservacion_acabados = -1 or ltc4.tamanio_banio = -1 or ltc4.enchape_banio = -1 or ltc4.mobiliario_banio = -1 or 
ltc4.conservacion_banio = -1 or ltc4.tamanio_cocina = -1 or ltc4.enchape_cocina = -1  or ltc4.mobiliario_cocina = -1 or ltc4.conservacion_cocina = -1
order by 10,4,14
)
select a2.id_regla, a2.componente, a2.descripcion_regla, a2.proyecto, a2.pk_id_predio, a2.tabla_error_1, a2.pk_tabla_error_1, a2.tabla_error_2, 
a2.pk_tabla_error_2, a2.numero_predial_nacional, a2.matricula_inmobiliaria, a2.destino_economico, a2.area_catastral_terreno, 
a2.identificador_caracteristica_unidad_construccion, a2.total_plantas, a2.tipo_unidad_construccion, a2.uso_construccion, a2.area_construida, 
a2.puntaje_calificacion, a2.tipo_novedad, a2.numero_predial_nacional_novedad, a2.tiene_excepcion, a2.descripcion_excepcion, a2.juridico_estado_asignacion, 
a2.juridico_estado_control, a2.reconocimiento_estado_asignacion, a2.reconocimiento_estado_control, a2.informal_estado_asignacion, a2.informal_estado_control, 
a2.geografico_estado_asignacion, a2.geografico_estado_control, a2.pk_lc_gen_predio_usuarioasignacion, a2.usuario_creacion, 
a2.fecha_creacion, a2.usuario_modificacion, a2.fecha_modificacion, a2.custom_1, a2.custom_2, a2.custom_3, a2.custom_4, a2.custom_5, a2.custom_6, 
a2.custom_7, a2.custom_8, a2.custom_9, a2.custom_10, a2.custom_11, a2.custom_12
from a2
left join actualizacion.lc_gen_predio lgp_final on a2.pk_id_predio = lgp_final.pk_id;
