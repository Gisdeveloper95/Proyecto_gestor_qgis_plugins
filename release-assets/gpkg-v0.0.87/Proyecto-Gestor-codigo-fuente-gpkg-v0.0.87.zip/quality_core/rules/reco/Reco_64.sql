-- name: Reco_64
with a as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
)
select 'Reco_64' id_regla, 'Calificacion' componente, 'Predios informales con calificacion mayor a 50 puntos' descripcion_regla, 
a.nombre_proyecto proyecto, a.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, a.pk_id pk_tabla_error_1, 'LC_Reco_CaracteristicasUnidadConstruccion' tabla_error_2, 
dac.pk_carac pk_tabla_error_2, a.numero_predial_nacional, a.matricula_inmobiliaria, lgdt.ilicode destino_economico, a.area_catastral_terreno, 
dac.identificador identificador_caracteristica_unidad_construccion, dac.total_plantas total_plantas, lrut.ilicode tipo_unidad_construccion, lgut.ilicode uso_construccion, 
dac.area_construida area_construida, dac.puntaje puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from a JOIN "general".determinacion_area_construccion dac ON a.pk_id = dac.pk_id 
LEFT JOIN actualizacion.lc_reco_unidadconstruccion_tipo lrut ON dac.tipo_unidad_construccion = lrut.itfcode 
LEFT JOIN actualizacion.lc_gen_usouconstruccion_tipo lgut ON dac.uso_construccion = lgut.itfcode 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on a.pk_id = lge.fk_id and 'Reco_64' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON a.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON a.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON a.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON a.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON a.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON a.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON a.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON a.geografico_estado_control = lgec_geo_ctrl.itfcode
where substring(a.numero_predial_nacional,22,1) IN ('2','5') AND dac.puntaje > 50
order by 10,4,14;
