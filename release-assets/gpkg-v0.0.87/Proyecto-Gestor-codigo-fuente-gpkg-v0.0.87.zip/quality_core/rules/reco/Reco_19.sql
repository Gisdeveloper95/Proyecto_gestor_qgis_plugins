-- name: Reco_19
with a as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false)
), a2 as(
select a.pk_id, coalesce(a.area_total_construida,0) area_construida_inicial, sum(coalesce(dac.area_construida,0)) area_construida_final from a 
left join general.determinacion_area_construccion dac on a.pk_id = dac.pk_id group by 1,2
), a3 as(
select a.*, a2.area_construida_inicial, a2.area_construida_final, 
case when a2.area_construida_inicial = 0 and a2.area_construida_final > 0 then 100 when a2.area_construida_inicial = 0 and a2.area_construida_final = 0 then 0
when a2.area_construida_inicial > 0 and a2.area_construida_final = 0 then 100
else abs((a2.area_construida_final-a2.area_construida_inicial)/a2.area_construida_inicial) end porcentaje_variacion
from a join a2 on a.pk_id = a2.pk_id
)
select 'Reco_19' id_regla, 'Reconocimiento' componente, 'Predios con cambio fisico y diferencia menor al 5% entre el area construida alfanumerica y geografica' descripcion_regla, 
a3.nombre_proyecto proyecto, a3.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, a3.pk_id pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, 
a3.numero_predial_nacional, a3.matricula_inmobiliaria, lgdt.ilicode destino_economico, a3.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, 
null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, null tipo_novedad, null numero_predial_nacional_novedad, 
case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, 
lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, lga_geo_asig.ilicode geografico_estado_asignacion, 
lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, null custom_5, 
null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from a3 left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a3.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on a3.pk_id = lge.fk_id and 'Reco_19' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a3.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on a3.pk_id = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
where a3.predio_tiene_cambio_fisico = true and a3.porcentaje_variacion < 5 order by 10,4,14;
