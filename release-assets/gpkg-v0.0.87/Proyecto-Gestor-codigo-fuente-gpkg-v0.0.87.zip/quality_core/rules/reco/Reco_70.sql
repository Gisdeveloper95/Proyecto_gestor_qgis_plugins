-- name: Reco_70
with a as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
), a2 as(
SELECT a.pk_id, a.numero_predial_nacional, a.nombre_proyecto, a.area_catastral_terreno, a.matricula_inmobiliaria, a.destinacion_economica,
'LC_Gen_Fotos_Predio' nombre_tabla, lg.pk_id pk_fotos, lg.foto 
FROM a JOIN actualizacion.lc_gen_fotos_predio lg ON a.pk_id = lg.fk_id WHERE a.numero_predial_nacional <> LEFT(lg.foto,30) 
UNION 
SELECT a.pk_id, a.numero_predial_nacional, a.nombre_proyecto, a.area_catastral_terreno, a.matricula_inmobiliaria, a.destinacion_economica,
'LC_Gen_Fotos_Caracteristica' nombre_tabla, lg.pk_id pk_fotos, lg.foto 
FROM a JOIN actualizacion.lc_reco_caracteristicasunidadconstruccion lrc ON a.pk_id = lrc.fk_id
JOIN actualizacion.lc_gen_fotos_caracteristica lg ON lrc.pk_id = lg.fk_id WHERE a.numero_predial_nacional <> LEFT(lg.foto,30)  
) 
select 'Reco_70' id_regla, 'Reconocimiento' componente, 'Predios con Fotos relacionadas de otro Numero predial Nacional' descripcion_regla, 
a2.nombre_proyecto proyecto, a2.pk_id pk_id_predio, a2.nombre_tabla tabla_error_1, a2.pk_fotos pk_tabla_error_1, null tabla_error_2, null pk_tabla_error_2, 
a2.numero_predial_nacional, a2.matricula_inmobiliaria, lgdt.ilicode destino_economico, a2.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, 
NULL total_plantas, NULL tipo_unidad_construccion, NULL uso_construccion, NULL area_construida, NULL puntaje_calificacion, null tipo_novedad, 
null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, lge.descripcion_excepcion, 
lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, lga_reco_asig.ilicode reconocimiento_estado_asignacion, 
lgec_reco_ctrl.ilicode reconocimiento_estado_control, lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 
'admin' usuario_creacion, now()::timestamp fecha_creacion, 'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, 
null custom_3, null custom_4, null custom_5, null custom_6, false custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12
from a2 JOIN actualizacion.lc_vis_contactovisita lvc ON a2.pk_id = lvc.fk_id 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on a2.destinacion_economica = lgdt.itfcode
left join actualizacion.lc_gen_excepciones lge on a2.pk_id = lge.fk_id and 'Reco_70' = lge.id_regla 
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on a2.pk_id = lgpc.fk_id
left join actualizacion.lc_gen_predio lgp_final on a2.pk_id = lgp_final.pk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp_final.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp_final.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp_final.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp_final.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp_final.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp_final.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp_final.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp_final.geografico_estado_control = lgec_geo_ctrl.itfcode
order by 10,4,14;
