-- name: Eco_03
with c as(
select * from actualizacion.lc_gen_predio lgp where (lgp.juridico_predio_cancelado is null or lgp.juridico_predio_cancelado = false) 
)
select 'Eco_03' id_regla, 'Economico' componente, 'Predios sin Avaluo Catastral' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_Gen_Predio' tabla_error_1, lgp.pk_id pk_tabla_error_1, 
'LC_Gen_Predio_Avaluo' tabla_error_2, lgpa.pk_id pk_tabla_error_2, lgp.numero_predial_nacional, lgp.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, lgp.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, 
null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, 
null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, 
lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, true custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from c lgp 
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on lgp.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on lgp.pk_id = lge.fk_id and 'Eco_03' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on lgp.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_predio_avaluo lgpa ON lgp.pk_id = lgpa.fk_id 
where (lgpa.avaluo_catastral IS NULL OR lgpa.avaluo_catastral = 0) AND substring(lgp.numero_predial_nacional,22,9) NOT IN ('700000000','800000000','900000000') 
UNION
select 'Eco_03' id_regla, 'Economico' componente, 'Predios sin Avaluo Catastral' descripcion_regla, 
lgp.nombre_proyecto proyecto, lgp.pk_id pk_id_predio, 'LC_PH_Predio' tabla_error_1, lpp.pk_id pk_tabla_error_1, 
'LC_PH_Predio_Avaluo' tabla_error_2, lgpa.pk_id pk_tabla_error_2, lpp.numero_predial_nacional, lpp.matricula_inmobiliaria, 
lgdt.ilicode destino_economico, lpp.area_catastral_terreno, null identificador_caracteristica_unidad_construccion, 
null total_plantas, null tipo_unidad_construccion, null uso_construccion, null area_construida, null puntaje_calificacion, 
null tipo_novedad, null numero_predial_nacional_novedad, case when lge.fid is null then false else true end tiene_excepcion, 
lge.descripcion_excepcion, lga_jur_asig.ilicode juridico_estado_asignacion, lgec_jur_ctrl.ilicode juridico_estado_control, 
lga_reco_asig.ilicode reconocimiento_estado_asignacion, lgec_reco_ctrl.ilicode reconocimiento_estado_control, 
lga_info_asig.ilicode informal_estado_asignacion, lgec_info_ctrl.ilicode informal_estado_control, 
lga_geo_asig.ilicode geografico_estado_asignacion, lgec_geo_ctrl.ilicode geografico_estado_control, 
lgpc.pk_id pk_lc_gen_predio_usuarioasignacion, 'admin' usuario_creacion, now()::timestamp fecha_creacion, 
'admin' usuario_modificacion, now()::timestamp fecha_modificacion, null custom_1, null custom_2, null custom_3, null custom_4, 
null custom_5, null custom_6, true custom_7, null custom_8, null custom_9, null custom_10, null custom_11, null custom_12 
from c lgp 
JOIN actualizacion.lc_ph_predio lpp ON lgp.pk_id = lpp.fk_id
left join actualizacion.lc_gen_destinacioneconomica_tipo lgdt on lpp.destinacion_economica = lgdt.itfcode 
left join actualizacion.lc_gen_excepciones lge on lpp.pk_id = lge.fk_id and 'Eco_03' = lge.id_regla
left join actualizacion.lc_gen_predio_usuarioasignacion lgpc on lpp.pk_id = lgpc.fk_id
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_jur_asig ON lgp.juridico_estado_asignacion = lga_jur_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_jur_ctrl ON lgp.juridico_estado_control = lgec_jur_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_reco_asig ON lgp.reconocimiento_estado_asignacion = lga_reco_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_reco_ctrl ON lgp.reconocimiento_estado_control = lgec_reco_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_info_asig ON lgp.informal_estado_asignacion = lga_info_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_info_ctrl ON lgp.informal_estado_control = lgec_info_ctrl.itfcode
LEFT JOIN actualizacion.lc_gen_asignacion_tipo lga_geo_asig ON lgp.geografico_estado_asignacion = lga_geo_asig.itfcode
LEFT JOIN actualizacion.lc_gen_estadocontrol_tipo lgec_geo_ctrl ON lgp.geografico_estado_control = lgec_geo_ctrl.itfcode
LEFT JOIN actualizacion.lc_ph_predio_avaluo lgpa ON lpp.pk_id = lgpa.fk_id 
where (lgpa.avaluo_catastral IS NULL OR lgpa.avaluo_catastral = 0) 
order by 10,4,14;
