"""Minimal streaming field-alias adapter for portable data sources."""

from __future__ import annotations


class AliasedFieldDataSource:
    def __init__(self, source, target_layer: str, aliases: dict[str, str]):
        self._source = source
        self._target_layer = target_layer
        self._aliases = dict(aliases)

    def iter_rows(self, layer_name, fields):
        if layer_name != self._target_layer:
            yield from self._source.iter_rows(layer_name, fields)
            return
        source_fields = tuple(dict.fromkeys(self._aliases.get(field, field) for field in fields))
        for row in self._source.iter_rows(layer_name, source_fields):
            yield {
                field: row.get(self._aliases.get(field, field))
                for field in fields
            }
