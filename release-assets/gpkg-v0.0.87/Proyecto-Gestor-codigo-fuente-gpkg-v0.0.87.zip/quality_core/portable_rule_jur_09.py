"""Independent portable implementation of the canonical Jur_09 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    municipality = postgres_substring(row.get("numero_predial_nacional"), 3, 3)
    return municipality is not None and municipality != "001"


_RULE = PredioScalarRule(
    canonical_id="Jur_09",
    component="Juridico",
    description=(
        "Predios con numero predial nacional diferente al municipio divipola"
    ),
    predicate=_matches,
    custom_7=True,
)


def execute_jur_09(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_09 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
