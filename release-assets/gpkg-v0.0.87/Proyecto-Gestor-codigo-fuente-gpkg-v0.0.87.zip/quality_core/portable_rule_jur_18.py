"""Independent portable implementation of the canonical Jur_18 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    matricula = row.get("matricula_inmobiliaria")
    return (
        row.get("area_terreno_registral") is None
        and matricula is not None
        and matricula > 0
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_18",
    component="Fisico",
    description="Predios con matricula inmobiliaria pero sin area registral",
    predicate=_matches,
    custom_7=True,
    filter_fields=("area_terreno_registral",),
)


def execute_jur_18(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_18 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
