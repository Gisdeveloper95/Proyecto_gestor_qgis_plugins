"""Independent portable implementation of canonical Reco_59."""
from .portable_alias_source import AliasedFieldDataSource
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_59", "Calificacion",
    "Predios con mejora o informal con destino diferente a habitacional",
    "lc_reco_marcasfisicas", ("pk_id", "fk_id", "nombre_quien_atendio"),
    "inner", "lower(r.nombre_quien_atendio) LIKE '%mejora%'",
    "p.destinacion_economica NOT IN (10)",
    "LC_Gen_Predio", "predio",
)

def execute_reco_59(data_source, layer_mapping, cancel_check=None):
    physical = layer_mapping.resolve("lc_reco_marcasfisicas")
    adapted = AliasedFieldDataSource(
        data_source, physical, {"nombre_quien_atendio": "tipo_marca"}
    )
    return execute_related_scalar(_RULE, adapted, layer_mapping, cancel_check)
