"""Independent portable implementation of the canonical Reco_52 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    zone = postgres_substring(row.get("numero_predial_nacional"), 6, 2)
    return (
        row.get("destinacion_economica") in (20, 21)
        and zone is not None
        and zone != "01"
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_52",
    component="Calificacion",
    description=(
        "Predios rurales con destino economico igual a lote urbanizable no "
        "urbanizado o lote urbanizado no construido"
    ),
    predicate=_matches,
    custom_7=False,
)


def execute_reco_52(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_52 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
