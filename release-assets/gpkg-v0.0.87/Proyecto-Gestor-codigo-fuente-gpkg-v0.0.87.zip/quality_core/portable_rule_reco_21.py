"""Independent portable implementation of canonical Reco_21."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_21", "Reconocimiento", "Predios sin cambio fisico con fotos de croquis",
    "lc_gen_fotos_predio", ("pk_id", "fk_id", "tipo_foto"), "inner",
    "r.tipo_foto = 0",
    "p.predio_tiene_cambio_fisico = 0 OR p.predio_tiene_cambio_fisico IS NULL",
    "LC_Gen_Predio", "predio", "LC_Gen_Fotos_Predio", "related",
    predio_filter_fields=("predio_tiene_cambio_fisico",),
    duplicate_predio_join=True,
)

def execute_reco_21(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
