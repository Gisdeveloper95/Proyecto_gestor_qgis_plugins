"""Independent portable implementation of canonical Reco_71."""
from .portable_reco_photos import execute_reco_71 as _execute


def execute_reco_71(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
