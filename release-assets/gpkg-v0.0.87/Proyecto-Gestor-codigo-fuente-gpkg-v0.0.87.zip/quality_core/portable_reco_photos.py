"""Disk-backed portable engine for the canonical RECO photo rules."""

from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
    sqlite_staging,
)


_PREDIO_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado",
    "nombre_proyecto", "matricula_inmobiliaria", "destinacion_economica",
    "area_catastral_terreno", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control", "informal_estado_asignacion",
    "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
_PHOTO_FIELDS = ("pk_id", "fk_id", "tipo_foto", "external_url", "foto")


_DEFINITIONS = {
    "Reco_46": ("Fotos sin Tipo de foto", None),
    "Reco_47": ("Fotos sin Url", None),
    "Reco_70": ("Predios con Fotos relacionadas de otro Numero predial Nacional", None),
    "Reco_71": ("Fotos con ruta mal cargada", "foto"),
}


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE predio (
            row_token INTEGER PRIMARY KEY, pk_id, pk_key TEXT,
            numero_predial_nacional, proyecto, matricula_inmobiliaria,
            destination_key TEXT, area_catastral_terreno,
            juridico_assignment_key TEXT, juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT, informal_assignment_key TEXT,
            informal_control_key TEXT, geografico_assignment_key TEXT,
            geografico_control_key TEXT
        );
        CREATE TABLE characteristic (
            row_token INTEGER PRIMARY KEY, pk_key TEXT, predio_key TEXT
        );
        CREATE TABLE photo_predio (
            row_token INTEGER PRIMARY KEY, pk_id, fk_key TEXT,
            type_key TEXT, external_url, foto
        );
        CREATE TABLE photo_characteristic (
            row_token INTEGER PRIMARY KEY, pk_id, fk_key TEXT,
            type_key TEXT, external_url, foto
        );
        CREATE TABLE photo_type (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE contact (
            row_token INTEGER PRIMARY KEY, predio_key TEXT
        );
        CREATE TABLE destination_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE exception_lookup (
            row_token INTEGER PRIMARY KEY, fk_token TEXT, fid,
            descripcion_excepcion
        );
        CREATE TABLE user_assignment (
            row_token INTEGER PRIMARY KEY, fk_token TEXT, pk_id
        );
        CREATE TABLE assignment_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE control_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        """
    )


def _ingest_predios(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("lc_gen_predio")
    sql = (
        "INSERT INTO predio(pk_id,pk_key,numero_predial_nacional,proyecto,"
        "matricula_inmobiliaria,destination_key,area_catastral_terreno,"
        "juridico_assignment_key,juridico_control_key,"
        "reconocimiento_assignment_key,reconocimiento_control_key,"
        "informal_assignment_key,informal_control_key,"
        "geografico_assignment_key,geografico_control_key) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    )
    with BatchInserter(db, sql, cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical_name, _PREDIO_FIELDS):
            raise_if_cancelled(cancel_check)
            if not postgres_boolean_is_false_or_null(
                row.get("juridico_predio_cancelado")
            ):
                continue
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                row.get("numero_predial_nacional"), row.get("nombre_proyecto"),
                row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),
                row.get("area_catastral_terreno"),
                _join_token(row.get("juridico_estado_asignacion")),
                _join_token(row.get("juridico_estado_control")),
                _join_token(row.get("reconocimiento_estado_asignacion")),
                _join_token(row.get("reconocimiento_estado_control")),
                _join_token(row.get("informal_estado_asignacion")),
                _join_token(row.get("informal_estado_control")),
                _join_token(row.get("geografico_estado_asignacion")),
                _join_token(row.get("geografico_estado_control")),
            ))


def _ingest_characteristics(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve(
        "lc_reco_caracteristicasunidadconstruccion"
    )
    with BatchInserter(
        db, "INSERT INTO characteristic(pk_key,predio_key) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("pk_id", "fk_id")):
            raise_if_cancelled(cancel_check)
            inserter.add((
                _join_token(row.get("pk_id")), _join_token(row.get("fk_id"))
            ))


def _ingest_photos(
    data_source, layer_mapping, db, cancel_check, logical_name, table_name
) -> None:
    physical_name = layer_mapping.resolve(logical_name)
    with BatchInserter(
        db,
        f"INSERT INTO {table_name}(pk_id,fk_key,type_key,external_url,foto) "
        "VALUES (?,?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, _PHOTO_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("fk_id")),
                _join_token(row.get("tipo_foto")), row.get("external_url"),
                row.get("foto"),
            ))


def _ingest_rule_support(
    rule_id, data_source, layer_mapping, db, cancel_check
) -> None:
    physical_name = layer_mapping.resolve("lc_gen_fotos_tipofotos_tipo")
    with BatchInserter(
        db, "INSERT INTO photo_type(key_token,ilicode) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("itfcode", "ilicode")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("itfcode")), row.get("ilicode")))

    physical_name = layer_mapping.resolve("lc_vis_contactovisita")
    with BatchInserter(
        db, "INSERT INTO contact(predio_key) VALUES (?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("fk_id",)):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("fk_id")),))

    definition = SimpleNamespace(canonical_id=rule_id)
    _ingest_enrichment(
        definition, data_source, layer_mapping, db, cancel_check
    )


def _prepare_indexes(db) -> None:
    db.executescript(
        """
        CREATE INDEX idx_predio_key ON predio(pk_key);
        CREATE INDEX idx_characteristic_pk ON characteristic(pk_key);
        CREATE INDEX idx_characteristic_predio ON characteristic(predio_key);
        CREATE INDEX idx_photo_predio_fk ON photo_predio(fk_key);
        CREATE INDEX idx_photo_characteristic_fk ON photo_characteristic(fk_key);
        CREATE INDEX idx_photo_type_key ON photo_type(key_token);
        CREATE INDEX idx_contact_predio ON contact(predio_key);
        CREATE INDEX idx_destination_key ON destination_lookup(key_token);
        CREATE INDEX idx_exception_key ON exception_lookup(fk_token);
        CREATE INDEX idx_user_assignment_key ON user_assignment(fk_token);
        CREATE INDEX idx_assignment_key ON assignment_lookup(key_token);
        CREATE INDEX idx_control_key ON control_lookup(key_token);
        """
    )


def _candidate_predicate(rule_id: str, photo_alias: str) -> str:
    if rule_id == "Reco_46":
        return (
            f"({photo_alias}.type_key IS NULL OR NOT EXISTS ("
            f"SELECT 1 FROM photo_type pt WHERE pt.key_token={photo_alias}.type_key))"
        )
    if rule_id == "Reco_47":
        return (
            f"({photo_alias}.external_url IS NULL OR "
            f"LOWER({photo_alias}.external_url) LIKE '%existe%')"
        )
    if rule_id == "Reco_70":
        return f"p.numero_predial_nacional <> SUBSTR({photo_alias}.foto,1,30)"
    return (
        f"UPPER(TRIM(COALESCE(CAST({photo_alias}.foto AS TEXT),''))) "
        "NOT IN ('','NULL','NONE') AND "
        f"(TRIM(CAST({photo_alias}.foto AS TEXT)) LIKE '/%' OR "
        f"TRIM(CAST({photo_alias}.foto AS TEXT)) LIKE '../%')"
    )


def _prepare_candidates(rule_id: str, db) -> None:
    direct_predicate = _candidate_predicate(rule_id, "f")
    characteristic_predicate = _candidate_predicate(rule_id, "f")
    db.execute(
        f"""
        CREATE TABLE candidate AS
        SELECT p.row_token predio_row_token,p.pk_key,p.pk_id,f.pk_id photo_pk,
               'LC_Gen_Fotos_Predio' table_name,f.foto
        FROM predio p JOIN photo_predio f ON f.fk_key=p.pk_key
        WHERE {direct_predicate}
        UNION
        SELECT p.row_token,p.pk_key,p.pk_id,f.pk_id,
               'LC_Gen_Fotos_Caracteristica',f.foto
        FROM predio p
        JOIN characteristic c ON c.predio_key=p.pk_key
        JOIN photo_characteristic f ON f.fk_key=c.pk_key
        WHERE {characteristic_predicate}
        """
    )
    db.execute("CREATE INDEX idx_candidate_predio ON candidate(pk_key)")


def _result_sql(rule_id: str) -> str:
    if rule_id in {"Reco_70", "Reco_71"}:
        final_join = "JOIN predio states ON states.pk_key=p.pk_key"
        states = "states"
    else:
        final_join = ""
        states = "p"
    contact_join = (
        "JOIN contact visit ON visit.predio_key=p.pk_key"
        if rule_id == "Reco_70" else ""
    )
    # Reco_46/47 are UNION queries, so duplicate projected rows disappear.
    distinct = "DISTINCT" if rule_id in {"Reco_46", "Reco_47"} else ""
    return f"""
        SELECT {distinct}
            p.pk_id,p.numero_predial_nacional,p.proyecto,p.matricula_inmobiliaria,
            d.ilicode,p.area_catastral_terreno,e.fid,e.descripcion_excepcion,
            jur_asig.ilicode,jur_ctrl.ilicode,reco_asig.ilicode,reco_ctrl.ilicode,
            info_asig.ilicode,info_ctrl.ilicode,geo_asig.ilicode,geo_ctrl.ilicode,
            ua.pk_id,c.table_name,c.photo_pk,c.foto
        FROM candidate c JOIN predio p ON p.row_token=c.predio_row_token
        {contact_join}
        {final_join}
        LEFT JOIN destination_lookup d ON d.key_token=p.destination_key
        LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key
        LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key
        LEFT JOIN assignment_lookup jur_asig
            ON jur_asig.key_token={states}.juridico_assignment_key
        LEFT JOIN control_lookup jur_ctrl
            ON jur_ctrl.key_token={states}.juridico_control_key
        LEFT JOIN assignment_lookup reco_asig
            ON reco_asig.key_token={states}.reconocimiento_assignment_key
        LEFT JOIN control_lookup reco_ctrl
            ON reco_ctrl.key_token={states}.reconocimiento_control_key
        LEFT JOIN assignment_lookup info_asig
            ON info_asig.key_token={states}.informal_assignment_key
        LEFT JOIN control_lookup info_ctrl
            ON info_ctrl.key_token={states}.informal_control_key
        LEFT JOIN assignment_lookup geo_asig
            ON geo_asig.key_token={states}.geografico_assignment_key
        LEFT JOIN control_lookup geo_ctrl
            ON geo_ctrl.key_token={states}.geografico_control_key
        ORDER BY p.numero_predial_nacional IS NULL,p.numero_predial_nacional,
                 p.proyecto IS NULL,p.proyecto,p.row_token,c.table_name,c.photo_pk
    """


def execute_photo_rule(
    rule_id: str, data_source, layer_mapping, cancel_check=None
) -> Iterator[dict[str, Any]]:
    description, custom_source = _DEFINITIONS[rule_id]
    definition = SimpleNamespace(
        canonical_id=rule_id, component="Reconocimiento",
        description=description, custom_7=False,
    )
    execution_timestamp = datetime.now()
    with sqlite_staging(
        cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-"
    ) as db:
        _create_stage(db)
        _ingest_predios(data_source, layer_mapping, db, cancel_check)
        _ingest_characteristics(data_source, layer_mapping, db, cancel_check)
        _ingest_photos(
            data_source, layer_mapping, db, cancel_check,
            "lc_gen_fotos_predio", "photo_predio",
        )
        _ingest_photos(
            data_source, layer_mapping, db, cancel_check,
            "lc_gen_fotos_caracteristica", "photo_characteristic",
        )
        _ingest_rule_support(
            rule_id, data_source, layer_mapping, db, cancel_check
        )
        _prepare_indexes(db)
        _prepare_candidates(rule_id, db)
        db.commit()
        cursor = db.execute(_result_sql(rule_id))
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                base = _result_row(definition, execution_timestamp, values[:17])
                table_name, photo_pk, foto = values[17:]
                base["tabla_error_1"] = table_name
                base["pk_tabla_error_1"] = photo_pk
                if custom_source == "foto":
                    base["custom_1"] = None if foto is None else str(foto)
                yield base
        finally:
            cursor.close()


def execute_reco_46(data_source, layer_mapping, cancel_check=None):
    return execute_photo_rule("Reco_46", data_source, layer_mapping, cancel_check)


def execute_reco_47(data_source, layer_mapping, cancel_check=None):
    return execute_photo_rule("Reco_47", data_source, layer_mapping, cancel_check)


def execute_reco_70(data_source, layer_mapping, cancel_check=None):
    return execute_photo_rule("Reco_70", data_source, layer_mapping, cancel_check)


def execute_reco_71(data_source, layer_mapping, cancel_check=None):
    return execute_photo_rule("Reco_71", data_source, layer_mapping, cancel_check)
