"""Small, testable contract for consuming a forward-only QtSql cursor."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from typing import Any


class CursorCancelled(RuntimeError):
    """Cooperative cancellation observed while navigating result rows."""


class CursorNavigationError(RuntimeError):
    """The driver reported an error after returning one or more rows."""


def _error_details(error: Any) -> tuple[bool, str]:
    if error is None:
        return False, ""
    is_valid = getattr(error, "isValid", None)
    valid = bool(is_valid()) if callable(is_valid) else False
    text_method = getattr(error, "text", None)
    text = str(text_method() or "") if callable(text_method) else str(error or "")
    return valid, text


def iter_forward_query(
    query: Any,
    *,
    cancel_check: Callable[[], bool] | None = None,
) -> Iterator[dict[str, Any]]:
    """Yield rows, then validate driver state and always finish the query.

    Qt's ``next() == False`` means either end-of-results or a navigation error.
    The caller must not commit its surrounding transaction until this generator
    is exhausted successfully.  A driver error and a cooperative cancellation
    use different exception types so the worker cannot misclassify one as the
    other.
    """

    record = query.record()
    columns = [record.fieldName(index) for index in range(record.count())]
    try:
        while True:
            if cancel_check is not None and cancel_check():
                raise CursorCancelled(
                    "Consulta cancelada durante la lectura de resultados."
                )
            if not query.next():
                break
            if cancel_check is not None and cancel_check():
                raise CursorCancelled(
                    "Consulta cancelada durante la lectura de resultados."
                )
            yield {
                columns[index]: query.value(index) for index in range(len(columns))
            }

        valid, text = _error_details(query.lastError())
        if valid:
            raise CursorNavigationError(
                text or "El driver QtSql fallo durante la navegacion del cursor."
            )
    finally:
        query.finish()
