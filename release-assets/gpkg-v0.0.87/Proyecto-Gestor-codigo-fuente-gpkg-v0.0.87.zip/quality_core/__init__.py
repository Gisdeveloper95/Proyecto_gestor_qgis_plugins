"""Shared quality-rule engine for QGIS plugins."""

from .registry import RuleRegistry, QualityRule

__all__ = ["RuleRegistry", "QualityRule"]
