"""Portable public/private interested classifier for canonical Jur_82."""
from datetime import datetime
from pathlib import Path
import re
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging

_PF=("pk_id","numero_predial_nacional","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")


def _public_predicate_sql():
 text=(Path(__file__).resolve().parent/"rules"/"juridico"/"Jur_82.sql").read_text(encoding="utf-8");marker="WHERE lji.estado_propietario <> 0 AND";start=text.index(marker)+len(marker);end=text.index("\n), c3 AS(",start);predicate=text[start:end].strip()
 return re.sub(r"nombre_completo_propietario\s+ILIKE\s+('(?:''|[^'])*')",r"mt_ilike(nombre_completo_propietario, \1)",predicate,flags=re.IGNORECASE)


def _ilike(value,pattern):
 if value is None or pattern is None:return None
 expression="".join(".*"if c=="%"else"."if c=="_"else re.escape(c)for c in str(pattern));return int(re.fullmatch(expression,str(value),flags=re.IGNORECASE|re.DOTALL)is not None)


def execute_jur_82(data_source,layer_mapping,cancel_check=None):
 definition=SimpleNamespace(canonical_id="Jur_82",component="Interesado",description="Predios con interesados publicos y con interesados privados activos",custom_7=False);stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix="mapingtool-calidad-gpkg-jur_82-")as db:
  db.create_function("mt_ilike",2,_ilike);db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,predio_key TEXT);CREATE TABLE interesado(row_token INTEGER PRIMARY KEY,pk_id,derecho_key TEXT,estado_propietario,nombre_completo_propietario,publico INTEGER DEFAULT 0);CREATE TABLE candidate(row_token INTEGER PRIMARY KEY,predio_row INTEGER,derecho_row INTEGER);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
  with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),_PF):raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
  with BatchInserter(db,"INSERT INTO derecho(pk_id,pk_key,predio_key)VALUES(?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_derecho"),("pk_id","fk_id")):raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id"))))
  with BatchInserter(db,"INSERT INTO interesado(pk_id,derecho_key,estado_propietario,nombre_completo_propietario)VALUES(?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_interesado"),("pk_id","fk_id","estado_propietario","nombre_completo_propietario")):raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),r.get("estado_propietario"),r.get("nombre_completo_propietario")))
  db.execute("UPDATE interesado SET publico=CASE WHEN estado_propietario<>0 AND ("+_public_predicate_sql()+") THEN 1 ELSE 0 END");_ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
  db.executescript("""CREATE INDEX jur82_d_predio ON derecho(predio_key);CREATE INDEX jur82_i_right ON interesado(derecho_key);CREATE TEMP TABLE eligible AS SELECT p.row_token predio_row FROM predio p WHERE EXISTS(SELECT 1 FROM derecho d JOIN interesado i ON i.derecho_key=d.pk_key WHERE d.predio_key=p.pk_key AND i.publico=1) AND (SELECT count(*) FROM derecho d JOIN interesado i ON i.derecho_key=d.pk_key WHERE d.predio_key=p.pk_key AND i.estado_propietario<>0)>1;CREATE TEMP TABLE raw AS SELECT e.predio_row,d.row_token derecho_row FROM eligible e JOIN predio p ON p.row_token=e.predio_row LEFT JOIN derecho d ON d.predio_key=p.pk_key;INSERT INTO candidate(predio_row,derecho_row) SELECT predio_row,derecho_row FROM(SELECT x.*,row_number()OVER(PARTITION BY p.npn ORDER BY p.project IS NULL,p.project,x.predio_row,x.derecho_row)rn FROM raw x JOIN predio p ON p.row_token=x.predio_row)WHERE rn=1;""");db.commit()
  cur=db.execute("""SELECT p.pk_id,p.npn,p.project,p.registration,dest.ilicode,p.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,d.pk_id FROM candidate x JOIN predio p ON p.row_token=x.predio_row LEFT JOIN derecho d ON d.row_token=x.derecho_row LEFT JOIN destination_lookup dest ON dest.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project""")
  try:
   for v in cur:raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row.update({"tabla_error_1":"LC_Jur_Derecho","pk_tabla_error_1":v[17]});yield row
  finally:cur.close()
