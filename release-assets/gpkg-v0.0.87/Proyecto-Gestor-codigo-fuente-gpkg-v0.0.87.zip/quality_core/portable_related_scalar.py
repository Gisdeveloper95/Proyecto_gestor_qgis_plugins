"""Disk-backed predio-to-related-row pipeline for portable validation rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
    sqlite_staging,
)


_PREDIO_BASE_FIELDS = (
    "pk_id",
    "numero_predial_nacional",
    "juridico_predio_cancelado",
    "nombre_proyecto",
    "matricula_inmobiliaria",
    "destinacion_economica",
    "area_catastral_terreno",
    "juridico_estado_asignacion",
    "juridico_estado_control",
    "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control",
    "informal_estado_asignacion",
    "informal_estado_control",
    "geografico_estado_asignacion",
    "geografico_estado_control",
)


@dataclass(frozen=True)
class RelatedScalarRule:
    canonical_id: str
    component: str
    description: str
    related_layer: str
    related_fields: tuple[str, ...]
    join_mode: str
    related_match_sql: str
    predicate_sql: str
    table_error_1: str
    table_error_1_source: str
    table_error_2: str | None = None
    table_error_2_source: str = "null"
    predio_filter_fields: tuple[str, ...] = ()
    duplicate_predio_join: bool = False
    custom_7: bool = False


def _unique_fields(base: tuple[str, ...], extra: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys((*base, *extra)))


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE all_active_predio_key (
            row_token INTEGER PRIMARY KEY,
            pk_key TEXT
        );
        CREATE TABLE predio (
            row_token INTEGER PRIMARY KEY,
            pk_id,
            pk_key TEXT,
            numero_predial_nacional,
            proyecto,
            matricula_inmobiliaria,
            destinacion_economica,
            destination_key TEXT,
            area_catastral_terreno,
            juridico_assignment_key TEXT,
            juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT,
            informal_assignment_key TEXT,
            informal_control_key TEXT,
            geografico_assignment_key TEXT,
            geografico_control_key TEXT,
            juridico_predio_para_visita,
            reconocimiento_predio_para_visita,
            predio_tiene_cambio_fisico
        );
        CREATE TABLE related (
            row_token INTEGER PRIMARY KEY,
            fk_key TEXT,
            pk_id,
            resultado_visita,
            nombre_quien_atendio,
            tipo_documento_quien_atendio,
            numero_documento_quien_atendio,
            tipo_foto
        );
        CREATE TABLE selected (
            row_token INTEGER PRIMARY KEY,
            predio_row_token INTEGER,
            related_row_token INTEGER,
            pk_id,
            pk_key TEXT,
            numero_predial_nacional,
            proyecto,
            matricula_inmobiliaria,
            destination_key TEXT,
            area_catastral_terreno,
            juridico_assignment_key TEXT,
            juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT,
            informal_assignment_key TEXT,
            informal_control_key TEXT,
            geografico_assignment_key TEXT,
            geografico_control_key TEXT,
            related_pk_id
        );
        CREATE TABLE destination_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        CREATE TABLE exception_lookup (
            row_token INTEGER PRIMARY KEY,
            fk_token TEXT,
            fid,
            descripcion_excepcion
        );
        CREATE TABLE user_assignment (
            row_token INTEGER PRIMARY KEY,
            fk_token TEXT,
            pk_id
        );
        CREATE TABLE assignment_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        CREATE TABLE control_lookup (
            row_token INTEGER PRIMARY KEY,
            key_token TEXT,
            ilicode
        );
        """
    )


def _ingest_predios(definition, data_source, layer_mapping, db, cancel_check) -> None:
    fields = _unique_fields(_PREDIO_BASE_FIELDS, definition.predio_filter_fields)
    physical_name = layer_mapping.resolve("lc_gen_predio")
    active_keys = BatchInserter(
        db,
        "INSERT INTO all_active_predio_key(pk_key) VALUES (?)",
        cancel_check=cancel_check,
    )
    predios = BatchInserter(
        db,
        "INSERT INTO predio("
        "pk_id,pk_key,numero_predial_nacional,proyecto,matricula_inmobiliaria,"
        "destinacion_economica,destination_key,area_catastral_terreno,"
        "juridico_assignment_key,juridico_control_key,"
        "reconocimiento_assignment_key,reconocimiento_control_key,"
        "informal_assignment_key,informal_control_key,"
        "geografico_assignment_key,geografico_control_key,"
        "juridico_predio_para_visita,reconocimiento_predio_para_visita,"
        "predio_tiene_cambio_fisico) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    )
    with active_keys, predios:
        for row in data_source.iter_rows(physical_name, fields):
            raise_if_cancelled(cancel_check)
            if not postgres_boolean_is_false_or_null(
                row.get("juridico_predio_cancelado")
            ):
                continue
            pk_key = _join_token(row.get("pk_id"))
            active_keys.add((pk_key,))
            predios.add(
                (
                    row.get("pk_id"),
                    pk_key,
                    row.get("numero_predial_nacional"),
                    row.get("nombre_proyecto"),
                    row.get("matricula_inmobiliaria"),
                    row.get("destinacion_economica"),
                    _join_token(row.get("destinacion_economica")),
                    row.get("area_catastral_terreno"),
                    _join_token(row.get("juridico_estado_asignacion")),
                    _join_token(row.get("juridico_estado_control")),
                    _join_token(row.get("reconocimiento_estado_asignacion")),
                    _join_token(row.get("reconocimiento_estado_control")),
                    _join_token(row.get("informal_estado_asignacion")),
                    _join_token(row.get("informal_estado_control")),
                    _join_token(row.get("geografico_estado_asignacion")),
                    _join_token(row.get("geografico_estado_control")),
                    row.get("juridico_predio_para_visita"),
                    row.get("reconocimiento_predio_para_visita"),
                    row.get("predio_tiene_cambio_fisico"),
                )
            )


def _ingest_related(definition, data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve(definition.related_layer)
    with BatchInserter(
        db,
        "INSERT INTO related("
        "fk_key,pk_id,resultado_visita,nombre_quien_atendio,"
        "tipo_documento_quien_atendio,numero_documento_quien_atendio,"
        "tipo_foto) VALUES (?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, definition.related_fields):
            raise_if_cancelled(cancel_check)
            inserter.add(
                (
                    _join_token(row.get("fk_id")),
                    row.get("pk_id"),
                    row.get("resultado_visita"),
                    row.get("nombre_quien_atendio"),
                    row.get("tipo_documento_quien_atendio"),
                    row.get("numero_documento_quien_atendio"),
                    row.get("tipo_foto"),
                )
            )


def _prepare_selected(definition, db) -> None:
    if definition.join_mode == "inner":
        join_sql = (
            "JOIN related r ON r.fk_key = p.pk_key AND ("
            + definition.related_match_sql
            + ")"
        )
        absence_sql = ""
    elif definition.join_mode == "anti":
        join_sql = (
            "LEFT JOIN related r ON r.fk_key = p.pk_key AND ("
            + definition.related_match_sql
            + ")"
        )
        absence_sql = "r.row_token IS NULL AND "
    else:
        raise ValueError("join_mode invalido: {0}".format(definition.join_mode))
    db.execute(
        """
        INSERT INTO selected(
            predio_row_token,related_row_token,pk_id,pk_key,
            numero_predial_nacional,proyecto,matricula_inmobiliaria,
            destination_key,area_catastral_terreno,juridico_assignment_key,
            juridico_control_key,reconocimiento_assignment_key,
            reconocimiento_control_key,informal_assignment_key,
            informal_control_key,geografico_assignment_key,
            geografico_control_key,related_pk_id)
        SELECT
            p.row_token,r.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,
            p.proyecto,p.matricula_inmobiliaria,p.destination_key,
            p.area_catastral_terreno,p.juridico_assignment_key,
            p.juridico_control_key,p.reconocimiento_assignment_key,
            p.reconocimiento_control_key,p.informal_assignment_key,
            p.informal_control_key,p.geografico_assignment_key,
            p.geografico_control_key,r.pk_id
        FROM predio p
        {join_sql}
        WHERE {absence_sql}({predicate_sql})
        """.format(
            join_sql=join_sql,
            absence_sql=absence_sql,
            predicate_sql=definition.predicate_sql,
        )
    )


def _prepare_indexes(db) -> None:
    db.executescript(
        """
        CREATE INDEX idx_active_predio_pk ON all_active_predio_key(pk_key);
        CREATE INDEX idx_predio_pk ON predio(pk_key);
        CREATE INDEX idx_related_fk ON related(fk_key);
        CREATE INDEX idx_selected_pk ON selected(pk_key);
        CREATE INDEX idx_selected_destination ON selected(destination_key);
        CREATE INDEX idx_destination_key ON destination_lookup(key_token);
        CREATE INDEX idx_exception_fk ON exception_lookup(fk_token);
        CREATE INDEX idx_user_assignment_fk ON user_assignment(fk_token);
        CREATE INDEX idx_assignment_key ON assignment_lookup(key_token);
        CREATE INDEX idx_control_key ON control_lookup(key_token);
        """
    )


def _result_sql(definition) -> str:
    duplicate_join = (
        "LEFT JOIN all_active_predio_key duplicate_predio "
        "ON duplicate_predio.pk_key = p.pk_key"
        if definition.duplicate_predio_join
        else ""
    )
    duplicate_order = (
        ",duplicate_predio.row_token" if definition.duplicate_predio_join else ""
    )
    return """
        SELECT
            p.pk_id,p.numero_predial_nacional,p.proyecto,p.matricula_inmobiliaria,
            d.ilicode,p.area_catastral_terreno,e.fid,e.descripcion_excepcion,
            jur_asig.ilicode,jur_ctrl.ilicode,reco_asig.ilicode,reco_ctrl.ilicode,
            info_asig.ilicode,info_ctrl.ilicode,geo_asig.ilicode,geo_ctrl.ilicode,
            ua.pk_id,p.related_pk_id
        FROM selected p
        {duplicate_join}
        LEFT JOIN destination_lookup d ON d.key_token = p.destination_key
        LEFT JOIN exception_lookup e ON e.fk_token = p.pk_key
        LEFT JOIN user_assignment ua ON ua.fk_token = p.pk_key
        LEFT JOIN assignment_lookup jur_asig
            ON jur_asig.key_token = p.juridico_assignment_key
        LEFT JOIN control_lookup jur_ctrl
            ON jur_ctrl.key_token = p.juridico_control_key
        LEFT JOIN assignment_lookup reco_asig
            ON reco_asig.key_token = p.reconocimiento_assignment_key
        LEFT JOIN control_lookup reco_ctrl
            ON reco_ctrl.key_token = p.reconocimiento_control_key
        LEFT JOIN assignment_lookup info_asig
            ON info_asig.key_token = p.informal_assignment_key
        LEFT JOIN control_lookup info_ctrl
            ON info_ctrl.key_token = p.informal_control_key
        LEFT JOIN assignment_lookup geo_asig
            ON geo_asig.key_token = p.geografico_assignment_key
        LEFT JOIN control_lookup geo_ctrl
            ON geo_ctrl.key_token = p.geografico_control_key
        ORDER BY
            p.numero_predial_nacional IS NULL,p.numero_predial_nacional,
            p.proyecto IS NULL,p.proyecto,p.predio_row_token,p.related_row_token
            {duplicate_order},d.row_token,e.row_token,ua.row_token,
            jur_asig.row_token,jur_ctrl.row_token,reco_asig.row_token,
            reco_ctrl.row_token,info_asig.row_token,info_ctrl.row_token,
            geo_asig.row_token,geo_ctrl.row_token
    """.format(
        duplicate_join=duplicate_join,
        duplicate_order=duplicate_order,
    )


def _canonical_row(definition, execution_timestamp, values) -> dict[str, Any]:
    base = _result_row(definition, execution_timestamp, values[:-1])
    related_pk = values[-1]
    base["tabla_error_1"] = definition.table_error_1
    base["pk_tabla_error_1"] = (
        related_pk if definition.table_error_1_source == "related" else base["pk_id_predio"]
    )
    base["tabla_error_2"] = definition.table_error_2
    base["pk_tabla_error_2"] = (
        related_pk if definition.table_error_2_source == "related" else None
    )
    return base


def execute_related_scalar(
    definition: RelatedScalarRule,
    data_source,
    layer_mapping,
    cancel_check=None,
) -> Iterator[dict[str, Any]]:
    execution_timestamp = datetime.now()
    prefix = "mapingtool-calidad-gpkg-{0}-".format(definition.canonical_id.lower())
    with sqlite_staging(cancel_check, prefix=prefix) as db:
        _create_stage(db)
        _ingest_predios(definition, data_source, layer_mapping, db, cancel_check)
        _ingest_related(definition, data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(definition, data_source, layer_mapping, db, cancel_check)
        _prepare_selected(definition, db)
        _prepare_indexes(db)
        db.commit()
        raise_if_cancelled(cancel_check)
        cursor = db.execute(_result_sql(definition))
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                yield _canonical_row(definition, execution_timestamp, values)
        finally:
            cursor.close()
