"""Portable PH interested-party history and duplicate-identity rules."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,raise_if_cancelled,sqlite_staging
@dataclass(frozen=True)
class Rule:
 canonical_id:str;component:str;description:str;mode:str;custom_7:bool=False
RULES={"PH_46":Rule("PH_46","Interesado","Interesados PH anteriores que no existen en la base de datos","missing_current"),"PH_47":Rule("PH_47","Interesado","Interesados PH nuevos existentes en los interesados PH anterior","reused_new"),"PH_53":Rule("PH_53","Interesado","Interesados PH con el mismo documento de identidad pero diferente nombre","duplicate_name")}
GF=("pk_id","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control");PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno");IF=("fid","pk_id","fk_id","tipo_documento","documento_identidad","nombre_completo_propietario")
def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE excluded(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE right_(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,ph_key TEXT);CREATE TABLE current_(row_token INTEGER PRIMARY KEY,fid,pk_id,pk_key TEXT,right_key TEXT,document_type,document,full_name);CREATE TABLE prior(row_token INTEGER PRIMARY KEY,fid,pk_id,pk_key TEXT,right_key TEXT,document_type,document,full_name);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,ph_key TEXT,error_table,error_pk,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 with BatchInserter(db,"INSERT INTO excluded(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
 with BatchInserter(db,"INSERT INTO right_(pk_id,pk_key,ph_key)VALUES(?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_derecho"),("pk_id","fk_id")):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id"))))
 for logical,table in(("lc_ph_interesado","current_"),("lc_ph_interesado_anterior","prior")):
  with BatchInserter(db,f"INSERT INTO {table}(fid,pk_id,pk_key,right_key,document_type,document,full_name)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve(logical),IF):raise_if_cancelled(cancel);ins.add((r.get("fid"),r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("tipo_documento"),r.get("documento_identidad"),r.get("nombre_completo_propietario")))
def _prepare(definition,db):
 pre="INSERT INTO selected(general_pk,ph_pk,ph_key,error_table,error_pk,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)";base="SELECT g.pk_id,p.pk_id,p.pk_key,{table},{error},p.npn,g.project,p.registration,p.destination_key,p.area,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c FROM ph p JOIN gen g ON g.pk_key=p.parent_key JOIN right_ r ON r.ph_key=p.pk_key {joins} WHERE NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key)AND {predicate}"
 if definition.mode=="missing_current":q=base.format(table="'LC_PH_InteresadoAnterior'",error="a.pk_id",joins="JOIN prior a ON a.right_key=r.pk_key LEFT JOIN current_ i ON i.pk_key=a.pk_key",predicate="i.fid IS NULL")
 elif definition.mode=="reused_new":q=base.format(table="'LC_PH_Interesado'",error="i.pk_id",joins="JOIN current_ i ON i.right_key=r.pk_key LEFT JOIN prior a ON a.right_key=i.right_key AND a.document=i.document",predicate="i.pk_id LIKE '{%' AND a.fid IS NOT NULL")
 else:q=base.format(table="'LC_PH_Interesado'",error="i.pk_id",joins="JOIN current_ i ON i.right_key=r.pk_key JOIN(SELECT document FROM(SELECT document_type,document,full_name,count(*)n FROM current_ i2 JOIN right_ r2 ON r2.pk_key=i2.right_key JOIN ph p2 ON p2.pk_key=r2.ph_key WHERE NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p2.pk_key)AND document<>'0'GROUP BY document_type,document,full_name HAVING count(*)>1)q GROUP BY document HAVING count(*)>1)d ON d.document=i.document",predicate="1=1")
 db.execute(pre+q)
RESULT="""SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.error_table,s.error_pk FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project,s.error_pk IS NULL,s.error_pk"""
def execute_relations(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]=v[18]if rid=="PH_46"else"LC_PH_Predio";row["pk_tabla_error_1"]=v[19]if rid=="PH_46"else v[17];row["tabla_error_2"]=None if rid=="PH_46"else v[18];row["pk_tabla_error_2"]=None if rid=="PH_46"else v[19];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_relations(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_46=_entry("PH_46");execute_ph_47=_entry("PH_47");execute_ph_53=_entry("PH_53")
