"""Independent portable implementation of canonical Reco_19."""
from .portable_reco_aggregate import execute_reco_19 as _execute


def execute_reco_19(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
