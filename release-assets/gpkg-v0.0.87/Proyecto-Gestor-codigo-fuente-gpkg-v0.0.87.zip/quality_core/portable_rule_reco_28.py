"""Independent portable implementation of canonical Reco_28."""
from .portable_reco_calification import execute_calification_rule
def execute_reco_28(data_source,layer_mapping,cancel_check=None): return execute_calification_rule("Reco_28",data_source,layer_mapping,cancel_check)
