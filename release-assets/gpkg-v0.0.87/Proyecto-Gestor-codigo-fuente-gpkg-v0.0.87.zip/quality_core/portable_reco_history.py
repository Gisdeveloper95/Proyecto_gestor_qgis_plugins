"""Disk-backed portable engine for historical RECO comparisons."""

from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
    sqlite_staging,
)


_CURRENT_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado",
    "nombre_proyecto", "matricula_inmobiliaria", "destinacion_economica",
    "area_catastral_terreno", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control", "informal_estado_asignacion",
    "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
_PREVIOUS_PREDIO_FIELDS = (
    "pk_id", "numero_predial_nacional", "nombre_proyecto",
    "matricula_inmobiliaria", "destinacion_economica",
    "area_catastral_terreno",
)
_PREVIOUS_CHARACTERISTIC_FIELDS = (
    "pk_id", "fk_id", "identificador", "total_plantas",
    "tipo_unidad_construccion", "area_construida", "puntaje_anterior",
)


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE current_predio (
            row_token INTEGER PRIMARY KEY, pk_id, pk_key TEXT, active INTEGER,
            numero_predial_nacional, proyecto, matricula_inmobiliaria,
            destination_key TEXT, area_catastral_terreno,
            juridico_assignment_key TEXT, juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT, informal_assignment_key TEXT,
            informal_control_key TEXT, geografico_assignment_key TEXT,
            geografico_control_key TEXT
        );
        CREATE TABLE previous_predio (
            row_token INTEGER PRIMARY KEY, pk_id, pk_key TEXT,
            numero_predial_nacional, proyecto, matricula_inmobiliaria,
            destination_key TEXT, area_catastral_terreno
        );
        CREATE TABLE previous_characteristic (
            row_token INTEGER PRIMARY KEY, pk_id, pk_key TEXT,
            predio_key TEXT, identificador, total_plantas, type_key TEXT,
            area_construida, puntaje_anterior
        );
        CREATE TABLE current_characteristic (
            row_token INTEGER PRIMARY KEY, pk_key TEXT
        );
        CREATE TABLE unit_type_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE destination_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE exception_lookup (
            row_token INTEGER PRIMARY KEY, fk_token TEXT, fid,
            descripcion_excepcion
        );
        CREATE TABLE user_assignment (
            row_token INTEGER PRIMARY KEY, fk_token TEXT, pk_id
        );
        CREATE TABLE assignment_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE control_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        """
    )


def _ingest_current(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("lc_gen_predio")
    sql = (
        "INSERT INTO current_predio(pk_id,pk_key,active,numero_predial_nacional,"
        "proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno,"
        "juridico_assignment_key,juridico_control_key,"
        "reconocimiento_assignment_key,reconocimiento_control_key,"
        "informal_assignment_key,informal_control_key,"
        "geografico_assignment_key,geografico_control_key) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    )
    with BatchInserter(db, sql, cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical_name, _CURRENT_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                int(postgres_boolean_is_false_or_null(
                    row.get("juridico_predio_cancelado")
                )),
                row.get("numero_predial_nacional"), row.get("nombre_proyecto"),
                row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),
                row.get("area_catastral_terreno"),
                _join_token(row.get("juridico_estado_asignacion")),
                _join_token(row.get("juridico_estado_control")),
                _join_token(row.get("reconocimiento_estado_asignacion")),
                _join_token(row.get("reconocimiento_estado_control")),
                _join_token(row.get("informal_estado_asignacion")),
                _join_token(row.get("informal_estado_control")),
                _join_token(row.get("geografico_estado_asignacion")),
                _join_token(row.get("geografico_estado_control")),
            ))


def _ingest_previous_predios(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("lc_gen_predio_anterior")
    with BatchInserter(
        db,
        "INSERT INTO previous_predio(pk_id,pk_key,numero_predial_nacional,"
        "proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno) "
        "VALUES (?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, _PREVIOUS_PREDIO_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                row.get("numero_predial_nacional"), row.get("nombre_proyecto"),
                row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),
                row.get("area_catastral_terreno"),
            ))


def _ingest_characteristics(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve(
        "lc_reco_caracteristicasunidadconstruccion_anterior"
    )
    with BatchInserter(
        db,
        "INSERT INTO previous_characteristic(pk_id,pk_key,predio_key,"
        "identificador,total_plantas,type_key,area_construida,puntaje_anterior) "
        "VALUES (?,?,?,?,?,?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(
            physical_name, _PREVIOUS_CHARACTERISTIC_FIELDS
        ):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                _join_token(row.get("fk_id")), row.get("identificador"),
                row.get("total_plantas"),
                _join_token(row.get("tipo_unidad_construccion")),
                row.get("area_construida"), row.get("puntaje_anterior"),
            ))

    physical_name = layer_mapping.resolve(
        "lc_reco_caracteristicasunidadconstruccion"
    )
    with BatchInserter(
        db, "INSERT INTO current_characteristic(pk_key) VALUES (?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("pk_id",)):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("pk_id")),))

    physical_name = layer_mapping.resolve("lc_reco_unidadconstruccion_tipo")
    with BatchInserter(
        db, "INSERT INTO unit_type_lookup(key_token,ilicode) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("itfcode", "ilicode")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("itfcode")), row.get("ilicode")))


def _prepare_indexes(db) -> None:
    db.executescript(
        """
        CREATE INDEX idx_current_predio_key ON current_predio(pk_key);
        CREATE INDEX idx_previous_predio_key ON previous_predio(pk_key);
        CREATE INDEX idx_previous_characteristic_predio
            ON previous_characteristic(predio_key);
        CREATE INDEX idx_current_characteristic_key
            ON current_characteristic(pk_key);
        CREATE INDEX idx_unit_type_key ON unit_type_lookup(key_token);
        CREATE INDEX idx_destination_key ON destination_lookup(key_token);
        CREATE INDEX idx_exception_key ON exception_lookup(fk_token);
        CREATE INDEX idx_user_assignment_key ON user_assignment(fk_token);
        CREATE INDEX idx_assignment_key ON assignment_lookup(key_token);
        CREATE INDEX idx_control_key ON control_lookup(key_token);
        """
    )


def _base_joins(predio_alias: str, states_alias: str) -> str:
    return f"""
        LEFT JOIN destination_lookup d ON d.key_token={predio_alias}.destination_key
        LEFT JOIN exception_lookup e ON e.fk_token={predio_alias}.pk_key
        LEFT JOIN user_assignment ua ON ua.fk_token={predio_alias}.pk_key
        LEFT JOIN assignment_lookup jur_asig
            ON jur_asig.key_token={states_alias}.juridico_assignment_key
        LEFT JOIN control_lookup jur_ctrl
            ON jur_ctrl.key_token={states_alias}.juridico_control_key
        LEFT JOIN assignment_lookup reco_asig
            ON reco_asig.key_token={states_alias}.reconocimiento_assignment_key
        LEFT JOIN control_lookup reco_ctrl
            ON reco_ctrl.key_token={states_alias}.reconocimiento_control_key
        LEFT JOIN assignment_lookup info_asig
            ON info_asig.key_token={states_alias}.informal_assignment_key
        LEFT JOIN control_lookup info_ctrl
            ON info_ctrl.key_token={states_alias}.informal_control_key
        LEFT JOIN assignment_lookup geo_asig
            ON geo_asig.key_token={states_alias}.geografico_assignment_key
        LEFT JOIN control_lookup geo_ctrl
            ON geo_ctrl.key_token={states_alias}.geografico_control_key
    """


_COMMON = """
    {p}.pk_id,{p}.numero_predial_nacional,{p}.proyecto,
    {p}.matricula_inmobiliaria,d.ilicode,{p}.area_catastral_terreno,
    e.fid,e.descripcion_excepcion,jur_asig.ilicode,jur_ctrl.ilicode,
    reco_asig.ilicode,reco_ctrl.ilicode,info_asig.ilicode,info_ctrl.ilicode,
    geo_asig.ilicode,geo_ctrl.ilicode,ua.pk_id
"""


def _execute(rule_id, data_source, layer_mapping, cancel_check=None):
    descriptions = {
        "Reco_01": "Predios iniciales no existentes en la base de datos",
        "Reco_65": "Caracteristica Unidad de Construccion antigua eliminada",
    }
    definition = SimpleNamespace(
        canonical_id=rule_id,
        component="Juridico" if rule_id == "Reco_01" else "Reconocimiento",
        description=descriptions[rule_id], custom_7=False,
    )
    execution_timestamp = datetime.now()
    with sqlite_staging(
        cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-"
    ) as db:
        _create_stage(db)
        _ingest_current(data_source, layer_mapping, db, cancel_check)
        _ingest_previous_predios(data_source, layer_mapping, db, cancel_check)
        _ingest_characteristics(data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(
            definition, data_source, layer_mapping, db, cancel_check
        )
        _prepare_indexes(db)
        db.commit()
        if rule_id == "Reco_01":
            # The anti-join guarantees that current-state catalogue outputs are NULL.
            sql = f"""
                SELECT {_COMMON.format(p='p')}
                FROM previous_predio p
                LEFT JOIN current_predio states ON states.pk_key=p.pk_key
                {_base_joins('p', 'states')}
                WHERE states.row_token IS NULL
                ORDER BY p.numero_predial_nacional IS NULL,p.numero_predial_nacional,
                         p.proyecto IS NULL,p.proyecto,p.row_token,d.row_token,
                         e.row_token,ua.row_token
            """
        else:
            sql = f"""
                SELECT {_COMMON.format(p='p')},h.pk_id,h.identificador,
                       h.total_plantas,ut.ilicode,h.area_construida,h.puntaje_anterior
                FROM current_predio p
                JOIN previous_characteristic h ON h.predio_key=p.pk_key
                LEFT JOIN current_characteristic c ON c.pk_key=h.pk_key
                LEFT JOIN unit_type_lookup ut ON ut.key_token=h.type_key
                {_base_joins('p', 'p')}
                WHERE p.active=1 AND c.row_token IS NULL
                ORDER BY p.numero_predial_nacional IS NULL,p.numero_predial_nacional,
                         p.proyecto IS NULL,p.proyecto,h.identificador IS NULL,
                         h.identificador,p.row_token,h.row_token,ut.row_token,
                         d.row_token,e.row_token,ua.row_token
            """
        cursor = db.execute(sql)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                base = _result_row(definition, execution_timestamp, values[:17])
                if rule_id == "Reco_65":
                    characteristic_pk, identifier, floors, unit_type, area, score = values[17:]
                    base.update({
                        "tabla_error_1": "LC_Reco_CaracteristicasUnidadConstruccion_Anterior",
                        "pk_tabla_error_1": characteristic_pk,
                        "identificador_caracteristica_unidad_construccion": identifier,
                        "total_plantas": floors,
                        "tipo_unidad_construccion": unit_type,
                        "area_construida": area,
                        "puntaje_calificacion": score,
                    })
                yield base
        finally:
            cursor.close()


def execute_reco_01(data_source, layer_mapping, cancel_check=None):
    return _execute("Reco_01", data_source, layer_mapping, cancel_check)


def execute_reco_65(data_source, layer_mapping, cancel_check=None):
    return _execute("Reco_65", data_source, layer_mapping, cancel_check)
