"""Independent portable implementation of the canonical Reco_60 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


_URBAN_RARE_DESTINATIONS = frozenset(
    (0, 1, 2, 3, 4, 5, 7, 8, 9, 12, 13, 14, 15, 16, 17, 18, 19, 23, 24, 25, 26, 27, 28, 29, 30)
)


def _matches(row: Mapping[str, Any]) -> bool:
    return (
        postgres_substring(row.get("numero_predial_nacional"), 6, 2) == "01"
        and row.get("destinacion_economica") in _URBAN_RARE_DESTINATIONS
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_60",
    component="Calificacion",
    description="Predios urbanos con destinos economicos raros",
    predicate=_matches,
    custom_7=False,
)


def execute_reco_60(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_60 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
