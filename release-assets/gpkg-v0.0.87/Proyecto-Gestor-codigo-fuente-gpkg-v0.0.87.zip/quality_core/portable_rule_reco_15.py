"""Independent portable implementation of canonical Reco_15."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_15", "Reconocimiento",
    "Predios sin marca de visita en la etapa de reconocimiento con foto de fachada, unidades, cocina, anexo, etc",
    "lc_gen_fotos_predio", ("pk_id", "fk_id", "tipo_foto"), "inner",
    "r.tipo_foto IN (1,2,3,4,5,6,7,8,9)",
    "(p.reconocimiento_predio_para_visita IS NULL OR p.reconocimiento_predio_para_visita = 0) "
    "AND (p.juridico_predio_para_visita IS NULL OR p.juridico_predio_para_visita = 0)",
    "LC_Gen_Predio", "predio", "LC_Gen_Fotos_Predio", "related",
    predio_filter_fields=("reconocimiento_predio_para_visita", "juridico_predio_para_visita"),
)

def execute_reco_15(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
