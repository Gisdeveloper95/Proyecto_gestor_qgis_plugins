"""Independent portable implementation of canonical Reco_70."""
from .portable_reco_photos import execute_reco_70 as _execute


def execute_reco_70(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
