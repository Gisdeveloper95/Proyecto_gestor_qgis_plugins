"""Independent portable implementation of canonical Reco_44."""
from .portable_reco_calification import execute_calification_rule
def execute_reco_44(data_source,layer_mapping,cancel_check=None): return execute_calification_rule("Reco_44",data_source,layer_mapping,cancel_check)
