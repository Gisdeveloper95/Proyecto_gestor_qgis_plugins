"""Independent portable implementation of canonical Reco_65."""
from .portable_reco_history import execute_reco_65 as _execute


def execute_reco_65(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
