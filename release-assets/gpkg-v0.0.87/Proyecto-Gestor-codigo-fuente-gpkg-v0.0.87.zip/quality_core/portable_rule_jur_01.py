"""Independent portable implementation of the canonical Jur_01 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    matricula = row.get("matricula_inmobiliaria")
    return matricula is not None and len(str(matricula)) > 7


_RULE = PredioScalarRule(
    canonical_id="Jur_01",
    component="Juridico",
    description=(
        "Predios con matricula inmobiliaria y su longitud es mayor a 7 digitos"
    ),
    predicate=_matches,
    custom_7=False,
)


def execute_jur_01(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_01 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
