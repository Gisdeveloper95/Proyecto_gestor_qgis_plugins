"""Independent portable implementation of the canonical Reco_53 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    zone = postgres_substring(row.get("numero_predial_nacional"), 6, 2)
    area = row.get("area_catastral_terreno")
    return row.get("destinacion_economica") == 23 and (
        zone == "01" or (area is not None and area > 1000)
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_53",
    component="Calificacion",
    description=(
        "Predios con destino economico igual a lote rural en la zona urbana "
        "o mayores a 1000 metros"
    ),
    predicate=_matches,
    custom_7=False,
)


def execute_reco_53(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_53 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
