"""Independent portable implementation of the canonical Jur_05 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_boolean_is_true


def _matches(row: Mapping[str, Any]) -> bool:
    matricula = row.get("matricula_inmobiliaria")
    return (matricula is None or matricula == 0) and postgres_boolean_is_true(
        row.get("juridico_cambio_juridico")
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_05",
    component="Juridico",
    description=(
        "Predios con marca en el cambio juridico sin matricula inmobiliaria"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=("juridico_cambio_juridico",),
)


def execute_jur_05(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_05 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
