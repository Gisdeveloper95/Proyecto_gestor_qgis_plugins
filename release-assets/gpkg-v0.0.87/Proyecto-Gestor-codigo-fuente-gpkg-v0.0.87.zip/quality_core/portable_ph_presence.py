"""Portable direction, right and active-interested PH presence rules."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,postgres_boolean_is_true,raise_if_cancelled,sqlite_staging
@dataclass(frozen=True)
class Rule:
 canonical_id:str;component:str;description:str;mode:str;exclude_parent:bool=False;custom_7:bool=False
RULES={"PH_20":Rule("PH_20","PH","Predios PH sin dirección","direction"),"PH_21":Rule("PH_21","Juridico","Predios PH con mas de un derecho","multi_right"),"PH_22":Rule("PH_22","Juridico","Predios PH sin interesados activos","no_active"),"PH_77":Rule("PH_77","PH","Predios PH sin interesados activos","no_active_rights",True)}
GF=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control");PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,cancelled,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE excluded_ph(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE excluded_gen(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE direction(row_token INTEGER PRIMARY KEY,pk_id,fid,fk_key TEXT,property_name);CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,fk_key TEXT);CREATE TABLE interested(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,owner_state);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,ph_key TEXT,error_pk,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(definition,source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,npn,cancelled,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("juridico_predio_cancelado"),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 with BatchInserter(db,"INSERT INTO excluded_ph(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
 if definition.exclude_parent:
  with BatchInserter(db,"INSERT INTO excluded_gen(key_token)VALUES(?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"),("fk_id","tipo_novedad")):
    raise_if_cancelled(cancel)
    if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
   for k,npn,cancelled in db.execute("SELECT pk_key,npn,cancelled FROM gen"):
    if postgres_boolean_is_true(cancelled)and npn is not None and len(npn)>=22 and npn[21:22]=='9':ins.add((k,))
 if definition.mode=="direction":
  with BatchInserter(db,"INSERT INTO direction(pk_id,fid,fk_key,property_name)VALUES(?,?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_ph_direccion"),("pk_id","fid","fk_id","nombre_predio")):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),r.get("fid"),_join_token(r.get("fk_id")),r.get("nombre_predio")))
 if definition.mode in("multi_right","no_active","no_active_rights"):
  with BatchInserter(db,"INSERT INTO derecho(pk_id,pk_key,fk_key)VALUES(?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_ph_derecho"),("pk_id","fk_id")):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id"))))
 if definition.mode in("no_active","no_active_rights"):
  with BatchInserter(db,"INSERT INTO interested(pk_id,fk_key,owner_state)VALUES(?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_ph_interesado"),("pk_id","fk_id","estado_propietario")):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),r.get("estado_propietario")))
def _eligible(definition):return"NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.key_token=p.pk_key)"+(" AND NOT EXISTS(SELECT 1 FROM excluded_gen y WHERE y.key_token=p.parent_key)"if definition.exclude_parent else"")
def _prepare(definition,db):
 join="LEFT JOIN gen g ON p.parent_key=g.pk_key"if definition.mode=="no_active_rights"else"JOIN gen g ON p.parent_key=g.pk_key";base=f"SELECT g.pk_id,p.pk_id,p.pk_key,{{error}},p.npn,g.project,p.registration,p.destination_key,p.area,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c FROM ph p {join} {{extra}} WHERE {_eligible(definition)} {{predicate}}"
 if definition.mode=="direction":q=base.format(error="d.pk_id",extra="LEFT JOIN direction d ON d.fk_key=p.pk_key",predicate="AND(d.fid IS NULL OR d.property_name IS NULL)")
 elif definition.mode=="multi_right":q=base.format(error="NULL",extra="JOIN(SELECT fk_key FROM derecho GROUP BY fk_key HAVING count(*)>1)r ON r.fk_key=p.pk_key",predicate="")
 elif definition.mode=="no_active":q=base.format(error="NULL",extra="",predicate="AND NOT EXISTS(SELECT 1 FROM derecho d JOIN interested i ON i.fk_key=d.pk_key WHERE d.fk_key=p.pk_key AND i.owner_state<>0)")
 else:q=base.format(error="d.pk_id",extra="LEFT JOIN derecho d ON d.fk_key=p.pk_key",predicate="AND NOT EXISTS(SELECT 1 FROM derecho d2 JOIN interested i ON i.fk_key=d2.pk_key WHERE d2.fk_key=p.pk_key AND i.owner_state<>0)")
 db.execute("INSERT INTO selected(general_pk,ph_pk,ph_key,error_pk,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)"+q)
RESULT="""SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.error_pk FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project"""
def execute_presence(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(definition,source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]="LC_PH_Predio";row["pk_tabla_error_1"]=v[17];row["tabla_error_2"]="LC_PH_Direccion"if rid=="PH_20"else"LC_PH_Derecho";row["pk_tabla_error_2"]=v[18]if rid in("PH_20","PH_77")else None;yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_presence(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_20=_entry("PH_20");execute_ph_21=_entry("PH_21");execute_ph_22=_entry("PH_22");execute_ph_77=_entry("PH_77")
