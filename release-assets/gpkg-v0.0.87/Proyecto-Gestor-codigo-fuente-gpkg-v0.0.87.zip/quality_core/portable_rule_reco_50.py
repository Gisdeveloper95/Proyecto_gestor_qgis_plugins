"""Independent portable implementation of the canonical Reco_50 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    return (
        row.get("destinacion_economica_anterior") == "10-Habitacional"
        and row.get("destinacion_economica") in (6, 11)
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_50",
    component="Calificacion",
    description=(
        "Predios con destino economico anterior igual a habitacional y ahora "
        "destino economico comercial e industrial"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=("destinacion_economica_anterior",),
)


def execute_reco_50(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_50 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
