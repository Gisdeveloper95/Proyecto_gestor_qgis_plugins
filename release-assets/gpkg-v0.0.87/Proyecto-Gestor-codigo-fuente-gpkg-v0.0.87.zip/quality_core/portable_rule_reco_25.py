"""Independent portable implementation of canonical Reco_25."""

from .portable_construction_scalar import (
    ConstructionScalarRule,
    execute_construction_scalar,
)


_RULE = ConstructionScalarRule(
    "Reco_25",
    "Calificacion",
    "Caracteristica Unidad de Construccion con un total de plantas menor a 1 o mayor a 6",
    "c.total_plantas < 1 OR c.total_plantas > 6",
    False,
    duplicate_predio_join=True,
)


def execute_reco_25(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
