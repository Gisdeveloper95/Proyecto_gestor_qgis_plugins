"""Independent portable implementation of canonical Reco_69."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_69", "Reconocimiento",
    "Predios con contacto de Visita con tipo de documento igual a sin información y con documento de identidad, o sin documento de identidad pero con tipo de documento \ndiferente a sin_informacion",
    "lc_vis_contactovisita",
    ("pk_id", "fk_id", "tipo_documento_quien_atendio", "numero_documento_quien_atendio"),
    "inner", "1=1",
    "(r.tipo_documento_quien_atendio = 7 AND r.numero_documento_quien_atendio NOT IN ('0','1','')) "
    "OR (r.tipo_documento_quien_atendio <> 7 AND (r.numero_documento_quien_atendio IN ('0','1','') "
    "OR r.numero_documento_quien_atendio IS NULL))",
    "LC_Vis_ContactoVisita", "related",
)

def execute_reco_69(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
