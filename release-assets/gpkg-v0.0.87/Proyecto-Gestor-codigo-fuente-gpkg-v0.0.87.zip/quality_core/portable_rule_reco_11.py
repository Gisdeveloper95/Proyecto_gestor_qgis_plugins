"""Independent portable implementation of canonical Reco_11."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_11", "Reconocimiento",
    "Predios con destino economico diferente a lote con resultado de visita exitoso sin informacion del nombre de quien lo atendio",
    "lc_vis_contactovisita", ("pk_id", "fk_id", "resultado_visita", "nombre_quien_atendio"),
    "inner", "1=1",
    "p.destinacion_economica NOT IN (20,21,22,23) AND r.resultado_visita = 0 AND r.nombre_quien_atendio IS NULL",
    "LC_Gen_Predio", "predio", "LC_Vis_ContactoVisita", "related",
)

def execute_reco_11(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
