"""Independent portable implementation of the canonical Jur_07 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    position_18 = postgres_substring(row.get("numero_predial_nacional"), 18, 1)
    return (
        row.get("numero_predial_nacional_anterior") is None
        and position_18 is not None
        and position_18 != "A"
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_07",
    component="Juridico",
    description="Predios nuevos sin la letra A en la posicion 18",
    predicate=_matches,
    custom_7=True,
    filter_fields=("numero_predial_nacional_anterior",),
)


def execute_jur_07(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_07 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
