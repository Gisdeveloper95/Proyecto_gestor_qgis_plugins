"""PostgreSQL implementation of the user-configurable RECO scope."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
import re
from typing import Any

from .reco_filter_policy import (
    DEFAULT_RECO_FILTER_POLICY,
    normalize_reco_filter_policy,
)


def load_configurable_reco_post_filter_sql(
    policy: Mapping[str, Any] | None = None,
) -> str:
    """Build the PostgreSQL RECO scope from the four UI switches."""

    normalized = normalize_reco_filter_policy(policy)
    if normalized == DEFAULT_RECO_FILTER_POLICY:
        path = Path(__file__).resolve().with_name("reco_post_filter.sql")
        sql = path.read_text(encoding="utf-8")
        return re.sub(r";\s*$", "", sql.strip())

    predicates = []
    if normalized["exclude_cancelled"]:
        predicates.append(
            "coalesce(p.juridico_predio_cancelado, false) = false"
        )
    if normalized["require_assignment_2"]:
        predicates.append(
            "btrim(p.reconocimiento_estado_asignacion::text) = '2'"
        )
    if normalized["exclude_conditions"]:
        predicates.append(
            "regexp_replace(\n"
            "        btrim(coalesce(p.condicion::text, '')),\n"
            "        '\\.0$',\n"
            "        ''\n"
            "      ) NOT IN ('2', '5', '8', '9')"
        )
    if normalized["exclude_informal_visit"]:
        predicates.append(
            "coalesce(p.informal_predio_para_visita, false) = false"
        )
    where_sql = "\n  AND ".join(predicates) if predicates else "TRUE"
    return (
        "SELECT p.pk_id::text AS pk_id_predio\n"
        "FROM actualizacion.lc_gen_predio AS p\n"
        "WHERE {0}".format(where_sql)
    )
