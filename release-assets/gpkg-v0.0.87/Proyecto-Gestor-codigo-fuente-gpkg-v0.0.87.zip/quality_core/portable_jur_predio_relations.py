"""Disk-backed portable engine for juridical predio relation rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_boolean_is_false_or_null, raise_if_cancelled, sqlite_staging


@dataclass(frozen=True)
class RelationRule:
    canonical_id: str
    component: str
    description: str
    mode: str
    custom_7: bool
    predio_extra_fields: tuple[str, ...] = ()


RULES={
 "Jur_06":RelationRule("Jur_06","Juridico","Predios sin Numero Predial Nacional","right_length",True),
 "Jur_19":RelationRule("Jur_19","Fisico","Predios sin Direccion","direction_missing",True),
 "Jur_20":RelationRule("Jur_20","Juridico","Predios con mas de un derecho","right_count",False),
 "Jur_24":RelationRule("Jur_24","Juridico","Predios con marca juridica sin observacion juridica","mark_observation",False,("juridico_cambio_juridico","juridico_observaciones_generales")),
 "Jur_25":RelationRule("Jur_25","Juridico","Los predios asociados a tipo de predio privado y con tipo de derecho dominio deben tener Folio de Matriula Inmobiliaria.","right_domain_fmi",True),
}


_BASE_FIELDS=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")


def _create(db):
 db.executescript("""
 CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key TEXT,area_catastral_terreno,juridico_assignment_key TEXT,juridico_control_key TEXT,reconocimiento_assignment_key TEXT,reconocimiento_control_key TEXT,informal_assignment_key TEXT,informal_control_key TEXT,geografico_assignment_key TEXT,geografico_control_key TEXT,juridico_cambio_juridico,juridico_observaciones_generales);
 CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,type_key TEXT);
 CREATE TABLE derecho_tipo(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 CREATE TABLE direccion(row_token INTEGER PRIMARY KEY,fid,fk_key TEXT);
 CREATE TABLE marca(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT);
 CREATE TABLE selected(row_token INTEGER PRIMARY KEY,source_row INTEGER,pk_id,pk_key TEXT,numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key TEXT,area_catastral_terreno,juridico_assignment_key TEXT,juridico_control_key TEXT,reconocimiento_assignment_key TEXT,reconocimiento_control_key TEXT,informal_assignment_key TEXT,informal_control_key TEXT,geografico_assignment_key TEXT,geografico_control_key TEXT);
 CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
 CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
 CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 """)


def _ingest_predio(definition,data_source,layer_mapping,db,cancel_check):
 fields=tuple(dict.fromkeys((*_BASE_FIELDS,*definition.predio_extra_fields)))
 sql="INSERT INTO predio(pk_id,pk_key,numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno,juridico_assignment_key,juridico_control_key,reconocimiento_assignment_key,reconocimiento_control_key,informal_assignment_key,informal_control_key,geografico_assignment_key,geografico_control_key,juridico_cambio_juridico,juridico_observaciones_generales) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
 with BatchInserter(db,sql,cancel_check=cancel_check) as ins:
  for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),fields):
   raise_if_cancelled(cancel_check)
   if not postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado")): continue
   ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control")),r.get("juridico_cambio_juridico"),r.get("juridico_observaciones_generales")))


def _ingest_relations(definition,data_source,layer_mapping,db,cancel_check):
 if definition.mode in {"right_length","right_count","right_domain_fmi"}:
  right_fields=("pk_id","fk_id") if definition.mode=="right_count" else ("pk_id","fk_id","tipo_derecho")
  with BatchInserter(db,"INSERT INTO derecho(pk_id,fk_key,type_key) VALUES (?,?,?)",cancel_check=cancel_check) as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_derecho"),right_fields):
    raise_if_cancelled(cancel_check); ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),_join_token(r.get("tipo_derecho"))))
 if definition.mode in {"right_length","right_domain_fmi"}:
  with BatchInserter(db,"INSERT INTO derecho_tipo(key_token,ilicode) VALUES (?,?)",cancel_check=cancel_check) as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_derecho_tipo"),("itfcode","ilicode")):
    raise_if_cancelled(cancel_check); ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
 if definition.mode=="direction_missing":
  with BatchInserter(db,"INSERT INTO direccion(fid,fk_key) VALUES (?,?)",cancel_check=cancel_check) as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_direccion"),("fid","fk_id")):
    raise_if_cancelled(cancel_check); ins.add((r.get("fid"),_join_token(r.get("fk_id"))))
 if definition.mode=="mark_observation":
  with BatchInserter(db,"INSERT INTO marca(pk_id,fk_key) VALUES (?,?)",cancel_check=cancel_check) as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_marcasjuridicas"),("pk_id","fk_id")):
    raise_if_cancelled(cancel_check); ins.add((r.get("pk_id"),_join_token(r.get("fk_id"))))


_SELECT="SELECT p.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,p.proyecto,p.matricula_inmobiliaria,p.destination_key,p.area_catastral_terreno,p.juridico_assignment_key,p.juridico_control_key,p.reconocimiento_assignment_key,p.reconocimiento_control_key,p.informal_assignment_key,p.informal_control_key,p.geografico_assignment_key,p.geografico_control_key FROM predio p "
def _prepare(definition,db):
 if definition.mode=="right_length": tail="JOIN derecho r ON r.fk_key=p.pk_key JOIN derecho_tipo t ON t.key_token=r.type_key WHERE length(p.numero_predial_nacional) <> 30 OR p.numero_predial_nacional IS NULL"
 elif definition.mode=="direction_missing": tail="LEFT JOIN direccion d ON d.fk_key=p.pk_key WHERE d.fid IS NULL"
 elif definition.mode=="right_count": tail="JOIN (SELECT p2.pk_id FROM predio p2 JOIN derecho r ON r.fk_key=p2.pk_key GROUP BY p2.pk_id HAVING count(*)>1) c ON c.pk_id=p.pk_id"
 elif definition.mode=="mark_observation": tail="JOIN marca m ON m.fk_key=p.pk_key WHERE p.juridico_cambio_juridico=1 AND p.juridico_observaciones_generales IS NULL"
 elif definition.mode=="right_domain_fmi": tail="JOIN derecho r ON r.fk_key=p.pk_key JOIN derecho_tipo t ON t.key_token=r.type_key WHERE t.ilicode='Dominio' AND (p.matricula_inmobiliaria IS NULL OR p.matricula_inmobiliaria=0)"
 else: raise ValueError(definition.mode)
 db.execute("INSERT INTO selected(source_row,pk_id,pk_key,numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno,juridico_assignment_key,juridico_control_key,reconocimiento_assignment_key,reconocimiento_control_key,informal_assignment_key,informal_control_key,geografico_assignment_key,geografico_control_key) "+_SELECT+tail)


_RESULT="""SELECT s.pk_id,s.numero_predial_nacional,s.proyecto,s.matricula_inmobiliaria,d.ilicode,s.area_catastral_terreno,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=s.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.juridico_assignment_key LEFT JOIN control_lookup jc ON jc.key_token=s.juridico_control_key LEFT JOIN assignment_lookup ra ON ra.key_token=s.reconocimiento_assignment_key LEFT JOIN control_lookup rc ON rc.key_token=s.reconocimiento_control_key LEFT JOIN assignment_lookup ia ON ia.key_token=s.informal_assignment_key LEFT JOIN control_lookup ic ON ic.key_token=s.informal_control_key LEFT JOIN assignment_lookup ga ON ga.key_token=s.geografico_assignment_key LEFT JOIN control_lookup gc ON gc.key_token=s.geografico_control_key"""


def execute_relation_rule(rule_id,data_source,layer_mapping,cancel_check=None):
 definition=RULES[rule_id]; timestamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
  _create(db); _ingest_predio(definition,data_source,layer_mapping,db,cancel_check); _ingest_relations(definition,data_source,layer_mapping,db,cancel_check); _ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check); _prepare(definition,db); db.commit(); cur=db.execute(_RESULT)
  try:
   for values in cur:
    raise_if_cancelled(cancel_check); yield _result_row(definition,timestamp,values)
  finally: cur.close()


def _entry(rule_id):
 def execute(data_source,layer_mapping,cancel_check=None): return execute_relation_rule(rule_id,data_source,layer_mapping,cancel_check)
 execute.__name__=f"execute_{rule_id.lower()}"; return execute
execute_jur_06=_entry("Jur_06")
execute_jur_19=_entry("Jur_19")
execute_jur_20=_entry("Jur_20")
execute_jur_24=_entry("Jur_24")
execute_jur_25=_entry("Jur_25")
