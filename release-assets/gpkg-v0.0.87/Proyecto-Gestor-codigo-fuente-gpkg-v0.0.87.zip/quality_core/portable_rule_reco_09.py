"""Independent portable implementation of canonical Reco_09."""
from .portable_alias_source import AliasedFieldDataSource
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_09", "Calificacion",
    "Predios con destino economico Comercial, Industrial o Habitacional sin Caracteristica Unidad de Construccion Asociada",
    "determinacion_area_construccion", ("pk_id", "fk_id"), "anti", "1=1",
    "p.destinacion_economica IN (6,10,11)",
    "LC_Gen_Predio", "predio", "LC_Reco_Caracteristicasunidadconstruccion",
)

def execute_reco_09(data_source, layer_mapping, cancel_check=None):
    physical = layer_mapping.resolve("determinacion_area_construccion")
    adapted = AliasedFieldDataSource(data_source, physical, {"fk_id": "pk_id"})
    return execute_related_scalar(_RULE, adapted, layer_mapping, cancel_check)
