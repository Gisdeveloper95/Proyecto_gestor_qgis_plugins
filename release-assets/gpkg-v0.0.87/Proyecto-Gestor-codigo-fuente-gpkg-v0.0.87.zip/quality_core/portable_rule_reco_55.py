"""Independent portable implementation of canonical Reco_55."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_55", "Calificacion",
    "Predios con destino economico religioso sin uso de construccion religioso",
    "p.destinacion_economica IN (26) AND (c.uso_construccion IS NULL OR c.uso_construccion NOT IN (49,56,57,65))",
    False, table_error_1="LC_Gen_Predio", table_error_1_source="predio",
    table_error_2="LC_Reco_CaracteristicasUnidadConstruccion",
)

def execute_reco_55(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
