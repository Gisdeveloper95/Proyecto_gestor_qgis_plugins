"""Independent portable implementation of canonical Reco_56."""
from .portable_reco_owner_classification import execute_reco_56 as _execute
def execute_reco_56(data_source,layer_mapping,cancel_check=None):return _execute(data_source,layer_mapping,cancel_check)
