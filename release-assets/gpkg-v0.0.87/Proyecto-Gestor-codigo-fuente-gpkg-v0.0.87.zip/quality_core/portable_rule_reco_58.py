"""Independent portable implementation of the canonical Reco_58 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    destination = row.get("destinacion_economica")
    return (
        destination is not None
        and destination != 10
        and postgres_substring(row.get("numero_predial_nacional"), 22, 1)
        in ("2", "5")
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_58",
    component="Calificacion",
    description="Predios informales con destino economico diferente a habitacional",
    predicate=_matches,
    custom_7=False,
)


def execute_reco_58(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_58 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
