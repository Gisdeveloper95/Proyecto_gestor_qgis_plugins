"""Portable PH rating consistency rules PH_40 and PH_42 through PH_45."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator

from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,raise_if_cancelled,sqlite_staging

@dataclass(frozen=True)
class Rule:
 canonical_id:str;description:str;mode:str;component:str="PH";custom_7:bool=False
RULES={
 "PH_40":Rule("PH_40","Caracteristica Unidad de Construccion PH con multiples calificaciones","multiple"),
 "PH_42":Rule("PH_42","Caracteristica Unidad de Construccion PH con al menos un elemento de la calificación en valores negativos, es decir, errores en el detalle de la calificacion","negative"),
 "PH_43":Rule("PH_43","Caracteristica Unidad de Construccion PH con puntaje anterior mayor 5 puntos comparado con el puntaje nuevo","positive_delta"),
 "PH_44":Rule("PH_44","Caracteristica Unidad de Construccion PH con puntaje anterior menor 5 puntos comparado con el puntaje nuevo","negative_delta"),
 "PH_45":Rule("PH_45","Caracteristica Unidad de Construccion PH con puntajes de calificaciones anexas diferentes a los definidos en el estudio economico","annex_value"),
}
GF=("pk_id","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
DF=("pk_id","pk_carac","identificador","total_plantas","tipo_unidad_construccion","uso_construccion","area_construida","puntaje")
CF=("pk_id","fk_id","uso_residencial","uso_comercial","uso_industrial","uso_institucional","uso_anexo","puntaje_anterior","uso_anterior")
RATING_TABLES=(
 ("lc_ph_calificacioncomercial","LC_PH_CalificacionComercial","commercial"),
 ("lc_ph_calificacionindustrial","LC_PH_CalificacionIndustrial","industrial"),
 ("lc_ph_calificacionnoconvencional","LC_PH_CalificacionNoConvencional","annex"),
 ("lc_ph_calificacionresidencial","LC_PH_CalificacionResidencial","residential"),
)
NEGATIVE_FIELDS={
 "commercial":("armazon","muros","cubierta","conservacion_cubierta","fachada","cubrimiento_muros","piso","conservacion_acabados","mobiliario_banio","mobiliario_cocina"),
 "industrial":("armazon","muros","cubierta","conservacion_cubierta","fachada","cubrimiento_muros","piso","conservacion_acabados","mobiliario_banio","mobiliario_cocina","cerchas_complemento_industria"),
 "residential":("armazon","muros","cubierta","conservacion_cubierta","fachada","cubrimiento_muros","piso","conservacion_acabados","tamanio_banio","enchape_banio","mobiliario_banio","conservacion_banio","tamanio_cocina","enchape_cocina","mobiliario_cocina","conservacion_cocina"),
}

def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination,destination_key TEXT,area);CREATE TABLE excluded(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE construction(row_token INTEGER PRIMARY KEY,ph_key TEXT,characteristic_pk,characteristic_key TEXT,identifier,total_floors,unit_key TEXT,usage,usage_key TEXT,built_area,score);CREATE TABLE characteristic(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,ph_key TEXT,use_r,use_c,use_i,use_t,use_a,previous_score,previous_use);CREATE TABLE rating(row_token INTEGER PRIMARY KEY,pk_id,characteristic_key TEXT,rating_type,table_name,total_score,annex_key TEXT,negative);CREATE TABLE annex_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE construction_value(row_token INTEGER PRIMARY KEY,usage_text,score);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,output_pk,ph_pk,ph_key TEXT,characteristic_pk,rating_table,rating_pk,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT,identifier,total_floors,unit_key TEXT,usage_key TEXT,built_area,score,description);CREATE TABLE unit_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE usage_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")

def _ingest_base(definition,source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination,destination_key,area)VALUES(?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),r.get("destinacion_economica"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 with BatchInserter(db,"INSERT INTO excluded(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
 with BatchInserter(db,"INSERT INTO construction(ph_key,characteristic_pk,characteristic_key,identifier,total_floors,unit_key,usage,usage_key,built_area,score)VALUES(?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("determinacion_area_construccion"),DF):raise_if_cancelled(cancel);ins.add((_join_token(r.get("pk_id")),r.get("pk_carac"),_join_token(r.get("pk_carac")),r.get("identificador"),r.get("total_plantas"),_join_token(r.get("tipo_unidad_construccion")),r.get("uso_construccion"),_join_token(r.get("uso_construccion")),r.get("area_construida"),r.get("puntaje")))
 if definition.mode in("multiple","positive_delta","negative_delta"):
  with BatchInserter(db,"INSERT INTO characteristic(pk_id,pk_key,ph_key,use_r,use_c,use_i,use_t,use_a,previous_score,previous_use)VALUES(?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_ph_caracteristicasunidadconstruccion"),CF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("uso_residencial"),r.get("uso_comercial"),r.get("uso_industrial"),r.get("uso_institucional"),r.get("uso_anexo"),r.get("puntaje_anterior"),r.get("uso_anterior")))

def _ingest_ratings(definition,source,mapping,db,cancel):
 tables=RATING_TABLES
 if definition.mode=="negative":tables=tuple(x for x in tables if x[2]!="annex")
 if definition.mode=="annex_value":tables=(("lc_reco_cal_calificacionnoconvencional",None,"annex"),)
 with BatchInserter(db,"INSERT INTO rating(pk_id,characteristic_key,rating_type,table_name,total_score,annex_key,negative)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for logical,label,kind in tables:
   fields=["pk_id","fk_id"]
   if definition.mode in("positive_delta","negative_delta"):
    fields.append("tipo_anexo"if kind=="annex"else"total_calificacion")
   elif definition.mode=="annex_value":fields.append("tipo_anexo")
   elif definition.mode=="negative":fields.extend(NEGATIVE_FIELDS[kind])
   for r in source.iter_rows(mapping.resolve(logical),tuple(fields)):
    raise_if_cancelled(cancel);total=None;annex=None;negative=0
    if kind=="annex":annex=_join_token(r.get("tipo_anexo"))
    else:total=r.get("total_calificacion")
    if definition.mode=="negative":negative=int(any(r.get(f)==-1 for f in NEGATIVE_FIELDS[kind]))
    ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),kind,label,total,annex,negative))
 if definition.mode in("positive_delta","negative_delta","annex_value"):
  with BatchInserter(db,"INSERT INTO annex_lookup(key_token,ilicode)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_reco_cal_anexo_tipo"),("itfcode","ilicode")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
 if definition.mode=="annex_value":
  with BatchInserter(db,"INSERT INTO construction_value(usage_text,score)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_valoresconstruccion"),("tabla_usos_construccion","puntaje_calificacion")):raise_if_cancelled(cancel);ins.add((r.get("tabla_usos_construccion"),r.get("puntaje_calificacion")))

def _annex_score(value):
 if value is None:return None
 try:return int(str(value).split("_")[1])
 except(IndexError,ValueError):return None
def _previous_use(value):
 if value is None:return None
 try:return int(str(value).split("-")[0])
 except ValueError:return None
def _select(definition,db,cancel):
 prefix="INSERT INTO selected(general_pk,output_pk,ph_pk,ph_key,characteristic_pk,rating_table,rating_pk,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c,identifier,total_floors,unit_key,usage_key,built_area,score,description)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
 ratings=list(db.execute("SELECT row_token,pk_id,characteristic_key,rating_type,table_name,total_score,annex_key,negative FROM rating"));annex={k:v for k,v in db.execute("SELECT key_token,ilicode FROM annex_lookup")}
 selected=[]
 for p in db.execute("SELECT p.pk_id,p.pk_key,p.parent_key,p.npn,p.registration,p.destination_key,p.area,g.pk_id,g.project,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c FROM ph p JOIN gen g ON g.pk_key=p.parent_key WHERE NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key)"):
  ph_pk,ph_key,_,npn,reg,dest,area,gpk,project,*states=p
  for c in db.execute("SELECT characteristic_pk,characteristic_key,identifier,total_floors,unit_key,usage,usage_key,built_area,score FROM construction WHERE ph_key=?",(ph_key,)):
   cpk,ckey,identifier,floors,unit,usage,usage_key,built,score=c;chars=list(db.execute("SELECT use_r,use_c,use_i,use_t,use_a,previous_score,previous_use FROM characteristic WHERE pk_key=?",(ckey,)))
   matches=[r for r in ratings if r[2]==ckey]
   if definition.mode=="multiple":
    union={(r[3],r[1],r[4]) for r in matches}
    if len(union)>1:
     for r in matches:selected.append((gpk,gpk,ph_pk,ph_key,cpk,r[4],r[1],npn,project,reg,dest,area,*states,identifier,floors,unit,usage_key,built,score,definition.description))
   elif definition.mode=="negative":
    for r in matches:
     if r[7]:selected.append((gpk,gpk,ph_pk,ph_key,cpk,r[4],r[1],npn,project,reg,dest,area,*states,identifier,floors,unit,usage_key,built,score,definition.description if r[3]=="commercial" else definition.description.replace("calificación","calificacion")))
   elif definition.mode in("positive_delta","negative_delta"):
    for ch in chars:
     ur,uc,ui,ut,ua,previous,previous_use=ch;prior=_previous_use(previous_use)
     if previous is None or prior is None:continue
     for r in matches:
      kind=r[3]
      if kind=="commercial":current=uc if uc is not None else ut
      elif kind=="industrial":current=ui
      elif kind=="annex":current=ua
      else:current=ur
      new=_annex_score(annex.get(r[6])) if kind=="annex"else r[5]
      if current!=prior or new is None:continue
      delta=new-int(previous);ok=(0<delta<=5)if definition.mode=="positive_delta"else((0<delta<=5)if kind=="commercial"else(-5<=delta<0))
      if ok:selected.append((gpk,gpk,ph_pk,ph_key,cpk,r[4],r[1],npn,project,reg,dest,area,*states,identifier,floors,unit,usage_key,built,score,definition.description))
   else:
    for r in matches:
     annex_score=_annex_score(annex.get(r[6]));usage_exists=db.execute("SELECT 1 FROM usage_lookup WHERE key_token=? LIMIT 1",(usage_key,)).fetchone()is not None;value_exists=db.execute("SELECT 1 FROM construction_value WHERE usage_text=? AND score=? LIMIT 1",(str(usage),annex_score)).fetchone()is not None
     if not usage_exists or not value_exists:selected.append((gpk,ph_pk,ph_pk,ph_key,cpk,None,None,npn,project,reg,dest,area,*states,identifier,floors,unit,usage_key,built,score,definition.description))
  raise_if_cancelled(cancel)
 db.executemany(prefix,selected)

RESULT="""SELECT s.output_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.characteristic_pk,s.rating_table,s.rating_pk,s.identifier,s.total_floors,u.ilicode,v.ilicode,s.built_area,s.score,s.description FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key LEFT JOIN unit_lookup u ON u.key_token=s.unit_key LEFT JOIN usage_lookup v ON v.key_token=s.usage_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c ORDER BY s.characteristic_pk IS NULL,s.characteristic_pk,s.rating_pk IS NULL,s.rating_pk,s.npn IS NULL,s.npn"""
def execute_ratings(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest_base(definition,source,mapping,db,cancel_check);_ingest_ratings(definition,source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check)
  for logical,table in(("lc_reco_unidadconstruccion_tipo","unit_lookup"),("lc_gen_usouconstruccion_tipo","usage_lookup")):
   with BatchInserter(db,f"INSERT INTO {table}(key_token,ilicode)VALUES(?,?)",cancel_check=cancel_check)as ins:
    for r in source.iter_rows(mapping.resolve(logical),("itfcode","ilicode")):raise_if_cancelled(cancel_check);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
  _select(definition,db,cancel_check);db.commit();cur=db.execute(RESULT)
  try:
   for x in cur:
    raise_if_cancelled(cancel_check);local=Rule(rid,x[27],definition.mode);row=_result_row(local,stamp,x[:17]);row["tabla_error_1"]="LC_Reco_Caracteristicasunidadconstruccion"if rid=="PH_45"else"LC_PH_Caracteristicasunidadconstruccion";row["pk_tabla_error_1"]=x[18];row["tabla_error_2"]=x[19];row["pk_tabla_error_2"]=x[20];row["identificador_caracteristica_unidad_construccion"]=x[21];row["total_plantas"]=x[22];row["tipo_unidad_construccion"]=x[23];row["uso_construccion"]=x[24];row["area_construida"]=x[25];row["puntaje_calificacion"]=x[26];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_ratings(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_40=_entry("PH_40");execute_ph_42=_entry("PH_42");execute_ph_43=_entry("PH_43");execute_ph_44=_entry("PH_44");execute_ph_45=_entry("PH_45")
