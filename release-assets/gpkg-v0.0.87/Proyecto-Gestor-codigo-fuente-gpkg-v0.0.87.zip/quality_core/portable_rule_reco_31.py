"""Independent portable implementation of canonical Reco_31."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_31", "Calificacion",
    "Caracteristica Unidad de Construccion con diferencia mayor a 5 puntos entre el puntaje final y el puntaje masivo",
    "abs(c.puntaje_masivo - c.puntaje) > 5", False,
    construction_filter_fields=("puntaje_masivo",),
)

def execute_reco_31(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
