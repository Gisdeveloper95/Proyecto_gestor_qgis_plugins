"""Disk-backed portable engine for scalar PH interested-party rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging


@dataclass(frozen=True)
class PHInterestedRule:
    canonical_id: str
    description: str
    predicate_sql: str
    component: str = "Interesado"
    custom_7: bool = False


RULES = {
    "PH_48": PHInterestedRule(
        "PH_48", "Interesados PH con tipo de documento NIT con nombres y/o apellidos",
        "i.document_type = 2 AND (i.first_name IS NOT NULL OR i.middle_name IS NOT NULL OR i.first_surname IS NOT NULL OR i.second_surname IS NOT NULL)",
    ),
    "PH_49": PHInterestedRule(
        "PH_49", "Interesados PH con tipo de documento NIT sin razon social",
        "i.document_type = 2 AND i.business_name IS NULL",
    ),
    "PH_50": PHInterestedRule(
        "PH_50", "Interesados PH con tipo de documento distinto a NIT con razon social",
        "i.document_type <> 2 AND i.business_name IS NOT NULL",
    ),
    "PH_51": PHInterestedRule(
        "PH_51", "Interesados PH con tipo de documento distinto a NIT sin nombre completo diligenciado",
        "i.document_type <> 2 AND i.full_name IS NULL",
    ),
    "PH_52": PHInterestedRule(
        "PH_52", "Interesados PH con tipo de documento distinto a NIT sin nombre completo diligenciado",
        "i.identity_document IN ('0','',' ') OR i.identity_document IS NULL",
    ),
}


GENERAL_FIELDS = (
    "pk_id", "nombre_proyecto", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control", "informal_estado_asignacion",
    "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
PH_FIELDS = (
    "pk_id", "fk_id", "numero_predial_nacional", "matricula_inmobiliaria",
    "destinacion_economica", "area_catastral_terreno",
)
INTERESTED_FIELDS = (
    "pk_id", "fk_id", "tipo_documento", "primer_nombre", "segundo_nombre",
    "primer_apellido", "segundo_apellido", "razon_social",
    "nombre_completo_propietario", "documento_identidad",
)


def _create(db) -> None:
    db.executescript("""
      CREATE TABLE general_predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,
        project,jur_assignment TEXT,jur_control TEXT,reco_assignment TEXT,
        reco_control TEXT,info_assignment TEXT,info_control TEXT,geo_assignment TEXT,
        geo_control TEXT);
      CREATE TABLE ph_predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,
        parent_key TEXT,npn,registration,destination_key TEXT,area);
      CREATE TABLE excluded_ph(row_token INTEGER PRIMARY KEY,ph_key TEXT);
      CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,fk_key TEXT);
      CREATE TABLE interested(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,
        document_type,first_name,middle_name,first_surname,second_surname,
        business_name,full_name,identity_document);
      CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,ph_key TEXT,
        interested_pk,npn,project,registration,destination_key TEXT,area,
        jur_assignment TEXT,jur_control TEXT,reco_assignment TEXT,reco_control TEXT,
        info_assignment TEXT,info_control TEXT,geo_assignment TEXT,geo_control TEXT);
      CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
      CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
      CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    """)


def _ingest(source, mapping, db, cancel_check) -> None:
    with BatchInserter(db, """INSERT INTO general_predio(pk_id,pk_key,project,
      jur_assignment,jur_control,reco_assignment,reco_control,info_assignment,
      info_control,geo_assignment,geo_control)VALUES(?,?,?,?,?,?,?,?,?,?,?)""", cancel_check=cancel_check) as ins:
        for row in source.iter_rows(mapping.resolve("lc_gen_predio"), GENERAL_FIELDS):
            raise_if_cancelled(cancel_check)
            ins.add((row.get("pk_id"),_join_token(row.get("pk_id")),row.get("nombre_proyecto"),
                _join_token(row.get("juridico_estado_asignacion")),_join_token(row.get("juridico_estado_control")),
                _join_token(row.get("reconocimiento_estado_asignacion")),_join_token(row.get("reconocimiento_estado_control")),
                _join_token(row.get("informal_estado_asignacion")),_join_token(row.get("informal_estado_control")),
                _join_token(row.get("geografico_estado_asignacion")),_join_token(row.get("geografico_estado_control"))))
    with BatchInserter(db, "INSERT INTO ph_predio(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)", cancel_check=cancel_check) as ins:
        for row in source.iter_rows(mapping.resolve("lc_ph_predio"), PH_FIELDS):
            raise_if_cancelled(cancel_check); ins.add((row.get("pk_id"),_join_token(row.get("pk_id")),_join_token(row.get("fk_id")),row.get("numero_predial_nacional"),row.get("matricula_inmobiliaria"),_join_token(row.get("destinacion_economica")),row.get("area_catastral_terreno")))
    with BatchInserter(db, "INSERT INTO excluded_ph(ph_key)VALUES(?)", cancel_check=cancel_check) as ins:
        for row in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"), ("fk_id","tipo_novedad")):
            raise_if_cancelled(cancel_check)
            if row.get("tipo_novedad") in (5,6,7,8): ins.add((_join_token(row.get("fk_id")),))
    with BatchInserter(db, "INSERT INTO derecho(pk_id,pk_key,fk_key)VALUES(?,?,?)", cancel_check=cancel_check) as ins:
        for row in source.iter_rows(mapping.resolve("lc_ph_derecho"), ("pk_id","fk_id")):
            raise_if_cancelled(cancel_check); ins.add((row.get("pk_id"),_join_token(row.get("pk_id")),_join_token(row.get("fk_id"))))
    with BatchInserter(db, """INSERT INTO interested(pk_id,fk_key,document_type,
      first_name,middle_name,first_surname,second_surname,business_name,full_name,
      identity_document)VALUES(?,?,?,?,?,?,?,?,?,?)""", cancel_check=cancel_check) as ins:
        for row in source.iter_rows(mapping.resolve("lc_ph_interesado"), INTERESTED_FIELDS):
            raise_if_cancelled(cancel_check); ins.add((row.get("pk_id"),_join_token(row.get("fk_id")),row.get("tipo_documento"),row.get("primer_nombre"),row.get("segundo_nombre"),row.get("primer_apellido"),row.get("segundo_apellido"),row.get("razon_social"),row.get("nombre_completo_propietario"),row.get("documento_identidad")))


def _prepare(definition: PHInterestedRule, db) -> None:
    db.execute("""INSERT INTO selected(general_pk,ph_pk,ph_key,interested_pk,npn,
      project,registration,destination_key,area,jur_assignment,jur_control,
      reco_assignment,reco_control,info_assignment,info_control,geo_assignment,geo_control)
      SELECT g.pk_id,p.pk_id,p.pk_key,i.pk_id,p.npn,g.project,p.registration,
      p.destination_key,p.area,g.jur_assignment,g.jur_control,g.reco_assignment,
      g.reco_control,g.info_assignment,g.info_control,g.geo_assignment,g.geo_control
      FROM ph_predio p JOIN general_predio g ON p.parent_key=g.pk_key
      JOIN derecho d ON d.fk_key=p.pk_key JOIN interested i ON i.fk_key=d.pk_key
      WHERE NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.ph_key=p.pk_key) AND """ + definition.predicate_sql)


RESULT_SQL = """SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,
  e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,
  ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.interested_pk
  FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key
  LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key
  LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key
  LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_assignment
  LEFT JOIN control_lookup jc ON jc.key_token=s.jur_control
  LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_assignment
  LEFT JOIN control_lookup rc ON rc.key_token=s.reco_control
  LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_assignment
  LEFT JOIN control_lookup ic ON ic.key_token=s.info_control
  LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_assignment
  LEFT JOIN control_lookup gc ON gc.key_token=s.geo_control
  ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project"""


def execute_ph_interested_scalar(rule_id: str, source, mapping, cancel_check=None) -> Iterator[dict[str, Any]]:
    definition=RULES[rule_id]; timestamp=datetime.now()
    with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        _create(db); _ingest(source,mapping,db,cancel_check)
        _ingest_enrichment(definition,source,mapping,db,cancel_check)
        _prepare(definition,db); db.commit(); cursor=db.execute(RESULT_SQL)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check); row=_result_row(definition,timestamp,values[:17])
                row["tabla_error_1"]="LC_PH_Predio"; row["pk_tabla_error_1"]=values[17]
                row["tabla_error_2"]="LC_PH_Interesado"; row["pk_tabla_error_2"]=values[18]
                yield row
        finally: cursor.close()


def _entry(rule_id):
    def execute(source,mapping,cancel_check=None):
        return execute_ph_interested_scalar(rule_id,source,mapping,cancel_check)
    execute.__name__=f"execute_{rule_id.lower()}"; return execute


execute_ph_48=_entry("PH_48")
execute_ph_49=_entry("PH_49")
execute_ph_50=_entry("PH_50")
execute_ph_51=_entry("PH_51")
execute_ph_52=_entry("PH_52")
