"""Portable PH construction-detail rules over disk-backed SQLite staging."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,raise_if_cancelled,sqlite_staging

@dataclass(frozen=True)
class Rule:
 canonical_id:str;description:str;predicate:str;error_table:str="LC_PH_Caracteristicasunidadconstruccion";enrich_parent:bool=False;component:str="PH";custom_7:bool=False
RULES={
"PH_26":Rule("PH_26","Caracteristica Unidad de Construccion PH con un Identificador que posee numeros","c.identifier GLOB '*[0-9]*'"),
"PH_28":Rule("PH_28","Caracteristica Unidad de Construccion PH con total de plantas menor a 1 o mayor a 25","c.total_floors < 1 OR c.total_floors > 25"),
"PH_32":Rule("PH_32","Caracteristica Unidad de Construccion PH sin Uso de construccion","c.usage IS NULL"),
"PH_33":Rule("PH_33","Caracteristica Unidad de Construccion PH con usos de construccion diferentes de PH","c.usage NOT IN (0,4,6,7,10,12,14,15,17,19,20,23,24,27,30,31,33,34,35,38,40,42,44,57,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103)"),
"PH_34":Rule("PH_34","Caracteristica Unidad de Construccion PH con diferencia mayor a 5 puntos entre el puntaje final y el puntaje masivo","abs(c.massive_score-c.score)>5"),
"PH_35":Rule("PH_35","Caracteristica Unidad de Construccion PH con año de construccion mayor a 2026","c.construction_year>2026"),
"PH_36":Rule("PH_36","Caracteristica Unidad de Construccion PH sin año de construccion","c.construction_year IS NULL OR c.construction_year<=1900"),
"PH_37":Rule("PH_37","Caracteristica Unidad de Construccion PH sin area construida con cambio fisico","g.physical_change=1 AND (g.cancelled IS NULL OR g.cancelled=0) AND c.built_area IS NULL","LC_PH_CaracteristicasUnidadConstruccion"),
"PH_38":Rule("PH_38","Caracteristica Unidad de Construccion PH sin area construida sin cambio fisico","(g.physical_change=0 OR g.physical_change IS NULL) AND (g.cancelled IS NULL OR g.cancelled=0) AND c.built_area IS NULL","LC_PH_CaracteristicasUnidadConstruccion",True),
"PH_41":Rule("PH_41","Caracteristica Unidad de Construccion PH sin el detalle de calificación y sin puntaje anterior","c.score IS NULL OR c.score=0"),
}
GF=("pk_id","nombre_proyecto","predio_tiene_cambio_fisico","juridico_predio_cancelado","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
CF=("pk_id","pk_carac","identificador","total_plantas","tipo_unidad_construccion","uso_construccion","area_construida","puntaje","puntaje_masivo","anio_construccion")
def _create(db):
 db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,project,physical_change,cancelled,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area);CREATE TABLE excluded(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE construction(row_token INTEGER PRIMARY KEY,ph_key TEXT,characteristic_pk,identifier,total_floors,unit_type_key TEXT,usage,usage_key TEXT,built_area,score,massive_score,construction_year);CREATE TABLE unit_type_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE usage_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,general_key TEXT,ph_pk,ph_key TEXT,enrichment_key TEXT,characteristic_pk,npn,project,registration,destination_key TEXT,area,identifier,total_floors,unit_type_key TEXT,usage_key TEXT,built_area,score,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,project,physical_change,cancelled,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("nombre_proyecto"),r.get("predio_tiene_cambio_fisico"),r.get("juridico_predio_cancelado"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 with BatchInserter(db,"INSERT INTO excluded(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
 with BatchInserter(db,"INSERT INTO construction(ph_key,characteristic_pk,identifier,total_floors,unit_type_key,usage,usage_key,built_area,score,massive_score,construction_year)VALUES(?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("determinacion_area_construccion"),CF):raise_if_cancelled(cancel);ins.add((_join_token(r.get("pk_id")),r.get("pk_carac"),r.get("identificador"),r.get("total_plantas"),_join_token(r.get("tipo_unidad_construccion")),r.get("uso_construccion"),_join_token(r.get("uso_construccion")),r.get("area_construida"),r.get("puntaje"),r.get("puntaje_masivo"),r.get("anio_construccion")))
 for logical,table in(("lc_reco_unidadconstruccion_tipo","unit_type_lookup"),("lc_gen_usouconstruccion_tipo","usage_lookup")):
  with BatchInserter(db,f"INSERT INTO {table}(key_token,ilicode)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve(logical),("itfcode","ilicode")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
def _prepare(definition,db):
 enrichment="g.pk_key"if definition.enrich_parent else"p.pk_key"
 db.execute("""INSERT INTO selected(general_pk,general_key,ph_pk,ph_key,enrichment_key,characteristic_pk,npn,project,registration,destination_key,area,identifier,total_floors,unit_type_key,usage_key,built_area,score,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)SELECT g.pk_id,g.pk_key,p.pk_id,p.pk_key,"""+enrichment+""",c.characteristic_pk,p.npn,g.project,p.registration,p.destination_key,p.area,c.identifier,c.total_floors,c.unit_type_key,c.usage_key,c.built_area,c.score,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c FROM ph p JOIN gen g ON p.parent_key=g.pk_key JOIN construction c ON c.ph_key=p.pk_key WHERE NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key)AND("""+definition.predicate+")")
RESULT="""SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.characteristic_pk,s.identifier,s.total_floors,t.ilicode,u.ilicode,s.built_area,s.score FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.enrichment_key LEFT JOIN user_assignment ua ON ua.fk_token=s.enrichment_key LEFT JOIN unit_type_lookup t ON t.key_token=s.unit_type_key LEFT JOIN usage_lookup u ON u.key_token=s.usage_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project,s.identifier IS NULL,s.identifier"""
def execute_detail(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]="LC_PH_Predio";row["pk_tabla_error_1"]=v[17];row["tabla_error_2"]=definition.error_table;row["pk_tabla_error_2"]=v[18];row["identificador_caracteristica_unidad_construccion"]=v[19];row["total_plantas"]=v[20];row["tipo_unidad_construccion"]=v[21];row["uso_construccion"]=v[22];row["area_construida"]=v[23];row["puntaje_calificacion"]=v[24];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_detail(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_26=_entry("PH_26");execute_ph_28=_entry("PH_28");execute_ph_32=_entry("PH_32");execute_ph_33=_entry("PH_33");execute_ph_34=_entry("PH_34");execute_ph_35=_entry("PH_35");execute_ph_36=_entry("PH_36");execute_ph_37=_entry("PH_37");execute_ph_38=_entry("PH_38");execute_ph_41=_entry("PH_41")
