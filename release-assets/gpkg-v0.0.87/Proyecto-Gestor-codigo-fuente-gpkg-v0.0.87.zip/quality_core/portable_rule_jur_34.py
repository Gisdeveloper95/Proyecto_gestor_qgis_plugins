"""Independent portable implementation of canonical Jur_34."""
from .portable_predio_scalar import PredioScalarRule,execute_predio_scalar

class _PredioOverride:
 def __init__(self,source,physical): self._source=source; self._physical=physical
 def __getattr__(self,name): return getattr(self._source,name)
 def iter_rows(self,physical_name,fields):
  for row in self._source.iter_rows(physical_name,fields):
   if physical_name!=self._physical: yield row; continue
   item=dict(row); item["juridico_predio_cancelado"]=False; item["nombre_proyecto"]=None; yield item

_RULE=PredioScalarRule("Jur_34","Juridico","Predios con matricula inmobiliaria cerrada en la SNR",lambda r:r.get("fid") is None,False,("fid",))
def execute_jur_34(data_source,layer_mapping,cancel_check=None):
 return execute_predio_scalar(_RULE,_PredioOverride(data_source,layer_mapping.resolve("lc_gen_predio")),layer_mapping,cancel_check)
