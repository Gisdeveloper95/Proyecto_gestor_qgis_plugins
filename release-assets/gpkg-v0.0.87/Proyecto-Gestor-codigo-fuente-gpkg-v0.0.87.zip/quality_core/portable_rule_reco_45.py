"""Independent portable implementation of canonical Reco_45."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_45", "Calificacion",
    "Caracteristica Unidad de Construccion con calificacion total menor a 10",
    "c.puntaje <= 10", False, duplicate_predio_join=True,
)

def execute_reco_45(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
