"""Independent portable implementation of the canonical Reco_03 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    coefficient = row.get("coeficiente_condominio")
    return (
        postgres_substring(row.get("numero_predial_nacional"), 22, 1) == "8"
        and postgres_substring(row.get("numero_predial_nacional"), 27, 4)
        != "0000"
        and (coefficient is None or coefficient == 0)
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_03",
    component="Juridico",
    description="Predios en condicion de condominio sin coeficiente de copropiedad",
    predicate=_matches,
    custom_7=False,
    filter_fields=("coeficiente_condominio",),
)


def execute_reco_03(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_03 findings before the operational filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
