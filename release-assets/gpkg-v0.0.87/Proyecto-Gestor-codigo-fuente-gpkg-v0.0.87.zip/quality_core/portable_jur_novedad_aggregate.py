"""Disk-backed portable engine for aggregate juridical novelty rules."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from types import SimpleNamespace
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,raise_if_cancelled,sqlite_staging

@dataclass(frozen=True)
class Rule:
 canonical_id:str; component:str; description:str; exception_id:str|None=None; custom_7:bool=False

RULES={
"Jur_50":Rule("Jur_50","Novedad_Desenglobe_Division_Material","Si el tipo de novedad es desenglobe division material, minimo 2 predios deben tener el mismo numero predial de referencia con la misma novedad y el predio de referencia \ndebe estar cancelado por desenglobe"),
"Jur_52":Rule("Jur_52","Novedad_Desenglobe_Division_Material","El numero predial del desengloble división material no puede existir otra novedad diferente a desenglobe division material o \ncancelacion por desenglobe"),
"Jur_54":Rule("Jur_54","Novedad_Desenglobe_Venta_Parcial","Minimo 2 predios deben tener novedad desenglobe venta parcial y debe tener registrado numero predial anterior"),
"Jur_55":Rule("Jur_55","Novedad_Desenglobe_Venta_Parcial","No debe existir una novedad diferente a desenglobe venta parcial y solo debe tener una novedad"),
"Jur_57":Rule("Jur_57","Novedad_Englobe_Crea_FMI","Debe existir más de una novedad de englobe que crea nuevo FMI sobre el mismo predio y no deben tener el mismo numero de referencia"),
"Jur_58":Rule("Jur_58","Novedad_Englobe_Crea_FMI","Todos los numero prediales de las novedades que crean nuevo fmi deben tener novedad de cancelacion por englobe"),
"Jur_59":Rule("Jur_59","Novedad_Englobe_Crea_FMI","Todos los predios referenciados en novedad de englobe crea un nuevo FMI, no pueden tener una novedad diferente a cancelación por englobe","Jur_58"),
"Jur_61":Rule("Jur_61","Novedad_Englobe_Mantiene_FMI","Todos los que tengan novedad de Englobe mantiene fmi deben estar Cancelados por englobe Menos 1"),
"Jur_62":Rule("Jur_62","Novedad_Englobe_Mantiene_FMI","El numero predial de la novedad solo puede ser llamado una vez"),
"Jur_63":Rule("Jur_63","Cancelacion_Desenglobe_Englobe","Predios cancelados por englobe o desenglobe que no tienen novedad de englobe o desenglobe"),
"Jur_66":Rule("Jur_66","Cancelacion","Predios relacionados en mas de una novedad"),
}
_PF=("pk_id","numero_predial_nacional","numero_predial_nacional_anterior","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")

def _create(db):
 db.executescript("""
 CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,npn_anterior,proyecto,matricula,destination_key TEXT,area,jur_asig TEXT,jur_ctrl TEXT,reco_asig TEXT,reco_ctrl TEXT,info_asig TEXT,info_ctrl TEXT,geo_asig TEXT,geo_ctrl TEXT);
 CREATE TABLE novedad(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,fid,fk_key TEXT,type_key TEXT,ref);
 CREATE TABLE tipo(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 CREATE TABLE event(row_token INTEGER PRIMARY KEY,predio_row INTEGER,predio_pk,predio_key TEXT,npn,npn_anterior,proyecto,matricula,destination_key TEXT,area,jur_asig TEXT,jur_ctrl TEXT,reco_asig TEXT,reco_ctrl TEXT,info_asig TEXT,info_ctrl TEXT,geo_asig TEXT,geo_ctrl TEXT,novedad_pk,novedad_key TEXT,novedad_fid,tipo,ref);
 CREATE TABLE candidate(row_token INTEGER PRIMARY KEY,event_row INTEGER,state_row INTEGER,out_pk,pk1,pk2,tipo,ref,exception_key TEXT,assignment_key TEXT);
 CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
 CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
 CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
 """)

def _ingest(data_source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,npn_anterior,proyecto,matricula,destination_key,area,jur_asig,jur_ctrl,reco_asig,reco_ctrl,info_asig,info_ctrl,geo_asig,geo_ctrl) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel) as ins:
  for r in data_source.iter_rows(mapping.resolve("lc_gen_predio"),_PF):
   raise_if_cancelled(cancel); ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("numero_predial_nacional_anterior"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO novedad(pk_id,pk_key,fid,fk_key,type_key,ref) VALUES (?,?,?,?,?,?)",cancel_check=cancel) as ins:
  for r in data_source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"),("pk_id","fid","fk_id","tipo_novedad","numero_predial_nacional_novedad")):
   raise_if_cancelled(cancel); ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("fid"),_join_token(r.get("fk_id")),_join_token(r.get("tipo_novedad")),r.get("numero_predial_nacional_novedad")))
 with BatchInserter(db,"INSERT INTO tipo(key_token,ilicode) VALUES (?,?)",cancel_check=cancel) as ins:
  for r in data_source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial_tipo"),("itfcode","ilicode")):
   raise_if_cancelled(cancel); ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
 db.execute("""INSERT INTO event(predio_row,predio_pk,predio_key,npn,npn_anterior,proyecto,matricula,destination_key,area,jur_asig,jur_ctrl,reco_asig,reco_ctrl,info_asig,info_ctrl,geo_asig,geo_ctrl,novedad_pk,novedad_key,novedad_fid,tipo,ref) SELECT p.row_token,p.pk_id,p.pk_key,p.npn,p.npn_anterior,p.proyecto,p.matricula,p.destination_key,p.area,p.jur_asig,p.jur_ctrl,p.reco_asig,p.reco_ctrl,p.info_asig,p.info_ctrl,p.geo_asig,p.geo_ctrl,n.pk_id,n.pk_key,n.fid,t.ilicode,n.ref FROM predio p JOIN novedad n ON n.fk_key=p.pk_key JOIN tipo t ON t.key_token=n.type_key""")

_INS="INSERT INTO candidate(event_row,state_row,out_pk,pk1,pk2,tipo,ref,exception_key,assignment_key) "
def _prepare(rid,db):
 if rid=="Jur_50": q="""WITH c AS(SELECT * FROM event WHERE tipo='Desenglobe_Division_Material'),c2 AS(SELECT * FROM event WHERE tipo='Cancelacion_por_Desenglobe'),c3 AS(SELECT c.row_token FROM c LEFT JOIN c2 ON c.ref=c2.npn WHERE c2.npn IS NULL),c4 AS(SELECT ref FROM c WHERE substr(npn,22,1)<>'9' GROUP BY ref HAVING count(*)=1),c5 AS(SELECT e.row_token FROM event e JOIN c4 ON e.npn=c4.ref),bad AS(SELECT row_token FROM c3 UNION SELECT row_token FROM c5) SELECT e.row_token,s.row_token,e.predio_pk,e.predio_pk,e.novedad_pk,e.tipo,e.ref,e.predio_key,e.predio_key FROM bad b JOIN event e ON e.row_token=b.row_token LEFT JOIN predio s ON s.pk_key=e.predio_key"""
 elif rid=="Jur_52": q="""WITH c AS(SELECT * FROM event WHERE tipo='Desenglobe_Division_Material'),c2 AS(SELECT * FROM event WHERE tipo='Cancelacion_por_Desenglobe'),c3 AS(SELECT c.row_token FROM c LEFT JOIN c2 ON c.ref=c2.npn WHERE c2.predio_pk IS NULL),c4 AS(SELECT * FROM event WHERE tipo NOT IN('Desenglobe_Division_Material','Cancelacion_por_Desenglobe')),c5 AS(SELECT c.row_token FROM c JOIN c4 ON c.npn=c4.npn),bad AS(SELECT row_token FROM c3 UNION SELECT row_token FROM c5) SELECT e.row_token,s.row_token,e.predio_pk,e.predio_pk,e.novedad_pk,e.tipo,e.ref,e.predio_key,e.predio_key FROM bad b JOIN event e ON e.row_token=b.row_token LEFT JOIN predio s ON s.pk_key=e.predio_key"""
 elif rid=="Jur_54": q="""WITH c AS(SELECT * FROM event WHERE tipo='Desenglobe_Venta_Parcial'),one AS(SELECT ref FROM c GROUP BY ref HAVING count(*)=1),many AS(SELECT ref FROM c GROUP BY ref HAVING count(*)>1),bad AS(SELECT e.row_token FROM event e JOIN one ON e.npn=one.ref UNION SELECT e.row_token FROM event e JOIN many ON e.npn=many.ref WHERE e.npn_anterior IS NULL) SELECT e.row_token,s.row_token,e.predio_pk,e.predio_pk,e.novedad_pk,e.tipo,e.ref,e.predio_key,e.predio_key FROM bad b JOIN event e ON e.row_token=b.row_token LEFT JOIN predio s ON s.pk_key=e.predio_key"""
 elif rid=="Jur_55": q="""WITH c AS(SELECT * FROM event WHERE tipo='Desenglobe_Venta_Parcial'),o AS(SELECT * FROM event WHERE tipo<>'Desenglobe_Venta_Parcial') SELECT c.row_token,s.row_token,c.predio_pk,c.predio_pk,c.novedad_pk,o.tipo,o.ref,c.predio_key,c.predio_key FROM c JOIN o ON c.ref=o.ref LEFT JOIN predio s ON s.pk_key=c.predio_key"""
 elif rid=="Jur_57": q="""WITH c AS(SELECT * FROM event WHERE tipo='Englobe_Nuevo_FMI'),one AS(SELECT predio_key FROM c GROUP BY predio_pk,predio_key HAVING count(*)=1),same AS(SELECT predio_key FROM c WHERE npn=ref),bad AS(SELECT predio_key FROM one UNION SELECT predio_key FROM same) SELECT e.row_token,e.predio_row,e.predio_pk,e.predio_pk,e.novedad_pk,e.tipo,e.ref,e.predio_key,e.predio_key FROM bad JOIN event e ON e.predio_key=bad.predio_key"""
 elif rid=="Jur_58": q="""WITH c AS(SELECT * FROM event WHERE tipo='Englobe_Nuevo_FMI'),c2 AS(SELECT * FROM event WHERE tipo='Cancelacion_por_Englobe') SELECT c.row_token,s.row_token,c.novedad_pk,c.predio_pk,c.predio_pk,c.tipo,c.ref,c.predio_key,c.predio_key FROM c LEFT JOIN c2 ON c.ref=c2.npn LEFT JOIN predio s ON s.pk_key=c.novedad_key WHERE c2.predio_pk IS NULL"""
 elif rid=="Jur_59": q="""WITH c AS(SELECT * FROM event WHERE tipo='Englobe_Nuevo_FMI'),o AS(SELECT * FROM event WHERE tipo<>'Cancelacion_por_Englobe') SELECT c.row_token,s.row_token,c.predio_pk,c.predio_pk,c.novedad_pk,o.tipo,o.ref,c.predio_key,c.predio_key FROM c JOIN o ON c.ref=o.npn LEFT JOIN predio s ON s.pk_key=c.predio_key"""
 elif rid=="Jur_61": q="""WITH c AS(SELECT * FROM event WHERE tipo='Englobe_Mantiene_FMI'),c2 AS(SELECT npn,count(*) n1 FROM c GROUP BY npn),c3 AS(SELECT c.npn FROM c JOIN event x ON c.ref=x.ref WHERE x.tipo='Cancelacion_por_Englobe'),c4 AS(SELECT npn,count(*) n2 FROM c3 GROUP BY npn),bad AS(SELECT c2.npn FROM c2 LEFT JOIN c4 ON c2.npn=c4.npn WHERE c2.n1-coalesce(c4.n2,-1)<>1) SELECT e.row_token,e.predio_row,e.predio_pk,e.predio_pk,e.novedad_pk,e.tipo,e.ref,e.predio_key,e.predio_key FROM bad JOIN event e ON e.npn=bad.npn"""
 elif rid=="Jur_62": q="""WITH c AS(SELECT * FROM event WHERE tipo='Englobe_Mantiene_FMI'),bad AS(SELECT ref FROM c GROUP BY ref HAVING count(*)>1) SELECT e.row_token,e.predio_row,e.predio_pk,e.predio_pk,e.novedad_pk,e.tipo,bad.ref,e.predio_key,e.predio_key FROM bad JOIN event e ON e.npn=bad.ref"""
 elif rid=="Jur_63": q="""WITH c AS(SELECT * FROM event WHERE tipo IN('Cancelacion_por_Englobe','Cancelacion_por_Desenglobe')),ok AS(SELECT * FROM event WHERE tipo IN('Desenglobe_Division_Material','Englobe_Nuevo_FMI','Englobe_Mantiene_FMI')) SELECT c.row_token,s.row_token,c.predio_pk,c.predio_pk,c.novedad_pk,c.tipo,c.ref,c.predio_key,c.predio_key FROM c LEFT JOIN ok ON c.npn=ok.ref LEFT JOIN predio s ON s.pk_key=c.predio_key WHERE ok.predio_pk IS NULL"""
 elif rid=="Jur_66": q="""WITH c AS(SELECT * FROM event WHERE tipo IN('Cancelacion','Cancelacion_Doble_Inscripcion')),o AS(SELECT * FROM event WHERE tipo NOT IN('Cancelacion','Cancelacion_Doble_Inscripcion')) SELECT c.row_token,s.row_token,c.predio_pk,c.predio_pk,c.novedad_pk,o.tipo,o.ref,c.predio_key,c.predio_key FROM c JOIN o ON c.npn=o.ref OR c.npn=o.npn LEFT JOIN predio s ON s.pk_key=c.predio_key"""
 else: raise ValueError(rid)
 db.execute(_INS+q)

_RESULT="""SELECT DISTINCT c.out_pk,e.npn,e.proyecto,e.matricula,d.ilicode,e.area,x.fid,x.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.pk1,c.pk2,c.tipo,c.ref FROM candidate c JOIN event e ON e.row_token=c.event_row LEFT JOIN predio s ON s.row_token=c.state_row LEFT JOIN destination_lookup d ON d.key_token=e.destination_key LEFT JOIN exception_lookup x ON x.fk_token=c.exception_key LEFT JOIN user_assignment ua ON ua.fk_token=c.assignment_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_asig LEFT JOIN control_lookup jc ON jc.key_token=s.jur_ctrl LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_asig LEFT JOIN control_lookup rc ON rc.key_token=s.reco_ctrl LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_asig LEFT JOIN control_lookup ic ON ic.key_token=s.info_ctrl LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_asig LEFT JOIN control_lookup gc ON gc.key_token=s.geo_ctrl"""

def execute_aggregate(rid,data_source,mapping,cancel_check=None):
 definition=RULES[rid]; timestamp=datetime.now(); enrich=SimpleNamespace(canonical_id=definition.exception_id or rid)
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-") as db:
  _create(db); _ingest(data_source,mapping,db,cancel_check); _ingest_enrichment(enrich,data_source,mapping,db,cancel_check); _prepare(rid,db); db.commit(); cur=db.execute(_RESULT)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check); base=_result_row(definition,timestamp,v[:17]); base["tabla_error_1"]="LC_Gen_Predio"; base["pk_tabla_error_1"]=v[17]; base["tabla_error_2"]="LC_Jur_NovedadNumeroPredial"; base["pk_tabla_error_2"]=v[18]; base["tipo_novedad"]=v[19]; base["numero_predial_nacional_novedad"]=v[20]; yield base
  finally: cur.close()

def _entry(rid):
 def execute(data_source,layer_mapping,cancel_check=None): return execute_aggregate(rid,data_source,layer_mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}"; return execute
execute_jur_50=_entry("Jur_50"); execute_jur_52=_entry("Jur_52"); execute_jur_54=_entry("Jur_54"); execute_jur_55=_entry("Jur_55"); execute_jur_57=_entry("Jur_57"); execute_jur_58=_entry("Jur_58"); execute_jur_59=_entry("Jur_59"); execute_jur_61=_entry("Jur_61"); execute_jur_62=_entry("Jur_62"); execute_jur_63=_entry("Jur_63"); execute_jur_66=_entry("Jur_66")
