"""Independent portable implementation of canonical Reco_67."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_67", "Calificacion",
    "Caracter\u00edsticas unidad de construccion con uso anexo y mas de un piso",
    "c.uso_construccion > 68 AND c.total_plantas > 1", False,
    table_error_1="LC_Reco_CaracteristicasUnidadConstruccion", use_output="raw",
)

def execute_reco_67(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
