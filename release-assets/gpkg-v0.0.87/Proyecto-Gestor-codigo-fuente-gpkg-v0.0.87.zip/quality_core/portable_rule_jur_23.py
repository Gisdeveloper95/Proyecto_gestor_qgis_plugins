"""Portable implementation of canonical Jur_23."""
from datetime import datetime
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging

_PF=("pk_id","numero_predial_nacional","numero_predial_nacional_anterior","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")


def execute_jur_23(data_source,layer_mapping,cancel_check=None):
 definition=SimpleNamespace(canonical_id="Jur_23",component="Juridico",description="Predios antiguos con numero predial diferente al anterior sin novedad de cambio de numero predial ",custom_7=False);stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix="mapingtool-calidad-gpkg-jur_23-")as db:
  db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,previous_npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE novelty(row_token INTEGER PRIMARY KEY,fid,pk_id,fk_key TEXT,type_key TEXT,novelty_npn);CREATE TABLE ntype(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,predio_row INTEGER,novelty_pk,type_name,novelty_npn);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
  with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,previous_npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),_PF):
    raise_if_cancelled(cancel_check);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("numero_predial_nacional_anterior"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
  with BatchInserter(db,"INSERT INTO novelty(fid,pk_id,fk_key,type_key,novelty_npn)VALUES(?,?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_novedadnumeropredial"),("fid","pk_id","fk_id","tipo_novedad","numero_predial_nacional_novedad")):
    raise_if_cancelled(cancel_check);ins.add((r.get("fid"),r.get("pk_id"),_join_token(r.get("fk_id")),_join_token(r.get("tipo_novedad")),r.get("numero_predial_nacional_novedad")))
  with BatchInserter(db,"INSERT INTO ntype(key_token,ilicode)VALUES(?,?)",cancel_check=cancel_check)as ins:
   for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_novedadnumeropredial_tipo"),("itfcode","ilicode")):raise_if_cancelled(cancel_check);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
  _ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
  db.execute("""INSERT INTO selected(predio_row,novelty_pk,type_name,novelty_npn) SELECT p.row_token,n.pk_id,t.ilicode,n.novelty_npn FROM predio p LEFT JOIN novelty n ON n.fk_key=p.pk_key LEFT JOIN ntype t ON t.key_token=n.type_key WHERE p.previous_npn IS NOT NULL AND (lower(t.ilicode) NOT LIKE '%cambio%' OR n.fid IS NULL) AND p.npn<>p.previous_npn""");db.commit()
  cur=db.execute("""SELECT p.pk_id,p.npn,p.project,p.registration,d.ilicode,p.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.novelty_pk,s.type_name,s.novelty_npn FROM selected s JOIN predio p ON p.row_token=s.predio_row LEFT JOIN destination_lookup d ON d.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project""")
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row.update({"tabla_error_2":"LC_Jur_NovedadNumeroPredial","pk_tabla_error_2":v[17],"tipo_novedad":v[18],"numero_predial_nacional_novedad":v[19]});yield row
  finally:cur.close()
