"""Independent portable implementation of canonical Reco_23."""

from .portable_construction_scalar import (
    ConstructionScalarRule,
    execute_construction_scalar,
)


_RULE = ConstructionScalarRule(
    "Reco_23",
    "Calificacion",
    "Caracteristica Unidad de Construccion con un Identificador que posee numeros",
    "c.identificador GLOB '*[0-9]*'",
    False,
    duplicate_predio_join=True,
)


def execute_reco_23(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
