"""Independent portable implementation of canonical Reco_54."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_54", "Calificacion",
    "Predios con destino economico educativo sin uso de construccion educativo",
    "p.destinacion_economica IN (8) AND (c.uso_construccion IS NULL OR c.uso_construccion NOT IN (46,51,53,59))",
    False, table_error_1="LC_Gen_Predio", table_error_1_source="predio",
    table_error_2="LC_Reco_CaracteristicasUnidadConstruccion",
)

def execute_reco_54(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
