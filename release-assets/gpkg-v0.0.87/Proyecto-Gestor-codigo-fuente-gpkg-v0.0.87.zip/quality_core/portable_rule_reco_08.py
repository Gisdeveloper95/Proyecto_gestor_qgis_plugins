"""Independent portable implementation of canonical Reco_08."""
from .portable_construction_dominant import execute_construction_dominant
from .portable_construction_scalar import ConstructionScalarRule, _join_token

_RULE = ConstructionScalarRule(
    "Reco_08", "Calificacion",
    "Predios con destino economico Industrial con la Caracteristica Unidad de Construccion de mayor area diferente a un uso de construccion de tipo industrial",
    f"p.destinacion_economica = 11 AND c.type_key <> {_join_token(2)!r}", False,
    table_error_1="LC_Gen_Predio", table_error_1_source="predio",
    table_error_2="LC_Reco_Caracteristicasunidadconstruccion",
)

def execute_reco_08(data_source, layer_mapping, cancel_check=None):
    return execute_construction_dominant(_RULE, data_source, layer_mapping, cancel_check)
