"""Portable PH_76 detection of PH parcels owned by public entities."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_true,
    raise_if_cancelled,
    sqlite_staging,
)


@dataclass(frozen=True)
class _Definition:
    canonical_id: str = "PH_76"
    component: str = "Interesado"
    description: str = "Predios PH con Interesados Publicos"
    custom_7: bool = False


DEFINITION = _Definition()
GENERAL_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado",
    "nombre_proyecto", "juridico_estado_asignacion", "juridico_estado_control",
    "reconocimiento_estado_asignacion", "reconocimiento_estado_control",
    "informal_estado_asignacion", "informal_estado_control",
    "geografico_estado_asignacion", "geografico_estado_control",
)
PH_FIELDS = (
    "pk_id", "fk_id", "numero_predial_nacional", "matricula_inmobiliaria",
    "destinacion_economica", "area_catastral_terreno",
)


def _like_regex(pattern: str) -> re.Pattern[str]:
    pieces: list[str] = []
    index = 0
    while index < len(pattern):
        char = pattern[index]
        if char == "\\" and index + 1 < len(pattern):
            index += 1
            pieces.append(re.escape(pattern[index]))
        elif char == "%":
            pieces.append(".*")
        elif char == "_":
            pieces.append(".")
        else:
            pieces.append(re.escape(char))
        index += 1
    return re.compile("^" + "".join(pieces) + "$", re.IGNORECASE | re.DOTALL)


def _compile_ast(node):
    operator = node[0]
    if operator == "ilike":
        return (operator, _like_regex(node[1]))
    if operator == "eq":
        return (operator, node[1])
    return (operator, *(_compile_ast(child) for child in node[1:]))


@lru_cache(maxsize=1)
def _predicate_ast():
    path = Path(__file__).with_name("specs") / "ph_76_public_name_predicate.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("format") != "mapingtool.ph76-public-name-ast.v1":
        raise RuntimeError("Unsupported PH_76 public-name specification")
    return _compile_ast(payload["ast"])


def _matches(node, value: str) -> bool:
    operator = node[0]
    if operator == "ilike":
        return node[1].match(value) is not None
    if operator == "eq":
        return value == node[1]
    if operator == "and":
        return all(_matches(child, value) for child in node[1:])
    return any(_matches(child, value) for child in node[1:])


def _create(db) -> None:
    db.executescript(
        """
        CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,
          cancelled,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,
          info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);
        CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,
          npn,registration,destination_key TEXT,area);
        CREATE TABLE excluded_ph(row_token INTEGER PRIMARY KEY,key_token TEXT);
        CREATE TABLE excluded_gen(row_token INTEGER PRIMARY KEY,key_token TEXT);
        CREATE TABLE right_(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,ph_key TEXT);
        CREATE TABLE interested(row_token INTEGER PRIMARY KEY,pk_id,right_key TEXT,state,full_name);
        CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,ph_key TEXT,
          right_pk,interested_pk,npn,project,registration,destination_key TEXT,area,
          jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,
          geo_a TEXT,geo_c TEXT);
        CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
        CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
        CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        """
    )


def _ingest(source, mapping, db, cancel_check) -> None:
    cancelled_keys: list[str] = []
    with BatchInserter(db, """INSERT INTO gen(pk_id,pk_key,npn,cancelled,project,
      jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_gen_predio"), GENERAL_FIELDS):
            raise_if_cancelled(cancel_check)
            key = _join_token(row.get("pk_id"))
            npn = row.get("numero_predial_nacional")
            cancelled = postgres_boolean_is_true(row.get("juridico_predio_cancelado"))
            if cancelled and npn is not None and len(str(npn)) >= 22 and str(npn)[21] == "9":
                cancelled_keys.append(key)
            inserter.add((row.get("pk_id"),key,npn,row.get("juridico_predio_cancelado"),
                row.get("nombre_proyecto"),_join_token(row.get("juridico_estado_asignacion")),
                _join_token(row.get("juridico_estado_control")),_join_token(row.get("reconocimiento_estado_asignacion")),
                _join_token(row.get("reconocimiento_estado_control")),_join_token(row.get("informal_estado_asignacion")),
                _join_token(row.get("informal_estado_control")),_join_token(row.get("geografico_estado_asignacion")),
                _join_token(row.get("geografico_estado_control"))))
    with BatchInserter(db, "INSERT INTO excluded_gen(key_token)VALUES(?)", cancel_check=cancel_check) as inserter:
        for key in cancelled_keys:
            inserter.add((key,))
        for row in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"), ("fk_id", "tipo_novedad")):
            raise_if_cancelled(cancel_check)
            if row.get("tipo_novedad") in (5, 6, 7, 8):
                inserter.add((_join_token(row.get("fk_id")),))
    with BatchInserter(db, "INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_ph_predio"), PH_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((row.get("pk_id"),_join_token(row.get("pk_id")),_join_token(row.get("fk_id")),
                row.get("numero_predial_nacional"),row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),row.get("area_catastral_terreno")))
    with BatchInserter(db, "INSERT INTO excluded_ph(key_token)VALUES(?)", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"), ("fk_id", "tipo_novedad")):
            raise_if_cancelled(cancel_check)
            if row.get("tipo_novedad") in (5, 6, 7, 8):
                inserter.add((_join_token(row.get("fk_id")),))
    with BatchInserter(db, "INSERT INTO right_(pk_id,pk_key,ph_key)VALUES(?,?,?)", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_ph_derecho"), ("pk_id", "fk_id")):
            raise_if_cancelled(cancel_check)
            inserter.add((row.get("pk_id"),_join_token(row.get("pk_id")),_join_token(row.get("fk_id"))))
    ast = _predicate_ast()
    with BatchInserter(db, "INSERT INTO interested(pk_id,right_key,state,full_name)VALUES(?,?,?,?)", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_ph_interesado"), ("pk_id", "fk_id", "estado_propietario", "nombre_completo_propietario")):
            raise_if_cancelled(cancel_check)
            state = row.get("estado_propietario")
            full_name = row.get("nombre_completo_propietario")
            if state is not None and state != 0 and full_name is not None and _matches(ast, str(full_name)):
                inserter.add((row.get("pk_id"),_join_token(row.get("fk_id")),state,full_name))


def _prepare(db) -> None:
    db.execute(
        """INSERT INTO selected(general_pk,ph_pk,ph_key,right_pk,interested_pk,npn,
          project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,
          info_a,info_c,geo_a,geo_c)
        SELECT general_pk,ph_pk,ph_key,right_pk,interested_pk,npn,project,
          registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,
          info_c,geo_a,geo_c FROM (
          SELECT g.pk_id general_pk,p.pk_id ph_pk,p.pk_key ph_key,r.pk_id right_pk,
            i.pk_id interested_pk,p.npn,g.project,p.registration,p.destination_key,
            p.area,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c,
            row_number() OVER(PARTITION BY p.npn ORDER BY p.row_token,r.row_token,i.row_token) ordinal
          FROM ph p LEFT JOIN gen g ON g.pk_key=p.parent_key
          JOIN right_ r ON r.ph_key=p.pk_key JOIN interested i ON i.right_key=r.pk_key
          WHERE NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.key_token=p.pk_key)
            AND NOT EXISTS(SELECT 1 FROM excluded_gen x WHERE x.key_token=p.parent_key)
        ) candidates WHERE ordinal=1"""
    )


RESULT_SQL = """SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,
 e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,
 ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.right_pk
 FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key
 LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key
 LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key
 LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a
 LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c
 LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a
 LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c
 LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a
 LEFT JOIN control_lookup ic ON ic.key_token=s.info_c
 LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a
 LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c
 ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project"""


def execute_ph_76(source, mapping, cancel_check=None) -> Iterator[dict[str, Any]]:
    timestamp = datetime.now()
    with sqlite_staging(cancel_check, prefix="mapingtool-calidad-gpkg-ph_76-") as db:
        _create(db)
        _ingest(source, mapping, db, cancel_check)
        _ingest_enrichment(DEFINITION, source, mapping, db, cancel_check)
        _prepare(db)
        db.commit()
        cursor = db.execute(RESULT_SQL)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                row = _result_row(DEFINITION, timestamp, values[:17])
                row["tabla_error_1"] = "LC_PH_Predio"
                row["pk_tabla_error_1"] = values[17]
                row["tabla_error_2"] = "LC_PH_Derecho"
                row["pk_tabla_error_2"] = values[18]
                yield row
        finally:
            cursor.close()
