"""Disk-backed portable engine for scalar juridical novelty rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, raise_if_cancelled, sqlite_staging


_BASE_PREDIO_FIELDS = (
    "pk_id",
    "numero_predial_nacional",
    "nombre_proyecto",
    "matricula_inmobiliaria",
    "destinacion_economica",
    "area_catastral_terreno",
    "juridico_estado_asignacion",
    "juridico_estado_control",
    "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control",
    "informal_estado_asignacion",
    "informal_estado_control",
    "geografico_estado_asignacion",
    "geografico_estado_control",
)


@dataclass(frozen=True)
class JurNovedadScalarRule:
    canonical_id: str
    component: str
    description: str
    predicate_sql: str
    predio_extra_fields: tuple[str, ...] = ()
    custom_7: bool = False


RULES = {
    "Jur_49": JurNovedadScalarRule(
        "Jur_49", "Novedad_Predio_Nuevo",
        "Predios nuevos que tienen el numero predial diferente al numero predial de la tabla novedad",
        "t.ilicode = 'Predio_Nuevo' AND p.numero_predial_nacional <> n.numero_predial_nacional_novedad",
    ),
    "Jur_51": JurNovedadScalarRule(
        "Jur_51", "Novedad_Desenglobe_Division_Material",
        "Predios con numero predial igual al numero predial de la novedad",
        "t.ilicode = 'Desenglobe_Division_Material' AND p.numero_predial_nacional = n.numero_predial_nacional_novedad",
    ),
    "Jur_53": JurNovedadScalarRule(
        "Jur_53", "Novedad_Desenglobe_Venta_Parcial",
        "Predios con numero predial igual al numero predial de la novedad pero diferente al numero predial anterior",
        "t.ilicode = 'Desenglobe_Venta_Parcial' AND p.numero_predial_nacional = n.numero_predial_nacional_novedad AND p.numero_predial_nacional <> p.numero_predial_nacional_anterior",
        ("numero_predial_nacional_anterior",),
    ),
    "Jur_56": JurNovedadScalarRule(
        "Jur_56", "Novedad_Englobe_Crea_FMI",
        "Predios con numero predial igual al numero predial de la novedad",
        "t.ilicode = 'Englobe_Nuevo_FMI' AND p.numero_predial_nacional = n.numero_predial_nacional_novedad",
    ),
    "Jur_64": JurNovedadScalarRule(
        "Jur_64", "Cancelacion",
        "Predios con novedad de cancelado sin marcas predio_cancelado en la tabla predio",
        "lower(t.ilicode) LIKE 'cancelacion%' AND (p.juridico_predio_cancelado IS NULL OR p.juridico_predio_cancelado = 0)",
        ("juridico_predio_cancelado",),
    ),
    "Jur_65": JurNovedadScalarRule(
        "Jur_65", "Cancelacion",
        "Predios con numero predial diferente al relacionado en la novedad",
        "lower(t.ilicode) LIKE 'cancelacion%' AND p.numero_predial_nacional <> n.numero_predial_nacional_novedad",
    ),
    "Jur_67": JurNovedadScalarRule(
        "Jur_67", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de numero predial con numero predial anterior diferente al de la novedad",
        "lower(t.ilicode) LIKE 'cambio%' AND p.numero_predial_nacional_anterior <> n.numero_predial_nacional_novedad",
        ("numero_predial_nacional_anterior",),
    ),
    "Jur_68": JurNovedadScalarRule(
        "Jur_68", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de numero predial con numero predial de la novedad igual al numero predial nacional",
        "lower(t.ilicode) LIKE 'cambio%' AND p.numero_predial_nacional = n.numero_predial_nacional_novedad",
    ),
    "Jur_69": JurNovedadScalarRule(
        "Jur_69", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de mejora a formal, PH a NPH o Condominio a NPH donde la posicion 22 del numero predial es diferente a 0",
        "t.ilicode IN ('Cambio_Mejora_Formal','Cambio_PH_NPH','Cambio_Condominio_NPH') AND substr(p.numero_predial_nacional,22,1) <> '0'",
    ),
    "Jur_70": JurNovedadScalarRule(
        "Jur_70", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de mejora a informal o de formal a informal donde la posicion 22 del numero predial es diferente a 2",
        "t.ilicode IN ('Cambio_Mejora_Informal','Cambio_Formal_Informal') AND substr(p.numero_predial_nacional,22,1) <> '2'",
    ),
    "Jur_71": JurNovedadScalarRule(
        "Jur_71", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de NPH a Bien de Uso Publico donde la posicion 22 es diferente a 3",
        "t.ilicode = 'Cambio_NPH_Bien_Uso_Publico' AND substr(p.numero_predial_nacional,22,1) <> '3'",
    ),
    "Jur_72": JurNovedadScalarRule(
        "Jur_72", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de NPH a VIA donde la posicion 22 es diferente a 4",
        "t.ilicode = 'Cambio_NPH_Via' AND substr(p.numero_predial_nacional,22,1) <> '4'",
    ),
    "Jur_73": JurNovedadScalarRule(
        "Jur_73", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de PH a Condominio, de NPH a Condominio o Condominio a Condominio donde la posicion 22 del numero predial es diferente a 8",
        "t.ilicode IN ('Cambio_PH_Condominio','Cambio_NPH_Condominio','Cambio_Condominio_Condominio') AND substr(p.numero_predial_nacional,22,1) <> '8'",
    ),
    "Jur_74": JurNovedadScalarRule(
        "Jur_74", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de Condominio a PH, PH a PH o de NPH a PH donde la posicion 22 del numero predial es diferente a 9",
        "t.ilicode IN ('Cambio_PH_PH','Cambio_Condominio_PH','Cambio_NPH_PH') AND substr(p.numero_predial_nacional,22,1) <> '9'",
    ),
    "Jur_75": JurNovedadScalarRule(
        "Jur_75", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de urbano a rural donde la posicion 7 es igual a 1",
        "t.ilicode = 'Cambio_Urbano_Rural' AND substr(p.numero_predial_nacional,7,1) = '1'",
    ),
    "Jur_76": JurNovedadScalarRule(
        "Jur_76", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de rural a urbano donde la posicion 7 es diferente a 1",
        "t.ilicode = 'Cambio_Rural_Urbano' AND substr(p.numero_predial_nacional,7,1) <> '1'",
    ),
    "Jur_77": JurNovedadScalarRule(
        "Jur_77", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de manzana donde la manzana nueva es igual a la anterior",
        "t.ilicode = 'Cambio_Manzana' AND substr(p.numero_predial_nacional,14,4) = substr(n.numero_predial_nacional_novedad,14,4)",
    ),
    "Jur_78": JurNovedadScalarRule(
        "Jur_78", "Novedad_Cambio_NumeroPredial",
        "Predios con novedad de cambio de vereda donde la vereda nueva es igual a la anterior",
        "t.ilicode = 'Cambio_Vereda' AND substr(p.numero_predial_nacional,14,4) = substr(n.numero_predial_nacional_novedad,14,4)",
    ),
    "Jur_79": JurNovedadScalarRule(
        "Jur_79", "Novedad_Cambio_NumeroPredial",
        "Predios con novedades de Desengloebe_Venta_Parcial o Englobe_Mantiene_FMI con area catastral de terreno igual al area catastral de terreno anterior",
        "t.ilicode IN ('Desenglobe_Venta_Parcial','Englobe_Mantiene_FMI') AND p.area_catastral_terreno = p.area_catastral_terreno_anterior",
        ("area_catastral_terreno_anterior",),
    ),
}


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE predio (
            row_token INTEGER PRIMARY KEY, pk_id, pk_key TEXT,
            numero_predial_nacional, numero_predial_nacional_anterior,
            proyecto, matricula_inmobiliaria, destination_key TEXT,
            area_catastral_terreno, area_catastral_terreno_anterior,
            juridico_predio_cancelado,
            juridico_assignment_key TEXT, juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT, reconocimiento_control_key TEXT,
            informal_assignment_key TEXT, informal_control_key TEXT,
            geografico_assignment_key TEXT, geografico_control_key TEXT
        );
        CREATE TABLE novedad (
            row_token INTEGER PRIMARY KEY, pk_id, fk_key TEXT,
            tipo_key TEXT, numero_predial_nacional_novedad
        );
        CREATE TABLE novedad_tipo (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE selected (
            row_token INTEGER PRIMARY KEY, predio_row_token INTEGER,
            novedad_row_token INTEGER, pk_id, pk_key TEXT,
            numero_predial_nacional, proyecto, matricula_inmobiliaria,
            destination_key TEXT, area_catastral_terreno,
            juridico_assignment_key TEXT, juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT, reconocimiento_control_key TEXT,
            informal_assignment_key TEXT, informal_control_key TEXT,
            geografico_assignment_key TEXT, geografico_control_key TEXT,
            novedad_pk_id, tipo_novedad, numero_predial_nacional_novedad
        );
        CREATE TABLE destination_lookup (row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode);
        CREATE TABLE exception_lookup (row_token INTEGER PRIMARY KEY, fk_token TEXT, fid, descripcion_excepcion);
        CREATE TABLE user_assignment (row_token INTEGER PRIMARY KEY, fk_token TEXT, pk_id);
        CREATE TABLE assignment_lookup (row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode);
        CREATE TABLE control_lookup (row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode);
        """
    )


def _ingest_predio(definition, data_source, layer_mapping, db, cancel_check) -> None:
    fields = tuple(dict.fromkeys((*_BASE_PREDIO_FIELDS, *definition.predio_extra_fields)))
    sql = """INSERT INTO predio(
        pk_id,pk_key,numero_predial_nacional,numero_predial_nacional_anterior,
        proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno,
        area_catastral_terreno_anterior,juridico_predio_cancelado,
        juridico_assignment_key,juridico_control_key,
        reconocimiento_assignment_key,reconocimiento_control_key,
        informal_assignment_key,informal_control_key,
        geografico_assignment_key,geografico_control_key)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
    physical = layer_mapping.resolve("lc_gen_predio")
    with BatchInserter(db, sql, cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical, fields):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _join_token(row.get("pk_id")),
                row.get("numero_predial_nacional"), row.get("numero_predial_nacional_anterior"),
                row.get("nombre_proyecto"), row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")), row.get("area_catastral_terreno"),
                row.get("area_catastral_terreno_anterior"), row.get("juridico_predio_cancelado"),
                _join_token(row.get("juridico_estado_asignacion")),
                _join_token(row.get("juridico_estado_control")),
                _join_token(row.get("reconocimiento_estado_asignacion")),
                _join_token(row.get("reconocimiento_estado_control")),
                _join_token(row.get("informal_estado_asignacion")),
                _join_token(row.get("informal_estado_control")),
                _join_token(row.get("geografico_estado_asignacion")),
                _join_token(row.get("geografico_estado_control")),
            ))


def _ingest_novedad(data_source, layer_mapping, db, cancel_check) -> None:
    physical = layer_mapping.resolve("lc_jur_novedadnumeropredial")
    with BatchInserter(db, "INSERT INTO novedad(pk_id,fk_key,tipo_key,numero_predial_nacional_novedad) VALUES (?,?,?,?)", cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical, ("pk_id", "fk_id", "tipo_novedad", "numero_predial_nacional_novedad")):
            raise_if_cancelled(cancel_check)
            inserter.add((row.get("pk_id"), _join_token(row.get("fk_id")), _join_token(row.get("tipo_novedad")), row.get("numero_predial_nacional_novedad")))
    physical = layer_mapping.resolve("lc_jur_novedadnumeropredial_tipo")
    with BatchInserter(db, "INSERT INTO novedad_tipo(key_token,ilicode) VALUES (?,?)", cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical, ("itfcode", "ilicode")):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("itfcode")), row.get("ilicode")))


def _prepare_selected(definition, db) -> None:
    db.execute("""INSERT INTO selected(
        predio_row_token,novedad_row_token,pk_id,pk_key,numero_predial_nacional,
        proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno,
        juridico_assignment_key,juridico_control_key,reconocimiento_assignment_key,
        reconocimiento_control_key,informal_assignment_key,informal_control_key,
        geografico_assignment_key,geografico_control_key,novedad_pk_id,
        tipo_novedad,numero_predial_nacional_novedad)
        SELECT p.row_token,n.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,
        p.proyecto,p.matricula_inmobiliaria,p.destination_key,p.area_catastral_terreno,
        p.juridico_assignment_key,p.juridico_control_key,p.reconocimiento_assignment_key,
        p.reconocimiento_control_key,p.informal_assignment_key,p.informal_control_key,
        p.geografico_assignment_key,p.geografico_control_key,n.pk_id,t.ilicode,
        n.numero_predial_nacional_novedad
        FROM predio p JOIN novedad n ON n.fk_key=p.pk_key
        JOIN novedad_tipo t ON t.key_token=n.tipo_key
        WHERE """ + definition.predicate_sql)


_RESULT_SQL = """SELECT DISTINCT
    s.pk_id,s.numero_predial_nacional,s.proyecto,s.matricula_inmobiliaria,
    d.ilicode,s.area_catastral_terreno,e.fid,e.descripcion_excepcion,
    ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,
    ga.ilicode,gc.ilicode,ua.pk_id,s.novedad_pk_id,s.tipo_novedad,
    s.numero_predial_nacional_novedad
    FROM selected s
    LEFT JOIN destination_lookup d ON d.key_token=s.destination_key
    LEFT JOIN exception_lookup e ON e.fk_token=s.pk_key
    LEFT JOIN user_assignment ua ON ua.fk_token=s.pk_key
    LEFT JOIN assignment_lookup ja ON ja.key_token=s.juridico_assignment_key
    LEFT JOIN control_lookup jc ON jc.key_token=s.juridico_control_key
    LEFT JOIN assignment_lookup ra ON ra.key_token=s.reconocimiento_assignment_key
    LEFT JOIN control_lookup rc ON rc.key_token=s.reconocimiento_control_key
    LEFT JOIN assignment_lookup ia ON ia.key_token=s.informal_assignment_key
    LEFT JOIN control_lookup ic ON ic.key_token=s.informal_control_key
    LEFT JOIN assignment_lookup ga ON ga.key_token=s.geografico_assignment_key
    LEFT JOIN control_lookup gc ON gc.key_token=s.geografico_control_key"""


def execute_jur_novedad_scalar(rule_id, data_source, layer_mapping, cancel_check=None) -> Iterator[dict[str, Any]]:
    definition = RULES[rule_id]
    execution_timestamp = datetime.now()
    with sqlite_staging(cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        _create_stage(db)
        _ingest_predio(definition, data_source, layer_mapping, db, cancel_check)
        _ingest_novedad(data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(definition, data_source, layer_mapping, db, cancel_check)
        _prepare_selected(definition, db)
        db.commit()
        cursor = db.execute(_RESULT_SQL)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                base = _result_row(definition, execution_timestamp, values[:17])
                base["tabla_error_2"] = "LC_Jur_NovedadNumeroPredial"
                base["pk_tabla_error_2"] = values[17]
                base["tipo_novedad"] = values[18]
                base["numero_predial_nacional_novedad"] = values[19]
                yield base
        finally:
            cursor.close()


def _entrypoint(rule_id):
    def execute(data_source, layer_mapping, cancel_check=None):
        return execute_jur_novedad_scalar(
            rule_id, data_source, layer_mapping, cancel_check
        )
    execute.__name__ = "execute_{0}".format(rule_id.lower())
    return execute


execute_jur_49 = _entrypoint("Jur_49")
execute_jur_51 = _entrypoint("Jur_51")
execute_jur_53 = _entrypoint("Jur_53")
execute_jur_56 = _entrypoint("Jur_56")
execute_jur_64 = _entrypoint("Jur_64")
execute_jur_65 = _entrypoint("Jur_65")
execute_jur_67 = _entrypoint("Jur_67")
execute_jur_68 = _entrypoint("Jur_68")
execute_jur_69 = _entrypoint("Jur_69")
execute_jur_70 = _entrypoint("Jur_70")
execute_jur_71 = _entrypoint("Jur_71")
execute_jur_72 = _entrypoint("Jur_72")
execute_jur_73 = _entrypoint("Jur_73")
execute_jur_74 = _entrypoint("Jur_74")
execute_jur_75 = _entrypoint("Jur_75")
execute_jur_76 = _entrypoint("Jur_76")
execute_jur_77 = _entrypoint("Jur_77")
execute_jur_78 = _entrypoint("Jur_78")
execute_jur_79 = _entrypoint("Jur_79")
