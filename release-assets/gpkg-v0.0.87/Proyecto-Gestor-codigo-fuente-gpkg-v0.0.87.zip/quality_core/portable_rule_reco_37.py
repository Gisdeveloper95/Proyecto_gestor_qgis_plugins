"""Independent portable implementation of canonical Reco_37."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_37", "Calificacion",
    "Caracteristica Unidad de Construccion sin estado de conservacion",
    "c.estado_conservacion IS NULL OR c.estado_conservacion > 8", True,
    construction_filter_fields=("estado_conservacion",),
)

def execute_reco_37(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
