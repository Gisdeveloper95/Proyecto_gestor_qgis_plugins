"""Independent portable implementation of canonical Reco_12."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_12", "Juridico",
    "Predios marcados para visita en la etapa juridica sin contacto visita",
    "lc_vis_contactovisita", ("pk_id", "fk_id"), "anti", "1=1",
    "p.juridico_predio_para_visita = 1",
    "LC_Gen_Predio", "predio", "LC_Vis_ContactoVisita",
    predio_filter_fields=("juridico_predio_para_visita",),
)

def execute_reco_12(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
