"""Independent portable implementation of canonical Reco_20."""

from .portable_construction_scalar import (
    ConstructionScalarRule,
    execute_construction_scalar,
)


_RULE = ConstructionScalarRule(
    "Reco_20",
    "Calificacion",
    "Predios sin cambio fisico con Caracteristicas Unidad de Construccion nuevas",
    "(p.predio_tiene_cambio_fisico = 0 OR p.predio_tiene_cambio_fisico IS NULL) "
    "AND c.pk_carac LIKE '{%'",
    False,
    predio_filter_fields=("predio_tiene_cambio_fisico",),
    table_error_1="LC_Gen_Predio",
    table_error_1_source="predio",
    table_error_2="LC_Reco_Caracteristicasunidadconstruccion",
)


def _canonical_rows(data_source, layer_mapping, cancel_check):
    for row in execute_construction_scalar(
        _RULE, data_source, layer_mapping, cancel_check
    ):
        # These five expressions are literal NULLs in the canonical projection.
        row["identificador_caracteristica_unidad_construccion"] = None
        row["total_plantas"] = None
        row["area_construida"] = None
        row["puntaje_calificacion"] = None
        yield row


def execute_reco_20(data_source, layer_mapping, cancel_check=None):
    return _canonical_rows(data_source, layer_mapping, cancel_check)
