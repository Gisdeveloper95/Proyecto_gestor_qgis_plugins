"""Independent portable implementation of canonical Reco_64."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_64", "Calificacion",
    "Predios informales con calificacion mayor a 50 puntos",
    "substr(p.numero_predial_nacional,22,1) IN ('2','5') AND c.puntaje > 50",
    False, table_error_1="LC_Gen_Predio", table_error_1_source="predio",
    table_error_2="LC_Reco_CaracteristicasUnidadConstruccion",
)

def execute_reco_64(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
