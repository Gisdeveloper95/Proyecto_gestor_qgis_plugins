"""Independent portable implementation of the canonical Reco_04 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    coefficient_area = row.get("area_terreno_condominio_coeficiente")
    return (
        postgres_substring(row.get("numero_predial_nacional"), 22, 1) == "8"
        and postgres_substring(row.get("numero_predial_nacional"), 27, 4)
        != "0000"
        and (coefficient_area is None or coefficient_area == 0)
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_04",
    component="Juridico",
    description=(
        "Predios en condicion de condominio sin area catastral de terreno "
        "correspondiente al calculo por coeficiente"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=("area_terreno_condominio_coeficiente",),
)


def execute_reco_04(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_04 findings before the operational filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
