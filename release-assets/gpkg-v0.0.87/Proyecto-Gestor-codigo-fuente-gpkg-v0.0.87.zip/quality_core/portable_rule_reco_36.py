"""Independent portable implementation of canonical Reco_36."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_36", "Reconocimiento",
    "Caracteristica Unidad de Construccion sin area construida sin cambio fisico",
    "c.area_construida IS NULL AND (p.predio_tiene_cambio_fisico IS NULL OR p.predio_tiene_cambio_fisico = 0)",
    True, predio_filter_fields=("predio_tiene_cambio_fisico",),
    table_error_1="LC_Reco_CaracteristicasUnidadConstruccion",
)

def execute_reco_36(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
