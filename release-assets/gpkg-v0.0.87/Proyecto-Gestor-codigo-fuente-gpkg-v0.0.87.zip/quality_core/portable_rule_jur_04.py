"""Independent portable implementation of the canonical Jur_04 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_boolean_is_false_or_null


def _matches(row: Mapping[str, Any]) -> bool:
    matricula = row.get("matricula_inmobiliaria")
    matricula_anterior = row.get("matricula_inmobiliaria_anterior")
    return (
        matricula is not None
        and matricula_anterior is not None
        and "190-{0}".format(matricula) != str(matricula_anterior)
        and postgres_boolean_is_false_or_null(row.get("juridico_cambio_juridico"))
    )


_RULE = PredioScalarRule(
    canonical_id="Jur_04",
    component="Juridico",
    description=(
        "Predios con matricula inmobiliaria diferente a la matricula "
        "inmobiliaria anterior sin marca de cambio juridico"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=("matricula_inmobiliaria_anterior", "juridico_cambio_juridico"),
)


def execute_jur_04(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_04 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
