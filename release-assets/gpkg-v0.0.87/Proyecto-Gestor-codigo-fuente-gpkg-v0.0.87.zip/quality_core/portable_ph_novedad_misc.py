"""Portable miscellaneous and aggregate PH novelty rules."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,postgres_boolean_is_true,raise_if_cancelled,sqlite_staging
@dataclass(frozen=True)
class Rule:
 canonical_id:str;component:str;description:str;mode:str;custom_7:bool=False
RULES={
"PH_24":Rule("PH_24","PH","Predios PH nuevos con novedad de cambio de numero de predial o cancelacion","new"),
"PH_25":Rule("PH_25","PH","Predios PH antiguos con numero predial diferente al anterior sin novedad de cambio de numero predial","old"),
"PH_58":Rule("PH_58","Cancelacion","Predios relacionados en mas de una novedad","multiple"),
"PH_64":Rule("PH_64","PH","Predios PH Matrices con mas de un Destino Economico","destinations"),
}
GF=("pk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_predio_cancelado","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control");PF=("pk_id","fk_id","numero_predial_nacional","numero_predial_nacional_anterior","numero_predial_matriz","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,registration,destination_key TEXT,area,cancelled,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,previous_npn,matrix_npn,registration,destination,destination_key TEXT,area);CREATE TABLE event(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,type_code,type_key TEXT,type_name,reference);CREATE TABLE excluded_parent(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE candidate(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,exception_key TEXT,assignment_key TEXT,error_table_1,error_pk_1,error_table_2,error_pk_2,npn,project,registration,destination_key TEXT,area,novelty_type,reference,custom_10,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(definition,source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,npn,registration,destination_key,area,cancelled,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),r.get("juridico_predio_cancelado"),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,previous_npn,matrix_npn,registration,destination,destination_key,area)VALUES(?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("numero_predial_nacional_anterior"),r.get("numero_predial_matriz"),r.get("matricula_inmobiliaria"),r.get("destinacion_economica"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 raw_events=[]
 for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("pk_id","fk_id","tipo_novedad","numero_predial_nacional_novedad")):raise_if_cancelled(cancel);raw_events.append(r)
 type_names={}
 if definition.mode!="destinations":
  for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial_tipo"),("itfcode","ilicode")):raise_if_cancelled(cancel);type_names.setdefault(_join_token(r.get("itfcode")),[]).append(r.get("ilicode"))
 with BatchInserter(db,"INSERT INTO event(pk_id,fk_key,type_code,type_key,type_name,reference)VALUES(?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in raw_events:
   names=type_names.get(_join_token(r.get("tipo_novedad")),[None])
   for name in names:ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),r.get("tipo_novedad"),_join_token(r.get("tipo_novedad")),name,r.get("numero_predial_nacional_novedad")))
 if definition.mode=="destinations":
  with BatchInserter(db,"INSERT INTO excluded_parent(key_token)VALUES(?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"),("fk_id","tipo_novedad")):
    raise_if_cancelled(cancel)
    if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
   for k,npn,cancelled in db.execute("SELECT pk_key,npn,cancelled FROM gen"):
    if postgres_boolean_is_true(cancelled)and npn is not None and len(npn)>=22 and npn[21:22]=='9':ins.add((k,))
def _prepare(definition,db):
 ins="INSERT INTO candidate(general_pk,ph_pk,exception_key,assignment_key,error_table_1,error_pk_1,error_table_2,error_pk_2,npn,project,registration,destination_key,area,novelty_type,reference,custom_10,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)"
 fields="g.pk_id,p.pk_id,p.pk_key,p.pk_key,'LC_PH_Predio',p.pk_id,'LC_PH_NovedadNumeroPredial',{err2},p.npn,g.project,p.registration,p.destination_key,p.area,{novtype},{reference},NULL,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c"
 eligible="NOT EXISTS(SELECT 1 FROM event x WHERE x.fk_key=p.pk_key AND x.type_code IN(5,6,7,8))"
 if definition.mode=="new":q=f"SELECT {fields.format(err2='e.pk_id',novtype='e.type_name',reference='e.reference')} FROM ph p JOIN gen g ON p.parent_key=g.pk_key JOIN event e ON e.fk_key=p.pk_key WHERE {eligible} AND e.type_code>=5 AND p.previous_npn IS NULL"
 elif definition.mode=="old":q=f"SELECT {fields.format(err2='NULL',novtype='NULL',reference='NULL')} FROM ph p JOIN gen g ON p.parent_key=g.pk_key WHERE {eligible} AND p.previous_npn IS NOT NULL AND p.npn<>p.previous_npn AND NOT EXISTS(SELECT 1 FROM event e WHERE e.fk_key=p.pk_key AND e.type_code>=8)"
 elif definition.mode=="multiple":q=f"SELECT {fields.format(err2='c.pk_id',novtype='o.type_name',reference='o.reference')} FROM ph p JOIN gen g ON p.parent_key=g.pk_key JOIN event c ON c.fk_key=p.pk_key JOIN event o ON o.fk_key=p.pk_key WHERE c.type_name IN('Cancelacion','Cancelacion_Doble_Inscripcion') AND o.type_name NOT IN('Cancelacion','Cancelacion_Doble_Inscripcion') AND(c.reference IS NOT NULL OR o.reference IS NOT NULL) AND(p.npn=o.reference OR p.npn=p.npn)"
 else:q="""WITH eligible AS(SELECT p.* FROM ph p WHERE NOT EXISTS(SELECT 1 FROM event e WHERE e.fk_key=p.pk_key AND e.type_code IN(5,6,7,8))AND NOT EXISTS(SELECT 1 FROM excluded_parent x WHERE x.key_token=p.parent_key)),groups AS(SELECT parent_key,matrix_npn,destination,destination_key,count(*)n FROM eligible GROUP BY parent_key,matrix_npn,destination,destination_key),multi AS(SELECT parent_key,matrix_npn FROM groups GROUP BY parent_key,matrix_npn HAVING count(*)>1)SELECT g.pk_id,NULL,g.pk_key,g.pk_key,'LC_Gen_Predio',g.pk_id,NULL,NULL,g.npn,g.project,g.registration,gr.destination_key,g.area,NULL,NULL,gr.n,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c FROM groups gr JOIN multi m ON m.parent_key=gr.parent_key AND(m.matrix_npn=gr.matrix_npn OR(m.matrix_npn IS NULL AND gr.matrix_npn IS NULL))LEFT JOIN gen g ON g.pk_key=gr.parent_key"""
 db.execute(ins+q)
RESULT="""SELECT DISTINCT c.general_pk,c.npn,c.project,c.registration,d.ilicode,c.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.ph_pk,c.error_table_1,c.error_pk_1,c.error_table_2,c.error_pk_2,c.novelty_type,c.reference,c.custom_10 FROM candidate c LEFT JOIN destination_lookup d ON d.key_token=c.destination_key LEFT JOIN exception_lookup e ON e.fk_token=c.exception_key LEFT JOIN user_assignment ua ON ua.fk_token=c.assignment_key LEFT JOIN assignment_lookup ja ON ja.key_token=c.jur_a LEFT JOIN control_lookup jc ON jc.key_token=c.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=c.reco_a LEFT JOIN control_lookup rc ON rc.key_token=c.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=c.info_a LEFT JOIN control_lookup ic ON ic.key_token=c.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=c.geo_a LEFT JOIN control_lookup gc ON gc.key_token=c.geo_c ORDER BY c.npn IS NULL,c.npn,c.project IS NULL,c.project,d.ilicode IS NULL,d.ilicode"""
def execute_misc(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(definition,source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT)
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["tabla_error_1"]=v[18];row["pk_tabla_error_1"]=v[19];row["tabla_error_2"]=v[20];row["pk_tabla_error_2"]=v[21];row["tipo_novedad"]=v[22];row["numero_predial_nacional_novedad"]=v[23];row["custom_10"]=v[24];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_misc(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_24=_entry("PH_24");execute_ph_25=_entry("PH_25");execute_ph_58=_entry("PH_58");execute_ph_64=_entry("PH_64")
