"""Isolated adapters for the remaining scalar juridical novelty rules."""
from .portable_jur_novedad_scalar import (
    JurNovedadScalarRule,
    RULES,
    execute_jur_novedad_scalar,
)


RULES.setdefault(
    "Jur_22",
    JurNovedadScalarRule(
        "Jur_22",
        "Juridico",
        "Predios nuevos con novedad de cambio de numero de predial o cancelacion",
        "p.numero_predial_nacional_anterior IS NULL AND "
        "(lower(t.ilicode) LIKE '%cancelacion%' OR lower(t.ilicode) LIKE '%cambio%')",
        ("numero_predial_nacional_anterior",),
        False,
    ),
)
RULES.setdefault(
    "Jur_60",
    JurNovedadScalarRule(
        "Jur_60",
        "Novedad_Englobe_Mantiene_FMI",
        "El numero predial de la novedad debe ser diferente al predio o si es igual debe ser igual al numero predial anterior",
        "t.ilicode = 'Englobe_Mantiene_FMI' AND "
        "p.numero_predial_nacional = n.numero_predial_nacional_novedad AND "
        "p.numero_predial_nacional <> p.numero_predial_nacional_anterior",
        ("numero_predial_nacional_anterior",),
        False,
    ),
)


def execute_jur_22(data_source, layer_mapping, cancel_check=None):
    return execute_jur_novedad_scalar("Jur_22", data_source, layer_mapping, cancel_check)


def execute_jur_60(data_source, layer_mapping, cancel_check=None):
    return execute_jur_novedad_scalar("Jur_60", data_source, layer_mapping, cancel_check)
