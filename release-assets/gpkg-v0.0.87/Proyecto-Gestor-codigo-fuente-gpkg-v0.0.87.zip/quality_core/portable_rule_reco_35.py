"""Independent portable implementation of canonical Reco_35."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_RULE = ConstructionScalarRule(
    "Reco_35", "Reconocimiento",
    "Caracteristica Unidad de Construccion sin area construida con cambio fisico",
    "c.area_construida IS NULL AND p.predio_tiene_cambio_fisico = 1", True,
    predio_filter_fields=("predio_tiene_cambio_fisico",),
    table_error_1="LC_Reco_CaracteristicasUnidadConstruccion",
)

def execute_reco_35(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
