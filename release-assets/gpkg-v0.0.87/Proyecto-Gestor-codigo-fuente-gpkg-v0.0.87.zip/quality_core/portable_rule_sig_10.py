"""Independent portable implementation of the canonical SIG_10 rule."""

from __future__ import annotations

from collections.abc import Callable, Iterator
import json
from pathlib import Path
import sqlite3
import tempfile
from typing import Any


SIG_10_INGEST_BATCH_SIZE = 256
SIG_10_SQLITE_CACHE_KIB = 4096


def _cancelled(cancel_check: Callable[[], bool] | None) -> None:
    if cancel_check is not None and cancel_check():
        raise InterruptedError("Ejecucion portable cancelada por el usuario.")


def _join_key(value: Any) -> str | None:
    if value is None:
        return None
    return str(value)


def _active_predio(value: Any) -> bool:
    """Match ``juridico_predio_cancelado IS NULL OR ... = false``."""

    if value is None or value is False or value == 0:
        return True
    return str(value).strip().lower() in {"false", "f", "no", "n"}


def _is_true(value: Any) -> bool:
    if value is True or value == 1:
        return True
    return str(value).strip().lower() in {"true", "t", "yes", "y", "si"}


def _is_excluding_novelty(value: Any) -> bool:
    """Match ``tipo_novedad IN (5, 6, 7, 8)`` for portable scalar values."""

    if value in {5, 6, 7, 8}:
        return True
    return isinstance(value, str) and value.strip() in {"5", "6", "7", "8"}


def _is_ph_code(value: Any) -> bool:
    """Match PostgreSQL ``substring(codigo, 22, 1) = '9'``."""

    if value is None:
        return False
    return str(value)[21:22] == "9"


def _json_value(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str, separators=(",", ":"))


def _flush_batch(db: sqlite3.Connection, sql: str, batch: list[tuple]) -> None:
    if batch:
        db.executemany(sql, batch)
        batch.clear()


def execute_sig_10(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield SIG_10 findings using bounded, disk-backed attribute joins."""

    with tempfile.TemporaryDirectory(prefix="mapingtool-calidad-gpkg-sig10-") as temp_dir:
        stage_path = Path(temp_dir) / "stage.sqlite"
        db = sqlite3.connect(str(stage_path))
        try:
            db.execute("PRAGMA journal_mode=OFF")
            db.execute("PRAGMA synchronous=OFF")
            db.execute("PRAGMA temp_store=FILE")
            db.execute("PRAGMA cache_size=-{0}".format(SIG_10_SQLITE_CACHE_KIB))
            if cancel_check is not None:
                db.set_progress_handler(lambda: 1 if cancel_check() else 0, 1000)

            db.execute(
                "CREATE TABLE excluded_novelty (pk_key TEXT PRIMARY KEY) WITHOUT ROWID"
            )
            novelty_batch: list[tuple] = []
            novelty_layer = layer_mapping.resolve("lc_ph_novedadnumeropredial")
            for row in data_source.iter_rows(
                novelty_layer, ("fk_id", "tipo_novedad")
            ):
                _cancelled(cancel_check)
                if not _is_excluding_novelty(row.get("tipo_novedad")):
                    continue
                pk_key = _join_key(row.get("fk_id"))
                # A NULL never matches lpp.pk_id in the canonical inner join.
                if pk_key is not None:
                    novelty_batch.append((pk_key,))
                if len(novelty_batch) >= SIG_10_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT OR IGNORE INTO excluded_novelty(pk_key) VALUES (?)",
                        novelty_batch,
                    )
            _flush_batch(
                db,
                "INSERT OR IGNORE INTO excluded_novelty(pk_key) VALUES (?)",
                novelty_batch,
            )

            db.execute(
                "CREATE TABLE ph_predio ("
                "row_token INTEGER PRIMARY KEY, fid_is_null INTEGER NOT NULL, "
                "pk_is_null INTEGER NOT NULL, pk_key TEXT, fk_key TEXT, "
                "number_key TEXT, association_token TEXT NOT NULL)"
            )
            ph_batch: list[tuple] = []
            ph_layer = layer_mapping.resolve("lc_ph_predio")
            for row in data_source.iter_rows(
                ph_layer,
                ("fid", "pk_id", "fk_id", "numero_predial_nacional"),
            ):
                _cancelled(cancel_check)
                raw_pk = row.get("pk_id")
                fk_key = _join_key(row.get("fk_id"))
                number_key = _join_key(row.get("numero_predial_nacional"))
                ph_batch.append(
                    (
                        int(row.get("fid") is None),
                        int(raw_pk is None),
                        _join_key(raw_pk),
                        fk_key,
                        number_key,
                        _json_value([fk_key, number_key]),
                    )
                )
                if len(ph_batch) >= SIG_10_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT INTO ph_predio("
                        "fid_is_null, pk_is_null, pk_key, fk_key, number_key, "
                        "association_token) VALUES (?, ?, ?, ?, ?, ?)",
                        ph_batch,
                    )
            _flush_batch(
                db,
                "INSERT INTO ph_predio("
                "fid_is_null, pk_is_null, pk_key, fk_key, number_key, "
                "association_token) VALUES (?, ?, ?, ?, ?, ?)",
                ph_batch,
            )
            db.execute("CREATE INDEX idx_sig10_ph_pk ON ph_predio(pk_key)")
            db.execute("CREATE INDEX idx_sig10_ph_fk ON ph_predio(fk_key)")

            db.execute(
                "CREATE TABLE gen_predio ("
                "row_token INTEGER PRIMARY KEY, pk_key TEXT, "
                "change_is_true INTEGER NOT NULL)"
            )
            gen_batch: list[tuple] = []
            gen_layer = layer_mapping.resolve("lc_gen_predio")
            for row in data_source.iter_rows(
                gen_layer,
                (
                    "pk_id",
                    "juridico_predio_cancelado",
                    "predio_tiene_cambio_fisico",
                    "nombre_proyecto",
                ),
            ):
                _cancelled(cancel_check)
                if not _active_predio(row.get("juridico_predio_cancelado")):
                    continue
                gen_batch.append(
                    (
                        _join_key(row.get("pk_id")),
                        int(_is_true(row.get("predio_tiene_cambio_fisico"))),
                    )
                )
                if len(gen_batch) >= SIG_10_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT INTO gen_predio(pk_key, change_is_true) VALUES (?, ?)",
                        gen_batch,
                    )
            _flush_batch(
                db,
                "INSERT INTO gen_predio(pk_key, change_is_true) VALUES (?, ?)",
                gen_batch,
            )
            db.execute("CREATE INDEX idx_sig10_gen_pk ON gen_predio(pk_key)")

            db.execute(
                "CREATE TABLE eligible_ph ("
                "row_token INTEGER PRIMARY KEY, fid_is_null INTEGER NOT NULL, "
                "pk_is_null INTEGER NOT NULL, pk_key TEXT, fk_key TEXT, "
                "number_key TEXT, association_token TEXT NOT NULL, "
                "change_is_true INTEGER NOT NULL)"
            )
            db.execute(
                "INSERT INTO eligible_ph("
                "fid_is_null, pk_is_null, pk_key, fk_key, number_key, "
                "association_token, change_is_true) "
                "SELECT p.fid_is_null, p.pk_is_null, p.pk_key, p.fk_key, "
                "p.number_key, p.association_token, g.change_is_true "
                "FROM ph_predio p JOIN gen_predio g ON p.fk_key = g.pk_key "
                "WHERE NOT EXISTS (SELECT 1 FROM excluded_novelty n "
                "WHERE n.pk_key = p.pk_key)"
            )
            _cancelled(cancel_check)

            invalid_sentinel = db.execute(
                "SELECT fid_is_null, pk_is_null FROM eligible_ph "
                "WHERE fid_is_null = 1 OR pk_is_null = 1 LIMIT 1"
            ).fetchone()
            if invalid_sentinel is not None:
                field_name = "fid" if invalid_sentinel[0] else "pk_id"
                raise ValueError(
                    "SIG_10 requiere {0} no nulo en cada predio PH elegible; "
                    "los LEFT JOIN canonicos usan esos campos como centinelas.".format(
                        field_name
                    )
                )

            ambiguous_pk = db.execute(
                "SELECT pk_key FROM eligible_ph GROUP BY pk_key "
                "HAVING COUNT(DISTINCT association_token) > 1 LIMIT 1"
            ).fetchone()
            if ambiguous_pk is not None:
                raise ValueError(
                    "SIG_10 no puede resolver el mismo pk_id PH asociado a "
                    "distintos fk_id o numeros prediales; DISTINCT ON carece de orden."
                )
            db.execute("CREATE INDEX idx_sig10_eligible_pk ON eligible_ph(pk_key)")

            db.execute(
                "CREATE TABLE characteristic ("
                "row_token INTEGER PRIMARY KEY, fk_key TEXT, identifier_key TEXT)"
            )
            characteristic_batch: list[tuple] = []
            characteristic_layer = layer_mapping.resolve(
                "lc_ph_caracteristicasunidadconstruccion"
            )
            for row in data_source.iter_rows(
                characteristic_layer, ("fk_id", "identificador")
            ):
                _cancelled(cancel_check)
                characteristic_batch.append(
                    (
                        _join_key(row.get("fk_id")),
                        _join_key(row.get("identificador")),
                    )
                )
                if len(characteristic_batch) >= SIG_10_INGEST_BATCH_SIZE:
                    _flush_batch(
                        db,
                        "INSERT INTO characteristic(fk_key, identifier_key) "
                        "VALUES (?, ?)",
                        characteristic_batch,
                    )
            _flush_batch(
                db,
                "INSERT INTO characteristic(fk_key, identifier_key) VALUES (?, ?)",
                characteristic_batch,
            )
            db.execute("CREATE INDEX idx_sig10_characteristic_fk ON characteristic(fk_key)")

            db.execute(
                "CREATE TABLE joined_ph ("
                "row_token INTEGER PRIMARY KEY, fid_is_null INTEGER NOT NULL, "
                "pk_key TEXT NOT NULL, number_key TEXT, "
                "change_is_true INTEGER NOT NULL, identifier_key TEXT)"
            )
            db.execute(
                "INSERT INTO joined_ph("
                "fid_is_null, pk_key, number_key, change_is_true, identifier_key) "
                "SELECT p.fid_is_null, p.pk_key, p.number_key, p.change_is_true, "
                "c.identifier_key FROM eligible_ph p JOIN characteristic c "
                "ON p.pk_key = c.fk_key"
            )
            db.execute(
                "CREATE INDEX idx_sig10_join_match "
                "ON joined_ph(number_key, identifier_key)"
            )
            db.execute(
                "CREATE INDEX idx_sig10_join_changed "
                "ON joined_ph(change_is_true, pk_key, row_token)"
            )

            db.execute(
                "CREATE TABLE unit ("
                "distinct_token TEXT PRIMARY KEY, pk_json TEXT NOT NULL, "
                "code_json TEXT NOT NULL, planta_json TEXT NOT NULL, "
                "identifier_json TEXT NOT NULL, code_key TEXT NOT NULL, "
                "identifier_key TEXT, table_label TEXT NOT NULL, "
                "pk_is_null INTEGER NOT NULL, pk_sort TEXT NOT NULL, "
                "identifier_is_null INTEGER NOT NULL, identifier_sort TEXT NOT NULL) "
                "WITHOUT ROWID"
            )
            unit_batch: list[tuple] = []
            unit_insert = (
                "INSERT OR IGNORE INTO unit("
                "distinct_token, pk_json, code_json, planta_json, identifier_json, "
                "code_key, identifier_key, table_label, pk_is_null, pk_sort, "
                "identifier_is_null, identifier_sort) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            )
            unit_layers = (
                ("lc_gen_unidadconstruccion", "LC_Gen_UnidadConstruccion"),
                (
                    "lc_gen_unidadconstruccion_informal",
                    "LC_Gen_UnidadConstruccion_Informal",
                ),
            )
            for logical_name, table_label in unit_layers:
                physical_layer = layer_mapping.resolve(logical_name)
                for row in data_source.iter_rows(
                    physical_layer,
                    (
                        "pk_id",
                        "codigo",
                        "planta",
                        "tipo_construccion",
                        "etiqueta",
                        "identificador",
                    ),
                ):
                    _cancelled(cancel_check)
                    raw_code = row.get("codigo")
                    if not _is_ph_code(raw_code):
                        continue
                    raw_pk = row.get("pk_id")
                    raw_planta = row.get("planta")
                    raw_identifier = row.get("identificador")
                    code_key = _join_key(raw_code)
                    identifier_key = _join_key(raw_identifier)
                    distinct_token = _json_value(
                        [
                            raw_pk,
                            raw_code,
                            raw_planta,
                            row.get("tipo_construccion"),
                            row.get("etiqueta"),
                            raw_identifier,
                            table_label,
                        ]
                    )
                    unit_batch.append(
                        (
                            distinct_token,
                            _json_value(raw_pk),
                            _json_value(raw_code),
                            _json_value(raw_planta),
                            _json_value(raw_identifier),
                            code_key,
                            identifier_key,
                            table_label,
                            int(raw_pk is None),
                            "" if raw_pk is None else str(raw_pk),
                            int(raw_identifier is None),
                            "" if raw_identifier is None else str(raw_identifier),
                        )
                    )
                    if len(unit_batch) >= SIG_10_INGEST_BATCH_SIZE:
                        _flush_batch(db, unit_insert, unit_batch)
            _flush_batch(db, unit_insert, unit_batch)
            db.commit()
            _cancelled(cancel_check)

            cursor = db.execute(
                "WITH b5 AS ("
                "SELECT u.* FROM unit u LEFT JOIN joined_ph b "
                "ON u.code_key = b.number_key "
                "AND u.identifier_key = b.identifier_key "
                "WHERE b.row_token IS NULL"
                "), ranked_changed AS ("
                "SELECT b.*, ROW_NUMBER() OVER ("
                "PARTITION BY b.pk_key ORDER BY b.row_token) AS selected_row "
                "FROM joined_ph b WHERE b.change_is_true = 1"
                "), b6 AS ("
                "SELECT * FROM ranked_changed WHERE selected_row = 1"
                ") "
                "SELECT b5.pk_json, b5.code_json, b5.planta_json, "
                "b5.identifier_json, b5.table_label "
                "FROM b5 LEFT JOIN b6 ON b5.code_key = b6.number_key "
                "WHERE b6.row_token IS NULL "
                "ORDER BY b5.code_key, b5.identifier_is_null, "
                "b5.identifier_sort, b5.pk_is_null, b5.pk_sort, b5.table_label"
            )
            try:
                for pk_json, code_json, planta_json, identifier_json, table_label in cursor:
                    _cancelled(cancel_check)
                    yield {
                        "id_regla": "SIG_10",
                        "descripcion_regla": (
                            "Unidad de Construccion PH en comision sin cambio fisico"
                        ),
                        "tabla_error": table_label,
                        "pk_tabla_error": json.loads(pk_json),
                        "codigo": json.loads(code_json),
                        "identificador_unidad_construccion": json.loads(
                            identifier_json
                        ),
                        "planta_unidad_construccion": json.loads(planta_json),
                        "tiene_excepcion": None,
                    }
            finally:
                cursor.close()
        except sqlite3.OperationalError as exc:
            if cancel_check is not None and cancel_check():
                raise InterruptedError(
                    "Ejecucion portable cancelada por el usuario."
                ) from exc
            raise
        finally:
            db.close()
