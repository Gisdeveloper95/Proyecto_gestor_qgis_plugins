"""Independent portable implementation of canonical Reco_38."""
from .portable_reco_calification import execute_calification_rule
def execute_reco_38(data_source,layer_mapping,cancel_check=None): return execute_calification_rule("Reco_38",data_source,layer_mapping,cancel_check)
