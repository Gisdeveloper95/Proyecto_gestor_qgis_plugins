"""Independent portable implementation of canonical Reco_22."""
from .portable_reco_aggregate import execute_reco_22 as _execute


def execute_reco_22(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
