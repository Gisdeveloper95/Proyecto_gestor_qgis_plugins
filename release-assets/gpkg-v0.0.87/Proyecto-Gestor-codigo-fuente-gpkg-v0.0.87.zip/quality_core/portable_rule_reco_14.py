"""Independent portable implementation of canonical Reco_14."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_14", "Reconocimiento",
    "Predios sin marca de visita en la etapa de reconocimiento con datos de visita",
    "lc_vis_contactovisita", ("pk_id", "fk_id"), "inner", "1=1",
    "(p.reconocimiento_predio_para_visita IS NULL OR p.reconocimiento_predio_para_visita = 0) "
    "AND (p.juridico_predio_para_visita IS NULL OR p.juridico_predio_para_visita = 0)",
    "LC_Gen_Predio", "predio", "LC_Vis_ContactoVisita", "related",
    predio_filter_fields=("reconocimiento_predio_para_visita", "juridico_predio_para_visita"),
)

def execute_reco_14(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
