"""Portable PH aggregate area and coefficient rules."""
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from types import SimpleNamespace
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_boolean_is_false_or_null, postgres_boolean_is_true, raise_if_cancelled, sqlite_staging
from .portable_rule_reco_49 import _wkb_area


@dataclass(frozen=True)
class Rule:
    canonical_id: str
    component: str
    description: str
    mode: str
    custom_7: bool = False


RULES = {
    "PH_02": Rule("PH_02", "Juridico", "Predios PH Matriz con un coeficiente total diferente a 100%", "coefficient"),
    "PH_03": Rule("PH_03", "PH", "Predios PH Matriz con cambio fisico y diferencia menor al 5% entre el area construida alfanumérica y geográfica", "built_area"),
    "PH_08": Rule("PH_08", "PH", "Predios PH Matriz con area catastral de terreno diferente a la suma de áreas de las unidades prediales", "cadastral_area"),
    "PH_67": Rule("PH_67", "PH", "Predios PH Matriz con area geometrica de terreno diferente a la suma de áreas de las unidades prediales (superior al 2%)", "geometric_area"),
}

GF = ("pk_id", "numero_predial_nacional", "matricula_inmobiliaria", "destinacion_economica", "area_catastral_terreno", "juridico_predio_cancelado", "predio_tiene_cambio_fisico", "nombre_proyecto", "juridico_estado_asignacion", "juridico_estado_control", "reconocimiento_estado_asignacion", "reconocimiento_estado_control", "informal_estado_asignacion", "informal_estado_control", "geografico_estado_asignacion", "geografico_estado_control")
PF = ("pk_id", "fk_id", "numero_predial_nacional", "matricula_inmobiliaria", "destinacion_economica", "area_catastral_terreno", "coeficiente", "area_total_construida")


def _create(db):
    db.executescript("""
    CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,npn_key TEXT,registration,destination_key TEXT,area,cancelled,physical_change,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);
    CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination_key TEXT,area,coefficient,built_area);
    CREATE TABLE excluded(row_token INTEGER PRIMARY KEY,key_token TEXT);
    CREATE TABLE construction(row_token INTEGER PRIMARY KEY,ph_key TEXT,area);
    CREATE TABLE terrain(row_token INTEGER PRIMARY KEY,code_key TEXT,fid,geometry_area);
    CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,enrichment_key TEXT,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT,custom_1,custom_2,custom_3);
    CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
    CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
    CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    """)


def _ingest(definition, source, mapping, db, cancel):
    with BatchInserter(db, "INSERT INTO gen(pk_id,pk_key,npn,npn_key,registration,destination_key,area,cancelled,physical_change,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", cancel_check=cancel) as ins:
        for r in source.iter_rows(mapping.resolve("lc_gen_predio"), GF):
            raise_if_cancelled(cancel)
            ins.add((r.get("pk_id"), _join_token(r.get("pk_id")), r.get("numero_predial_nacional"), _join_token(r.get("numero_predial_nacional")), r.get("matricula_inmobiliaria"), _join_token(r.get("destinacion_economica")), r.get("area_catastral_terreno"), r.get("juridico_predio_cancelado"), r.get("predio_tiene_cambio_fisico"), r.get("nombre_proyecto"), _join_token(r.get("juridico_estado_asignacion")), _join_token(r.get("juridico_estado_control")), _join_token(r.get("reconocimiento_estado_asignacion")), _join_token(r.get("reconocimiento_estado_control")), _join_token(r.get("informal_estado_asignacion")), _join_token(r.get("informal_estado_control")), _join_token(r.get("geografico_estado_asignacion")), _join_token(r.get("geografico_estado_control"))))
    with BatchInserter(db, "INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area,coefficient,built_area)VALUES(?,?,?,?,?,?,?,?,?)", cancel_check=cancel) as ins:
        for r in source.iter_rows(mapping.resolve("lc_ph_predio"), PF):
            raise_if_cancelled(cancel)
            ins.add((r.get("pk_id"), _join_token(r.get("pk_id")), _join_token(r.get("fk_id")), r.get("numero_predial_nacional"), r.get("matricula_inmobiliaria"), _join_token(r.get("destinacion_economica")), r.get("area_catastral_terreno"), r.get("coeficiente"), r.get("area_total_construida")))
    if definition.mode in ("coefficient", "cadastral_area", "geometric_area"):
        with BatchInserter(db, "INSERT INTO excluded(key_token)VALUES(?)", cancel_check=cancel) as ins:
            if definition.mode == "coefficient":
                for r in source.iter_rows(mapping.resolve("lc_jur_novedadnumeropredial"), ("fk_id", "tipo_novedad")):
                    raise_if_cancelled(cancel)
                    if r.get("tipo_novedad") in (5, 6, 7, 8): ins.add((_join_token(r.get("fk_id")),))
                for key, cancelled in db.execute("SELECT pk_key,cancelled FROM gen"):
                    if postgres_boolean_is_true(cancelled): ins.add((key,))
            for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"), ("fk_id", "tipo_novedad")):
                raise_if_cancelled(cancel)
                if r.get("tipo_novedad") in (5, 6, 7, 8): ins.add((_join_token(r.get("fk_id")),))
    if definition.mode == "built_area":
        with BatchInserter(db, "INSERT INTO construction(ph_key,area)VALUES(?,?)", cancel_check=cancel) as ins:
            for r in source.iter_rows(mapping.resolve("determinacion_area_construccion"), ("pk_id", "area_construida")):
                raise_if_cancelled(cancel); ins.add((_join_token(r.get("pk_id")), r.get("area_construida")))
    if definition.mode == "geometric_area":
        physical = mapping.resolve("lc_gen_terreno"); fields = set(source.describe(physical).fields); geometry_field = "geom" if "geom" in fields else "geom_area"
        with BatchInserter(db, "INSERT INTO terrain(code_key,fid,geometry_area)VALUES(?,?,?)", cancel_check=cancel) as ins:
            for r in source.iter_rows(physical, ("codigo", "fid", geometry_field)):
                raise_if_cancelled(cancel); area = _wkb_area(r.get("geom")) if geometry_field == "geom" else r.get("geom_area"); ins.add((_join_token(r.get("codigo")), r.get("fid"), area))


def _prepare(definition, db):
    prefix = "INSERT INTO selected(general_pk,ph_pk,enrichment_key,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c,custom_1,custom_2,custom_3)"
    states = "g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,g.geo_a,g.geo_c"
    if definition.mode == "coefficient":
        q = f"SELECT g.pk_id,NULL,g.pk_key,g.npn,g.project,g.registration,g.destination_key,g.area,{states},NULL,NULL,NULL FROM gen g JOIN ph p ON p.parent_key=g.pk_key WHERE NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=g.pk_key) AND NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key) GROUP BY g.row_token HAVING sum(p.coefficient)<97 OR sum(p.coefficient)>103"
    elif definition.mode == "built_area":
        q = f"SELECT g.pk_id,p.pk_id,p.pk_key,p.npn,g.project,p.registration,p.destination_key,p.area,{states},NULL,NULL,NULL FROM gen g JOIN ph p ON p.parent_key=g.pk_key LEFT JOIN construction c ON c.ph_key=p.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0) GROUP BY p.row_token HAVING g.physical_change=1 AND CASE WHEN coalesce(p.built_area,0)=0 AND sum(coalesce(c.area,0))>0 THEN 100 WHEN coalesce(p.built_area,0)=0 AND sum(coalesce(c.area,0))=0 THEN 0 WHEN coalesce(p.built_area,0)>0 AND sum(coalesce(c.area,0))=0 THEN 100 ELSE abs((sum(coalesce(c.area,0))-coalesce(p.built_area,0))/coalesce(p.built_area,0)) END < 5"
    elif definition.mode == "cadastral_area":
        q = f"SELECT g.pk_id,NULL,g.pk_key,g.npn,g.project,g.registration,g.destination_key,g.area,{states},NULL,NULL,NULL FROM gen g JOIN ph p ON p.parent_key=g.pk_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key) GROUP BY g.row_token HAVING abs(g.area-sum(p.area))>1"
    else:
        q = f"SELECT g.pk_id,NULL,g.pk_key,g.npn,g.project,g.registration,g.destination_key,g.area,{states},sum(p.area),CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END,abs(sum(p.area)-CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END) FROM gen g JOIN ph p ON p.parent_key=g.pk_key LEFT JOIN terrain t ON t.code_key=g.npn_key WHERE(g.cancelled IS NULL OR g.cancelled=0)AND NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key) GROUP BY g.row_token,t.row_token HAVING CASE WHEN sum(p.area)>0 AND(CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END IS NULL OR CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END=0)THEN 1 WHEN sum(p.area)=0 AND(CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END IS NULL OR CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END=0)THEN 0 ELSE abs(sum(p.area)-(CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END))/(CASE WHEN t.fid IS NULL THEN 0 ELSE t.geometry_area END) END > .02"
    db.execute(prefix + q)


RESULT = """SELECT s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.custom_1,s.custom_2,s.custom_3 FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.enrichment_key LEFT JOIN user_assignment ua ON ua.fk_token=s.enrichment_key LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a LEFT JOIN control_lookup ic ON ic.key_token=s.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project"""


def _numeric_text(value):
    return format(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), "f")


def execute_areas(rid, source, mapping, cancel_check=None) -> Iterator[dict[str, Any]]:
    definition = RULES[rid]; stamp = datetime.now()
    with sqlite_staging(cancel_check, prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-") as db:
        _create(db); _ingest(definition, source, mapping, db, cancel_check); _ingest_enrichment(definition, source, mapping, db, cancel_check); _prepare(definition, db); db.commit(); cur = db.execute(RESULT)
        try:
            for v in cur:
                raise_if_cancelled(cancel_check); row = _result_row(definition, stamp, v[:17])
                if rid == "PH_03": row["tabla_error_1"] = "LC_PH_Predio"; row["pk_tabla_error_1"] = v[17]; row["tabla_error_2"] = "LC_Ph_Predio"; row["pk_tabla_error_2"] = v[17]
                if rid == "PH_67": row["custom_1"] = _numeric_text(v[18]); row["custom_2"] = _numeric_text(v[19]); row["custom_3"] = Decimal(str(v[20])).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                yield row
        finally: cur.close()


def _entry(rid):
    def execute(source, mapping, cancel_check=None): return execute_areas(rid, source, mapping, cancel_check)
    execute.__name__ = f"execute_{rid.lower()}"; return execute


execute_ph_02 = _entry("PH_02")
execute_ph_03 = _entry("PH_03")
execute_ph_08 = _entry("PH_08")
execute_ph_67 = _entry("PH_67")
