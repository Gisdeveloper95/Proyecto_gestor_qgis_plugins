"""Independent portable implementation of the canonical Jur_17 rule."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    area = row.get("area_catastral_terreno")
    return area is None or area == 0


_RULE = PredioScalarRule(
    canonical_id="Jur_17",
    component="Fisico",
    description="Predios sin area catastral de terreno",
    predicate=_matches,
    custom_7=True,
)


def execute_jur_17(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield canonical Jur_17 findings."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
