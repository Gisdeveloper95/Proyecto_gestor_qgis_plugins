"""Independent portable implementation of the canonical Reco_62 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_substring


def _matches(row: Mapping[str, Any]) -> bool:
    zone = postgres_substring(row.get("numero_predial_nacional"), 6, 2)
    area = row.get("area_catastral_terreno")
    return zone is not None and zone != "01" and area is not None and area < 50


_RULE = PredioScalarRule(
    canonical_id="Reco_62",
    component="Reconocimiento",
    description="Predios rurales con area catastral de terreno menor a 50 metros",
    predicate=_matches,
    custom_7=False,
)


def execute_reco_62(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_62 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
