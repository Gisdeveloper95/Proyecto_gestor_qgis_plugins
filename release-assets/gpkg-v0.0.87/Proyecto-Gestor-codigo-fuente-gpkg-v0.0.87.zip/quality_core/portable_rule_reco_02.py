"""Independent disk-backed implementation of canonical Reco_02."""

from datetime import datetime
from types import SimpleNamespace

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import BatchInserter, postgres_boolean_is_false_or_null, raise_if_cancelled, sqlite_staging


_PREDIO_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado", "nombre_proyecto",
    "matricula_inmobiliaria", "destinacion_economica", "area_catastral_terreno",
    "juridico_estado_asignacion", "juridico_estado_control",
    "reconocimiento_estado_asignacion", "reconocimiento_estado_control",
    "informal_estado_asignacion", "informal_estado_control",
    "geografico_estado_asignacion", "geografico_estado_control",
)
_PH_FIELDS = (
    "pk_id", "fk_id", "numero_predial_nacional", "matricula_inmobiliaria",
    "destinacion_economica", "area_catastral_terreno",
)


def _create_stage(db):
    db.executescript("""
      CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,active INTEGER,
        numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key TEXT,
        area_catastral_terreno,juridico_assignment_key TEXT,juridico_control_key TEXT,
        reconocimiento_assignment_key TEXT,reconocimiento_control_key TEXT,
        informal_assignment_key TEXT,informal_control_key TEXT,
        geografico_assignment_key TEXT,geografico_control_key TEXT);
      CREATE TABLE ph_predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,matrix_key TEXT,
        numero_predial_nacional,matricula_inmobiliaria,destination_key TEXT,area_catastral_terreno);
      CREATE TABLE excluded_ph(row_token INTEGER PRIMARY KEY,ph_key TEXT);
      CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
      CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
      CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    """)


def _ingest(data_source, layer_mapping, db, cancel_check):
    with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,active,numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key,area_catastral_terreno,juridico_assignment_key,juridico_control_key,reconocimiento_assignment_key,reconocimiento_control_key,informal_assignment_key,informal_control_key,geografico_assignment_key,geografico_control_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"),_PREDIO_FIELDS):
            raise_if_cancelled(cancel_check)
            ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),int(postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado"))),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
    with BatchInserter(db,"INSERT INTO ph_predio(pk_id,pk_key,matrix_key,numero_predial_nacional,matricula_inmobiliaria,destination_key,area_catastral_terreno) VALUES (?,?,?,?,?,?,?)",cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_ph_predio"),_PH_FIELDS):
            raise_if_cancelled(cancel_check); ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
    with BatchInserter(db,"INSERT INTO excluded_ph(ph_key) VALUES (?)",cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
            raise_if_cancelled(cancel_check)
            if r.get("tipo_novedad") in (5,6,7,8): ins.add((_join_token(r.get("fk_id")),))


def execute_reco_02(data_source, layer_mapping, cancel_check=None):
    definition=SimpleNamespace(canonical_id="Reco_02",component="Juridico",description="Predios con numero predial repetido",custom_7=False)
    timestamp=datetime.now()
    with sqlite_staging(cancel_check,prefix="mapingtool-calidad-gpkg-reco_02-") as db:
        _create_stage(db); _ingest(data_source,layer_mapping,db,cancel_check); _ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
        db.executescript("""
          CREATE INDEX idx_predio_key ON predio(pk_key); CREATE INDEX idx_ph_matrix ON ph_predio(matrix_key);
          CREATE INDEX idx_excluded_ph ON excluded_ph(ph_key); CREATE INDEX idx_dest ON destination_lookup(key_token);
          CREATE INDEX idx_exception ON exception_lookup(fk_token); CREATE INDEX idx_user ON user_assignment(fk_token);
          CREATE INDEX idx_assignment ON assignment_lookup(key_token); CREATE INDEX idx_control ON control_lookup(key_token);
          CREATE TABLE candidate AS
          WITH general_duplicates AS (SELECT numero_predial_nacional FROM predio WHERE active=1 AND numero_predial_nacional IS NOT NULL GROUP BY numero_predial_nacional HAVING COUNT(*)>1),
          eligible_ph AS (SELECT ph.* FROM ph_predio ph WHERE NOT EXISTS(SELECT 1 FROM excluded_ph x WHERE x.ph_key=ph.pk_key)),
          expanded_ph AS (SELECT ph.*,m.pk_id matrix_pk,m.pk_key matrix_key_actual,m.proyecto FROM eligible_ph ph JOIN predio m ON m.pk_key=ph.matrix_key WHERE m.active=1),
          ph_duplicates AS (SELECT numero_predial_nacional FROM expanded_ph WHERE numero_predial_nacional IS NOT NULL GROUP BY numero_predial_nacional HAVING COUNT(*)>1)
          SELECT 'LC_Gen_Predio' table_name,p.pk_id matrix_pk,p.pk_key matrix_key,p.numero_predial_nacional npn_general,p.proyecto,p.matricula_inmobiliaria,p.destination_key,p.area_catastral_terreno,p.numero_predial_nacional npn_output,p.pk_id error_pk,_join_dummy
          FROM (SELECT predio.*,NULL _join_dummy FROM predio) p JOIN general_duplicates d ON d.numero_predial_nacional=p.numero_predial_nacional WHERE p.active=1
          UNION
          SELECT 'LC_PH_Predio',x.matrix_pk,x.matrix_key_actual,m.numero_predial_nacional,x.proyecto,x.matricula_inmobiliaria,x.destination_key,x.area_catastral_terreno,x.numero_predial_nacional,x.pk_id,NULL
          FROM expanded_ph x JOIN ph_duplicates d ON d.numero_predial_nacional=x.numero_predial_nacional JOIN predio m ON m.row_token=(SELECT MIN(row_token) FROM predio WHERE pk_key=x.matrix_key_actual);
        """)
        sql="""
          SELECT c.matrix_pk,c.npn_output,c.proyecto,c.matricula_inmobiliaria,d.ilicode,c.area_catastral_terreno,
            e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,c.table_name,c.error_pk
          FROM candidate c JOIN predio s ON s.pk_key=c.matrix_key
          LEFT JOIN destination_lookup d ON d.key_token=c.destination_key
          LEFT JOIN exception_lookup e ON e.fk_token=CASE WHEN c.error_pk IS NULL THEN NULL ELSE printf('%s',json_quote(c.error_pk)) END
          LEFT JOIN user_assignment ua ON ua.fk_token=CASE WHEN c.error_pk IS NULL THEN NULL ELSE printf('%s',json_quote(c.error_pk)) END
          LEFT JOIN assignment_lookup ja ON ja.key_token=s.juridico_assignment_key LEFT JOIN control_lookup jc ON jc.key_token=s.juridico_control_key
          LEFT JOIN assignment_lookup ra ON ra.key_token=s.reconocimiento_assignment_key LEFT JOIN control_lookup rc ON rc.key_token=s.reconocimiento_control_key
          LEFT JOIN assignment_lookup ia ON ia.key_token=s.informal_assignment_key LEFT JOIN control_lookup ic ON ic.key_token=s.informal_control_key
          LEFT JOIN assignment_lookup ga ON ga.key_token=s.geografico_assignment_key LEFT JOIN control_lookup gc ON gc.key_token=s.geografico_control_key
          ORDER BY c.npn_output IS NULL,c.npn_output,c.table_name,c.proyecto IS NULL,c.proyecto
        """
        # SQLite json_quote is not the typed-token format; bind the exact error key in a staged column.
        db.execute("ALTER TABLE candidate ADD COLUMN error_key TEXT")
        for rowid,error_pk in db.execute("SELECT rowid,error_pk FROM candidate"):
            db.execute("UPDATE candidate SET error_key=? WHERE rowid=?",(_join_token(error_pk),rowid))
        sql=sql.replace("CASE WHEN c.error_pk IS NULL THEN NULL ELSE printf('%s',json_quote(c.error_pk)) END","c.error_key")
        db.commit(); cur=db.execute(sql)
        try:
            for values in cur:
                raise_if_cancelled(cancel_check); base=_result_row(definition,timestamp,values[:17]); base["tabla_error_1"]=values[17]; base["pk_tabla_error_1"]=values[18]; yield base
        finally: cur.close()
