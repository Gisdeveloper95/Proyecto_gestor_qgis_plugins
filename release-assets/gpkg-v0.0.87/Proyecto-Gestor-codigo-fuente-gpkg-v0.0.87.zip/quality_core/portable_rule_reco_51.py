"""Independent portable implementation of the canonical Reco_51 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    return (
        row.get("destinacion_economica_anterior") == "6-Comercial"
        and row.get("destinacion_economica") == 10
    )


_RULE = PredioScalarRule(
    canonical_id="Reco_51",
    component="Calificacion",
    description=(
        "Predios con destino economico anterior igual a comercial y ahora "
        "destino economico habitacional"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=("destinacion_economica_anterior",),
)


def execute_reco_51(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_51 findings before the operational post-filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
