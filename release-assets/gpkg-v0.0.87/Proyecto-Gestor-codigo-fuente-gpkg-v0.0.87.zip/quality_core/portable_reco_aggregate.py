"""Disk-backed portable implementations for aggregate RECO rules.

The canonical PostgreSQL queries for Reco_19, Reco_22 and Reco_24 depend on
GROUP BY/window expressions and on catalogue joins.  This module stages only
the required attributes in a temporary SQLite database, preserving SQL NULL
and join multiplicity without loading the complete result set in memory.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Iterator

from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    postgres_boolean_is_true,
    raise_if_cancelled,
    sqlite_staging,
    typed_union_token,
)


_PREDIO_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado",
    "nombre_proyecto", "matricula_inmobiliaria", "destinacion_economica",
    "area_catastral_terreno", "area_total_construida",
    "predio_tiene_cambio_fisico", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control", "informal_estado_asignacion",
    "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
_CONSTRUCTION_FIELDS = (
    "pk_id", "pk_carac", "identificador", "total_plantas",
    "tipo_unidad_construccion", "uso_construccion", "area_construida",
    "puntaje",
)


def _token(value: Any) -> str | None:
    return None if value is None else typed_union_token((value,))


def _create_stage(db) -> None:
    db.executescript(
        """
        CREATE TABLE predio (
            row_token INTEGER PRIMARY KEY, pk_id, pk_key TEXT, active INTEGER,
            numero_predial_nacional, proyecto, matricula_inmobiliaria,
            destination_key TEXT, area_catastral_terreno,
            area_total_construida, predio_tiene_cambio_fisico INTEGER,
            juridico_assignment_key TEXT, juridico_control_key TEXT,
            reconocimiento_assignment_key TEXT,
            reconocimiento_control_key TEXT, informal_assignment_key TEXT,
            informal_control_key TEXT, geografico_assignment_key TEXT,
            geografico_control_key TEXT
        );
        CREATE TABLE construction (
            row_token INTEGER PRIMARY KEY, predio_key TEXT, pk_carac,
            identificador, total_plantas, type_key TEXT, use_key TEXT,
            area_construida, puntaje
        );
        CREATE TABLE characteristic (
            row_token INTEGER PRIMARY KEY, predio_key TEXT, pk_id,
            identificador
        );
        CREATE TABLE destination_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE unit_type_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE use_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE exception_lookup (
            row_token INTEGER PRIMARY KEY, fk_token TEXT, fid,
            descripcion_excepcion
        );
        CREATE TABLE user_assignment (
            row_token INTEGER PRIMARY KEY, fk_token TEXT, pk_id
        );
        CREATE TABLE assignment_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        CREATE TABLE control_lookup (
            row_token INTEGER PRIMARY KEY, key_token TEXT, ilicode
        );
        """
    )


def _ingest_predios(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("lc_gen_predio")
    sql = (
        "INSERT INTO predio(pk_id,pk_key,active,numero_predial_nacional,"
        "proyecto,matricula_inmobiliaria,destination_key,"
        "area_catastral_terreno,area_total_construida,"
        "predio_tiene_cambio_fisico,juridico_assignment_key,"
        "juridico_control_key,reconocimiento_assignment_key,"
        "reconocimiento_control_key,informal_assignment_key,"
        "informal_control_key,geografico_assignment_key,"
        "geografico_control_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    )
    with BatchInserter(db, sql, cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical_name, _PREDIO_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                row.get("pk_id"), _token(row.get("pk_id")),
                int(postgres_boolean_is_false_or_null(
                    row.get("juridico_predio_cancelado")
                )),
                row.get("numero_predial_nacional"), row.get("nombre_proyecto"),
                row.get("matricula_inmobiliaria"),
                _token(row.get("destinacion_economica")),
                row.get("area_catastral_terreno"),
                row.get("area_total_construida"),
                int(postgres_boolean_is_true(
                    row.get("predio_tiene_cambio_fisico")
                )),
                _token(row.get("juridico_estado_asignacion")),
                _token(row.get("juridico_estado_control")),
                _token(row.get("reconocimiento_estado_asignacion")),
                _token(row.get("reconocimiento_estado_control")),
                _token(row.get("informal_estado_asignacion")),
                _token(row.get("informal_estado_control")),
                _token(row.get("geografico_estado_asignacion")),
                _token(row.get("geografico_estado_control")),
            ))


def _ingest_constructions(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve("determinacion_area_construccion")
    sql = (
        "INSERT INTO construction(predio_key,pk_carac,identificador,"
        "total_plantas,type_key,use_key,area_construida,puntaje) "
        "VALUES (?,?,?,?,?,?,?,?)"
    )
    with BatchInserter(db, sql, cancel_check=cancel_check) as inserter:
        for row in data_source.iter_rows(physical_name, _CONSTRUCTION_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((
                _token(row.get("pk_id")), row.get("pk_carac"),
                row.get("identificador"), row.get("total_plantas"),
                _token(row.get("tipo_unidad_construccion")),
                _token(row.get("uso_construccion")),
                row.get("area_construida"), row.get("puntaje"),
            ))


def _ingest_characteristics(data_source, layer_mapping, db, cancel_check) -> None:
    physical_name = layer_mapping.resolve(
        "lc_reco_caracteristicasunidadconstruccion"
    )
    with BatchInserter(
        db,
        "INSERT INTO characteristic(predio_key,pk_id,identificador) "
        "VALUES (?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(
            physical_name, ("fk_id", "pk_id", "identificador")
        ):
            raise_if_cancelled(cancel_check)
            inserter.add((
                _token(row.get("fk_id")), row.get("pk_id"),
                row.get("identificador"),
            ))


def _simple_lookup(
    data_source, layer_mapping, db, cancel_check, logical_name, table_name
) -> None:
    physical_name = layer_mapping.resolve(logical_name)
    with BatchInserter(
        db,
        f"INSERT INTO {table_name}(key_token,ilicode) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("itfcode", "ilicode")):
            raise_if_cancelled(cancel_check)
            inserter.add((_token(row.get("itfcode")), row.get("ilicode")))


def _ingest_enrichment(
    rule_id, data_source, layer_mapping, db, cancel_check
) -> None:
    for logical_name, table_name in (
        ("lc_gen_destinacioneconomica_tipo", "destination_lookup"),
        ("lc_reco_unidadconstruccion_tipo", "unit_type_lookup"),
        ("lc_gen_usouconstruccion_tipo", "use_lookup"),
        ("lc_gen_asignacion_tipo", "assignment_lookup"),
        ("lc_gen_estadocontrol_tipo", "control_lookup"),
    ):
        _simple_lookup(
            data_source, layer_mapping, db, cancel_check,
            logical_name, table_name,
        )

    physical_name = layer_mapping.resolve("lc_gen_excepciones")
    with BatchInserter(
        db,
        "INSERT INTO exception_lookup(fk_token,fid,descripcion_excepcion) "
        "VALUES (?,?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(
            physical_name, ("fid", "fk_id", "id_regla", "descripcion_excepcion")
        ):
            raise_if_cancelled(cancel_check)
            if row.get("id_regla") == rule_id:
                inserter.add((
                    _token(row.get("fk_id")), row.get("fid"),
                    row.get("descripcion_excepcion"),
                ))

    physical_name = layer_mapping.resolve("lc_gen_predio_usuarioasignacion")
    with BatchInserter(
        db,
        "INSERT INTO user_assignment(fk_token,pk_id) VALUES (?,?)",
        cancel_check=cancel_check,
    ) as inserter:
        for row in data_source.iter_rows(physical_name, ("pk_id", "fk_id")):
            raise_if_cancelled(cancel_check)
            inserter.add((_token(row.get("fk_id")), row.get("pk_id")))


def _prepare_indexes(db) -> None:
    db.executescript(
        """
        CREATE INDEX idx_predio_key ON predio(pk_key);
        CREATE INDEX idx_construction_key ON construction(predio_key);
        CREATE INDEX idx_characteristic_key ON characteristic(predio_key);
        CREATE INDEX idx_destination_key ON destination_lookup(key_token);
        CREATE INDEX idx_unit_type_key ON unit_type_lookup(key_token);
        CREATE INDEX idx_use_key ON use_lookup(key_token);
        CREATE INDEX idx_exception_key ON exception_lookup(fk_token);
        CREATE INDEX idx_user_assignment_key ON user_assignment(fk_token);
        CREATE INDEX idx_assignment_key ON assignment_lookup(key_token);
        CREATE INDEX idx_control_key ON control_lookup(key_token);
        """
    )


_ENRICHMENT_JOINS_SELECTED = """
    LEFT JOIN destination_lookup d ON d.key_token = p.destination_key
    LEFT JOIN exception_lookup e ON e.fk_token = p.pk_key
    LEFT JOIN user_assignment ua ON ua.fk_token = p.pk_key
    LEFT JOIN assignment_lookup jur_asig
        ON jur_asig.key_token = {states}.juridico_assignment_key
    LEFT JOIN control_lookup jur_ctrl
        ON jur_ctrl.key_token = {states}.juridico_control_key
    LEFT JOIN assignment_lookup reco_asig
        ON reco_asig.key_token = {states}.reconocimiento_assignment_key
    LEFT JOIN control_lookup reco_ctrl
        ON reco_ctrl.key_token = {states}.reconocimiento_control_key
    LEFT JOIN assignment_lookup info_asig
        ON info_asig.key_token = {states}.informal_assignment_key
    LEFT JOIN control_lookup info_ctrl
        ON info_ctrl.key_token = {states}.informal_control_key
    LEFT JOIN assignment_lookup geo_asig
        ON geo_asig.key_token = {states}.geografico_assignment_key
    LEFT JOIN control_lookup geo_ctrl
        ON geo_ctrl.key_token = {states}.geografico_control_key
"""


_COMMON_COLUMNS = """
    p.pk_id,p.numero_predial_nacional,p.proyecto,p.matricula_inmobiliaria,
    d.ilicode,p.area_catastral_terreno,
    e.fid,e.descripcion_excepcion,jur_asig.ilicode,jur_ctrl.ilicode,
    reco_asig.ilicode,reco_ctrl.ilicode,info_asig.ilicode,info_ctrl.ilicode,
    geo_asig.ilicode,geo_ctrl.ilicode,ua.pk_id
"""


def _predio_result_row(
    rule_id: str, description: str, execution_timestamp: datetime, values
) -> dict[str, Any]:
    (
        pk_id, npn, project, registration, destination, terrain_area,
        exception_fid, exception_description, jur_assignment, jur_control,
        reco_assignment, reco_control, info_assignment, info_control,
        geo_assignment, geo_control, assignment_pk,
    ) = values
    return {
        "id_regla": rule_id,
        "componente": "Calificacion" if rule_id == "Reco_22" else "Reconocimiento",
        "descripcion_regla": description,
        "proyecto": project, "pk_id_predio": pk_id,
        "tabla_error_1": "LC_Gen_Predio", "pk_tabla_error_1": pk_id,
        "tabla_error_2": None, "pk_tabla_error_2": None,
        "numero_predial_nacional": npn, "matricula_inmobiliaria": registration,
        "destino_economico": destination,
        "area_catastral_terreno": terrain_area,
        "identificador_caracteristica_unidad_construccion": None,
        "total_plantas": None, "tipo_unidad_construccion": None,
        "uso_construccion": None, "area_construida": None,
        "puntaje_calificacion": None, "tipo_novedad": None,
        "numero_predial_nacional_novedad": None,
        "tiene_excepcion": exception_fid is not None,
        "descripcion_excepcion": exception_description,
        "juridico_estado_asignacion": jur_assignment,
        "juridico_estado_control": jur_control,
        "reconocimiento_estado_asignacion": reco_assignment,
        "reconocimiento_estado_control": reco_control,
        "informal_estado_asignacion": info_assignment,
        "informal_estado_control": info_control,
        "geografico_estado_asignacion": geo_assignment,
        "geografico_estado_control": geo_control,
        "pk_lc_gen_predio_usuarioasignacion": assignment_pk,
        "usuario_creacion": "admin", "fecha_creacion": execution_timestamp,
        "usuario_modificacion": "admin", "fecha_modificacion": execution_timestamp,
        "custom_1": None, "custom_2": None, "custom_3": None,
        "custom_4": None, "custom_5": None, "custom_6": None,
        "custom_7": False, "custom_8": None, "custom_9": None,
        "custom_10": None, "custom_11": None, "custom_12": None,
    }


def _construction_result_row(execution_timestamp: datetime, values) -> dict[str, Any]:
    common = values[:17]
    pk_carac, identifier, floors, unit_type, use, area, score = values[17:]
    row = _predio_result_row(
        "Reco_24",
        "Caracteristica Unidad de Construccion con el Identificador repetido en un mismo predio",
        execution_timestamp,
        common,
    )
    row.update({
        "componente": "Calificacion",
        "tabla_error_1": "LC_Reco_Caracteristicasunidadconstruccion",
        "pk_tabla_error_1": pk_carac,
        "identificador_caracteristica_unidad_construccion": identifier,
        "total_plantas": floors, "tipo_unidad_construccion": unit_type,
        "uso_construccion": use, "area_construida": area,
        "puntaje_calificacion": score,
    })
    return row


def _execute(
    rule_id: str, description: str, data_source, layer_mapping,
    cancel_check=None,
) -> Iterator[dict[str, Any]]:
    execution_timestamp = datetime.now()
    with sqlite_staging(
        cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-"
    ) as db:
        _create_stage(db)
        _ingest_predios(data_source, layer_mapping, db, cancel_check)
        _ingest_constructions(data_source, layer_mapping, db, cancel_check)
        _ingest_characteristics(data_source, layer_mapping, db, cancel_check)
        _ingest_enrichment(
            rule_id, data_source, layer_mapping, db, cancel_check
        )
        _prepare_indexes(db)
        db.commit()
        raise_if_cancelled(cancel_check)

        if rule_id == "Reco_19":
            selected = """
                WITH areas AS (
                    SELECT p.row_token,
                           COALESCE(p.area_total_construida,0) initial_area,
                           SUM(COALESCE(c.area_construida,0)) final_area
                    FROM predio p
                    LEFT JOIN construction c ON c.predio_key = p.pk_key
                    WHERE p.active = 1
                    GROUP BY p.row_token,COALESCE(p.area_total_construida,0)
                ), variation AS (
                    SELECT row_token,
                        CASE
                          WHEN initial_area=0 AND final_area>0 THEN 100
                          WHEN initial_area=0 AND final_area=0 THEN 0
                          WHEN initial_area>0 AND final_area=0 THEN 100
                          ELSE ABS((final_area-initial_area)*1.0/initial_area)
                        END ratio
                    FROM areas
                )
                SELECT p.row_token predio_row_token
                FROM predio p JOIN variation v ON v.row_token=p.row_token
                WHERE p.predio_tiene_cambio_fisico=1 AND v.ratio<5
            """
            states = "final_predio"
            extra_join = (
                "JOIN predio final_predio ON final_predio.pk_key=p.pk_key "
            )
        elif rule_id == "Reco_22":
            selected = """
                WITH ranked AS (
                    SELECT p.row_token predio_row_token,c.identificador,
                           ROW_NUMBER() OVER (
                             PARTITION BY p.numero_predial_nacional
                             ORDER BY c.identificador IS NULL,c.identificador
                           ) sequence_number
                    FROM predio p
                    JOIN characteristic c ON c.predio_key=p.pk_key
                    WHERE p.active=1
                )
                SELECT predio_row_token FROM ranked
                WHERE NOT (
                  COALESCE((LENGTH(TRIM(identificador))=1
                   AND UNICODE(SUBSTR(identificador,1,1))-64=sequence_number)
                  ,0)
                  OR
                  COALESCE((LENGTH(TRIM(identificador))=2
                   AND (UNICODE(SUBSTR(identificador,1,1))-64)*26
                       +UNICODE(SUBSTR(identificador,2,1))-64=sequence_number)
                  ,0)
                )
            """
            states = "p"
            # The canonical lgp_final join is unused but still multiplies rows.
            extra_join = "JOIN predio final_predio ON final_predio.pk_key=p.pk_key "
        else:
            selected = """
                WITH duplicates AS (
                    SELECT predio_key,identificador
                    FROM characteristic
                    GROUP BY predio_key,identificador HAVING COUNT(*)>1
                )
                SELECT p.row_token predio_row_token,c.row_token construction_row_token
                FROM predio p
                JOIN duplicates d ON d.predio_key=p.pk_key
                JOIN construction c ON c.predio_key=p.pk_key
                                   AND c.identificador=d.identificador
                WHERE p.active=1
            """
            states = "final_predio"
            extra_join = "JOIN predio final_predio ON final_predio.pk_key=p.pk_key "

        db.execute("CREATE TEMP TABLE chosen AS " + selected)
        if rule_id == "Reco_24":
            sql = f"""
                SELECT {_COMMON_COLUMNS},c.pk_carac,c.identificador,c.total_plantas,
                       ut.ilicode,uu.ilicode,c.area_construida,c.puntaje
                FROM chosen s JOIN predio p ON p.row_token=s.predio_row_token
                JOIN construction c ON c.row_token=s.construction_row_token
                {extra_join}
                LEFT JOIN unit_type_lookup ut ON ut.key_token=c.type_key
                LEFT JOIN use_lookup uu ON uu.key_token=c.use_key
                {_ENRICHMENT_JOINS_SELECTED.format(states=states)}
                ORDER BY p.numero_predial_nacional IS NULL,p.numero_predial_nacional,
                         p.proyecto IS NULL,p.proyecto,c.identificador IS NULL,
                         c.identificador,p.row_token,c.row_token,final_predio.row_token,
                         d.row_token,ut.row_token,uu.row_token,e.row_token,ua.row_token
            """
        else:
            sql = f"""
                SELECT {_COMMON_COLUMNS}
                FROM chosen s JOIN predio p ON p.row_token=s.predio_row_token
                {extra_join}
                {_ENRICHMENT_JOINS_SELECTED.format(states=states)}
                ORDER BY p.numero_predial_nacional IS NULL,p.numero_predial_nacional,
                         p.proyecto IS NULL,p.proyecto,p.row_token,
                         final_predio.row_token,d.row_token,e.row_token,ua.row_token
            """
        cursor = db.execute(sql)
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                if rule_id == "Reco_24":
                    yield _construction_result_row(execution_timestamp, values)
                else:
                    yield _predio_result_row(
                        rule_id, description, execution_timestamp, values
                    )
        finally:
            cursor.close()


def execute_reco_19(data_source, layer_mapping, cancel_check=None):
    return _execute(
        "Reco_19",
        "Predios con cambio fisico y diferencia menor al 5% entre el area construida alfanumerica y geografica",
        data_source, layer_mapping, cancel_check,
    )


def execute_reco_22(data_source, layer_mapping, cancel_check=None):
    return _execute(
        "Reco_22",
        "Predios sin secuencia en el Identificador (A, C, D y no tiene B) asignado en las Caracteristicas Unidad Construccion",
        data_source, layer_mapping, cancel_check,
    )


def execute_reco_24(data_source, layer_mapping, cancel_check=None):
    return _execute(
        "Reco_24",
        "Caracteristica Unidad de Construccion con el Identificador repetido en un mismo predio",
        data_source, layer_mapping, cancel_check,
    )
