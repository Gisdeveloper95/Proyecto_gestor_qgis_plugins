"""Portable non-geometric homogeneous-zone rules SIG_13..SIG_15."""
from datetime import datetime
from types import SimpleNamespace
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,postgres_boolean_is_false_or_null,raise_if_cancelled,sqlite_staging
RULES={"SIG_13":("Predios sin cubrimiento de zonas homogeneas","missing_regular"),"SIG_14":("Predios PH Matriz sin cubrimiento de zonas homogeneas","missing_ph"),"SIG_15":("Interseccion de zonas homogeneas con un area menor a 10 metros","small")}
PF=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control")
def execute(rule_id,source,mapping,cancel=None):
 desc,mode=RULES[rule_id];definition=SimpleNamespace(canonical_id=rule_id,component="Digitalizacion",description=desc,custom_7=False);stamp=datetime.now()
 with sqlite_staging(cancel,prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-")as db:
  db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE zone(row_token INTEGER PRIMARY KEY,fid,pk_id,predio_key TEXT,intersection_area);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,predio_row INTEGER,zone_pk);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
  with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,project,registration,destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_predio"),PF):
    raise_if_cancelled(cancel)
    if postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado")):ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
  with BatchInserter(db,"INSERT INTO zone(fid,pk_id,predio_key,intersection_area)VALUES(?,?,?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_terreno_zonas"),("fid","pk_id","pk_gen_predio","area_interseccion")):raise_if_cancelled(cancel);ins.add((r.get("fid"),r.get("pk_id"),_join_token(r.get("pk_gen_predio")),r.get("area_interseccion")))
  _ingest_enrichment(definition,source,mapping,db,cancel)
  special="('700000000','800000000','900000000')"
  if mode=="small":q="SELECT p.row_token,z.pk_id FROM predio p JOIN zone z ON z.predio_key=p.pk_key WHERE z.intersection_area<=10"
  else:q=f"SELECT p.row_token,NULL FROM predio p LEFT JOIN zone z ON z.predio_key=p.pk_key WHERE substr(p.npn,22,9) {'IN'if mode=='missing_ph'else'NOT IN'} {special} AND z.fid IS NULL"
  db.execute("INSERT INTO selected(predio_row,zone_pk) "+q);db.commit();cur=db.execute("""SELECT p.pk_id,p.npn,p.project,p.registration,d.ilicode,p.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.zone_pk FROM selected s JOIN predio p ON p.row_token=s.predio_row LEFT JOIN destination_lookup d ON d.key_token=p.destination_key LEFT JOIN exception_lookup e ON e.fk_token=p.pk_key LEFT JOIN user_assignment ua ON ua.fk_token=p.pk_key LEFT JOIN assignment_lookup ja ON ja.key_token=p.jur_a LEFT JOIN control_lookup jc ON jc.key_token=p.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=p.reco_a LEFT JOIN control_lookup rc ON rc.key_token=p.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=p.info_a LEFT JOIN control_lookup ic ON ic.key_token=p.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=p.geo_a LEFT JOIN control_lookup gc ON gc.key_token=p.geo_c ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project""")
  try:
   for v in cur:
    raise_if_cancelled(cancel);row=_result_row(definition,stamp,v[:17])
    if mode=="small":row.update({"tabla_error_1":"LC_Gen_Terreno_Zonas","pk_tabla_error_1":v[17]})
    yield row
  finally:cur.close()
def execute_sig_13(s,m,cancel_check=None):return execute("SIG_13",s,m,cancel_check)
def execute_sig_14(s,m,cancel_check=None):return execute("SIG_14",s,m,cancel_check)
def execute_sig_15(s,m,cancel_check=None):return execute("SIG_15",s,m,cancel_check)
