"""Independent portable implementation of the canonical Reco_05 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar


def _matches(row: Mapping[str, Any]) -> bool:
    destination = row.get("destinacion_economica")
    return destination is None or destination > 30


_RULE = PredioScalarRule(
    canonical_id="Reco_05",
    component="Calificacion",
    description="Predios sin Destino Economico",
    predicate=_matches,
    custom_7=True,
)


def execute_reco_05(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_05 findings before the operational filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
