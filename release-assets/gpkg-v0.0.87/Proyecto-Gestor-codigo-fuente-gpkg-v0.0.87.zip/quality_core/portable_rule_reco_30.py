"""Independent portable implementation of canonical Reco_30."""
from .portable_construction_scalar import ConstructionScalarRule, execute_construction_scalar

_USES = "0,6,10,12,14,17,19,24,27,30,33,38,40,42,44,57,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103"
_RULE = ConstructionScalarRule(
    "Reco_30", "Calificacion",
    "Caracteristica Unidad de Construccion con uso de construccion distinto a los anexos y a usos diferentes de los correspondientes a PH para predios en condicion de Condominio",
    f"substr(p.numero_predial_nacional,22,1) = '8' AND c.uso_construccion NOT IN ({_USES})",
    True, duplicate_predio_join=True,
)

def execute_reco_30(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
