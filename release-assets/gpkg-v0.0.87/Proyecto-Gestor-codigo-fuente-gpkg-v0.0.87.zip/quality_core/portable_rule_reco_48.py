"""Independent portable implementation of the canonical Reco_48 SQL."""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from .portable_predio_scalar import PredioScalarRule, execute_predio_scalar
from .portable_primitives import postgres_boolean_is_false_or_null


_FIELDS = (
    "reconocimiento_predio_completo",
    "predio_tiene_cambio_fisico",
    "reconocimiento_predio_para_visita",
    "juridico_predio_para_visita",
)


def _matches(row: Mapping[str, Any]) -> bool:
    return all(postgres_boolean_is_false_or_null(row.get(field)) for field in _FIELDS)


_RULE = PredioScalarRule(
    canonical_id="Reco_48",
    component="Reconocimiento",
    description=(
        "Predios sin marca de predio completo, sin marca de cambio físico y "
        "sin marca de visita"
    ),
    predicate=_matches,
    custom_7=False,
    filter_fields=_FIELDS,
)


def execute_reco_48(data_source, layer_mapping, cancel_check=None) -> Iterator[dict]:
    """Yield raw canonical Reco_48 findings before the operational filter."""

    return execute_predio_scalar(_RULE, data_source, layer_mapping, cancel_check)
