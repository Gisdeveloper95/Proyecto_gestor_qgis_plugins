"""Portable PH construction classification rules."""
from dataclasses import dataclass
from datetime import datetime
from typing import Any,Iterator
from .portable_predio_scalar import _ingest_enrichment,_join_token,_result_row
from .portable_primitives import BatchInserter,raise_if_cancelled,sqlite_staging
@dataclass(frozen=True)
class Rule:
 canonical_id:str;description:str;mode:str;destination:int|None=None;expected_type:int|None=None;ph_result_id:bool=False;component:str="PH";custom_7:bool=False
RULES={
"PH_15":Rule("PH_15","Predios PH con destino economico Habitacional con la Caracteristica Unidad de Construccion de mayor área diferente a un uso de construcción de tipo residencial","dominant",10,0,True),
"PH_16":Rule("PH_16","Predios PH con destino economico Comercial con la Caracteristica Unidad de Construccion de mayor área diferente a un uso de construcción de tipo comercial","dominant",6,1),
"PH_17":Rule("PH_17","Predios PH con destino economico Industrial con la Caracteristica Unidad de Construccion de mayor área diferente a un uso de construcción de tipo industrial","dominant",11,2),
"PH_19":Rule("PH_19","Predios PH con destino economico Lote y con Caracteristica Unidad de Construccion","lot"),
"PH_30":Rule("PH_30","Caracteristica Unidad de Construccion PH con el tipo de unidad de construccion diferente al uso de construccion asignado","range"),
}
GF=("pk_id","nombre_proyecto","juridico_estado_asignacion","juridico_estado_control","reconocimiento_estado_asignacion","reconocimiento_estado_control","informal_estado_asignacion","informal_estado_control","geografico_estado_asignacion","geografico_estado_control");PF=("pk_id","fk_id","numero_predial_nacional","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno");CF=("nombre_proyecto","pk_id","numero_predial_nacional","pk_carac","identificador","tipo_unidad_construccion","uso_construccion","area_construida","total_plantas","puntaje")
def _create(db):db.executescript("""CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,project,jur_a TEXT,jur_c TEXT,reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT);CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,npn,registration,destination,destination_key TEXT,area);CREATE TABLE excluded(row_token INTEGER PRIMARY KEY,key_token TEXT);CREATE TABLE construction(row_token INTEGER PRIMARY KEY,ph_key TEXT,characteristic_pk,identifier,unit_type,unit_type_key TEXT,usage,usage_key TEXT,built_area,total_floors,score);CREATE TABLE unit_type_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE usage_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,ph_pk,ph_key TEXT,characteristic_pk,npn,project,registration,destination_key TEXT,area,identifier,total_floors,unit_type_key TEXT,usage_key TEXT,built_area,score,type_from_usage);CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);""")
def _ingest(source,mapping,db,cancel):
 with BatchInserter(db,"INSERT INTO gen(pk_id,pk_key,project,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c)VALUES(?,?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_gen_predio"),GF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("nombre_proyecto"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
 with BatchInserter(db,"INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination,destination_key,area)VALUES(?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_predio"),PF):raise_if_cancelled(cancel);ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id")),r.get("numero_predial_nacional"),r.get("matricula_inmobiliaria"),r.get("destinacion_economica"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
 with BatchInserter(db,"INSERT INTO excluded(key_token)VALUES(?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("lc_ph_novedadnumeropredial"),("fk_id","tipo_novedad")):
   raise_if_cancelled(cancel)
   if r.get("tipo_novedad")in(5,6,7,8):ins.add((_join_token(r.get("fk_id")),))
 with BatchInserter(db,"INSERT INTO construction(ph_key,characteristic_pk,identifier,unit_type,unit_type_key,usage,usage_key,built_area,total_floors,score)VALUES(?,?,?,?,?,?,?,?,?,?)",cancel_check=cancel)as ins:
  for r in source.iter_rows(mapping.resolve("determinacion_area_construccion"),CF):raise_if_cancelled(cancel);ins.add((_join_token(r.get("pk_id")),r.get("pk_carac"),r.get("identificador"),r.get("tipo_unidad_construccion"),_join_token(r.get("tipo_unidad_construccion")),r.get("uso_construccion"),_join_token(r.get("uso_construccion")),r.get("area_construida"),r.get("total_plantas"),r.get("puntaje")))
 for logical,table in(("lc_reco_unidadconstruccion_tipo","unit_type_lookup"),("lc_gen_usouconstruccion_tipo","usage_lookup")):
  with BatchInserter(db,f"INSERT INTO {table}(key_token,ilicode)VALUES(?,?)",cancel_check=cancel)as ins:
   for r in source.iter_rows(mapping.resolve(logical),("itfcode","ilicode")):raise_if_cancelled(cancel);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
def _prepare(definition,db):
 common="""SELECT g.pk_id,p.pk_id,p.pk_key,c.characteristic_pk,p.npn,g.project,p.registration,p.destination_key,p.area,c.identifier,c.total_floors,c.unit_type_key,c.usage_key,c.built_area,c.score,{type_from_usage} FROM ph p JOIN gen g ON p.parent_key=g.pk_key JOIN construction c ON c.ph_key=p.pk_key {extra} WHERE NOT EXISTS(SELECT 1 FROM excluded x WHERE x.key_token=p.pk_key) AND {predicate}"""
 if definition.mode=="dominant":
  extra="JOIN unit_type_lookup required_type ON required_type.key_token=c.unit_type_key";predicate=f"p.destination={definition.destination} AND c.unit_type IS NOT NULL AND c.unit_type<>4 AND c.unit_type<>{definition.expected_type} AND c.built_area=(SELECT max(group_area) FROM(SELECT sum(c2.built_area)group_area FROM construction c2 WHERE c2.ph_key=c.ph_key AND c2.unit_type IS NOT NULL AND c2.unit_type<>4 GROUP BY c2.unit_type))";q=common.format(type_from_usage="0",extra=extra,predicate=predicate)
 elif definition.mode=="lot":q=common.format(type_from_usage="1",extra="",predicate="p.destination IN(20,21,22,23) AND c.characteristic_pk IS NOT NULL")
 else:
  pred="(c.unit_type=0 AND c.usage>14)OR(c.unit_type=1 AND(c.usage<15 OR c.usage>40))OR(c.unit_type=2 AND(c.usage<41 OR c.usage>45))OR(c.unit_type=3 AND(c.usage<46 OR c.usage>68))OR(c.unit_type=4 AND c.usage<69)";q=common.format(type_from_usage="0",extra="",predicate="("+pred+")")
 prefix="INSERT INTO selected(general_pk,ph_pk,ph_key,characteristic_pk,npn,project,registration,destination_key,area,identifier,total_floors,unit_type_key,usage_key,built_area,score,type_from_usage)"
 db.execute(prefix+q)
RESULT="""SELECT {distinct}s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.ph_pk,s.characteristic_pk,s.identifier,s.total_floors,CASE WHEN s.type_from_usage=1 THEN u.ilicode ELSE t.ilicode END,u.ilicode,s.built_area,s.score FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key LEFT JOIN exception_lookup e ON e.fk_token=s.ph_key LEFT JOIN user_assignment ua ON ua.fk_token=s.ph_key LEFT JOIN unit_type_lookup t ON t.key_token=s.unit_type_key LEFT JOIN usage_lookup u ON u.key_token=s.usage_key JOIN gen g ON g.pk_id=s.general_pk LEFT JOIN assignment_lookup ja ON ja.key_token=g.jur_a LEFT JOIN control_lookup jc ON jc.key_token=g.jur_c LEFT JOIN assignment_lookup ra ON ra.key_token=g.reco_a LEFT JOIN control_lookup rc ON rc.key_token=g.reco_c LEFT JOIN assignment_lookup ia ON ia.key_token=g.info_a LEFT JOIN control_lookup ic ON ic.key_token=g.info_c LEFT JOIN assignment_lookup ga ON ga.key_token=g.geo_a LEFT JOIN control_lookup gc ON gc.key_token=g.geo_c ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project,s.identifier IS NULL,s.identifier"""
def execute_classification(rid,source,mapping,cancel_check=None)->Iterator[dict[str,Any]]:
 definition=RULES[rid];stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rid.lower()}-")as db:
  _create(db);_ingest(source,mapping,db,cancel_check);_ingest_enrichment(definition,source,mapping,db,cancel_check);_prepare(definition,db);db.commit();cur=db.execute(RESULT.format(distinct="DISTINCT "if definition.mode=="range"else""))
  try:
   for v in cur:
    raise_if_cancelled(cancel_check);row=_result_row(definition,stamp,v[:17]);row["pk_id_predio"]=v[17]if definition.ph_result_id else v[0];row["tabla_error_1"]="LC_PH_Predio";row["pk_tabla_error_1"]=v[17];row["tabla_error_2"]="LC_PH_Caracteristicasunidadconstruccion";row["pk_tabla_error_2"]=v[18];row["identificador_caracteristica_unidad_construccion"]=v[19];row["total_plantas"]=v[20];row["tipo_unidad_construccion"]=v[21];row["uso_construccion"]=v[22];row["area_construida"]=v[23];row["puntaje_calificacion"]=v[24];yield row
  finally:cur.close()
def _entry(rid):
 def execute(source,mapping,cancel_check=None):return execute_classification(rid,source,mapping,cancel_check)
 execute.__name__=f"execute_{rid.lower()}";return execute
execute_ph_15=_entry("PH_15");execute_ph_16=_entry("PH_16");execute_ph_17=_entry("PH_17");execute_ph_19=_entry("PH_19");execute_ph_30=_entry("PH_30")
