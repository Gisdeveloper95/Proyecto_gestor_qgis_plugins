"""Independent portable implementation of canonical Reco_27."""
from .portable_construction_scalar import ConstructionScalarRule, _join_token, execute_construction_scalar


_RULE = ConstructionScalarRule(
    "Reco_27",
    "Calificacion",
    "Caracteristica Unidad de Construccion con el tipo de unidad de construccion diferente al uso de construccion asignado",
    "(" 
    f"c.type_key={_join_token(0)!r} AND c.uso_construccion>14" 
    ") OR ("
    f"c.type_key={_join_token(1)!r} AND (c.uso_construccion<15 OR c.uso_construccion>40)"
    ") OR ("
    f"c.type_key={_join_token(2)!r} AND (c.uso_construccion<41 OR c.uso_construccion>45)"
    ") OR ("
    f"c.type_key={_join_token(3)!r} AND (c.uso_construccion<46 OR c.uso_construccion>68)"
    ") OR ("
    f"c.type_key={_join_token(4)!r} AND c.uso_construccion<69"
    ")",
    False,
)


def execute_reco_27(data_source, layer_mapping, cancel_check=None):
    return execute_construction_scalar(_RULE, data_source, layer_mapping, cancel_check)
