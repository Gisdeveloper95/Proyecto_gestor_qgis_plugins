"""Independent portable implementation of canonical Reco_17."""
from .portable_related_scalar import RelatedScalarRule, execute_related_scalar

_RULE = RelatedScalarRule(
    "Reco_17", "Reconocimiento", "Predios con cambio fisico sin foto del croquis",
    "lc_gen_fotos_predio", ("pk_id", "fk_id", "tipo_foto"), "anti",
    "r.tipo_foto = 0", "p.predio_tiene_cambio_fisico = 1",
    "LC_Gen_Predio", "predio", "LC_Gen_Fotos_Predio",
    predio_filter_fields=("predio_tiene_cambio_fisico",),
)

def execute_reco_17(data_source, layer_mapping, cancel_check=None):
    return execute_related_scalar(_RULE, data_source, layer_mapping, cancel_check)
