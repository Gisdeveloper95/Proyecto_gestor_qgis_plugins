"""Independent portable implementation of canonical Reco_41."""
from .portable_reco_calification import execute_calification_rule
def execute_reco_41(data_source,layer_mapping,cancel_check=None): return execute_calification_rule("Reco_41",data_source,layer_mapping,cancel_check)
