"""Independent portable implementation of canonical Reco_46."""
from .portable_reco_photos import execute_reco_46 as _execute


def execute_reco_46(data_source, layer_mapping, cancel_check=None):
    return _execute(data_source, layer_mapping, cancel_check)
