"""Portable exact-geometry implementation of canonical SIG_16."""
from datetime import datetime
from .portable_predio_scalar import _join_token
from .portable_primitives import BatchInserter,postgres_boolean_is_false_or_null,raise_if_cancelled,sqlite_staging
from .portable_rule_jur_47 import _geometry

PF=("pk_id","numero_predial_nacional","juridico_predio_cancelado","nombre_proyecto","matricula_inmobiliaria","destinacion_economica","area_catastral_terreno")
OUTPUT=("id_regla","componente","descripcion_regla","proyecto","pk_id_predio","tabla_error_1","pk_tabla_error_1","tabla_error_2","pk_tabla_error_2","numero_predial_nacional","matricula_inmobiliaria","destino_economico","area_catastral_terreno","identificador_caracteristica_unidad_construccion","total_plantas","tipo_unidad_construccion","uso_construccion","area_construida","puntaje_calificacion","tipo_novedad","numero_predial_nacional_novedad","tiene_excepcion","usuario_creacion","fecha_creacion","usuario_modificacion","fecha_modificacion","custom_1","custom_2","custom_3","custom_4","custom_5","custom_6","custom_7","custom_8","custom_9","custom_10","custom_11","custom_12")


def _geometry_field(source,physical):
 fields=set(source.describe(physical).fields);return"geom"if"geom"in fields else"geom_wkt"


def execute_sig_16(source,mapping,cancel_check=None):
 stamp=datetime.now()
 with sqlite_staging(cancel_check,prefix="mapingtool-calidad-gpkg-sig_16-")as db:
  db.executescript("""CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,npn_key TEXT,project,registration,destination_key TEXT,area);CREATE TABLE terrain_general(row_token INTEGER PRIMARY KEY,code,code_key TEXT,geometry);CREATE TABLE terrain_informal(row_token INTEGER PRIMARY KEY,code,code_key TEXT,geometry);CREATE TABLE perimeter(row_token INTEGER PRIMARY KEY,geometry);CREATE TABLE selected(row_token INTEGER PRIMARY KEY,predio_row INTEGER,table_name);CREATE TABLE destination(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);CREATE TABLE exception(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid);""")
  with BatchInserter(db,"INSERT INTO predio(pk_id,pk_key,npn,npn_key,project,registration,destination_key,area)VALUES(?,?,?,?,?,?,?,?)",cancel_check=cancel_check)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_predio"),PF):
    raise_if_cancelled(cancel_check)
    if postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado")):ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),_join_token(r.get("numero_predial_nacional")),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno")))
  for logical,table in(("lc_gen_terreno","terrain_general"),("lc_gen_terreno_informal","terrain_informal")):
   physical=mapping.resolve(logical);gf=_geometry_field(source,physical)
   with BatchInserter(db,f"INSERT INTO {table}(code,code_key,geometry)VALUES(?,?,?)",cancel_check=cancel_check)as ins:
    for r in source.iter_rows(physical,("codigo",gf)):raise_if_cancelled(cancel_check);ins.add((r.get("codigo"),_join_token(r.get("codigo")),r.get(gf)))
  physical=mapping.resolve("perimetro_urbano_20260702");gf=_geometry_field(source,physical)
  with BatchInserter(db,"INSERT INTO perimeter(geometry)VALUES(?)",cancel_check=cancel_check)as ins:
   for r in source.iter_rows(physical,(gf,)):raise_if_cancelled(cancel_check);ins.add((r.get(gf),))
  with BatchInserter(db,"INSERT INTO destination(key_token,ilicode)VALUES(?,?)",cancel_check=cancel_check)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_destinacioneconomica_tipo"),("itfcode","ilicode")):raise_if_cancelled(cancel_check);ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))
  with BatchInserter(db,"INSERT INTO exception(fk_token,fid)VALUES(?,?)",cancel_check=cancel_check)as ins:
   for r in source.iter_rows(mapping.resolve("lc_gen_excepciones"),("fid","fk_id","id_regla")):
    raise_if_cancelled(cancel_check)
    if r.get("id_regla")=="SIG_16":ins.add((_join_token(r.get("fk_id")),r.get("fid")))
  db.execute("CREATE TEMP TABLE terrains AS SELECT code,code_key,geometry,'lc_gen_terreno' table_name FROM terrain_general UNION SELECT code,code_key,geometry,'lc_gen_terreno_informal' FROM terrain_informal")
  for code_key,terrain_payload,table_name,perimeter_payload in db.execute("SELECT t.code_key,t.geometry,t.table_name,p.geometry FROM terrains t CROSS JOIN perimeter p"):
   raise_if_cancelled(cancel_check);terrain=_geometry(terrain_payload);perimeter=_geometry(perimeter_payload)
   if not terrain.isGeosValid()or not perimeter.isGeosValid()or not terrain.intersects(perimeter):continue
   area=terrain.area()
   if area==0:continue
   ratio=terrain.intersection(perimeter).area()/area
   for predio_row,npn in db.execute("SELECT row_token,npn FROM predio WHERE npn_key=?",(code_key,)):
    segment=npn[5:7]if npn is not None and len(npn)>=7 else None
    if (ratio<.5 and segment=="01")or(ratio>.5 and segment is not None and segment!="01"):db.execute("INSERT INTO selected(predio_row,table_name)VALUES(?,?)",(predio_row,table_name))
  db.commit();cur=db.execute("""SELECT p.pk_id,p.npn,p.project,p.registration,d.ilicode,p.area,e.fid,s.table_name FROM selected s JOIN predio p ON p.row_token=s.predio_row LEFT JOIN destination d ON d.key_token=p.destination_key LEFT JOIN exception e ON e.fk_token=p.pk_key ORDER BY p.npn IS NULL,p.npn,p.project IS NULL,p.project""")
  try:
   for pk,npn,project,registration,destination,area,exception_fid,table_name in cur:
    raise_if_cancelled(cancel_check);row={"id_regla":"SIG_16","componente":"Digitalizacion","descripcion_regla":"Predios urbanos con más del 50% fuera del perimetro urbano","proyecto":project,"pk_id_predio":pk,"tabla_error_1":"LC_Gen_Predio","pk_tabla_error_1":pk,"tabla_error_2":table_name,"pk_tabla_error_2":None,"numero_predial_nacional":npn,"matricula_inmobiliaria":registration,"destino_economico":destination,"area_catastral_terreno":area,"identificador_caracteristica_unidad_construccion":None,"total_plantas":None,"tipo_unidad_construccion":None,"uso_construccion":None,"area_construida":None,"puntaje_calificacion":None,"tipo_novedad":None,"numero_predial_nacional_novedad":None,"tiene_excepcion":exception_fid is not None,"usuario_creacion":"admin","fecha_creacion":stamp,"usuario_modificacion":"admin","fecha_modificacion":stamp,"custom_1":None,"custom_2":None,"custom_3":None,"custom_4":None,"custom_5":None,"custom_6":None,"custom_7":False,"custom_8":None,"custom_9":None,"custom_10":None,"custom_11":None,"custom_12":None};yield row
  finally:cur.close()
