"""Disk-backed portable implementation of the seven economic rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
    sqlite_staging,
)


@dataclass(frozen=True)
class EcoRule:
    canonical_id: str
    description: str
    field: str
    include_ph: bool = False
    left_join: bool = False
    requires_construction: bool = False
    exclude_types_2_5: bool = False
    component: str = "Economico"
    custom_7: bool = True


RULES = {
    "Eco_01": EcoRule("Eco_01", "Predios sin valor comercial total", "valor_comercial", True, True),
    "Eco_02": EcoRule("Eco_02", "Predios No PH con valor comercial total diferente a la suma del avaluo de terreno y avaluo de construccion", "sum_mismatch"),
    "Eco_03": EcoRule("Eco_03", "Predios sin Avaluo Catastral", "avaluo_catastral", True, True),
    "Eco_04": EcoRule("Eco_04", "Predios No PH sin valor comercial de terreno", "valor_comercial_terreno", exclude_types_2_5=True),
    "Eco_05": EcoRule("Eco_05", "Predios No PH sin Avaluo Catastral de Terreno", "avaluo_catastral_terreno", exclude_types_2_5=True),
    "Eco_06": EcoRule("Eco_06", "Predios No PH con construcciones sin valor comercial de Construccion", "valor_comercial_construccion", requires_construction=True),
    "Eco_07": EcoRule("Eco_07", "Predios No PH con construccion sin Avaluo Catastral de Construccion", "avaluo_catastral_construccion", requires_construction=True),
}

GENERAL_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado",
    "nombre_proyecto", "matricula_inmobiliaria", "destinacion_economica",
    "area_catastral_terreno", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control", "informal_estado_asignacion",
    "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
PH_FIELDS = (
    "pk_id", "fk_id", "numero_predial_nacional", "matricula_inmobiliaria",
    "destinacion_economica", "area_catastral_terreno",
)
VALUATION_FIELDS = (
    "pk_id", "fk_id", "valor_comercial", "valor_comercial_terreno",
    "valor_comercial_construccion", "avaluo_catastral",
    "avaluo_catastral_terreno", "avaluo_catastral_construccion",
)


def _ordinary_npn(value: Any) -> bool:
    if value is None:
        return False
    return str(value)[21:30] not in {"700000000", "800000000", "900000000"}


def _ordinary_terrain_npn(value: Any) -> bool:
    if not _ordinary_npn(value):
        return False
    return str(value)[21:22] not in {"2", "5"}


def _zero(value: Any) -> bool:
    return value is None or value == 0


def _decimal(value: Any) -> Decimal:
    return Decimal(0) if value is None else Decimal(str(value))


def _round_thousand(value: Any) -> Decimal:
    return _decimal(value).quantize(Decimal("1E3"), rounding=ROUND_HALF_UP)


def _violation(definition: EcoRule, row) -> bool:
    if definition.field == "sum_mismatch":
        difference = abs(
            _decimal(row.get("valor_comercial"))
            - _round_thousand(row.get("valor_comercial_terreno"))
            - _round_thousand(row.get("valor_comercial_construccion"))
        )
        return difference > Decimal(5000)
    return _zero(row.get(definition.field))


def _create(db) -> None:
    db.executescript(
        """
        CREATE TABLE gen(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,npn,project,
          registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,reco_a TEXT,
          reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT,ordinary INTEGER,
          ordinary_terrain INTEGER);
        CREATE TABLE ph(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,parent_key TEXT,
          npn,registration,destination_key TEXT,area);
        CREATE TABLE gen_valuation(row_token INTEGER PRIMARY KEY,pk_id,parent_key TEXT,violates INTEGER);
        CREATE TABLE ph_valuation(row_token INTEGER PRIMARY KEY,pk_id,parent_key TEXT,violates INTEGER);
        CREATE TABLE construction(row_token INTEGER PRIMARY KEY,parent_key TEXT);
        CREATE TABLE selected(row_token INTEGER PRIMARY KEY,general_pk,object_key TEXT,npn,
          project,registration,destination_key TEXT,area,jur_a TEXT,jur_c TEXT,
          reco_a TEXT,reco_c TEXT,info_a TEXT,info_c TEXT,geo_a TEXT,geo_c TEXT,
          table_1,pk_1,table_2,pk_2);
        CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
        CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
        CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
        """
    )


def _ingest(definition: EcoRule, source, mapping, db, cancel_check) -> None:
    with BatchInserter(db, """INSERT INTO gen(pk_id,pk_key,npn,project,registration,
      destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c,
      ordinary,ordinary_terrain)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_gen_predio"), GENERAL_FIELDS):
            raise_if_cancelled(cancel_check)
            if not postgres_boolean_is_false_or_null(row.get("juridico_predio_cancelado")):
                continue
            npn = row.get("numero_predial_nacional")
            inserter.add((row.get("pk_id"),_join_token(row.get("pk_id")),npn,
                row.get("nombre_proyecto"),row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),row.get("area_catastral_terreno"),
                _join_token(row.get("juridico_estado_asignacion")),_join_token(row.get("juridico_estado_control")),
                _join_token(row.get("reconocimiento_estado_asignacion")),_join_token(row.get("reconocimiento_estado_control")),
                _join_token(row.get("informal_estado_asignacion")),_join_token(row.get("informal_estado_control")),
                _join_token(row.get("geografico_estado_asignacion")),_join_token(row.get("geografico_estado_control")),
                int(_ordinary_npn(npn)),int(_ordinary_terrain_npn(npn))))
    with BatchInserter(db, "INSERT INTO ph(pk_id,pk_key,parent_key,npn,registration,destination_key,area)VALUES(?,?,?,?,?,?,?)", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("lc_ph_predio"), PH_FIELDS):
            raise_if_cancelled(cancel_check)
            inserter.add((row.get("pk_id"),_join_token(row.get("pk_id")),_join_token(row.get("fk_id")),
                row.get("numero_predial_nacional"),row.get("matricula_inmobiliaria"),
                _join_token(row.get("destinacion_economica")),row.get("area_catastral_terreno")))
    for logical, table in (("lc_gen_predio_avaluo", "gen_valuation"), ("lc_ph_predio_avaluo", "ph_valuation")):
        with BatchInserter(db, f"INSERT INTO {table}(pk_id,parent_key,violates)VALUES(?,?,?)", cancel_check=cancel_check) as inserter:
            for row in source.iter_rows(mapping.resolve(logical), VALUATION_FIELDS):
                raise_if_cancelled(cancel_check)
                inserter.add((row.get("pk_id"),_join_token(row.get("fk_id")),int(_violation(definition,row))))
    with BatchInserter(db, "INSERT INTO construction(parent_key)VALUES(?)", cancel_check=cancel_check) as inserter:
        for row in source.iter_rows(mapping.resolve("determinacion_area_construccion"), ("pk_id",)):
            raise_if_cancelled(cancel_check)
            inserter.add((_join_token(row.get("pk_id")),))


def _prepare(definition: EcoRule, db) -> None:
    insert = """INSERT INTO selected(general_pk,object_key,npn,project,registration,
      destination_key,area,jur_a,jur_c,reco_a,reco_c,info_a,info_c,geo_a,geo_c,
      table_1,pk_1,table_2,pk_2) """
    construction = " JOIN construction c ON c.parent_key=g.pk_key" if definition.requires_construction else ""
    npn_filter = "g.ordinary_terrain=1" if definition.exclude_types_2_5 else "g.ordinary=1"
    join_type = "LEFT JOIN" if definition.left_join else "JOIN"
    predicate = "(v.violates=1 OR v.pk_id IS NULL)" if definition.left_join else "v.violates=1"
    db.execute(insert + f"""SELECT g.pk_id,g.pk_key,g.npn,g.project,g.registration,
      g.destination_key,g.area,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,
      g.geo_a,g.geo_c,'LC_Gen_Predio',g.pk_id,'LC_Gen_Predio_Avaluo',v.pk_id
      FROM gen g {construction} {join_type} gen_valuation v ON v.parent_key=g.pk_key
      WHERE {predicate} AND {npn_filter}""")
    if definition.include_ph:
        db.execute(insert + """SELECT g.pk_id,p.pk_key,p.npn,g.project,p.registration,
          p.destination_key,p.area,g.jur_a,g.jur_c,g.reco_a,g.reco_c,g.info_a,g.info_c,
          g.geo_a,g.geo_c,'LC_PH_Predio',p.pk_id,'LC_PH_Predio_Avaluo',v.pk_id
          FROM gen g JOIN ph p ON p.parent_key=g.pk_key
          LEFT JOIN ph_valuation v ON v.parent_key=p.pk_key
          WHERE v.violates=1 OR v.pk_id IS NULL""")


def _result_sql(distinct: bool) -> str:
    keyword = "DISTINCT" if distinct else ""
    return f"""SELECT {keyword} s.general_pk,s.npn,s.project,s.registration,d.ilicode,s.area,
      e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,ra.ilicode,rc.ilicode,
      ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,s.table_1,s.pk_1,s.table_2,s.pk_2
      FROM selected s LEFT JOIN destination_lookup d ON d.key_token=s.destination_key
      LEFT JOIN exception_lookup e ON e.fk_token=s.object_key
      LEFT JOIN user_assignment ua ON ua.fk_token=s.object_key
      LEFT JOIN assignment_lookup ja ON ja.key_token=s.jur_a
      LEFT JOIN control_lookup jc ON jc.key_token=s.jur_c
      LEFT JOIN assignment_lookup ra ON ra.key_token=s.reco_a
      LEFT JOIN control_lookup rc ON rc.key_token=s.reco_c
      LEFT JOIN assignment_lookup ia ON ia.key_token=s.info_a
      LEFT JOIN control_lookup ic ON ic.key_token=s.info_c
      LEFT JOIN assignment_lookup ga ON ga.key_token=s.geo_a
      LEFT JOIN control_lookup gc ON gc.key_token=s.geo_c
      ORDER BY s.npn IS NULL,s.npn,s.project IS NULL,s.project,s.row_token"""


def execute_eco(rule_id: str, source, mapping, cancel_check=None) -> Iterator[dict[str, Any]]:
    definition = RULES[rule_id]
    timestamp = datetime.now()
    with sqlite_staging(cancel_check, prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        _create(db)
        _ingest(definition, source, mapping, db, cancel_check)
        _ingest_enrichment(definition, source, mapping, db, cancel_check)
        _prepare(definition, db)
        db.commit()
        cursor = db.execute(_result_sql(definition.include_ph))
        try:
            for values in cursor:
                raise_if_cancelled(cancel_check)
                row = _result_row(definition, timestamp, values[:17])
                row["tabla_error_1"], row["pk_tabla_error_1"] = values[17:19]
                row["tabla_error_2"], row["pk_tabla_error_2"] = values[19:21]
                yield row
        finally:
            cursor.close()


def _entry(rule_id: str):
    def execute(source, mapping, cancel_check=None):
        return execute_eco(rule_id, source, mapping, cancel_check)
    execute.__name__ = f"execute_{rule_id.lower()}"
    return execute


execute_eco_01 = _entry("Eco_01")
execute_eco_02 = _entry("Eco_02")
execute_eco_03 = _entry("Eco_03")
execute_eco_04 = _entry("Eco_04")
execute_eco_05 = _entry("Eco_05")
execute_eco_06 = _entry("Eco_06")
execute_eco_07 = _entry("Eco_07")
