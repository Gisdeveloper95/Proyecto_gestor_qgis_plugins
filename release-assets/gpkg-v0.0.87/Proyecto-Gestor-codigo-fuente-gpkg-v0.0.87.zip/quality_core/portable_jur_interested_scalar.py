"""Disk-backed portable engine for scalar interested-party rules."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterator

from .portable_predio_scalar import _ingest_enrichment, _join_token, _result_row
from .portable_primitives import (
    BatchInserter,
    postgres_boolean_is_false_or_null,
    raise_if_cancelled,
    sqlite_staging,
)


@dataclass(frozen=True)
class InterestedRule:
    canonical_id: str
    description: str
    predicate_sql: str
    document_type_join: bool
    component: str = "Juridico"
    custom_7: bool = True


RULES = {
    "Jur_39": InterestedRule(
        "Jur_39", "Interesados con tipo de documento NIT con nombres y/o apellidos",
        "i.estado_propietario <> 0 AND i.tipo_documento = 2 AND (i.primer_nombre IS NOT NULL OR i.segundo_nombre IS NOT NULL OR i.primer_apellido IS NOT NULL OR i.segundo_nombre IS NOT NULL)", True,
    ),
    "Jur_40": InterestedRule(
        "Jur_40", "Interesados con tipo de documento NIT sin razon social",
        "i.estado_propietario <> 0 AND i.tipo_documento = 2 AND i.razon_social IS NULL", True,
    ),
    "Jur_41": InterestedRule(
        "Jur_41", "Interesados con tipo de documento distinto a NIT con razon social",
        "i.estado_propietario <> 0 AND i.tipo_documento <> 2 AND i.razon_social IS NOT NULL", True,
    ),
    "Jur_42": InterestedRule(
        "Jur_42", "Interesados con tipo de documento distinto a NIT sin nombre completo diligenciado",
        "i.estado_propietario <> 0 AND i.tipo_documento <> 2 AND i.nombre_completo_propietario IS NULL", True,
    ),
    "Jur_43": InterestedRule(
        "Jur_43", "Interesados sin tipo de documento",
        "(i.tipo_documento IS NULL OR i.tipo_documento > 7) AND i.estado_propietario <> 0", False,
    ),
    "Jur_44": InterestedRule(
        "Jur_44", "Interesados con documento de identidad en 0, vacío o nulo",
        "(i.documento_identidad = '0' OR i.documento_identidad IS NULL OR i.documento_identidad = '') AND i.estado_propietario <> 0", False,
    ),
    "Jur_46": InterestedRule(
        "Jur_46", "Interesados con tipo de documento distinto a NIT sin sexo",
        "i.tipo_documento <> 2 AND i.sexo IS NULL", False,
    ),
}


_PREDIO_FIELDS = (
    "pk_id", "numero_predial_nacional", "juridico_predio_cancelado",
    "nombre_proyecto", "matricula_inmobiliaria", "destinacion_economica",
    "area_catastral_terreno", "juridico_estado_asignacion",
    "juridico_estado_control", "reconocimiento_estado_asignacion",
    "reconocimiento_estado_control", "informal_estado_asignacion",
    "informal_estado_control", "geografico_estado_asignacion",
    "geografico_estado_control",
)
_INTERESTED_FIELDS = (
    "pk_id", "fk_id", "estado_propietario", "tipo_documento",
    "primer_nombre", "segundo_nombre", "primer_apellido", "razon_social",
    "nombre_completo_propietario", "documento_identidad", "sexo",
)


def _create_stage(db):
    db.executescript("""
      CREATE TABLE predio(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,
        numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key TEXT,
        area_catastral_terreno,juridico_assignment_key TEXT,juridico_control_key TEXT,
        reconocimiento_assignment_key TEXT,reconocimiento_control_key TEXT,
        informal_assignment_key TEXT,informal_control_key TEXT,
        geografico_assignment_key TEXT,geografico_control_key TEXT);
      CREATE TABLE derecho(row_token INTEGER PRIMARY KEY,pk_id,pk_key TEXT,fk_key TEXT);
      CREATE TABLE interesado(row_token INTEGER PRIMARY KEY,pk_id,fk_key TEXT,
        estado_propietario,tipo_documento,tipo_documento_key TEXT,primer_nombre,
        segundo_nombre,primer_apellido,razon_social,nombre_completo_propietario,
        documento_identidad,sexo);
      CREATE TABLE documento_tipo(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE selected(row_token INTEGER PRIMARY KEY,predio_row INTEGER,
        derecho_row INTEGER,interesado_row INTEGER,pk_id,pk_key TEXT,
        numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key TEXT,
        area_catastral_terreno,juridico_assignment_key TEXT,juridico_control_key TEXT,
        reconocimiento_assignment_key TEXT,reconocimiento_control_key TEXT,
        informal_assignment_key TEXT,informal_control_key TEXT,
        geografico_assignment_key TEXT,geografico_control_key TEXT,derecho_pk,interesado_pk);
      CREATE TABLE destination_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE exception_lookup(row_token INTEGER PRIMARY KEY,fk_token TEXT,fid,descripcion_excepcion);
      CREATE TABLE user_assignment(row_token INTEGER PRIMARY KEY,fk_token TEXT,pk_id);
      CREATE TABLE assignment_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
      CREATE TABLE control_lookup(row_token INTEGER PRIMARY KEY,key_token TEXT,ilicode);
    """)


def _ingest(data_source, layer_mapping, db, cancel_check):
    sql = """INSERT INTO predio(pk_id,pk_key,numero_predial_nacional,proyecto,
      matricula_inmobiliaria,destination_key,area_catastral_terreno,
      juridico_assignment_key,juridico_control_key,reconocimiento_assignment_key,
      reconocimiento_control_key,informal_assignment_key,informal_control_key,
      geografico_assignment_key,geografico_control_key) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"""
    with BatchInserter(db, sql, cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_gen_predio"), _PREDIO_FIELDS):
            raise_if_cancelled(cancel_check)
            if not postgres_boolean_is_false_or_null(r.get("juridico_predio_cancelado")):
                continue
            ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),r.get("numero_predial_nacional"),r.get("nombre_proyecto"),r.get("matricula_inmobiliaria"),_join_token(r.get("destinacion_economica")),r.get("area_catastral_terreno"),_join_token(r.get("juridico_estado_asignacion")),_join_token(r.get("juridico_estado_control")),_join_token(r.get("reconocimiento_estado_asignacion")),_join_token(r.get("reconocimiento_estado_control")),_join_token(r.get("informal_estado_asignacion")),_join_token(r.get("informal_estado_control")),_join_token(r.get("geografico_estado_asignacion")),_join_token(r.get("geografico_estado_control"))))
    with BatchInserter(db, "INSERT INTO derecho(pk_id,pk_key,fk_key) VALUES (?,?,?)", cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_derecho"), ("pk_id","fk_id")):
            raise_if_cancelled(cancel_check); ins.add((r.get("pk_id"),_join_token(r.get("pk_id")),_join_token(r.get("fk_id"))))
    sql = """INSERT INTO interesado(pk_id,fk_key,estado_propietario,tipo_documento,
      tipo_documento_key,primer_nombre,segundo_nombre,primer_apellido,razon_social,
      nombre_completo_propietario,documento_identidad,sexo) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"""
    with BatchInserter(db, sql, cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_interesado"), _INTERESTED_FIELDS):
            raise_if_cancelled(cancel_check)
            ins.add((r.get("pk_id"),_join_token(r.get("fk_id")),r.get("estado_propietario"),r.get("tipo_documento"),_join_token(r.get("tipo_documento")),r.get("primer_nombre"),r.get("segundo_nombre"),r.get("primer_apellido"),r.get("razon_social"),r.get("nombre_completo_propietario"),r.get("documento_identidad"),r.get("sexo")))
    with BatchInserter(db, "INSERT INTO documento_tipo(key_token,ilicode) VALUES (?,?)", cancel_check=cancel_check) as ins:
        for r in data_source.iter_rows(layer_mapping.resolve("lc_jur_documento_interesado_tipo"), ("itfcode","ilicode")):
            raise_if_cancelled(cancel_check); ins.add((_join_token(r.get("itfcode")),r.get("ilicode")))


def _prepare(definition, db):
    doc_join = "LEFT JOIN documento_tipo dt ON dt.key_token=i.tipo_documento_key" if definition.document_type_join else ""
    db.execute("""INSERT INTO selected(predio_row,derecho_row,interesado_row,pk_id,pk_key,
      numero_predial_nacional,proyecto,matricula_inmobiliaria,destination_key,
      area_catastral_terreno,juridico_assignment_key,juridico_control_key,
      reconocimiento_assignment_key,reconocimiento_control_key,informal_assignment_key,
      informal_control_key,geografico_assignment_key,geografico_control_key,derecho_pk,interesado_pk)
      SELECT p.row_token,d.row_token,i.row_token,p.pk_id,p.pk_key,p.numero_predial_nacional,
      p.proyecto,p.matricula_inmobiliaria,p.destination_key,p.area_catastral_terreno,
      p.juridico_assignment_key,p.juridico_control_key,p.reconocimiento_assignment_key,
      p.reconocimiento_control_key,p.informal_assignment_key,p.informal_control_key,
      p.geografico_assignment_key,p.geografico_control_key,d.pk_id,i.pk_id
      FROM predio p JOIN derecho d ON d.fk_key=p.pk_key
      JOIN interesado i ON i.fk_key=d.pk_key """ + doc_join + " WHERE " + definition.predicate_sql)


_RESULT_SQL = """SELECT s.pk_id,s.numero_predial_nacional,s.proyecto,s.matricula_inmobiliaria,
 d.ilicode,s.area_catastral_terreno,e.fid,e.descripcion_excepcion,ja.ilicode,jc.ilicode,
 ra.ilicode,rc.ilicode,ia.ilicode,ic.ilicode,ga.ilicode,gc.ilicode,ua.pk_id,
 s.derecho_pk,s.interesado_pk FROM selected s
 LEFT JOIN destination_lookup d ON d.key_token=s.destination_key
 LEFT JOIN exception_lookup e ON e.fk_token=s.pk_key
 LEFT JOIN user_assignment ua ON ua.fk_token=s.pk_key
 LEFT JOIN assignment_lookup ja ON ja.key_token=s.juridico_assignment_key
 LEFT JOIN control_lookup jc ON jc.key_token=s.juridico_control_key
 LEFT JOIN assignment_lookup ra ON ra.key_token=s.reconocimiento_assignment_key
 LEFT JOIN control_lookup rc ON rc.key_token=s.reconocimiento_control_key
 LEFT JOIN assignment_lookup ia ON ia.key_token=s.informal_assignment_key
 LEFT JOIN control_lookup ic ON ic.key_token=s.informal_control_key
 LEFT JOIN assignment_lookup ga ON ga.key_token=s.geografico_assignment_key
 LEFT JOIN control_lookup gc ON gc.key_token=s.geografico_control_key"""


def execute_interested_scalar(rule_id, data_source, layer_mapping, cancel_check=None) -> Iterator[dict[str, Any]]:
    definition=RULES[rule_id]; timestamp=datetime.now()
    with sqlite_staging(cancel_check,prefix=f"mapingtool-calidad-gpkg-{rule_id.lower()}-") as db:
        _create_stage(db); _ingest(data_source,layer_mapping,db,cancel_check)
        _ingest_enrichment(definition,data_source,layer_mapping,db,cancel_check)
        _prepare(definition,db); db.commit(); cur=db.execute(_RESULT_SQL)
        try:
            for values in cur:
                raise_if_cancelled(cancel_check)
                base=_result_row(definition,timestamp,values[:17])
                base["tabla_error_1"]="LC_Jur_Derecho"; base["pk_tabla_error_1"]=values[17]
                base["tabla_error_2"]="LC_Jur_Interesado"; base["pk_tabla_error_2"]=values[18]
                yield base
        finally: cur.close()


def _entrypoint(rule_id):
    def execute(data_source, layer_mapping, cancel_check=None):
        return execute_interested_scalar(
            rule_id, data_source, layer_mapping, cancel_check
        )
    execute.__name__ = "execute_{0}".format(rule_id.lower())
    return execute


execute_jur_39=_entrypoint("Jur_39")
execute_jur_40=_entrypoint("Jur_40")
execute_jur_41=_entrypoint("Jur_41")
execute_jur_42=_entrypoint("Jur_42")
execute_jur_43=_entrypoint("Jur_43")
execute_jur_44=_entrypoint("Jur_44")
execute_jur_46=_entrypoint("Jur_46")
