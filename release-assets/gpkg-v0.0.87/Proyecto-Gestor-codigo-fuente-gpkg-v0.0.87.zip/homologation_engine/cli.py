from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

from .compiler import ENGINE_VERSION, HomologationCompiler
from .models import CompileRequest


def _engine_sha256() -> str:
    digest = hashlib.sha256()
    root = Path(__file__).resolve().parent
    for path in sorted(root.glob("*.py")):
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest().upper()


def _request(value: dict[str, Any]) -> CompileRequest:
    metadata = value.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    table_mapping = value.get("table_mapping")
    if not isinstance(table_mapping, dict):
        table_mapping = {}
    return CompileRequest(
        opaque_key=str(value.get("opaque_key", "")),
        sql=str(value.get("sql", "")),
        table_mapping={str(key): str(item) for key, item in table_mapping.items()},
        expected_columns=tuple(str(item) for item in value.get("expected_columns", [])),
        geometry_columns=tuple(str(item) for item in value.get("geometry_columns", [])),
        metadata=metadata,
    )


def compile_bundle(source: Path, destination: Path) -> int:
    bundle = json.loads(source.read_text(encoding="utf-8"))
    raw_rules = bundle.get("rules")
    if not isinstance(raw_rules, list) or not raw_rules:
        raise ValueError("bundle_rules_required")
    requests = tuple(_request(item) for item in raw_rules if isinstance(item, dict))
    compiler = HomologationCompiler()
    results = tuple(compiler.compile(item) for item in requests)
    payload = {
        "schema_version": 1,
        "engine_version": ENGINE_VERSION,
        "engine_sha256": _engine_sha256(),
        "change_set_id": str(bundle.get("change_set_id", "")),
        "revision": int(bundle.get("revision", 0)),
        "base_sha": str(bundle.get("base_sha", "")),
        "gpkg_build_allowed": False,
        "parity_status": "verification_pending"
        if all(item.compilable and not item.review_required for item in results)
        else "blocked",
        "results": [
            {
                "opaque_key": request.opaque_key,
                **result.to_dict(),
            }
            for request, result in zip(requests, results, strict=True)
        ],
    }
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return 0 if payload["parity_status"] == "verification_pending" else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Motor clean-room de homologación SQL.")
    subparsers = parser.add_subparsers(dest="command", required=True)
    compile_parser = subparsers.add_parser("compile-bundle")
    compile_parser.add_argument("--input", required=True, type=Path)
    compile_parser.add_argument("--output", required=True, type=Path)
    subparsers.add_parser("engine-hash")
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    if arguments.command == "compile-bundle":
        return compile_bundle(arguments.input, arguments.output)
    if arguments.command == "engine-hash":
        print(_engine_sha256())
        return 0
    raise ValueError("unknown_command")


if __name__ == "__main__":
    sys.exit(main())
