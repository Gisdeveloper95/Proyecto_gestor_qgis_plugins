from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class OutputMode(StrEnum):
    SQLITE_SQL = "sqlite_sql"
    PORTABLE_IR = "portable_ir"
    PYTHON_ADAPTER_CANDIDATE = "python_adapter_candidate"
    MANUAL_REQUIRED = "manual_required"


class DiagnosticLevel(StrEnum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class Diagnostic:
    code: str
    message: str
    level: DiagnosticLevel = DiagnosticLevel.ERROR
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "level": self.level.value,
            "details": self.details,
        }


@dataclass(frozen=True, slots=True)
class CompileRequest:
    sql: str
    opaque_key: str = ""
    table_mapping: dict[str, str] = field(default_factory=dict)
    expected_columns: tuple[str, ...] = ()
    geometry_columns: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CompileResult:
    engine_version: str
    input_sha256: str
    mode: OutputMode
    sqlite_sql: str | None
    portable_plan: dict[str, Any] | None
    output_columns: tuple[str, ...]
    required_capabilities: tuple[str, ...]
    diagnostics: tuple[Diagnostic, ...]
    plan_sha256: str
    review_required: bool = False

    @property
    def compilable(self) -> bool:
        return self.mode is not OutputMode.MANUAL_REQUIRED

    def to_dict(self) -> dict[str, Any]:
        return {
            "engine_version": self.engine_version,
            "input_sha256": self.input_sha256,
            "mode": self.mode.value,
            "sqlite_sql": self.sqlite_sql,
            "portable_plan": self.portable_plan,
            "output_columns": list(self.output_columns),
            "required_capabilities": list(self.required_capabilities),
            "diagnostics": [item.to_dict() for item in self.diagnostics],
            "plan_sha256": self.plan_sha256,
            "review_required": self.review_required,
            "compilable": self.compilable,
        }


@dataclass(frozen=True, slots=True)
class HomologationBatchResult:
    engine_version: str
    engine_sha256: str
    results: tuple[CompileResult, ...]
    gpkg_build_allowed: bool

    def to_dict(self) -> dict[str, Any]:
        return {
            "engine_version": self.engine_version,
            "engine_sha256": self.engine_sha256,
            "gpkg_build_allowed": self.gpkg_build_allowed,
            "results": [item.to_dict() for item in self.results],
        }
