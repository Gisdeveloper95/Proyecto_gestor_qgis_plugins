from __future__ import annotations

import base64
import datetime as dt
import decimal
import hashlib
import json
import math
from collections import Counter
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from shapely import equals_exact, normalize, to_wkb

from .runtime import geometry_and_srid


@dataclass(frozen=True, slots=True)
class ComparisonContract:
    expected_columns: tuple[str, ...]
    geometry_columns: tuple[str, ...] = ()
    ordered: bool = False
    float_tolerance: float = 1e-9
    geometry_tolerance: float = 1e-8


@dataclass(frozen=True, slots=True)
class EquivalenceResult:
    equivalent: bool
    reference_rows: int
    candidate_rows: int
    missing_rows: int
    unexpected_rows: int
    schema_matches: bool
    evidence_sha256: str
    diagnostics: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "equivalent": self.equivalent,
            "reference_rows": self.reference_rows,
            "candidate_rows": self.candidate_rows,
            "missing_rows": self.missing_rows,
            "unexpected_rows": self.unexpected_rows,
            "schema_matches": self.schema_matches,
            "evidence_sha256": self.evidence_sha256,
            "diagnostics": list(self.diagnostics),
        }


def _geometry_token(value: Any, tolerance: float) -> dict[str, Any]:
    geometry, srid = geometry_and_srid(value)
    if geometry is None:
        return {"kind": "geometry", "value": None}
    normalized = normalize(geometry)
    return {
        "kind": "geometry",
        "srid": srid,
        "type": geometry.geom_type,
        "empty": bool(geometry.is_empty),
        "wkb": base64.b64encode(
            bytes(to_wkb(normalized, output_dimension=3)),
        ).decode("ascii"),
    }


def _canonical_scalar(value: Any, tolerance: float) -> Any:
    if value is None or isinstance(value, str):
        return value
    if isinstance(value, bool):
        # SQLite's only native boolean representation is INTEGER 0/1.
        return {"kind": "number", "value": "1" if value else "0"}
    if isinstance(value, (int, float, decimal.Decimal)):
        numeric = decimal.Decimal(str(value))
        if isinstance(value, float):
            if math.isnan(value):
                return {"kind": "float", "value": "nan"}
            if math.isinf(value):
                return {"kind": "float", "value": "inf" if value > 0 else "-inf"}
            digits = max(
                0,
                min(
                    15,
                    int(abs(math.log10(tolerance))) if tolerance > 0 else 15,
                ),
            )
            numeric = decimal.Decimal(str(round(value, digits)))
        normalized = numeric.normalize()
        rendered = format(normalized, "f")
        if rendered == "-0":
            rendered = "0"
        return {"kind": "number", "value": rendered}
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return {"kind": type(value).__name__, "value": value.isoformat()}
    if isinstance(value, memoryview):
        value = value.tobytes()
    if isinstance(value, bytearray):
        value = bytes(value)
    if isinstance(value, bytes):
        return {"kind": "bytes", "value": base64.b64encode(value).decode("ascii")}
    return {"kind": type(value).__name__, "value": str(value)}


def _canonical_row(
    row: Mapping[str, Any],
    contract: ComparisonContract,
) -> str:
    geometry_columns = set(contract.geometry_columns)
    values = [
        _geometry_token(row.get(column), contract.geometry_tolerance)
        if column in geometry_columns and row.get(column) is not None
        else _canonical_scalar(row.get(column), contract.float_tolerance)
        for column in contract.expected_columns
    ]
    return json.dumps(values, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def compare_rows(
    reference: Sequence[Mapping[str, Any]],
    candidate: Sequence[Mapping[str, Any]],
    contract: ComparisonContract,
) -> EquivalenceResult:
    expected = set(contract.expected_columns)
    reference_schema = all(set(row) == expected for row in reference)
    candidate_schema = all(set(row) == expected for row in candidate)
    schema_matches = reference_schema and candidate_schema
    reference_tokens = [_canonical_row(row, contract) for row in reference]
    candidate_tokens = [_canonical_row(row, contract) for row in candidate]
    if contract.ordered:
        equivalent_values = reference_tokens == candidate_tokens
        missing = max(0, len(reference_tokens) - len(candidate_tokens))
        unexpected = max(0, len(candidate_tokens) - len(reference_tokens))
    else:
        reference_counter = Counter(reference_tokens)
        candidate_counter = Counter(candidate_tokens)
        missing = sum((reference_counter - candidate_counter).values())
        unexpected = sum((candidate_counter - reference_counter).values())
        equivalent_values = missing == 0 and unexpected == 0
    diagnostics: list[str] = []
    if not schema_matches:
        diagnostics.append("schema_mismatch")
    if missing:
        diagnostics.append(f"missing_rows:{missing}")
    if unexpected:
        diagnostics.append(f"unexpected_rows:{unexpected}")
    evidence = {
        "contract": {
            "expected_columns": contract.expected_columns,
            "geometry_columns": contract.geometry_columns,
            "ordered": contract.ordered,
            "float_tolerance": contract.float_tolerance,
            "geometry_tolerance": contract.geometry_tolerance,
        },
        "reference": reference_tokens,
        "candidate": candidate_tokens,
    }
    evidence_sha256 = hashlib.sha256(
        json.dumps(evidence, sort_keys=True, separators=(",", ":")).encode("utf-8"),
    ).hexdigest().upper()
    return EquivalenceResult(
        equivalent=schema_matches and equivalent_values,
        reference_rows=len(reference),
        candidate_rows=len(candidate),
        missing_rows=missing,
        unexpected_rows=unexpected,
        schema_matches=schema_matches,
        evidence_sha256=evidence_sha256,
        diagnostics=tuple(diagnostics),
    )


class DifferentialVerifier:
    def __init__(
        self,
        reference_executor: Callable[[int], Sequence[Mapping[str, Any]]],
        candidate_executor: Callable[[int], Sequence[Mapping[str, Any]]],
    ) -> None:
        self.reference_executor = reference_executor
        self.candidate_executor = candidate_executor

    def verify(
        self,
        seeds: Iterable[int],
        contract: ComparisonContract,
    ) -> dict[str, Any]:
        outcomes: list[dict[str, Any]] = []
        for seed in seeds:
            result = compare_rows(
                self.reference_executor(seed),
                self.candidate_executor(seed),
                contract,
            )
            outcomes.append({"seed": seed, **result.to_dict()})
        aggregate = {
            "schema_version": 1,
            "seeds": outcomes,
            "equivalent": bool(outcomes) and all(item["equivalent"] for item in outcomes),
        }
        aggregate["evidence_sha256"] = hashlib.sha256(
            json.dumps(aggregate, sort_keys=True, separators=(",", ":")).encode("utf-8"),
        ).hexdigest().upper()
        return aggregate


def geometries_equal(left: Any, right: Any, tolerance: float = 1e-8) -> bool:
    left_geometry, left_srid = geometry_and_srid(left)
    right_geometry, right_srid = geometry_and_srid(right)
    if left_srid is not None and right_srid is not None and left_srid != right_srid:
        return False
    if left_geometry is None or right_geometry is None:
        return left_geometry is right_geometry
    return bool(equals_exact(left_geometry, right_geometry, tolerance, normalize=True))
