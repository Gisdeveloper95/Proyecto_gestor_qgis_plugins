from __future__ import annotations

from decimal import Decimal, InvalidOperation
import sqlite3
import struct
import time
import re
from collections.abc import Callable, Iterable, Mapping
from pathlib import Path
from typing import Any

from shapely import (
    area,
    boundary,
    buffer,
    centroid,
    contains,
    crosses,
    difference,
    disjoint,
    distance,
    envelope,
    equals,
    from_wkb,
    from_wkt,
    get_coordinate_dimension,
    get_num_geometries,
    get_num_interior_rings,
    get_num_points,
    get_point,
    get_type_id,
    intersection,
    intersects,
    is_empty,
    is_simple,
    is_valid,
    length,
    overlaps,
    point_on_surface,
    relate,
    symmetric_difference,
    to_wkb,
    to_wkt,
    touches,
    union,
    within,
)

from .models import OutputMode

_ENVELOPE_BYTES = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
_TYPE_NAMES = {
    0: "POINT",
    1: "LINESTRING",
    2: "LINEARRING",
    3: "POLYGON",
    4: "MULTIPOINT",
    5: "MULTILINESTRING",
    6: "MULTIPOLYGON",
    7: "GEOMETRYCOLLECTION",
}


def _gpkg_parts(value: bytes) -> tuple[int | None, bytes]:
    if len(value) < 8 or value[:2] != b"GP":
        return None, value
    flags = value[3]
    little_endian = bool(flags & 0b1)
    envelope_code = (flags >> 1) & 0b111
    envelope_bytes = _ENVELOPE_BYTES.get(envelope_code)
    if envelope_bytes is None:
        raise ValueError("invalid_gpkg_envelope")
    byte_order = "<" if little_endian else ">"
    srs_id = struct.unpack(f"{byte_order}i", value[4:8])[0]
    offset = 8 + envelope_bytes
    if offset > len(value):
        raise ValueError("truncated_gpkg_geometry")
    return srs_id, value[offset:]


def geometry_and_srid(value: Any) -> tuple[Any | None, int | None]:
    if value is None:
        return None, None
    if isinstance(value, memoryview):
        value = value.tobytes()
    if isinstance(value, bytearray):
        value = bytes(value)
    if isinstance(value, bytes):
        srid, payload = _gpkg_parts(value)
        return from_wkb(payload), srid
    if isinstance(value, str):
        return from_wkt(value), None
    if hasattr(value, "geom_type"):
        return value, None
    raise ValueError("unsupported_geometry_encoding")


def _geometry(value: Any) -> Any | None:
    return geometry_and_srid(value)[0]


def _binary_predicate(operation: Callable[[Any, Any], Any]) -> Callable[[Any, Any], int | None]:
    def invoke(left: Any, right: Any) -> int | None:
        if left is None or right is None:
            return None
        return int(bool(operation(_geometry(left), _geometry(right))))

    return invoke


def _binary_measure(operation: Callable[[Any, Any], Any]) -> Callable[[Any, Any], float | None]:
    def invoke(left: Any, right: Any) -> float | None:
        if left is None or right is None:
            return None
        return float(operation(_geometry(left), _geometry(right)))

    return invoke


def _unary_measure(operation: Callable[[Any], Any]) -> Callable[[Any], float | None]:
    def invoke(value: Any) -> float | None:
        if value is None:
            return None
        return float(operation(_geometry(value)))

    return invoke


def _geometry_result(operation: Callable[..., Any]) -> Callable[..., bytes | None]:
    def invoke(*values: Any) -> bytes | None:
        if any(value is None for value in values):
            return None
        geometries = [_geometry(value) for value in values]
        return bytes(to_wkb(operation(*geometries), output_dimension=3))

    return invoke


def _register_geos(connection: sqlite3.Connection) -> None:
    predicates = {
        "ST_Contains": contains,
        "ST_Crosses": crosses,
        "ST_Disjoint": disjoint,
        "ST_Equals": equals,
        "ST_Intersects": intersects,
        "ST_Overlaps": overlaps,
        "ST_Touches": touches,
        "ST_Within": within,
    }
    for name, operation in predicates.items():
        connection.create_function(name, 2, _binary_predicate(operation), deterministic=True)
    connection.create_function(
        "ST_Distance",
        2,
        _binary_measure(distance),
        deterministic=True,
    )
    connection.create_function(
        "ST_DWithin",
        3,
        lambda left, right, radius: None
        if left is None or right is None or radius is None
        else int(float(distance(_geometry(left), _geometry(right))) <= float(radius)),
        deterministic=True,
    )
    connection.create_function("ST_Area", 1, _unary_measure(area), deterministic=True)
    connection.create_function("ST_Length", 1, _unary_measure(length), deterministic=True)

    geometry_operations: dict[str, tuple[int, Callable[..., Any]]] = {
        "ST_Boundary": (1, boundary),
        "ST_Centroid": (1, centroid),
        "ST_Difference": (2, difference),
        "ST_Envelope": (1, envelope),
        "ST_Intersection": (2, intersection),
        "ST_PointOnSurface": (1, point_on_surface),
        "ST_SymDifference": (2, symmetric_difference),
        "ST_Union": (2, union),
    }
    for name, (arity, operation) in geometry_operations.items():
        connection.create_function(
            name,
            arity,
            _geometry_result(operation),
            deterministic=True,
        )

    def buffered(value: Any, radius: Any) -> bytes | None:
        if value is None or radius is None:
            return None
        return bytes(to_wkb(buffer(_geometry(value), float(radius)), output_dimension=3))

    connection.create_function("ST_Buffer", 2, buffered, deterministic=True)
    connection.create_function(
        "ST_AsBinary",
        1,
        lambda value: None if value is None else bytes(to_wkb(_geometry(value), output_dimension=3)),
        deterministic=True,
    )
    connection.create_function(
        "ST_AsText",
        1,
        lambda value: None if value is None else str(to_wkt(_geometry(value), rounding_precision=15)),
        deterministic=True,
    )
    connection.create_function(
        "ST_IsEmpty",
        1,
        lambda value: None if value is None else int(bool(is_empty(_geometry(value)))),
        deterministic=True,
    )
    connection.create_function(
        "ST_IsSimple",
        1,
        lambda value: None if value is None else int(bool(is_simple(_geometry(value)))),
        deterministic=True,
    )
    connection.create_function(
        "ST_IsValid",
        1,
        lambda value: None if value is None else int(bool(is_valid(_geometry(value)))),
        deterministic=True,
    )
    connection.create_function(
        "ST_GeometryType",
        1,
        lambda value: None
        if value is None
        else f"ST_{_TYPE_NAMES.get(int(get_type_id(_geometry(value))), 'GEOMETRY')}",
        deterministic=True,
    )
    connection.create_function(
        "GeometryType",
        1,
        lambda value: None
        if value is None
        else _TYPE_NAMES.get(int(get_type_id(_geometry(value))), "GEOMETRY"),
        deterministic=True,
    )
    connection.create_function(
        "ST_Dimension",
        1,
        lambda value: None
        if value is None
        else int(get_coordinate_dimension(_geometry(value))),
        deterministic=True,
    )
    connection.create_function(
        "ST_NumGeometries",
        1,
        lambda value: None if value is None else int(get_num_geometries(_geometry(value))),
        deterministic=True,
    )
    connection.create_function(
        "ST_NumInteriorRings",
        1,
        lambda value: None if value is None else int(get_num_interior_rings(_geometry(value))),
        deterministic=True,
    )
    connection.create_function(
        "ST_NumPoints",
        1,
        lambda value: None if value is None else int(get_num_points(_geometry(value))),
        deterministic=True,
    )
    connection.create_function(
        "ST_Relate",
        2,
        lambda left, right: None
        if left is None or right is None
        else str(relate(_geometry(left), _geometry(right))),
        deterministic=True,
    )
    connection.create_function(
        "ST_SRID",
        1,
        lambda value: None if value is None else geometry_and_srid(value)[1],
        deterministic=True,
    )

    def point_coordinate(value: Any, index: int) -> float | None:
        if value is None:
            return None
        point = get_point(_geometry(value), 0)
        coordinates = tuple(point.coords[0])
        return float(coordinates[index]) if len(coordinates) > index else None

    connection.create_function("ST_X", 1, lambda value: point_coordinate(value, 0), deterministic=True)
    connection.create_function("ST_Y", 1, lambda value: point_coordinate(value, 1), deterministic=True)
    connection.create_function(
        "ST_StartPoint",
        1,
        lambda value: None
        if value is None
        else bytes(to_wkb(get_point(_geometry(value), 0), output_dimension=3)),
        deterministic=True,
    )
    connection.create_function(
        "ST_EndPoint",
        1,
        lambda value: None
        if value is None
        else bytes(to_wkb(get_point(_geometry(value), -1), output_dimension=3)),
        deterministic=True,
    )
    connection.create_function(
        "ASCII",
        1,
        lambda value: None if value is None else (ord(str(value)[0]) if str(value) else 0),
        deterministic=True,
    )
    connection.create_function(
        "BTRIM",
        1,
        lambda value: None if value is None else str(value).strip(),
        deterministic=True,
    )
    connection.create_function(
        "LEFT",
        2,
        lambda value, count: None if value is None or count is None else str(value)[: int(count)],
        deterministic=True,
    )
    connection.create_function(
        "RIGHT",
        2,
        lambda value, count: None
        if value is None or count is None
        else str(value)[-int(count) :] if int(count) else "",
        deterministic=True,
    )

    def split_part(value: Any, delimiter: Any, field: Any) -> str | None:
        if value is None or delimiter is None or field is None:
            return None
        index = int(field)
        if index == 0:
            raise ValueError("split_part_field_zero")
        parts = str(value).split(str(delimiter))
        try:
            return parts[index - 1] if index > 0 else parts[index]
        except IndexError:
            return ""

    connection.create_function("SPLIT_PART", 3, split_part, deterministic=True)

    def pg_cast_text(value: Any, scale: Any) -> str | None:
        if value is None:
            return None
        requested_scale = int(scale) if scale is not None else -1
        if isinstance(value, (int, float)):
            try:
                numeric = Decimal(str(value))
            except InvalidOperation:
                return str(value)
            if requested_scale >= 0:
                return format(numeric, ".{0}f".format(requested_scale))
            rendered = format(numeric, "f")
            if "." in rendered:
                rendered = rendered.rstrip("0").rstrip(".")
            return "0" if rendered in {"-0", ""} else rendered
        return str(value)

    connection.create_function(
        "PG_CAST_TEXT",
        2,
        pg_cast_text,
        deterministic=True,
    )
    connection.create_function(
        "REGEXP_LIKE",
        2,
        lambda value, pattern: None
        if value is None or pattern is None
        else int(re.search(str(pattern), str(value)) is not None),
        deterministic=True,
    )


class PortableExecutor:
    def __init__(
        self,
        source: str | Path | sqlite3.Connection,
        *,
        timeout_seconds: float = 30.0,
        row_limit: int = 100_000,
        cancellation_check: Callable[[], bool] | None = None,
    ) -> None:
        self._owns_connection = not isinstance(source, sqlite3.Connection)
        if isinstance(source, sqlite3.Connection):
            self.connection = source
        else:
            uri = Path(source).resolve().as_uri() + "?mode=ro"
            self.connection = sqlite3.connect(uri, uri=True, check_same_thread=False)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA query_only = ON")
        self.connection.execute("PRAGMA trusted_schema = OFF")
        _register_geos(self.connection)
        self.timeout_seconds = max(0.05, timeout_seconds)
        self.row_limit = max(1, row_limit)
        self.cancellation_check = cancellation_check

    def close(self) -> None:
        if self._owns_connection:
            self.connection.close()

    def __enter__(self) -> PortableExecutor:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def execute_plan(self, plan: Mapping[str, Any]) -> list[dict[str, Any]]:
        if int(plan.get("schema_version", 0)) != 1:
            raise ValueError("unsupported_plan_schema")
        sql = plan.get("sqlite_sql")
        if not isinstance(sql, str) or not sql.strip():
            raise ValueError("portable_sql_missing")
        deadline = time.monotonic() + self.timeout_seconds

        def progress() -> int:
            if time.monotonic() >= deadline:
                return 1
            if self.cancellation_check and self.cancellation_check():
                return 1
            return 0

        self.connection.set_progress_handler(progress, 2_000)
        try:
            cursor = self.connection.execute(sql)
            output_types = plan.get("output_types", {})
            boolean_columns = {
                str(column)
                for column, type_name in (
                    output_types.items()
                    if isinstance(output_types, Mapping)
                    else ()
                )
                if str(type_name).upper() == "BOOLEAN"
            }
            rows: list[dict[str, Any]] = []
            while True:
                batch = cursor.fetchmany(min(1_000, self.row_limit + 1 - len(rows)))
                if not batch:
                    break
                for item in batch:
                    row = dict(item)
                    for column in boolean_columns:
                        if row.get(column) is not None:
                            row[column] = bool(row[column])
                    rows.append(row)
                if len(rows) > self.row_limit:
                    raise RuntimeError("portable_row_limit_exceeded")
            return rows
        except sqlite3.OperationalError as exc:
            if "interrupted" in str(exc).lower():
                raise TimeoutError("portable_execution_interrupted") from exc
            raise
        finally:
            self.connection.set_progress_handler(None, 0)

    def execute_compiled(
        self,
        mode: OutputMode | str,
        sqlite_sql: str | None,
        portable_plan: Mapping[str, Any] | None,
    ) -> list[dict[str, Any]]:
        resolved_mode = OutputMode(mode)
        if resolved_mode is OutputMode.MANUAL_REQUIRED:
            raise ValueError("manual_homologation_required")
        if resolved_mode is OutputMode.PYTHON_ADAPTER_CANDIDATE:
            raise ValueError("review_required")
        plan = portable_plan or {
            "schema_version": 1,
            "sqlite_sql": sqlite_sql,
        }
        return self.execute_plan(plan)


def load_rows(
    connection: sqlite3.Connection,
    table: str,
    columns: Iterable[str],
    rows: Iterable[Iterable[Any]],
) -> None:
    column_list = tuple(columns)
    if not column_list:
        raise ValueError("columns_required")
    quoted_table = '"' + table.replace('"', '""') + '"'
    quoted_columns = ", ".join('"' + item.replace('"', '""') + '"' for item in column_list)
    placeholders = ", ".join("?" for _ in column_list)
    connection.executemany(
        f"INSERT INTO {quoted_table} ({quoted_columns}) VALUES ({placeholders})",
        rows,
    )
