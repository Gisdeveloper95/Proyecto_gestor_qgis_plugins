from __future__ import annotations

from dataclasses import dataclass

from sqlglot import exp, parse
from sqlglot.errors import ParseError

from .models import Diagnostic, DiagnosticLevel


@dataclass(frozen=True, slots=True)
class PolicyResult:
    expression: exp.Query | None
    diagnostics: tuple[Diagnostic, ...]

    @property
    def accepted(self) -> bool:
        return self.expression is not None and not any(
            item.level is DiagnosticLevel.ERROR for item in self.diagnostics
        )


_PROHIBITED_NODES = (
    exp.Alter,
    exp.Command,
    exp.Create,
    exp.Delete,
    exp.Drop,
    exp.Insert,
    exp.Merge,
    exp.Transaction,
    exp.Update,
)


def validate_select_only(sql: str, *, max_bytes: int = 2 * 1024 * 1024) -> PolicyResult:
    if not sql.strip():
        return PolicyResult(
            None,
            (Diagnostic("empty_sql", "La consulta está vacía."),),
        )
    if len(sql.encode("utf-8")) > max_bytes:
        return PolicyResult(
            None,
            (Diagnostic("sql_too_large", "La consulta supera el límite permitido."),),
        )
    try:
        expressions = [item for item in parse(sql, read="postgres") if item is not None]
    except ParseError as exc:
        return PolicyResult(
            None,
            (
                Diagnostic(
                    "postgres_parse_failed",
                    "PostgreSQL no pudo analizar la consulta.",
                    details={"error": str(exc)[:500]},
                ),
            ),
        )
    if len(expressions) != 1:
        return PolicyResult(
            None,
            (
                Diagnostic(
                    "multiple_statements",
                    "Solo se admite una sentencia SELECT o WITH.",
                    details={"statement_count": len(expressions)},
                ),
            ),
        )
    expression = expressions[0]
    if not isinstance(expression, exp.Query):
        return PolicyResult(
            None,
            (Diagnostic("read_only_required", "Solo se admite SELECT o WITH."),),
        )
    prohibited = sorted(
        {
            node.key.upper()
            for node in expression.walk()
            if isinstance(node, _PROHIBITED_NODES)
        },
    )
    if prohibited:
        return PolicyResult(
            None,
            (
                Diagnostic(
                    "write_operation",
                    "La consulta contiene operaciones no permitidas.",
                    details={"nodes": prohibited},
                ),
            ),
        )
    if expression.find(exp.Into):
        return PolicyResult(
            None,
            (
                Diagnostic(
                    "select_into_blocked",
                    "SELECT INTO no está permitido.",
                ),
            ),
        )
    return PolicyResult(expression, ())
