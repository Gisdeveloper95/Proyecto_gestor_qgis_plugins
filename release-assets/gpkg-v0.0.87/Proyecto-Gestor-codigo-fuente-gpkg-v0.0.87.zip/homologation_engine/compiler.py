from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping
from typing import Any

from sqlglot import exp
from sqlglot.errors import ErrorLevel, UnsupportedError
from sqlglot.optimizer.annotate_types import annotate_types
from sqlglot.optimizer.scope import traverse_scope

from .models import (
    CompileRequest,
    CompileResult,
    Diagnostic,
    DiagnosticLevel,
    HomologationBatchResult,
    OutputMode,
)
from .policy import validate_select_only

ENGINE_VERSION = "0.0.6"

# SQL functions whose semantics are supplied by SQLite itself or by SQLGlot's
# PostgreSQL-to-SQLite transpilation. This is deliberately domain-neutral.
_PORTABLE_FUNCTIONS = {
    "ABS",
    "AND",
    "AVG",
    "CAST",
    "CASE",
    "CEIL",
    "COALESCE",
    "CONCAT",
    "COUNT",
    "CURRENT_DATE",
    "CURRENT_TIME",
    "CURRENT_TIMESTAMP",
    "DATE",
    "DENSE_RANK",
    "FLOOR",
    "GROUP_CONCAT",
    "IFNULL",
    "IF",
    "IIF",
    "INSTR",
    "LAG",
    "LEAD",
    "LENGTH",
    "LOWER",
    "LTRIM",
    "MAX",
    "MIN",
    "NULLIF",
    "OR",
    "PRINTF",
    "RANK",
    "REPLACE",
    "ROUND",
    "ROW_NUMBER",
    "RTRIM",
    "STRFTIME",
    "SUBSTR",
    "SUBSTRING",
    "SUM",
    "TRIM",
    "UPPER",
}

# Scalar compatibility functions supplied by the generic SQLite runtime.
_RUNTIME_SCALAR_FUNCTIONS = {
    "ASCII",
    "BTRIM",
    "LEFT",
    "PG_CAST_TEXT",
    "REGEXP_LIKE",
    "RIGHT",
    "SPLIT_PART",
}

# General GEOS operations implemented by the portable runtime.
_GEOS_FUNCTIONS = {
    "ST_AREA",
    "ST_ASBINARY",
    "ST_ASTEXT",
    "ST_BOUNDARY",
    "ST_BUFFER",
    "ST_CENTROID",
    "ST_CONTAINS",
    "ST_CROSSES",
    "ST_DIFFERENCE",
    "ST_DIMENSION",
    "ST_DISJOINT",
    "ST_DISTANCE",
    "ST_DWITHIN",
    "ST_ENDPOINT",
    "ST_ENVELOPE",
    "ST_EQUALS",
    "ST_GEOMETRYTYPE",
    "ST_INTERSECTION",
    "ST_INTERSECTS",
    "ST_ISEMPTY",
    "ST_ISSIMPLE",
    "ST_ISVALID",
    "ST_LENGTH",
    "ST_NUMGEOMETRIES",
    "ST_NUMINTERIORRINGS",
    "ST_NUMPOINTS",
    "ST_OVERLAPS",
    "ST_POINTONSURFACE",
    "ST_RELATE",
    "ST_SRID",
    "ST_STARTPOINT",
    "ST_SYMDIFFERENCE",
    "ST_TOUCHES",
    "ST_UNION",
    "ST_WITHIN",
    "ST_X",
    "ST_Y",
}

# These have portable implementations in principle, but require a dependency
# or semantic contract outside GEOS. The compiler emits a review-only candidate.
_REVIEW_ONLY_FUNCTIONS = {
    "ST_CLUSTERDBSCAN",
    "ST_MAKEVALID",
    "ST_SNAPTOGRID",
    "ST_SUBDIVIDE",
    "ST_TRANSFORM",
}

_UNSUPPORTED_NODE_TYPES = (
    exp.Array,
    exp.Explode,
    exp.JSONExtract,
    exp.JSONExtractScalar,
    exp.Lateral,
    exp.Pivot,
    exp.Unnest,
)


def _stable_json(value: Any) -> str:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest().upper()


def _function_name(node: exp.Func) -> str:
    if isinstance(node, exp.Anonymous):
        return str(node.name).upper()
    try:
        value = node.sql_name()
    except Exception:
        value = node.key
    return str(value or node.key).upper()


def _collect_functions(expression: exp.Expression) -> tuple[str, ...]:
    return tuple(
        sorted({_function_name(node) for node in expression.walk() if isinstance(node, exp.Func)}),
    )


def _output_columns(expression: exp.Query) -> tuple[str, ...]:
    names: list[str] = []
    for item in expression.selects:
        name = item.alias_or_name
        if name:
            names.append(name)
    return tuple(names)


def _output_types(expression: exp.Query) -> dict[str, str]:
    annotated = annotate_types(expression.copy())
    output: dict[str, str] = {}
    for item in annotated.selects:
        name = item.alias_or_name
        type_name = str(item.type).upper()
        if name and type_name not in {"", "UNKNOWN"}:
            output[name] = type_name
    return output


def _logical_table_name(table: exp.Table) -> str:
    parts = [part for part in (table.catalog, table.db, table.name) if part]
    return ".".join(parts)


def _portable_table_name(logical: str, mapping: Mapping[str, str]) -> str:
    exact = mapping.get(logical)
    if exact:
        return exact
    folded = logical.casefold()
    for key, value in mapping.items():
        if key.casefold() == folded:
            return value
    return logical.rsplit(".", 1)[-1]


def _normalize_cte_references(expression: exp.Query) -> exp.Query:
    """Normalize unquoted CTE references using PostgreSQL identifier rules.

    PostgreSQL folds unquoted identifiers case-insensitively. SQLGlot keeps the
    spelling found in the source and its scope resolver can consequently treat
    ``P4 AS (...)`` and ``JOIN p4`` as different physical tables. Normalize
    those references before scope traversal so CTEs can never leak into the
    GeoPackage dependency map.
    """

    rewritten = expression.copy()
    aliases = {
        str(cte.alias).casefold(): str(cte.alias)
        for cte in rewritten.find_all(exp.CTE)
        if str(cte.alias)
    }
    if not aliases:
        return rewritten
    for table in rewritten.find_all(exp.Table):
        if table.catalog or table.db:
            continue
        canonical = aliases.get(str(table.name).casefold())
        if not canonical or str(table.name) == canonical:
            continue
        table.set("this", exp.to_identifier(canonical))
    return rewritten


def _rewrite_tables(
    expression: exp.Query,
    mapping: Mapping[str, str],
) -> tuple[exp.Query, dict[str, str]]:
    rewritten = _normalize_cte_references(expression)
    resolved: dict[str, str] = {}
    physical_tables = {
        id(source)
        for scope in traverse_scope(rewritten)
        for _, (_, source) in scope.selected_sources.items()
        if isinstance(source, exp.Table)
    }
    for table in rewritten.find_all(exp.Table):
        # A CTE reference is represented as exp.Table by SQLGlot, but its
        # selected source is another Scope. It must remain an internal query
        # name and must never be resolved as a GeoPackage layer.
        if id(table) not in physical_tables:
            continue
        logical = _logical_table_name(table)
        if not logical:
            continue
        physical = _portable_table_name(logical, mapping)
        resolved[logical] = physical
        table.set("catalog", None)
        table.set("db", None)
        table.set("this", exp.to_identifier(physical, quoted=True))
    return rewritten, resolved


def _rewrite_temporal_casts(expression: exp.Query) -> exp.Query:
    """Preserve temporal values instead of SQLite's numeric CAST affinity.

    SQLite accepts arbitrary type names in CAST, but names such as TIMESTAMP
    have NUMERIC affinity.  Casting an ISO timestamp therefore yields only its
    leading year.  The built-in date/time functions preserve a portable text
    representation with the intended logical type.
    """

    rewritten = expression.copy()
    temporal_functions = {
        exp.DataType.Type.DATE: "DATE",
        exp.DataType.Type.DATETIME: "DATETIME",
        exp.DataType.Type.TIME: "TIME",
        exp.DataType.Type.TIMESTAMP: "DATETIME",
        exp.DataType.Type.TIMESTAMPTZ: "DATETIME",
        exp.DataType.Type.TIMESTAMPLTZ: "DATETIME",
    }
    for cast in tuple(rewritten.find_all(exp.Cast)):
        target = cast.args.get("to")
        if not isinstance(target, exp.DataType):
            continue
        function_name = temporal_functions.get(target.this)
        if not function_name:
            continue
        cast.replace(
            exp.Anonymous(
                this=function_name,
                expressions=[cast.this.copy()],
            )
        )
    return rewritten


def _rewrite_text_casts(expression: exp.Query) -> exp.Query:
    """Render PostgreSQL numeric-to-text casts deterministically in SQLite."""

    rewritten = expression.copy()
    text_types = {
        "CHAR",
        "CHARACTER",
        "NCHAR",
        "NVARCHAR",
        "TEXT",
        "VARCHAR",
    }
    for cast in tuple(rewritten.find_all(exp.Cast)):
        target = cast.args.get("to")
        if not isinstance(target, exp.DataType):
            continue
        target_name = str(target.sql()).upper().split("(", 1)[0].strip()
        if target_name not in text_types:
            continue
        scale = -1
        source = cast.this
        if isinstance(source, exp.Round):
            decimals = source.args.get("decimals")
            if isinstance(decimals, exp.Literal) and not decimals.is_string:
                try:
                    scale = int(decimals.this)
                except (TypeError, ValueError):
                    scale = -1
        cast.replace(
            exp.Anonymous(
                this="PG_CAST_TEXT",
                expressions=[source.copy(), exp.Literal.number(scale)],
            )
        )
    return rewritten


def _unsupported_nodes(expression: exp.Expression) -> tuple[str, ...]:
    return tuple(
        sorted(
            {
                type(node).__name__
                for node in expression.walk()
                if isinstance(node, _UNSUPPORTED_NODE_TYPES)
            },
        ),
    )


class HomologationCompiler:
    """Compile SQL through a domain-neutral AST and capability registry."""

    def compile(self, request: CompileRequest) -> CompileResult:
        input_sha256 = _sha256_text(request.sql.replace("\r\n", "\n").replace("\r", "\n"))
        policy = validate_select_only(request.sql)
        if not policy.accepted or policy.expression is None:
            return self._result(
                input_sha256=input_sha256,
                mode=OutputMode.MANUAL_REQUIRED,
                sqlite_sql=None,
                plan=None,
                output_columns=(),
                capabilities=(),
                diagnostics=policy.diagnostics,
            )

        expression = policy.expression
        output_columns = _output_columns(expression)
        output_types = _output_types(expression)
        diagnostics: list[Diagnostic] = []
        if request.expected_columns and tuple(request.expected_columns) != output_columns:
            diagnostics.append(
                Diagnostic(
                    "output_contract_mismatch",
                    "Las columnas proyectadas no coinciden con el contrato declarado.",
                    details={
                        "declared": list(request.expected_columns),
                        "projected": list(output_columns),
                    },
                ),
            )

        unsupported_nodes = _unsupported_nodes(expression)
        if unsupported_nodes:
            diagnostics.append(
                Diagnostic(
                    "unsupported_ast",
                    "La consulta usa construcciones todavía no representables de forma segura.",
                    details={"nodes": list(unsupported_nodes)},
                ),
            )

        functions = _collect_functions(expression)
        unknown_functions = tuple(
            sorted(
                name
                for name in functions
                if name not in _PORTABLE_FUNCTIONS
                and name not in _RUNTIME_SCALAR_FUNCTIONS
                and name not in _GEOS_FUNCTIONS
                and name not in _REVIEW_ONLY_FUNCTIONS
            ),
        )
        if unknown_functions:
            diagnostics.append(
                Diagnostic(
                    "unsupported_functions",
                    "La consulta requiere funciones sin semántica portable registrada.",
                    details={"functions": list(unknown_functions)},
                ),
            )

        if any(item.level is DiagnosticLevel.ERROR for item in diagnostics):
            return self._result(
                input_sha256=input_sha256,
                mode=OutputMode.MANUAL_REQUIRED,
                sqlite_sql=None,
                plan=None,
                output_columns=output_columns,
                capabilities=functions,
                diagnostics=tuple(diagnostics),
            )

        rewritten, resolved_tables = _rewrite_tables(expression, request.table_mapping)
        rewritten = _rewrite_temporal_casts(rewritten)
        rewritten = _rewrite_text_casts(rewritten)
        functions = _collect_functions(rewritten)
        try:
            sqlite_sql = rewritten.sql(
                dialect="sqlite",
                pretty=True,
                unsupported_level=ErrorLevel.RAISE,
            )
        except (UnsupportedError, ValueError) as exc:
            diagnostics.append(
                Diagnostic(
                    "sqlite_generation_failed",
                    "No fue posible generar SQL SQLite determinista.",
                    details={"error": str(exc)[:500]},
                ),
            )
            return self._result(
                input_sha256=input_sha256,
                mode=OutputMode.MANUAL_REQUIRED,
                sqlite_sql=None,
                plan=None,
                output_columns=output_columns,
                capabilities=functions,
                diagnostics=tuple(diagnostics),
            )

        runtime_functions = tuple(
            name
            for name in functions
            if name in _GEOS_FUNCTIONS or name in _RUNTIME_SCALAR_FUNCTIONS
        )
        review_functions = tuple(name for name in functions if name in _REVIEW_ONLY_FUNCTIONS)
        if review_functions:
            mode = OutputMode.PYTHON_ADAPTER_CANDIDATE
            diagnostics.append(
                Diagnostic(
                    "review_required",
                    "Se generó un candidato portable que requiere revisión técnica.",
                    level=DiagnosticLevel.WARNING,
                    details={"functions": list(review_functions)},
                ),
            )
        elif runtime_functions:
            mode = OutputMode.PORTABLE_IR
        else:
            mode = OutputMode.SQLITE_SQL

        plan = {
            "schema_version": 1,
            "engine_version": ENGINE_VERSION,
            "executor": "sqlite-geos-v1" if runtime_functions or review_functions else "sqlite-v1",
            "sqlite_sql": sqlite_sql,
            "resolved_tables": resolved_tables,
            "required_functions": list(functions),
            "geometry_columns": list(request.geometry_columns),
            "expected_columns": list(request.expected_columns or output_columns),
            "output_types": output_types,
            "review_required": bool(review_functions),
        }
        diagnostics.append(
            Diagnostic(
                "differential_verification_required",
                "La compilación es candidata; la paridad solo se declara tras comparación diferencial.",
                level=DiagnosticLevel.INFO,
            ),
        )
        return self._result(
            input_sha256=input_sha256,
            mode=mode,
            sqlite_sql=sqlite_sql,
            plan=plan,
            output_columns=output_columns,
            capabilities=functions,
            diagnostics=tuple(diagnostics),
            review_required=bool(review_functions),
        )

    def compile_batch(
        self,
        requests: Iterable[CompileRequest],
        *,
        engine_sha256: str,
        verified_keys: Iterable[str] = (),
    ) -> HomologationBatchResult:
        request_list = tuple(requests)
        results = tuple(self.compile(item) for item in request_list)
        verified = set(verified_keys)
        allowed = bool(results) and all(
            result.compilable
            and not result.review_required
            and request.opaque_key in verified
            for request, result in zip(request_list, results, strict=True)
        )
        return HomologationBatchResult(
            engine_version=ENGINE_VERSION,
            engine_sha256=engine_sha256,
            results=results,
            gpkg_build_allowed=allowed,
        )

    @staticmethod
    def _result(
        *,
        input_sha256: str,
        mode: OutputMode,
        sqlite_sql: str | None,
        plan: dict[str, Any] | None,
        output_columns: tuple[str, ...],
        capabilities: tuple[str, ...],
        diagnostics: tuple[Diagnostic, ...],
        review_required: bool = False,
    ) -> CompileResult:
        subject = {
            "engine_version": ENGINE_VERSION,
            "input_sha256": input_sha256,
            "mode": mode.value,
            "sqlite_sql": sqlite_sql,
            "portable_plan": plan,
            "output_columns": output_columns,
            "required_capabilities": capabilities,
            "review_required": review_required,
        }
        return CompileResult(
            engine_version=ENGINE_VERSION,
            input_sha256=input_sha256,
            mode=mode,
            sqlite_sql=sqlite_sql,
            portable_plan=plan,
            output_columns=output_columns,
            required_capabilities=capabilities,
            diagnostics=diagnostics,
            plan_sha256=_sha256_text(_stable_json(subject)),
            review_required=review_required,
        )
