from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any

from shapely import Point, Polygon, to_wkb


@dataclass(frozen=True, slots=True)
class ColumnContract:
    name: str
    logical_type: str
    nullable: bool = True


@dataclass(frozen=True, slots=True)
class TableContract:
    logical_name: str
    columns: tuple[ColumnContract, ...]
    row_count: int = 24


def _value(column: ColumnContract, index: int, rng: random.Random) -> Any:
    if column.nullable and index % 11 == 0:
        return None
    logical_type = column.logical_type.casefold()
    if logical_type in {"integer", "bigint", "smallint"}:
        return index - 3
    if logical_type in {"numeric", "decimal", "real", "double"}:
        return round((index - 5) * 1.25 + rng.random() / 100, 6)
    if logical_type in {"boolean", "bool"}:
        return int(index % 3 == 0)
    if logical_type in {"date"}:
        return f"2026-{(index % 12) + 1:02d}-{(index % 27) + 1:02d}"
    if logical_type in {"timestamp", "datetime"}:
        return f"2026-{(index % 12) + 1:02d}-{(index % 27) + 1:02d}T12:34:56"
    if logical_type in {"geometry", "point"}:
        return bytes(to_wkb(Point(index, rng.randint(-5, 5))))
    if logical_type == "polygon":
        x = float(index)
        return bytes(
            to_wkb(
                Polygon(
                    [
                        (x, 0.0),
                        (x + 1.0, 0.0),
                        (x + 1.0, 1.0),
                        (x, 1.0),
                        (x, 0.0),
                    ],
                ),
            ),
        )
    if logical_type in {"blob", "binary"}:
        return f"blob-{index}".encode()
    return ["", "Árbol", "alpha", "BETA", "0", "  trim  ", f"value-{index % 7}"][index % 7]


def generate_table_rows(contract: TableContract, seed: int) -> list[dict[str, Any]]:
    rng = random.Random(f"{contract.logical_name}:{seed}")
    return [
        {column.name: _value(column, index, rng) for column in contract.columns}
        for index in range(contract.row_count)
    ]
