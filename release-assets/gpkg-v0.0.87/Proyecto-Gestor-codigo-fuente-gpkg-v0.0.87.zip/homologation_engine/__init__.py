"""Clean-room compiler from PostgreSQL/PostGIS SQL to portable GeoPackage plans."""

from .compiler import ENGINE_VERSION, HomologationCompiler
from .equivalence import ComparisonContract, DifferentialVerifier
from .models import (
    CompileRequest,
    CompileResult,
    Diagnostic,
    HomologationBatchResult,
    OutputMode,
)
from .runtime import PortableExecutor

__all__ = [
    "ENGINE_VERSION",
    "ComparisonContract",
    "CompileRequest",
    "CompileResult",
    "Diagnostic",
    "DifferentialVerifier",
    "HomologationBatchResult",
    "HomologationCompiler",
    "OutputMode",
    "PortableExecutor",
]
