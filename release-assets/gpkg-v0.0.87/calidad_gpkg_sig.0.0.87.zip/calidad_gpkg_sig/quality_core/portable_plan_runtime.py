"""Fail-closed executor for generated portable homologation plans.

This module is deliberately domain neutral.  It knows about the generated
plan contract, SQLite, GeoPackage geometry blobs and the geometry engine
shipped with QGIS, but it does not know rule identifiers or catalog families.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import re
import sqlite3
import struct
import time
from typing import Any


PLAN_SCHEMA_VERSION = 1
DEFAULT_TIMEOUT_SECONDS = 30.0
DEFAULT_ROW_LIMIT = 100_000
_GPKG_ENVELOPE_BYTES = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}
_REGISTERED_GEOMETRY_FUNCTIONS = {
    "ST_AREA",
    "ST_ASBINARY",
    "ST_ASTEXT",
    "ST_BOUNDARY",
    "ST_BUFFER",
    "ST_CENTROID",
    "ST_CONTAINS",
    "ST_CROSSES",
    "ST_DIFFERENCE",
    "ST_DIMENSION",
    "ST_DISJOINT",
    "ST_DISTANCE",
    "ST_DWITHIN",
    "ST_ENDPOINT",
    "ST_ENVELOPE",
    "ST_EQUALS",
    "ST_GEOMETRYTYPE",
    "ST_INTERSECTION",
    "ST_INTERSECTS",
    "ST_ISEMPTY",
    "ST_ISSIMPLE",
    "ST_ISVALID",
    "ST_LENGTH",
    "ST_NUMGEOMETRIES",
    "ST_NUMINTERIORRINGS",
    "ST_NUMPOINTS",
    "ST_OVERLAPS",
    "ST_POINTONSURFACE",
    "ST_RELATE",
    "ST_SRID",
    "ST_STARTPOINT",
    "ST_SYMDIFFERENCE",
    "ST_TOUCHES",
    "ST_UNION",
    "ST_WITHIN",
    "ST_X",
    "ST_Y",
}


def _quote_identifier(value: str) -> str:
    return '"' + str(value).replace('"', '""') + '"'


def _gpkg_wkb(value: Any) -> tuple[bytes | None, int | None]:
    if value is None:
        return None, None
    if isinstance(value, memoryview):
        value = value.tobytes()
    if isinstance(value, bytearray):
        value = bytes(value)
    if not isinstance(value, bytes):
        return None, None
    if len(value) < 8 or value[:2] != b"GP":
        return value, None
    flags = value[3]
    envelope_size = _GPKG_ENVELOPE_BYTES.get((flags >> 1) & 0b111)
    if envelope_size is None:
        raise ValueError("Cabecera geometrica GeoPackage invalida.")
    byte_order = "<" if flags & 0b1 else ">"
    srid = struct.unpack(byte_order + "i", value[4:8])[0]
    offset = 8 + envelope_size
    if offset > len(value):
        raise ValueError("Geometria GeoPackage truncada.")
    return value[offset:], srid


def _qgis_geometry(value: Any):
    if value is None:
        return None
    try:
        from qgis.core import QgsGeometry
    except ImportError as exc:
        raise RuntimeError(
            "El plan requiere geometria y debe ejecutarse dentro de QGIS."
        ) from exc
    if isinstance(value, str):
        geometry = QgsGeometry.fromWkt(value)
    else:
        wkb, _srid = _gpkg_wkb(value)
        if wkb is None:
            return None
        geometry = QgsGeometry()
        geometry.fromWkb(wkb)
        if geometry.isNull():
            raise ValueError("No fue posible leer la geometria.")
    if geometry.isNull():
        return None
    return geometry


def _geometry_wkb(geometry: Any) -> bytes | None:
    if geometry is None or geometry.isNull():
        return None
    return bytes(geometry.asWkb())


def _binary_predicate(method: str):
    def invoke(left: Any, right: Any) -> int | None:
        if left is None or right is None:
            return None
        first = _qgis_geometry(left)
        second = _qgis_geometry(right)
        if first is None or second is None:
            return None
        return int(bool(getattr(first, method)(second)))

    return invoke


def _binary_geometry(method: str):
    def invoke(left: Any, right: Any) -> bytes | None:
        if left is None or right is None:
            return None
        first = _qgis_geometry(left)
        second = _qgis_geometry(right)
        if first is None or second is None:
            return None
        return _geometry_wkb(getattr(first, method)(second))

    return invoke


def _register_scalar_functions(connection: sqlite3.Connection) -> None:
    connection.create_function(
        "ASCII",
        1,
        lambda value: None
        if value is None
        else (ord(str(value)[0]) if str(value) else 0),
        deterministic=True,
    )
    connection.create_function(
        "BTRIM",
        1,
        lambda value: None if value is None else str(value).strip(),
        deterministic=True,
    )
    connection.create_function(
        "LEFT",
        2,
        lambda value, count: None
        if value is None or count is None
        else str(value)[: int(count)],
        deterministic=True,
    )
    connection.create_function(
        "RIGHT",
        2,
        lambda value, count: None
        if value is None or count is None
        else (str(value)[-int(count) :] if int(count) else ""),
        deterministic=True,
    )

    def split_part(value: Any, delimiter: Any, field: Any) -> str | None:
        if value is None or delimiter is None or field is None:
            return None
        position = int(field)
        if position == 0:
            raise ValueError("SPLIT_PART no acepta la posicion cero.")
        parts = str(value).split(str(delimiter))
        try:
            return parts[position - 1] if position > 0 else parts[position]
        except IndexError:
            return ""

    connection.create_function("SPLIT_PART", 3, split_part, deterministic=True)

    def pg_cast_text(value: Any, scale: Any) -> str | None:
        if value is None:
            return None
        requested_scale = int(scale) if scale is not None else -1
        if isinstance(value, (int, float)):
            try:
                numeric = Decimal(str(value))
            except InvalidOperation:
                return str(value)
            if requested_scale >= 0:
                return format(numeric, ".{0}f".format(requested_scale))
            rendered = format(numeric, "f")
            if "." in rendered:
                rendered = rendered.rstrip("0").rstrip(".")
            return "0" if rendered in {"-0", ""} else rendered
        return str(value)

    connection.create_function(
        "PG_CAST_TEXT",
        2,
        pg_cast_text,
        deterministic=True,
    )
    connection.create_function(
        "REGEXP_LIKE",
        2,
        lambda value, pattern: None
        if value is None or pattern is None
        else int(re.search(str(pattern), str(value)) is not None),
        deterministic=True,
    )


def _register_geometry_functions(connection: sqlite3.Connection) -> None:
    for sql_name, method in {
        "ST_Contains": "contains",
        "ST_Crosses": "crosses",
        "ST_Disjoint": "disjoint",
        "ST_Equals": "equals",
        "ST_Intersects": "intersects",
        "ST_Overlaps": "overlaps",
        "ST_Touches": "touches",
        "ST_Within": "within",
    }.items():
        connection.create_function(
            sql_name,
            2,
            _binary_predicate(method),
            deterministic=True,
        )

    def distance(left: Any, right: Any) -> float | None:
        if left is None or right is None:
            return None
        first = _qgis_geometry(left)
        second = _qgis_geometry(right)
        if first is None or second is None:
            return None
        return float(first.distance(second))

    connection.create_function("ST_Distance", 2, distance, deterministic=True)
    connection.create_function(
        "ST_DWithin",
        3,
        lambda left, right, radius: None
        if left is None or right is None or radius is None
        else int(float(distance(left, right)) <= float(radius)),
        deterministic=True,
    )
    connection.create_function(
        "ST_Area",
        1,
        lambda value: None
        if value is None or _qgis_geometry(value) is None
        else float(_qgis_geometry(value).area()),
        deterministic=True,
    )
    connection.create_function(
        "ST_Length",
        1,
        lambda value: None
        if value is None or _qgis_geometry(value) is None
        else float(_qgis_geometry(value).length()),
        deterministic=True,
    )
    for sql_name, method in {
        "ST_Difference": "difference",
        "ST_Intersection": "intersection",
        "ST_SymDifference": "symDifference",
        "ST_Union": "combine",
    }.items():
        connection.create_function(
            sql_name,
            2,
            _binary_geometry(method),
            deterministic=True,
        )

    def unary_geometry(method: str):
        def invoke(value: Any) -> bytes | None:
            if value is None:
                return None
            geometry = _qgis_geometry(value)
            if geometry is None:
                return None
            return _geometry_wkb(getattr(geometry, method)())

        return invoke

    connection.create_function(
        "ST_Centroid", 1, unary_geometry("centroid"), deterministic=True
    )
    connection.create_function(
        "ST_PointOnSurface",
        1,
        unary_geometry("pointOnSurface"),
        deterministic=True,
    )

    def boundary(value: Any) -> bytes | None:
        if value is None:
            return None
        geometry = _qgis_geometry(value)
        if geometry is None:
            return None
        from qgis.core import QgsGeometry

        return _geometry_wkb(QgsGeometry(geometry.constGet().boundary()))

    connection.create_function("ST_Boundary", 1, boundary, deterministic=True)

    def envelope(value: Any) -> bytes | None:
        if value is None:
            return None
        geometry = _qgis_geometry(value)
        if geometry is None:
            return None
        from qgis.core import QgsGeometry

        return _geometry_wkb(QgsGeometry.fromRect(geometry.boundingBox()))

    connection.create_function("ST_Envelope", 1, envelope, deterministic=True)

    def buffered(value: Any, radius: Any) -> bytes | None:
        if value is None or radius is None:
            return None
        geometry = _qgis_geometry(value)
        if geometry is None:
            return None
        return _geometry_wkb(geometry.buffer(float(radius), 8))

    connection.create_function("ST_Buffer", 2, buffered, deterministic=True)
    connection.create_function(
        "ST_AsBinary",
        1,
        lambda value: None
        if value is None
        else _geometry_wkb(_qgis_geometry(value)),
        deterministic=True,
    )
    connection.create_function(
        "ST_AsText",
        1,
        lambda value: None
        if value is None or _qgis_geometry(value) is None
        else str(_qgis_geometry(value).asWkt(15)),
        deterministic=True,
    )
    connection.create_function(
        "ST_IsEmpty",
        1,
        lambda value: None
        if value is None or _qgis_geometry(value) is None
        else int(_qgis_geometry(value).isEmpty()),
        deterministic=True,
    )
    connection.create_function(
        "ST_IsValid",
        1,
        lambda value: None
        if value is None or _qgis_geometry(value) is None
        else int(_qgis_geometry(value).isGeosValid()),
        deterministic=True,
    )

    connection.create_function(
        "ST_IsSimple",
        1,
        lambda value: None
        if value is None or _qgis_geometry(value) is None
        else int(_qgis_geometry(value).isSimple()),
        deterministic=True,
    )

    def abstract_geometry(value: Any):
        geometry = _qgis_geometry(value)
        return None if geometry is None else geometry.constGet()

    connection.create_function(
        "ST_Dimension",
        1,
        lambda value: None
        if value is None or abstract_geometry(value) is None
        else int(abstract_geometry(value).dimension()),
        deterministic=True,
    )
    connection.create_function(
        "ST_NumGeometries",
        1,
        lambda value: None
        if value is None or abstract_geometry(value) is None
        else int(
            abstract_geometry(value).numGeometries()
            if hasattr(abstract_geometry(value), "numGeometries")
            else 1
        ),
        deterministic=True,
    )
    connection.create_function(
        "ST_NumInteriorRings",
        1,
        lambda value: None
        if value is None
        or abstract_geometry(value) is None
        or not hasattr(abstract_geometry(value), "numInteriorRings")
        else int(abstract_geometry(value).numInteriorRings()),
        deterministic=True,
    )
    connection.create_function(
        "ST_NumPoints",
        1,
        lambda value: None
        if value is None
        or abstract_geometry(value) is None
        or not hasattr(abstract_geometry(value), "numPoints")
        else int(abstract_geometry(value).numPoints()),
        deterministic=True,
    )

    def geometry_type(value: Any) -> str | None:
        geometry = _qgis_geometry(value)
        if geometry is None:
            return None
        from qgis.core import QgsWkbTypes

        flat_type = QgsWkbTypes.flatType(geometry.wkbType())
        return "ST_" + str(QgsWkbTypes.displayString(flat_type)).upper()

    connection.create_function(
        "ST_GeometryType",
        1,
        geometry_type,
        deterministic=True,
    )

    def relate(left: Any, right: Any) -> str | None:
        if left is None or right is None:
            return None
        first = _qgis_geometry(left)
        second = _qgis_geometry(right)
        if first is None or second is None:
            return None
        from qgis.core import QgsGeometry

        engine = QgsGeometry.createGeometryEngine(first.constGet())
        return str(engine.relate(second.constGet()))

    def relate_pattern(left: Any, right: Any, pattern: Any) -> int | None:
        if left is None or right is None or pattern is None:
            return None
        first = _qgis_geometry(left)
        second = _qgis_geometry(right)
        if first is None or second is None:
            return None
        from qgis.core import QgsGeometry

        engine = QgsGeometry.createGeometryEngine(first.constGet())
        return int(bool(engine.relatePattern(second.constGet(), str(pattern))))

    connection.create_function("ST_Relate", 2, relate, deterministic=True)
    connection.create_function(
        "ST_Relate",
        3,
        relate_pattern,
        deterministic=True,
    )

    def endpoint(value: Any, *, end: bool) -> bytes | None:
        abstract = abstract_geometry(value)
        if abstract is None:
            return None
        method = "endPoint" if end else "startPoint"
        if not hasattr(abstract, method):
            return None
        from qgis.core import QgsGeometry

        return _geometry_wkb(QgsGeometry(getattr(abstract, method)()))

    connection.create_function(
        "ST_StartPoint",
        1,
        lambda value: endpoint(value, end=False),
        deterministic=True,
    )
    connection.create_function(
        "ST_EndPoint",
        1,
        lambda value: endpoint(value, end=True),
        deterministic=True,
    )

    def point_coordinate(value: Any, axis: str) -> float | None:
        abstract = abstract_geometry(value)
        if abstract is None or not hasattr(abstract, axis):
            return None
        return float(getattr(abstract, axis)())

    connection.create_function(
        "ST_X",
        1,
        lambda value: point_coordinate(value, "x"),
        deterministic=True,
    )
    connection.create_function(
        "ST_Y",
        1,
        lambda value: point_coordinate(value, "y"),
        deterministic=True,
    )
    connection.create_function(
        "ST_SRID",
        1,
        lambda value: None if value is None else _gpkg_wkb(value)[1],
        deterministic=True,
    )


def _resolve_layer(layer_mapping: Any, logical_name: str, fallback: str) -> str:
    candidates = (
        logical_name,
        logical_name.rsplit(".", 1)[-1],
        fallback,
        fallback.rsplit(".", 1)[-1],
    )
    for candidate in candidates:
        try:
            return str(layer_mapping.resolve(candidate))
        except KeyError:
            continue
    layers = getattr(layer_mapping, "layers", {})
    if isinstance(layers, Mapping):
        folded = {str(key).casefold(): str(value) for key, value in layers.items()}
        for candidate in candidates:
            value = folded.get(candidate.casefold())
            if value:
                return value
    raise KeyError(logical_name)


def _runtime_sql(plan: Mapping[str, Any], layer_mapping: Any) -> str:
    sql = plan.get("sqlite_sql")
    if not isinstance(sql, str) or not sql.strip():
        raise ValueError("El plan portable no contiene SQL SQLite.")
    resolved_tables = plan.get("resolved_tables")
    if not isinstance(resolved_tables, Mapping):
        raise ValueError("El plan portable no contiene el mapa de tablas.")
    replacements: dict[str, str] = {}
    for logical, compiled_physical in resolved_tables.items():
        if not isinstance(logical, str) or not isinstance(compiled_physical, str):
            raise ValueError("El mapa de tablas del plan portable es invalido.")
        replacements[compiled_physical] = _resolve_layer(
            layer_mapping,
            logical,
            compiled_physical,
        )
    for original in sorted(replacements, key=len, reverse=True):
        sql = sql.replace(
            _quote_identifier(original),
            _quote_identifier(replacements[original]),
        )
    return sql


def _stage_data_source(
    connection: sqlite3.Connection,
    data_source: Any,
    layer_mapping: Any,
    plan: Mapping[str, Any],
    *,
    skip_existing: bool = False,
    cancel_check: Callable[[], bool] | None = None,
) -> None:
    resolved_tables = plan.get("resolved_tables", {})
    staged: set[str] = set()
    existing: set[str] = set()
    if skip_existing:
        existing = {
            str(row[0]).casefold()
            for row in connection.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type IN ('table', 'view')"
            )
        }
    for logical, compiled_physical in resolved_tables.items():
        physical = _resolve_layer(layer_mapping, str(logical), str(compiled_physical))
        folded = physical.casefold()
        if folded in staged or folded in existing:
            continue
        staged.add(folded)
        descriptor = data_source.describe(physical)
        fields = tuple(descriptor.fields)
        if not fields:
            raise ValueError("La capa {0} no declara campos.".format(physical))
        connection.execute(
            "CREATE TEMP TABLE {0} ({1})".format(
                _quote_identifier(physical),
                ", ".join(_quote_identifier(field) for field in fields),
            )
        )
        placeholders = ", ".join("?" for _ in fields)
        insert_sql = "INSERT INTO {0} ({1}) VALUES ({2})".format(
            _quote_identifier(physical),
            ", ".join(_quote_identifier(field) for field in fields),
            placeholders,
        )
        def values() -> Iterable[tuple[Any, ...]]:
            for row in data_source.iter_rows(physical, fields):
                if cancel_check is not None and cancel_check():
                    raise InterruptedError(
                        "La ejecucion portable fue cancelada."
                    )
                yield tuple(row.get(field) for field in fields)

        connection.executemany(insert_sql, values())


def _open_connection(
    data_source: Any,
    layer_mapping: Any,
    plan: Mapping[str, Any],
    cancel_check: Callable[[], bool] | None,
):
    source_path = getattr(data_source, "path", None)
    if source_path is not None:
        path = Path(source_path).expanduser().resolve()
        connection = sqlite3.connect(
            path.as_uri() + "?mode=ro",
            uri=True,
            check_same_thread=False,
        )
        connection.execute("PRAGMA temp_store = FILE")
        # Physical GeoPackage tables remain read-only. Entities supplied by
        # the data-source contract but absent from sqlite_master (for example,
        # a derived relational view) are materialized only in SQLite's
        # connection-local TEMP schema and disappear when the run closes.
        try:
            _stage_data_source(
                connection,
                data_source,
                layer_mapping,
                plan,
                skip_existing=True,
                cancel_check=cancel_check,
            )
        except Exception:
            connection.close()
            raise
        return connection
    # An empty SQLite filename creates a private disk-backed temporary
    # database which SQLite removes automatically on close.
    connection = sqlite3.connect("")
    connection.execute("PRAGMA temp_store = FILE")
    connection.execute("PRAGMA journal_mode = OFF")
    connection.execute("PRAGMA synchronous = OFF")
    try:
        _stage_data_source(
            connection,
            data_source,
            layer_mapping,
            plan,
            cancel_check=cancel_check,
        )
    except Exception:
        connection.close()
        raise
    return connection


def load_plan(path: str | Path) -> dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or payload.get("schema_version") != PLAN_SCHEMA_VERSION:
        raise ValueError("Version de plan portable no soportada.")
    if payload.get("review_required") is True:
        raise ValueError("El plan portable aun requiere revision tecnica.")
    if payload.get("equivalence_verified") is not True:
        raise ValueError("El plan portable no tiene equivalencia diferencial aprobada.")
    return payload


def execute_generated_plan(
    plan: Mapping[str, Any],
    data_source: Any,
    layer_mapping: Any,
    cancel_check: Callable[[], bool] | None = None,
) -> Iterable[dict[str, Any]]:
    """Execute one verified generated plan as a bounded lazy iterator."""

    if plan.get("schema_version") != PLAN_SCHEMA_VERSION:
        raise ValueError("Version de plan portable no soportada.")
    if plan.get("review_required") is True:
        raise ValueError("El plan portable aun requiere revision tecnica.")
    if plan.get("equivalence_verified") is not True:
        raise ValueError("El plan portable no tiene equivalencia diferencial aprobada.")
    sql = _runtime_sql(plan, layer_mapping)
    required_functions = {
        str(value).upper() for value in plan.get("required_functions", ())
    }
    unsupported_geometry_functions = {
        name
        for name in required_functions
        if name.startswith("ST_") and name not in _REGISTERED_GEOMETRY_FUNCTIONS
    }
    if unsupported_geometry_functions:
        raise ValueError(
            "El plan requiere funciones geometricas no registradas: {0}.".format(
                ", ".join(sorted(unsupported_geometry_functions))
            )
        )
    connection = _open_connection(
        data_source,
        layer_mapping,
        plan,
        cancel_check,
    )
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA query_only = ON")
    connection.execute("PRAGMA trusted_schema = OFF")
    _register_scalar_functions(connection)
    if any(name.startswith("ST_") or name == "GEOMETRYTYPE" for name in required_functions):
        _register_geometry_functions(connection)
    timeout_seconds = max(
        0.05,
        min(float(plan.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS)), 300.0),
    )
    row_limit = max(1, min(int(plan.get("row_limit", DEFAULT_ROW_LIMIT)), 1_000_000))
    deadline = time.monotonic() + timeout_seconds
    cancelled = False

    def progress() -> int:
        nonlocal cancelled
        if time.monotonic() >= deadline:
            return 1
        if cancel_check is not None and cancel_check():
            cancelled = True
            return 1
        return 0

    connection.set_progress_handler(progress, 2_000)
    output_types = plan.get("output_types", {})
    boolean_columns = {
        str(column)
        for column, type_name in (
            output_types.items() if isinstance(output_types, Mapping) else ()
        )
        if str(type_name).upper() == "BOOLEAN"
    }

    def rows() -> Iterable[dict[str, Any]]:
        cursor = None
        count = 0
        try:
            if cancel_check is not None and cancel_check():
                raise InterruptedError("La ejecucion portable fue cancelada.")
            cursor = connection.execute(sql)
            for row in cursor:
                if cancel_check is not None and cancel_check():
                    raise InterruptedError("La ejecucion portable fue cancelada.")
                count += 1
                if count > row_limit:
                    raise RuntimeError("El plan portable excedio el limite de filas.")
                record = dict(row)
                for column in boolean_columns:
                    if record.get(column) is not None:
                        record[column] = bool(record[column])
                yield record
        except sqlite3.OperationalError as exc:
            if "interrupted" in str(exc).casefold():
                if cancelled:
                    raise InterruptedError(
                        "La ejecucion portable fue cancelada."
                    ) from exc
                raise TimeoutError(
                    "La ejecucion portable excedio el tiempo limite."
                ) from exc
            raise
        finally:
            if cursor is not None:
                cursor.close()
            connection.set_progress_handler(None, 0)
            connection.close()

    return rows()
