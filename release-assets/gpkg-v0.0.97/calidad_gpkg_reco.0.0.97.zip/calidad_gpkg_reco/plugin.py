# -*- coding: utf-8 -*-
"""Generated QGIS plugin for the separate Calidad GPKG edition."""

from __future__ import annotations

import csv
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sqlite3
import tempfile
import time
import traceback
import unicodedata
import uuid
import zipfile

from qgis.PyQt.QtCore import QSettings, QSize, Qt, QThread, QTimer, QVariant, QUrl, pyqtSignal
from qgis.PyQt.QtGui import QColor, QDesktopServices, QFont, QIcon, QPalette
from qgis.PyQt.QtWidgets import (
    QAction,
    QAbstractItemView,
    QAbstractScrollArea,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDockWidget,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QProgressDialog,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QStyledItemDelegate,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QToolButton,
    QStyle,
    QStyleOptionViewItem,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsApplication,
    QgsAuthMethodConfig,
    QgsExpression,
    QgsFeature,
    QgsFeatureRequest,
    QgsFeedback,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsMapLayerStyle,
    QgsProject,
    QgsRelation,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)

from .quality_core.atomic_output import AtomicOutput, remove_with_retry
from .quality_core.excel_report import (
    validate_excel_package_manifest,
    write_quality_report_package_streaming,
)
from .quality_core.package_scope import load_package_rule_scope
from .quality_core.reco_filter_policy import (
    RECO_FILTER_DEFINITIONS,
    iter_portable_reco_scope,
    normalize_reco_filter_policy,
    reco_filter_policy_active,
    reco_filter_policy_summary,
)

from .quality_core.portable import (
    GeoPackageDataSource,
    LayerMapping,
    MappingDataSource,
    PortableRuleBackend,
    backup_geopackage,
    load_portable_manifest,
)
from .quality_core.portable_integrity import (
    resolve_package_file,
    verify_execution_bundle,
)
from .quality_core.portable_store import (
    DEFAULT_PAGE_SIZE,
    PORTABLE_EXPORT_COLUMNS,
    PortableResultStore,
    PortableStoreCancelled,
    csv_safe_value,
    display_value,
    is_truthy,
    presentation_columns,
)
from .quality_core.processing_filter_policy import (
    DEFAULT_PROCESSING_FILTER_POLICY,
    DISABLED_PROCESSING_FILTER_POLICY,
    PROFILE_AUTO,
    PROFILE_CONDOMINIO,
    PROFILE_INFORMALIDAD,
    PROFILE_LABELS,
    PROFILE_NPH,
    PROFILE_PH,
    PROFILE_PH_MATRIZ,
    effective_rule_filter_profile,
    iter_processing_allowed_predio_ids,
    normalize_processing_filter_policy,
    processing_filter_summary,
    processing_profile_active,
    processing_required_fields,
    profiles_for_rules,
    rule_filter_profile,
)
from .quality_core.profile_registry_client import (
    ProfileRegistryClient,
    ProfileRegistryError,
    ProfileRegistryHttpError,
)


PLUGIN_NAME = "Calidad GPKG Reco"
PLUGIN_FAMILY = "reco"
CANONICAL_RULE_COUNT = int("71")
PORTABLE_RULE_COUNT = int("71")
SETTINGS_PREFIX = "MapingTool/CalidadGPKG/{0}".format(PLUGIN_FAMILY)
TOP_MENU_NAME = "Calidad GPKG"
TOP_MENU_OBJECT_NAME = "MapingToolCalidadGpkgTopMenu"
TOOLBAR_OBJECT_NAME = "MapingToolCalidadGpkgToolbar"
TOOLBUTTON_OBJECT_NAME = "MapingToolCalidadGpkgMenuButton"
PROFILE_MENU_NAME = "Perfiles GPKG"
PROFILE_MENU_OBJECT_NAME = "MapingToolPerfilesGpkgTopMenu"
PROFILE_TOOLBAR_OBJECT_NAME = "MapingToolPerfilesGpkgToolbar"
PROFILE_TOOLBUTTON_OBJECT_NAME = "MapingToolPerfilesGpkgMenuButton"
TEMP_PREFIX = "mapingtool-calidad-gpkg-"
RESULT_LAYER_PREFIX = "calidad_gpkg_"
PAGE_SIZE = 250
EXPORT_COLUMNS = list(PORTABLE_EXPORT_COLUMNS)
PREDIO_LAYER_NAME = "lc_gen_predio"
MAX_AUTO_MAP_FEATURES = 50000
GPKG_EXPORT_PAGE_SIZE = 2000
SETTINGS_SCHEMA_VERSION = 11
PROFILE_REPOSITORY = "Gisdeveloper95/Mapper_GIS_Catastral_QGIS_Perfiles"
FAMILY_LABELS = {
    "*": "CATÁLOGO COMPLETO",
    "reco": "RECONOCIMIENTO / CALIFICACIÓN",
    "ph": "PROPIEDAD HORIZONTAL",
    "juridico": "JURÍDICO",
    "sig": "SIG / DIGITALIZACIÓN",
    "economico": "ECONÓMICO",
}
FAMILY_COLORS = {
    "*": "#244C66",
    "reco": "#136F63",
    "ph": "#6D4C9F",
    "juridico": "#7A4D1D",
    "sig": "#1F5D99",
    "economico": "#6C7A1D",
    "mixed": "#8A3D73",
}
CHILD_EXPORT_TARGETS = OrderedDict(
    (
        ("*", ("Total", "T")),
        ("economico", ("Económico", "E")),
        ("juridico", ("Jurídico", "J")),
        ("ph", ("PH", "PH")),
        ("reco", ("RECO", "R")),
        ("sig", ("SIG", "S")),
    )
)
WORKER_WAIT_MS = 5000
_ORPHANED_WORKERS = set()
_ORPHANED_PATHS = set()


def _load_child_profile(plugin_dir: Path) -> dict | None:
    path = plugin_dir / "child_profile.json"
    if not path.is_file():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    if (
        payload.get("schema_version") not in {1, 2, 3, 4}
        or payload.get("locked") is not True
        or not isinstance(payload.get("rule_ids"), list)
        or not payload.get("rule_ids")
        or not re.fullmatch(
            r"[a-z][a-z0-9_]{2,63}",
            str(payload.get("package_id") or ""),
        )
        or not str(payload.get("display_name") or "").strip()
    ):
        raise ValueError("child_profile.json no cumple el contrato de perfil.")
    payload["processing_filter_policy"] = normalize_processing_filter_policy(
        payload.get("processing_filter_policy")
    )
    return payload


def _child_profile_fingerprint(profile: dict) -> str:
    spec = {
        "schema_version": 1,
        "display_name": " ".join(str(profile.get("display_name") or "").split()),
        "parent_family": str(profile.get("parent_family") or ""),
        "parent_version": str(profile.get("parent_version") or ""),
        "rule_ids": sorted({str(value) for value in profile.get("rule_ids") or []}),
        "selected_families": sorted(
            {str(value) for value in profile.get("selected_families") or []}
        ),
        "processing_filter_policy": normalize_processing_filter_policy(
            profile.get("processing_filter_policy")
        ),
        "hide_exception_rows": profile.get("hide_exception_rows") is not False,
    }
    canonical = json.dumps(
        spec,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest().upper()


@dataclass(frozen=True)
class PortableRuleInfo:
    id: str
    family: str
    component: str
    title: str


class CollapsibleSection(QWidget):
    def __init__(self, title: str, accent: str, expanded: bool = True, parent=None):
        super().__init__(parent)
        self.toggle_button = QToolButton()
        self.toggle_button.setText(title)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(expanded)
        self.toggle_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self.toggle_button.setAutoRaise(True)
        self.toggle_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.toggle_button.setMinimumHeight(27)
        self.toggle_button.clicked.connect(self.on_toggled)
        self.toggle_button.setStyleSheet(
            "QToolButton {"
            "border: 0; border-left: 3px solid %s; border-bottom: 1px solid #d7dee5;"
            "padding: 4px 6px; font-weight: 700; color: #263746;"
            "background: transparent; text-align: left;"
            "}"
            "QToolButton:hover { background: #eef3f6; }" % accent
        )

        self.body = QWidget()
        self.body.setVisible(expanded)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        layout.addWidget(self.toggle_button)
        layout.addWidget(self.body)

    def setContentLayout(self, content_layout):
        if isinstance(content_layout, QWidget):
            wrapper = QVBoxLayout()
            wrapper.setContentsMargins(0, 4, 0, 0)
            wrapper.addWidget(content_layout)
            content_layout = wrapper
        self.body.setLayout(content_layout)

    def on_toggled(self):
        expanded = self.toggle_button.isChecked()
        self.toggle_button.setArrowType(Qt.DownArrow if expanded else Qt.RightArrow)
        self.body.setVisible(expanded)

    def isExpanded(self) -> bool:
        return self.toggle_button.isChecked()

    def setExpanded(self, expanded: bool) -> None:
        self.toggle_button.setChecked(bool(expanded))
        self.on_toggled()


def _safe_remove(path: str | Path | None) -> None:
    if not path:
        return
    candidate = Path(path)
    for target in (
        candidate,
        candidate.with_name(candidate.name + "-wal"),
        candidate.with_name(candidate.name + "-shm"),
    ):
        try:
            target.unlink(missing_ok=True)
        except PermissionError:
            pass


def _retain_until_finished(worker, paths) -> None:
    _ORPHANED_WORKERS.add(worker)
    retained = tuple(str(Path(path).resolve()) for path in paths if path)
    _ORPHANED_PATHS.update(retained)

    def release() -> None:
        for path in retained:
            _safe_remove(path)
            _ORPHANED_PATHS.discard(path)
        _ORPHANED_WORKERS.discard(worker)
        try:
            worker.finished.disconnect(release)
        except (RuntimeError, TypeError):
            pass
        worker.deleteLater()

    worker.finished.connect(release)
    if not worker.isRunning():
        release()


def _sha256_file(
    path: str | Path,
    cancel_check=None,
    progress_callback=None,
) -> str:
    digest = hashlib.sha256()
    source = Path(path)
    total = max(1, source.stat().st_size)
    completed = 0
    with source.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            if cancel_check is not None and cancel_check():
                raise InterruptedError("Calculo SHA-256 cancelado por el usuario.")
            digest.update(chunk)
            completed += len(chunk)
            if progress_callback is not None:
                progress_callback(completed, total)
    if cancel_check is not None and cancel_check():
        raise InterruptedError("Calculo SHA-256 cancelado por el usuario.")
    return digest.hexdigest().upper()


def _csv_value(value) -> str:
    text = "" if value is None else str(value)
    if text.lstrip().startswith(("=", "+", "-", "@")):
        return "'" + text
    return text


def _qgis_sql_string(value) -> str:
    if hasattr(QgsExpression, "quotedString"):
        return QgsExpression.quotedString(str(value))
    return "'" + str(value).replace("'", "''") + "'"


def _safe_name(value: str, max_length: int = 48) -> str:
    cleaned = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in str(value))
    cleaned = cleaned.strip("_") or "capa"
    return cleaned[:max_length]


def _normalized_entity_name(value: str) -> str:
    text = str(value or "").strip().casefold()
    text = re.sub(r"[\"'`\[\](){}]", "", text)
    text = re.sub(r"[^a-z0-9]+", "_", text).strip("_")
    return re.sub(r"_\d+$", "", text)


def _entity_aliases_from_text(value: str) -> set[str]:
    text = str(value or "").strip()
    if not text:
        return set()
    aliases = {text}
    for pattern in (
        r"(?:^|[|&;])layername=([^|&;]+)",
        r"(?:^|[|&;])table=([^|&;]+)",
        r'table\s*=\s*(?:"[^"]+"\.)?"([^"]+)"',
    ):
        aliases.update(
            match.group(1).strip().strip("\"'")
            for match in re.finditer(pattern, text, flags=re.IGNORECASE)
        )
    return {alias for alias in aliases if alias}


def _entity_match_score(logical_name: str, aliases) -> int:
    logical = _normalized_entity_name(logical_name)
    if not logical:
        return 0
    compact_logical = logical.replace("_", "")
    best = 0
    for alias in aliases:
        candidate = _normalized_entity_name(alias)
        if not candidate:
            continue
        compact_candidate = candidate.replace("_", "")
        if candidate == logical:
            best = max(best, 100)
        elif compact_candidate == compact_logical:
            best = max(best, 95)
        elif candidate.endswith("_" + logical) or candidate.startswith(logical + "_"):
            best = max(best, 80)
    return best


def _add_features_checked(provider, features: list, context: str) -> None:
    if not features:
        return
    result = provider.addFeatures(features)
    accepted = result[0] if isinstance(result, tuple) else bool(result)
    if not accepted:
        raise RuntimeError("QGIS rechazó objetos al construir {0}.".format(context))


class ScopeProfileItemDelegate(QStyledItemDelegate):
    """Paint scope rows independently from the active QGIS theme."""

    def paint(self, painter, option, index):
        configured = QStyleOptionViewItem(option)
        active = bool(
            configured.state
            & (QStyle.State_MouseOver | QStyle.State_Selected)
        )
        if active:
            configured.state |= QStyle.State_Selected
        else:
            configured.state &= ~(
                QStyle.State_MouseOver | QStyle.State_Selected
            )
        palette = QPalette(configured.palette)
        palette.setColor(QPalette.Base, QColor("#ffffff"))
        palette.setColor(QPalette.Window, QColor("#ffffff"))
        palette.setColor(QPalette.Text, QColor("#17212b"))
        palette.setColor(QPalette.WindowText, QColor("#17212b"))
        palette.setColor(QPalette.Highlight, QColor("#287f73"))
        palette.setColor(QPalette.HighlightedText, QColor("#ffffff"))
        configured.palette = palette
        super().paint(painter, configured, index)

    def sizeHint(self, option, index):
        size = super().sizeHint(option, index)
        size.setHeight(max(28, size.height()))
        return size


class PortableValidationWorker(QThread):
    tested = pyqtSignal(bool, str)
    rule_started = pyqtSignal(str)
    rule_finished = pyqtSignal(object)
    finished_all = pyqtSignal(object)
    log_message = pyqtSignal(str)

    def __init__(
        self,
        config: dict,
        rule_ids: list[str],
        store_path: str | None,
        test_only=False,
        reco_filter_policy=None,
        processing_filter_policy=None,
    ):
        super().__init__()
        self.config = dict(config)
        self.rule_ids = list(rule_ids)
        self.store_path = store_path
        self.test_only = bool(test_only)
        self.reco_filter_policy = normalize_reco_filter_policy(
            reco_filter_policy
        )
        self.reco_filter_enabled = reco_filter_policy_active(
            self.reco_filter_policy
        )
        self.use_legacy_reco_filter = processing_filter_policy is None
        self.processing_filter_policy = normalize_processing_filter_policy(
            (
                processing_filter_policy
                if processing_filter_policy is not None
                else DISABLED_PROCESSING_FILTER_POLICY
            )
        )
        self.cancel_requested = False

    def cancel(self) -> None:
        self.cancel_requested = True
        self.log_message.emit("Cancelacion portable solicitada.")

    def run(self) -> None:
        started = time.monotonic()
        source = None
        backend = None
        store = None
        active_rule_id = None
        ok_count = 0
        error_count = 0
        not_applicable_count = 0
        try:
            snapshot_path = str(self.config.get("snapshot_path") or "")
            expected_snapshot_sha256 = str(
                self.config.get("snapshot_sha256") or ""
            ).upper()
            if snapshot_path:
                if len(expected_snapshot_sha256) != 64:
                    raise ValueError("El snapshot no tiene un SHA-256 valido.")
                actual_snapshot_sha256 = _sha256_file(
                    snapshot_path,
                    cancel_check=lambda: self.cancel_requested,
                )
                if actual_snapshot_sha256 != expected_snapshot_sha256:
                    raise ValueError(
                        "El snapshot cambio despues de capturarse; ejecucion bloqueada."
                    )
            source = (
                GeoPackageDataSource(snapshot_path)
                if snapshot_path
                else MappingDataSource({})
            )
            backend = PortableRuleBackend(
                source,
                LayerMapping(dict(self.config.get("layer_mapping") or {})),
            )
            rule_profiles = {
                rule_id: effective_rule_filter_profile(
                    rule_id,
                    str(
                        backend.manifest["rules"]
                        .get(rule_id, {})
                        .get("family")
                        or ""
                    ),
                    self.processing_filter_policy,
                )
                for rule_id in self.rule_ids
            }
            active_processing_profiles = tuple(
                dict.fromkeys(
                    profile
                    for profile in rule_profiles.values()
                    if processing_profile_active(
                        self.processing_filter_policy,
                        profile,
                    )
                )
            )
            postprocessor_groups = {}
            for rule_id in self.rule_ids:
                postprocessor_id = backend.operational_postprocessor_id(rule_id)
                if postprocessor_id:
                    postprocessor_groups.setdefault(postprocessor_id, []).append(
                        rule_id
                    )
            preflight_results = {
                rule_id: backend.preflight.check_rule(rule_id)
                for rule_id in self.rule_ids
            }
            processing_filter_failure = ""
            selected_project = str(
                self.config.get("project_name") or ""
            ).strip()
            project_filter_failure = ""
            project_predio_name = ""
            if selected_project:
                try:
                    project_predio_name = backend.layer_mapping.resolve(
                        "lc_gen_predio"
                    )
                    project_descriptor = source.describe(project_predio_name)
                    missing_project_fields = {
                        "pk_id",
                        "nombre_proyecto",
                    } - set(project_descriptor.fields)
                    if missing_project_fields:
                        raise ValueError(
                            "lc_gen_predio no contiene campos de proyecto: "
                            + ", ".join(sorted(missing_project_fields))
                        )
                    found_project = False
                    project_rows = source.iter_rows(
                        project_predio_name,
                        ("pk_id", "nombre_proyecto"),
                    )
                    try:
                        for project_row in project_rows:
                            if self.cancel_requested:
                                raise InterruptedError(
                                    "Validación de proyecto cancelada."
                                )
                            if (
                                str(
                                    project_row.get("nombre_proyecto") or ""
                                ).strip()
                                == selected_project
                            ):
                                found_project = True
                                break
                    finally:
                        close_project_rows = getattr(project_rows, "close", None)
                        if callable(close_project_rows):
                            close_project_rows()
                    if not found_project:
                        raise ValueError(
                            "El proyecto {0} no existe en lc_gen_predio.".format(
                                selected_project
                            )
                        )
                except Exception as exc:
                    project_filter_failure = str(exc)
            if active_processing_profiles:
                try:
                    predio_name = backend.layer_mapping.resolve(
                        "lc_gen_predio"
                    )
                    predio_descriptor = source.describe(predio_name)
                    missing_filter_fields = sorted(
                        set(
                            processing_required_fields(
                                self.processing_filter_policy,
                                active_processing_profiles,
                            )
                        )
                        - set(predio_descriptor.fields)
                    )
                    if missing_filter_fields:
                        raise ValueError(
                            "lc_gen_predio no contiene campos de filtro: "
                            + ", ".join(missing_filter_fields)
                        )
                except Exception as exc:
                    processing_filter_failure = str(exc)
            if self.test_only:
                if not self.rule_ids:
                    self.tested.emit(
                        False,
                        "Esta familia declara 0 reglas portadas; el resto es backend_unsupported.",
                    )
                    return
                failures = []
                not_applicable = []
                for rule_id in self.rule_ids:
                    result = preflight_results[rule_id]
                    if result.status == "not_applicable":
                        not_applicable.append(
                            "{0}: {1}".format(rule_id, result.message)
                        )
                    elif not result.ok:
                        failures.append("{0}: {1}".format(rule_id, result.message))
                if processing_filter_failure:
                    failures.append(
                        "filtros_operativos: "
                        + processing_filter_failure
                    )
                if project_filter_failure:
                    failures.append(
                        "proyecto: " + project_filter_failure
                    )
                for postprocessor_id, rule_ids in postprocessor_groups.items():
                    if (
                        postprocessor_id == "reco_post_filter"
                        and not self.reco_filter_enabled
                    ):
                        continue
                    eligible_rule_ids = [
                        rule_id
                        for rule_id in rule_ids
                        if preflight_results[rule_id].ok
                    ]
                    if not eligible_rule_ids:
                        continue
                    try:
                        backend.validate_postprocessor(
                            eligible_rule_ids,
                            postprocessor_id,
                        )
                    except Exception as exc:
                        failures.append(
                            "{0}: {1}".format(postprocessor_id, exc)
                        )
                if failures:
                    self.tested.emit(False, " | ".join(failures))
                else:
                    optional_note = (
                        " Opcionales no aplicables: {0}".format(
                            " | ".join(not_applicable)
                        )
                        if not_applicable
                        else ""
                    )
                    self.tested.emit(
                        True,
                        (
                            "Preflight portable correcto: {0} regla(s), snapshot {1}."
                            "{2}"
                        ).format(
                            len(self.rule_ids),
                            self.config.get("snapshot_sha256", ""),
                            optional_note,
                        ),
                    )
                return

            if self.store_path:
                store = PortableResultStore.open(self.store_path)
            if store is None:
                raise RuntimeError("No existe almacenamiento portable de resultados.")

            processing_filter_failures = {}
            if selected_project:
                try:
                    if project_filter_failure:
                        raise ValueError(project_filter_failure)

                    def iter_project_scope():
                        for project_row in source.iter_rows(
                            project_predio_name,
                            ("pk_id", "nombre_proyecto"),
                        ):
                            if self.cancel_requested:
                                raise InterruptedError(
                                    "Carga de proyecto cancelada."
                                )
                            if (
                                str(
                                    project_row.get("nombre_proyecto") or ""
                                ).strip()
                                == selected_project
                            ):
                                yield {
                                    "pk_id_predio": project_row.get("pk_id")
                                }

                    project_count = store.replace_project_allowed(
                        iter_project_scope(),
                        cancel_check=lambda: self.cancel_requested,
                    )
                    self.log_message.emit(
                        "Proyecto activo {0}: {1} predio(s).".format(
                            selected_project,
                            project_count,
                        )
                    )
                except (InterruptedError, PortableStoreCancelled):
                    self.cancel_requested = True
                    return
                except Exception as exc:
                    for rule_id in self.rule_ids:
                        processing_filter_failures[rule_id] = (
                            "backend_integrity_error",
                            str(exc),
                        )
            if self.use_legacy_reco_filter:
                if "reco_post_filter" in postprocessor_groups:
                    self.log_message.emit(
                        reco_filter_policy_summary(
                            self.reco_filter_policy
                        )
                    )
                for postprocessor_id, grouped_rule_ids in (
                    postprocessor_groups.items()
                ):
                    if (
                        postprocessor_id == "reco_post_filter"
                        and not self.reco_filter_enabled
                    ):
                        continue
                    eligible_rule_ids = [
                        rule_id
                        for rule_id in grouped_rule_ids
                        if preflight_results[rule_id].ok
                    ]
                    if not eligible_rule_ids:
                        continue
                    try:
                        if postprocessor_id != "reco_post_filter":
                            raise ValueError(
                                "Postprocesador operativo no soportado: "
                                + postprocessor_id
                            )
                        allowed_count = store.replace_reco_allowed(
                            iter_portable_reco_scope(
                                backend,
                                eligible_rule_ids,
                                postprocessor_id,
                                policy=self.reco_filter_policy,
                                cancel_check=lambda: self.cancel_requested,
                            ),
                            cancel_check=lambda: self.cancel_requested,
                        )
                        self.log_message.emit(
                            "Filtro RECO compatible cargado en disco: "
                            "{0} predios.".format(allowed_count)
                        )
                    except (InterruptedError, PortableStoreCancelled):
                        self.cancel_requested = True
                        return
                    except Exception as exc:
                        for rule_id in eligible_rule_ids:
                            processing_filter_failures[rule_id] = (
                                "backend_integrity_error",
                                str(exc),
                            )
            else:
                self.log_message.emit(
                    processing_filter_summary(
                        self.processing_filter_policy,
                        active_processing_profiles,
                    )
                )
            if (
                not self.use_legacy_reco_filter
                and active_processing_profiles
            ):
                try:
                    if processing_filter_failure:
                        raise ValueError(processing_filter_failure)
                    allowed_counts = store.replace_processing_allowed(
                        active_processing_profiles,
                        iter_processing_allowed_predio_ids(
                            source,
                            backend.layer_mapping,
                            active_processing_profiles,
                            self.processing_filter_policy,
                            cancel_check=lambda: self.cancel_requested,
                        ),
                        cancel_check=lambda: self.cancel_requested,
                    )
                    self.log_message.emit(
                        "Alcances operativos cargados en disco: {0}.".format(
                            ", ".join(
                                "{0}={1}".format(
                                    PROFILE_LABELS.get(profile, profile),
                                    allowed_counts.get(profile, 0),
                                )
                                for profile in active_processing_profiles
                            )
                        )
                    )
                except (InterruptedError, PortableStoreCancelled):
                    self.cancel_requested = True
                    return
                except Exception as exc:
                    for rule_id, profile in rule_profiles.items():
                        if profile in active_processing_profiles:
                            processing_filter_failures[rule_id] = (
                                "backend_integrity_error",
                                str(exc),
                            )
            for rule_id in self.rule_ids:
                if self.cancel_requested:
                    break
                active_rule_id = rule_id
                self.rule_started.emit(rule_id)
                postprocessor_id = backend.operational_postprocessor_id(
                    rule_id
                )
                if rule_id in processing_filter_failures:
                    status, message = processing_filter_failures[rule_id]
                    error_count += 1
                    self.rule_finished.emit(
                        {
                            "rule_id": rule_id,
                            "status": status,
                            "count": 0,
                            "message": message,
                        }
                    )
                    active_rule_id = None
                    continue
                # Execute the canonical raw stage.  The versioned, rule-aware
                # operational scope is applied once by the disk-backed store.
                execution = backend.execute_raw(
                    rule_id, cancel_check=lambda: self.cancel_requested
                )
                if execution.status == "not_applicable":
                    not_applicable_count += 1
                    self.rule_finished.emit(
                        {
                            "rule_id": rule_id,
                            "status": "not_applicable",
                            "count": 0,
                            "message": execution.message,
                        }
                    )
                    active_rule_id = None
                    continue
                if execution.status != "ok":
                    error_count += 1
                    self.rule_finished.emit(
                        {
                            "rule_id": rule_id,
                            "status": execution.status,
                            "count": 0,
                            "message": execution.message,
                        }
                    )
                    active_rule_id = None
                    continue
                try:
                    raw_total = 0

                    def counted_rows():
                        nonlocal raw_total
                        for row in execution.rows:
                            raw_total += 1
                            yield row

                    count = store.replace_rule(
                        rule_id,
                        counted_rows(),
                        cancel_check=lambda: self.cancel_requested,
                        apply_reco_filter=(
                            self.use_legacy_reco_filter
                            and postprocessor_id == "reco_post_filter"
                            and self.reco_filter_enabled
                        ),
                        filter_profile=(
                            rule_profiles[rule_id]
                            if (
                                not self.use_legacy_reco_filter
                                and rule_profiles[rule_id]
                                in active_processing_profiles
                            )
                            else None
                        ),
                        project_name=selected_project or None,
                    )
                    self.log_message.emit(
                        "{0}: {1} inconsistencia(s) persistidas en disco; "
                        "quedan disponibles durante esta corrida sin retenerlas en memoria.".format(
                            rule_id,
                            count,
                        )
                    )
                except (InterruptedError, PortableStoreCancelled):
                    self.cancel_requested = True
                    self.rule_finished.emit(
                        {
                            "rule_id": rule_id,
                            "status": "cancelado",
                            "count": 0,
                            "message": "Ejecucion portable cancelada; no se guardaron filas parciales.",
                        }
                    )
                    active_rule_id = None
                    break
                ok_count += 1
                self.rule_finished.emit(
                    {
                        "rule_id": rule_id,
                        "status": "ok",
                        "count": count,
                        "raw_total": raw_total,
                        "filtered_out": max(raw_total - count, 0),
                        "message": (
                            "Regla revisada sin inconsistencias."
                            if count == 0
                            else "Validación completada: {0} inconsistencia(s).".format(
                                count
                            )
                        ),
                    }
                )
                active_rule_id = None
        except Exception as exc:
            error_count += 1
            if self.test_only:
                self.tested.emit(False, str(exc))
            else:
                self.rule_finished.emit(
                    {
                        "rule_id": active_rule_id or "__SOURCE__",
                        "status": "error",
                        "count": 0,
                        "message": str(exc),
                    }
                )
        finally:
            if store is not None:
                store.close()
            if backend is not None:
                backend.close()
                source = None
            elif source is not None:
                source.close()
            self.finished_all.emit(
                {
                    "ok": ok_count,
                    "errors": error_count,
                    "not_applicable": not_applicable_count,
                    "cancelled": self.cancel_requested,
                    "elapsed_ms": int((time.monotonic() - started) * 1000),
                }
            )


class ProfileUpdateWorker(QThread):
    checked = pyqtSignal(object)

    def __init__(
        self,
        package_id: str,
        current_version: str,
        profile_fingerprint: str,
    ):
        super().__init__()
        self.package_id = package_id
        self.current_version = current_version
        self.profile_fingerprint = profile_fingerprint

    def run(self) -> None:
        try:
            value = ProfileRegistryClient(timeout=3).check_update(
                self.package_id,
                self.current_version,
                self.profile_fingerprint,
            )
            self.checked.emit({"ok": True, "value": value})
        except (ProfileRegistryError, OSError, ValueError) as exc:
            # Abrir el plugin nunca se bloquea por falta de Internet o del portal.
            self.checked.emit({"ok": False, "error": str(exc)})


class CalidadGpkgPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = Path(__file__).resolve().parent
        self.child_profile = _load_child_profile(self.plugin_dir)
        if self.child_profile is not None:
            global PLUGIN_NAME
            PLUGIN_NAME = str(self.child_profile["display_name"]).strip()
        self.manifest = load_portable_manifest(self.plugin_dir / "quality_core")
        global EXPORT_COLUMNS
        EXPORT_COLUMNS = list(presentation_columns(self.manifest))
        available_rule_ids = set(self.manifest.get("rules", {}))
        if self.child_profile is None:
            self.rule_ids = sorted(available_rule_ids)
        else:
            requested_rule_ids = [
                str(value)
                for value in self.child_profile["rule_ids"]
            ]
            missing_rule_ids = sorted(
                set(requested_rule_ids) - available_rule_ids
            )
            if missing_rule_ids:
                raise ValueError(
                    "El perfil hijo solicita reglas ausentes: "
                    + ", ".join(missing_rule_ids)
                )
            self.rule_ids = sorted(set(requested_rule_ids))
        self.rules = [
            PortableRuleInfo(
                rule_id,
                str(self.manifest["rules"][rule_id].get("family") or ""),
                str(self.manifest["rules"][rule_id].get("component") or ""),
                str(self.manifest["rules"][rule_id].get("title") or rule_id),
            )
            for rule_id in self.rule_ids
        ]
        self.output_columns = tuple(EXPORT_COLUMNS)
        self.actions = []
        self.action = None
        self.dock = None
        self.worker = None
        self.profile_update_worker = None
        self.profile_update_last_check = 0.0
        self.profile_update_notified = set()
        self.mapping_combos = {}
        self.mapping_unlock_box = None
        self.mapping_lock_status_label = None
        self.snapshot_path = None
        self.store = None
        self.store_path = None
        self.result_store = None
        self.result_store_path = None
        self.page_number = 0
        self.detail_page_number = 0
        self.detail_page_size = min(DEFAULT_PAGE_SIZE, 100)
        self.detail_filtered_total = 0
        self.current_detail_rows = []
        self.summary_rows = {}
        self.summary_data = OrderedDict()
        self.log_lines = []
        self.current_config = {}
        self.map_cache_path = None
        self.map_layer_ids = []
        self.sections = {}
        self.saved_rule_ids = None
        self.package_scope = None
        self.package_scope_error = ""
        self.package_scope_signature = ""
        self.rule_family_by_id = {rule.id: rule.family for rule in self.rules}
        self.detail_dock = None
        self.detail_dock_table = None
        self.detail_dock_label = None
        self.detail_dock_search_edit = None
        self.detail_dock_hide_exceptions_box = None
        self.detail_dock_count_label = None
        self.hide_exception_rows_box = None
        self._detail_controls_installed = False
        self.feature_form_dialog = None
        self.navigation_layer_id = None
        self.navigation_context_layer_ids = []
        self.navigation_relation_ids = []
        self._detail_refreshing = False
        self.validation_running = False
        self._snapshot_under_construction = None
        self._unloading = False
        self._project_layer_signals_connected = False
        self._mapping_refresh_pending = False
        self.processing_filter_panel = None
        self.processing_filter_widgets = {}
        self.processing_filter_status_label = None
        self.available_projects = []
        self.project_combo = None
        self.project_status_label = None
        self._refreshing_projects = False
        self.export_child_btn = None
        self.export_child_action = None
        self.publish_child_action = None
        self.child_profile_banner = None
        self.navigation_menu_object_name = TOP_MENU_OBJECT_NAME
        self.navigation_toolbutton_object_name = TOOLBUTTON_OBJECT_NAME

    def initGui(self):
        is_profile = self.child_profile is not None
        profile_icon = self.plugin_dir / "profile_icon.svg"
        icon_path = str(
            profile_icon
            if is_profile and profile_icon.is_file()
            else self.plugin_dir / "icon.png"
        )
        self.action = QAction(QIcon(icon_path), PLUGIN_NAME, self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        menu_name = PROFILE_MENU_NAME if is_profile else TOP_MENU_NAME
        menu_object_name = (
            PROFILE_MENU_OBJECT_NAME
            if is_profile
            else TOP_MENU_OBJECT_NAME
        )
        toolbar_object_name = (
            PROFILE_TOOLBAR_OBJECT_NAME
            if is_profile
            else TOOLBAR_OBJECT_NAME
        )
        toolbutton_object_name = (
            PROFILE_TOOLBUTTON_OBJECT_NAME
            if is_profile
            else TOOLBUTTON_OBJECT_NAME
        )
        self.navigation_menu_object_name = menu_object_name
        self.navigation_toolbutton_object_name = toolbutton_object_name
        menu_bar = self.iface.mainWindow().menuBar()
        menu = menu_bar.findChild(QMenu, menu_object_name)
        if menu is None:
            menu = QMenu(menu_name, menu_bar)
            menu.setObjectName(menu_object_name)
            menu_bar.addMenu(menu)
        menu.addAction(self.action)
        toolbar = self.iface.mainWindow().findChild(
            QToolBar,
            toolbar_object_name,
        )
        if toolbar is None:
            toolbar = self.iface.addToolBar(menu_name)
            toolbar.setObjectName(toolbar_object_name)
        button = toolbar.findChild(QToolButton, toolbutton_object_name)
        if button is None:
            button = QToolButton(toolbar)
            button.setObjectName(toolbutton_object_name)
            button.setText(menu_name)
            button.setIcon(QIcon(icon_path))
            button.setPopupMode(QToolButton.InstantPopup)
            button.setMenu(QMenu(button))
            toolbar.addWidget(button)
        button.menu().addAction(self.action)
        self.actions.append(self.action)

    def unload(self):
        self._unloading = True
        update_worker = self.profile_update_worker
        if update_worker is not None and update_worker.isRunning():
            try:
                update_worker.checked.disconnect()
            except (RuntimeError, TypeError):
                pass
            if not update_worker.wait(3500):
                _retain_until_finished(update_worker, ())
            self.profile_update_worker = None
        self.disconnect_project_layer_signals()
        worker = self.worker
        if worker is not None and worker.isRunning():
            for name in ("tested", "rule_started", "rule_finished", "finished_all", "log_message"):
                try:
                    getattr(worker, name).disconnect()
                except (RuntimeError, TypeError):
                    pass
            worker.cancel()
            if not worker.wait(WORKER_WAIT_MS):
                if self.store is not None:
                    self.store.close()
                    self.store = None
                _retain_until_finished(worker, (self.snapshot_path, self.store_path))
                self.snapshot_path = None
                self.store_path = None
            self.worker = None
        self.cleanup_run_files()
        self.cleanup_map_cache()
        self.cleanup_navigation_layer()
        for action in self.actions:
            for object_name in (
                self.navigation_menu_object_name,
                self.navigation_toolbutton_object_name,
            ):
                owner = self.iface.mainWindow().findChild(
                    (
                        QMenu
                        if object_name
                        in {TOP_MENU_OBJECT_NAME, PROFILE_MENU_OBJECT_NAME}
                        else QToolButton
                    ),
                    object_name,
                )
                if owner is not None:
                    menu = owner if isinstance(owner, QMenu) else owner.menu()
                    if menu is not None:
                        menu.removeAction(action)
        if self.dock is not None:
            self.iface.removeDockWidget(self.dock)
            self.dock = None
        if self.detail_dock is not None:
            self.iface.removeDockWidget(self.detail_dock)
            self.detail_dock = None
            self.detail_dock_table = None
            self.detail_dock_label = None
            self.detail_dock_search_edit = None
            self.detail_dock_hide_exceptions_box = None
            self.detail_dock_count_label = None

    def run(self):
        if self.dock is None:
            self.create_dock()
        self.install_portable_detail_controls()
        self.dock.show()
        self.dock.raise_()
        self.schedule_loaded_layer_refresh()
        self.schedule_profile_update_check()

    def schedule_profile_update_check(self):
        if self.child_profile is None or self._unloading:
            return
        package_id = str(self.child_profile.get("package_id") or "")
        current_version = str(self.child_profile.get("child_version") or "")
        if not package_id or not current_version:
            return
        now = time.monotonic()
        if now - self.profile_update_last_check < 600:
            return
        worker = self.profile_update_worker
        if worker is not None and worker.isRunning():
            return
        self.profile_update_last_check = now
        worker = ProfileUpdateWorker(
            package_id,
            current_version,
            _child_profile_fingerprint(self.child_profile),
        )
        worker.checked.connect(self.on_profile_update_checked)
        worker.finished.connect(self.on_profile_update_worker_finished)
        self.profile_update_worker = worker
        worker.start()

    def on_profile_update_worker_finished(self):
        worker = self.profile_update_worker
        if worker is not None:
            try:
                worker.checked.disconnect(self.on_profile_update_checked)
                worker.finished.disconnect(self.on_profile_update_worker_finished)
            except (RuntimeError, TypeError):
                pass
            worker.deleteLater()
        self.profile_update_worker = None

    def on_profile_update_checked(self, result):
        if self._unloading or not isinstance(result, dict) or not result.get("ok"):
            return
        value = result.get("value")
        if not isinstance(value, dict):
            return
        status = str(value.get("status") or "")
        if status == "unknown_profile":
            return
        repository_xml = str(value.get("repositoryXml") or "")
        repository_configured = self.profile_repository_configured(
            repository_xml
        )
        if status == "current" and repository_configured:
            return
        recommended = str(value.get("recommendedVersion") or "")
        notification_key = (status, recommended, repository_configured)
        if notification_key in self.profile_update_notified:
            return
        self.profile_update_notified.add(notification_key)
        if status == "recovery_pending":
            QMessageBox.critical(
                self.dock,
                "Perfil retirado",
                str(value.get("message") or "La versión instalada fue retirada."),
            )
            return
        title = (
            "Actualización urgente del perfil"
            if status == "installed_release_revoked"
            else "Actualización disponible"
            if status == "update_available"
            else "Active las actualizaciones del perfil"
        )
        icon = (
            QMessageBox.Critical
            if status == "installed_release_revoked"
            else QMessageBox.Information
        )
        dialog = QMessageBox(self.dock)
        dialog.setIcon(icon)
        dialog.setWindowTitle(title)
        dialog.setText(
            str(value.get("message") or "Hay una nueva versión disponible.")
            if status != "current"
            else (
                "Este perfil tiene un canal de actualizaciones, pero su "
                "repositorio todavía no está configurado en QGIS."
            )
        )
        dialog.setInformativeText(
            (
                "Copie el enlace del repositorio y agréguelo una sola vez en "
                "Complementos; QGIS podrá ofrecer los siguientes releases."
            )
            if not repository_configured
            else (
                "Abra el Administrador de complementos de QGIS para instalar "
                "el release seguro recomendado."
            )
        )
        copy_button = None
        if repository_xml:
            dialog.setDetailedText("Repositorio QGIS:\n" + repository_xml)
            copy_button = dialog.addButton(
                "Copiar plugins.xml",
                QMessageBox.ActionRole,
            )
        update_button = dialog.addButton(
            "Abrir Administrador de complementos",
            QMessageBox.AcceptRole,
        )
        dialog.addButton("Más tarde", QMessageBox.RejectRole)
        dialog.exec_()
        if copy_button is not None and dialog.clickedButton() is copy_button:
            QApplication.clipboard().setText(repository_xml)
            QMessageBox.information(
                self.dock,
                "Enlace copiado",
                (
                    "El enlace plugins.xml quedó copiado. Agréguelo en "
                    "Configuración > Complementos > Repositorios."
                ),
            )
        if dialog.clickedButton() is update_button:
            try:
                self.iface.pluginManagerInterface().showPluginManager(3)
            except (AttributeError, RuntimeError):
                release_url = str(value.get("releaseUrl") or "")
                if release_url:
                    QDesktopServices.openUrl(QUrl(release_url))

    @staticmethod
    def profile_repository_configured(repository_xml):
        expected = str(repository_xml or "").strip().rstrip("/")
        if not expected:
            return False
        settings = QSettings()
        for key in settings.allKeys():
            if not str(key).casefold().endswith("/url"):
                continue
            value = str(settings.value(key, "") or "").strip().rstrip("/")
            if value == expected:
                return True
        return False

    def connect_project_layer_signals(self):
        if self._project_layer_signals_connected:
            return
        project = QgsProject.instance()
        for signal_name in ("layersAdded", "layersRemoved", "cleared"):
            signal = getattr(project, signal_name, None)
            if signal is not None:
                signal.connect(self.on_project_layers_changed)
        self._project_layer_signals_connected = True

    def disconnect_project_layer_signals(self):
        if not self._project_layer_signals_connected:
            return
        project = QgsProject.instance()
        for signal_name in ("layersAdded", "layersRemoved", "cleared"):
            signal = getattr(project, signal_name, None)
            if signal is not None:
                try:
                    signal.disconnect(self.on_project_layers_changed)
                except (RuntimeError, TypeError):
                    pass
        self._project_layer_signals_connected = False
        self._mapping_refresh_pending = False

    def on_project_layers_changed(self, *_args):
        self.schedule_loaded_layer_refresh()

    def schedule_loaded_layer_refresh(self):
        if (
            self._unloading
            or self.dock is None
            or self.validation_running
            or not hasattr(self, "source_combo")
        ):
            return
        if self.source_combo.currentData() != "loaded_layers":
            if not self.path_edit.text().strip():
                loaded = [
                    layer
                    for layer in QgsProject.instance().mapLayers().values()
                    if isinstance(layer, QgsVectorLayer) and layer.isValid()
                ]
                if loaded:
                    index = self.source_combo.findData("loaded_layers")
                    if index >= 0:
                        self.source_combo.setCurrentIndex(index)
            return
        if self._mapping_refresh_pending:
            return
        self._mapping_refresh_pending = True
        QTimer.singleShot(150, self.refresh_loaded_layers_if_pending)

    def refresh_loaded_layers_if_pending(self):
        if not self._mapping_refresh_pending:
            return
        self._mapping_refresh_pending = False
        if (
            not self._unloading
            and self.dock is not None
            and not self.validation_running
            and self.source_combo.currentData() == "loaded_layers"
        ):
            self.refresh_mapping()


    def load_summary_contract(self):
        self.summary_table.setRowCount(0)
        self.summary_rows = {}
        if not self.rule_ids:
            self.add_summary(
                PLUGIN_FAMILY.upper(),
                "backend_unsupported",
                0,
                "0 reglas portadas de {0}; no se ejecuta ni se informa OK.".format(
                    CANONICAL_RULE_COUNT
                ),
            )
            self.run_btn.setEnabled(False)
        else:
            for rule_id in self.rule_ids:
                self.add_summary(rule_id, "pendiente", 0, "")

    def add_summary(self, rule_id, status, count, message):
        row = self.summary_table.rowCount()
        self.summary_table.insertRow(row)
        self.summary_rows[rule_id] = row
        for column, value in enumerate((rule_id, status, count, message)):
            item = QTableWidgetItem(str(value))
            item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            self.summary_table.setItem(row, column, item)
        self.color_summary(row, status)

    def update_summary(self, rule_id, status, count, message):
        if rule_id not in self.summary_rows:
            self.add_summary(rule_id, status, count, message)
            return
        row = self.summary_rows[rule_id]
        for column, value in enumerate((rule_id, status, count, message)):
            self.summary_table.item(row, column).setText(str(value))
        self.color_summary(row, status)

    def color_summary(self, row, status):
        color = QColor("#1b5e20" if status == "ok" else "#a16207")
        if status in ("error", "backend_integrity_error"):
            color = QColor("#b00020")
        for column in range(self.summary_table.columnCount()):
            self.summary_table.item(row, column).setForeground(color)

    def required_entities(self):
        return self.required_entities_for_rules(
            self.package_scope.rule_ids
            if self.package_scope is not None
            else self.rule_ids
        )

    def required_entities_for_rules(self, rule_ids):
        entities = set()
        applicable = set(rule_ids)
        try:
            policy = self.processing_filter_policy()
        except (AttributeError, ValueError):
            policy = normalize_processing_filter_policy()
        for rule_id, declaration in self.manifest.get("rules", {}).items():
            if rule_id not in applicable:
                continue
            entities.update(declaration.get("dependencies", {}))
            profile = effective_rule_filter_profile(
                rule_id,
                str(declaration.get("family") or ""),
                policy,
            )
            if processing_profile_active(policy, profile):
                entities.add("lc_gen_predio")
        if applicable:
            # Project scope is a common execution contract for every edition.
            entities.add("lc_gen_predio")
        return tuple(sorted(entities))

    def optional_entities_for_rules(self, rule_ids):
        optional = set()
        required = set()
        applicable = set(rule_ids)
        for rule_id, declaration in self.manifest.get("rules", {}).items():
            if rule_id not in applicable:
                continue
            dependencies = set(declaration.get("dependencies", {}))
            if declaration.get("optional_for_work_packages") is True:
                declared_optional = set(
                    declaration.get("optional_missing_entities", ())
                )
                optional.update(dependencies.intersection(declared_optional))
                required.update(dependencies - declared_optional)
            else:
                required.update(dependencies)
        return optional - required

    def on_source_changed(self, *_args):
        gpkg = self.source_combo.currentData() == "gpkg"
        self.path_edit.setEnabled(gpkg)
        self.browse_btn.setEnabled(gpkg)
        self.refresh_mapping()

    def browse_gpkg(self):
        path, _selected = QFileDialog.getOpenFileName(
            self.dock, "Seleccionar GeoPackage", self.path_edit.text(), "GeoPackage (*.gpkg)"
        )
        if path:
            self.path_edit.setText(path)
            self.refresh_mapping()

    @staticmethod
    def loaded_layer_aliases(layer) -> set[str]:
        aliases = _entity_aliases_from_text(layer.name())
        short_name = getattr(layer, "shortName", None)
        if callable(short_name):
            aliases.update(_entity_aliases_from_text(short_name()))
        aliases.update(_entity_aliases_from_text(layer.source()))
        try:
            aliases.update(
                _entity_aliases_from_text(layer.dataProvider().dataSourceUri())
            )
        except (AttributeError, RuntimeError):
            pass
        return aliases

    def update_mapping_lock_state(self, *_args):
        unlock_box = getattr(self, "mapping_unlock_box", None)
        unlocked = bool(
            unlock_box is not None
            and unlock_box.isChecked()
            and not self.validation_running
        )
        for combo in self.mapping_combos.values():
            combo.setEnabled(unlocked)
            combo.setToolTip(
                "Edicion habilitada: seleccione deliberadamente la capa fisica."
                if unlocked
                else "Mapeo protegido. Active la casilla de desbloqueo para editar."
            )
        status = getattr(self, "mapping_lock_status_label", None)
        if status is not None:
            if unlocked:
                status.setText("Edicion habilitada")
                status.setStyleSheet(
                    "QLabel { color: #9a3412; font-weight: 700; }"
                )
            else:
                status.setText("Mapeo protegido")
                status.setStyleSheet(
                    "QLabel { color: #1f7a1f; font-weight: 700; }"
                )
        if hasattr(self, "mapping_table"):
            self.mapping_table.setToolTip(
                "Las asignaciones estan protegidas contra clic, teclado y rueda "
                "del mouse."
                if not unlocked
                else "Edicion habilitada hasta que desmarque la casilla."
            )

    def refresh_mapping(self):
        if not hasattr(self, "mapping_table"):
            return
        unlock_box = getattr(self, "mapping_unlock_box", None)
        if unlock_box is not None and unlock_box.isChecked():
            unlock_box.setChecked(False)
        self.refresh_package_scope()
        previous = {
            key: str(combo.currentData() or "") for key, combo in self.mapping_combos.items()
        }
        for key, value in getattr(self, "saved_layer_mapping", {}).items():
            previous.setdefault(str(key), str(value))
        options = []
        error = ""
        if self.source_combo.currentData() == "loaded_layers":
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsVectorLayer) and layer.isValid():
                    aliases = self.loaded_layer_aliases(layer)
                    options.append(
                        (
                            "{0} [{1} | {2}]".format(
                                layer.name(), layer.providerType(), layer.id()
                            ),
                            layer.id(),
                            aliases,
                        )
                    )
        else:
            try:
                source = GeoPackageDataSource(self.path_edit.text().strip())
                options = [
                    (name, name, {name}) for name in source.entities()
                ]
                source.close()
            except Exception as exc:
                error = str(exc)
        entities = self.required_entities()
        self.mapping_table.setRowCount(len(entities))
        self.mapping_combos = {}
        for row, logical_name in enumerate(entities):
            self.mapping_table.setItem(row, 0, QTableWidgetItem(logical_name))
            combo = QComboBox()
            combo.addItem("(sin asignar)", "")
            for label, value, _aliases in options:
                combo.addItem(label, value)
            scored = [
                (
                    _entity_match_score(logical_name, aliases),
                    value,
                )
                for _label, value, aliases in options
            ]
            best_score = max((score for score, _value in scored), default=0)
            exact = [
                value
                for score, value in scored
                if best_score > 0 and score == best_score
            ]
            wanted = previous.get(logical_name, "")
            if wanted and combo.findData(wanted) >= 0:
                combo.setCurrentIndex(combo.findData(wanted))
            elif len(exact) == 1:
                combo.setCurrentIndex(combo.findData(exact[0]))
            combo.currentIndexChanged.connect(self.update_mapping_status)
            self.mapping_table.setCellWidget(row, 1, combo)
            self.mapping_table.setItem(row, 2, QTableWidgetItem("dependency_missing"))
            self.mapping_combos[logical_name] = combo
        self.update_mapping_status()
        self.update_mapping_lock_state()
        if error and entities:
            self.status_label.setText(error)

    def refresh_package_scope(self):
        previous_signature = self.package_scope_signature
        self.package_scope = None
        self.package_scope_error = ""
        self.package_scope_signature = ""
        if self.source_combo.currentData() == "gpkg":
            source_path = self.path_edit.text().strip()
            if source_path:
                try:
                    self.package_scope = load_package_rule_scope(
                        source_path,
                        self.rule_ids,
                        PLUGIN_FAMILY,
                    )
                except Exception as exc:
                    self.package_scope_error = str(exc)
        if self.package_scope is not None:
            self.package_scope_signature = self.package_scope.sha256
            message = "Perfil {0}: {1} regla(s) aplicable(s) a esta edición.".format(
                self.package_scope.profile_id,
                len(self.package_scope.rule_ids),
            )
            tooltip = "{0}\nSHA-256: {1}".format(
                self.package_scope.source_path,
                self.package_scope.sha256,
            )
            if self.package_scope.reason:
                tooltip += "\nMotivo: " + self.package_scope.reason
        elif self.package_scope_error:
            message = "Alcance inválido: " + self.package_scope_error
            tooltip = message
        else:
            message = (
                "Selección manual: este paquete no está obligado a ejecutar "
                "todo el catálogo."
            )
            tooltip = (
                "Marque solo las reglas incluidas en el análisis del paquete. "
                "Puede entregarse mapingtool_scope.json junto al GPKG."
            )
        if hasattr(self, "scope_status_label"):
            self.scope_status_label.setText(message)
            self.scope_status_label.setToolTip(tooltip)
            self.scope_status_label.setStyleSheet(
                "QLabel { color: %s; padding: 3px 5px; }"
                % ("#b00020" if self.package_scope_error else "#334155")
            )
        if (
            hasattr(self, "rules_table")
            and previous_signature != self.package_scope_signature
        ):
            self.apply_package_scope_to_rules()

    def update_mapping_status(self, *_args):
        selected_rule_ids = (
            self.checked_rule_ids()
            if hasattr(self, "rules_table")
            else list(self.rule_ids)
        )
        selected_entities = (
            set(self.required_entities_for_rules(selected_rule_ids))
            if hasattr(self, "rules_table")
            else set(self.required_entities())
        )
        optional_entities = self.optional_entities_for_rules(selected_rule_ids)
        for row, logical_name in enumerate(self.required_entities()):
            combo = self.mapping_combos.get(logical_name)
            if logical_name not in selected_entities:
                status = "fuera_de_selección"
            elif combo and combo.currentData():
                status = "asignada"
            elif logical_name in optional_entities:
                status = "opcional_ausente"
            else:
                status = "dependency_missing"
            item = self.mapping_table.item(row, 2)
            item.setText(status)
            colors = {
                "asignada": "#1f7a1f",
                "opcional_ausente": "#475569",
                "fuera_de_selección": "#8a949e",
                "dependency_missing": "#a16207",
            }
            item.setForeground(QColor(colors.get(status, "#334155")))
            if status == "opcional_ausente":
                item.setToolTip(
                    "La capa es opcional para este paquete. La regla se omitirá "
                    "como no aplicable y no contará como error."
                )
            else:
                item.setToolTip("")
        if self.project_combo is not None:
            self.refresh_project_choices()

    def selected_mapping(self):
        return {
            logical: str(combo.currentData())
            for logical, combo in self.mapping_combos.items()
            if combo.currentData()
        }

    @staticmethod
    def normalized_project_name(value) -> str:
        normalized = unicodedata.normalize("NFKD", str(value or ""))
        ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
        return re.sub(r"[^a-z0-9]+", "_", ascii_value.casefold()).strip("_")

    def project_hint_candidates(self) -> list[str]:
        candidates = []
        if self.source_combo.currentData() == "gpkg":
            path = Path(self.path_edit.text().strip())
            if path.name:
                candidates.append(path.parent.name)
        project = QgsProject.instance()
        for value in (
            project.fileName(),
            project.homePath(),
            project.baseName(),
        ):
            if not value:
                continue
            path = Path(str(value))
            candidates.extend((path.stem, path.name, path.parent.name))
        return list(dict.fromkeys(value for value in candidates if value))

    def discover_project_names(self) -> list[str]:
        mapping = self.selected_mapping()
        physical = mapping.get("lc_gen_predio", "")
        if not physical:
            return []
        values = set()
        if self.source_combo.currentData() == "loaded_layers":
            layer = QgsProject.instance().mapLayer(physical)
            if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                return []
            field_index = layer.fields().indexOf("nombre_proyecto")
            if field_index < 0:
                return []
            request = QgsFeatureRequest()
            request.setSubsetOfAttributes([field_index])
            request.setFlags(QgsFeatureRequest.NoGeometry)
            for feature in layer.getFeatures(request):
                value = feature[field_index]
                if value not in (None, ""):
                    values.add(str(value).strip())
                if len(values) > 500:
                    raise ValueError(
                        "Se detectaron más de 500 proyectos; revise la fuente."
                    )
        else:
            source = GeoPackageDataSource(self.path_edit.text().strip())
            try:
                descriptor = source.describe(physical)
                if "nombre_proyecto" not in descriptor.fields:
                    return []
                for row in source.iter_rows(physical, ("nombre_proyecto",)):
                    value = row.get("nombre_proyecto")
                    if value not in (None, ""):
                        values.add(str(value).strip())
                    if len(values) > 500:
                        raise ValueError(
                            "Se detectaron más de 500 proyectos; revise la fuente."
                        )
            finally:
                source.close()
        return sorted(values, key=lambda value: value.casefold())

    def refresh_project_choices(self) -> None:
        combo = self.project_combo
        if combo is None or self._refreshing_projects:
            return
        self._refreshing_projects = True
        previous = str(combo.currentData() or "")
        saved = str(
            QSettings().value(self.setting_key("selected_project"), "") or ""
        )
        try:
            try:
                projects = self.discover_project_names()
                error = ""
            except Exception as exc:
                projects = []
                error = str(exc)
            self.available_projects = projects
            combo.blockSignals(True)
            combo.clear()
            if error:
                combo.addItem("Proyecto no disponible", "__required__")
                self.project_status_label.setText(error)
                self.project_status_label.setStyleSheet(
                    "QLabel { color: #b00020; font-weight: 700; }"
                )
                return
            if not projects:
                combo.addItem("Sin proyecto detectado", "__required__")
                self.project_status_label.setText(
                    "Asigne lc_gen_predio con el campo nombre_proyecto."
                )
                self.project_status_label.setStyleSheet(
                    "QLabel { color: #a16207; font-weight: 700; }"
                )
                return

            normalized = {
                self.normalized_project_name(project): project
                for project in projects
            }
            detected = None
            detected_from = ""
            for hint in self.project_hint_candidates():
                match = normalized.get(self.normalized_project_name(hint))
                if match is not None:
                    detected = match
                    detected_from = hint
                    break
            wanted = (
                previous
                if previous in projects or previous == "__all__"
                else saved
                if saved in projects or saved == "__all__"
                else detected
                if detected is not None
                else projects[0]
                if len(projects) == 1
                else "__required__"
            )
            if len(projects) > 1:
                combo.addItem("Seleccione un proyecto…", "__required__")
            for project_name in projects:
                combo.addItem(project_name, project_name)
            combo.insertSeparator(combo.count())
            combo.addItem("Todos los proyectos (explícito)", "__all__")
            index = combo.findData(wanted)
            combo.setCurrentIndex(index if index >= 0 else 0)
            if detected is not None and wanted == detected:
                status = "Detectado automáticamente desde {0}.".format(
                    detected_from
                )
            elif wanted == "__all__":
                status = "Se ejecutarán explícitamente todos los proyectos."
            elif wanted != "__required__":
                status = "Proyecto de trabajo seleccionado."
            else:
                status = "Hay {0} proyectos: elija cuál procesar.".format(
                    len(projects)
                )
            self.project_status_label.setText(status)
            self.project_status_label.setStyleSheet(
                "QLabel { color: %s; font-weight: 700; }"
                % ("#a16207" if wanted == "__required__" else "#075f50")
            )
        finally:
            combo.blockSignals(False)
            self._refreshing_projects = False

    def on_project_selection_changed(self, *_args) -> None:
        if self._refreshing_projects or self.project_combo is None:
            return
        value = str(self.project_combo.currentData() or "")
        QSettings().setValue(self.setting_key("selected_project"), value)
        if value == "__required__":
            self.project_status_label.setText(
                "Seleccione un proyecto antes de validar."
            )
            self.project_status_label.setStyleSheet(
                "QLabel { color: #b00020; font-weight: 700; }"
            )
        elif value == "__all__":
            self.project_status_label.setText(
                "Se ejecutarán explícitamente todos los proyectos."
            )
            self.project_status_label.setStyleSheet(
                "QLabel { color: #a16207; font-weight: 700; }"
            )
        else:
            self.project_status_label.setText(
                "Proyecto activo: {0}.".format(value)
            )
            self.project_status_label.setStyleSheet(
                "QLabel { color: #075f50; font-weight: 700; }"
            )

    def selected_project(self) -> str:
        if self.project_combo is None:
            raise ValueError("No está disponible el selector de proyecto.")
        value = str(self.project_combo.currentData() or "")
        if value in {"", "__required__"}:
            raise ValueError(
                "Seleccione el proyecto de trabajo antes de ejecutar."
            )
        return "" if value == "__all__" else value

    def new_snapshot_path(self):
        descriptor, value = tempfile.mkstemp(prefix=TEMP_PREFIX, suffix=".gpkg")
        os.close(descriptor)
        path = Path(value).resolve()
        path.unlink(missing_ok=True)
        self._snapshot_under_construction = str(path)
        return path

    def write_snapshot_manifest(self, path, payload):
        db = sqlite3.connect(str(path))
        try:
            db.execute(
                "CREATE TABLE IF NOT EXISTS mapingtool_gpkg_snapshot_manifest "
                "(manifest_key TEXT PRIMARY KEY, manifest_json TEXT NOT NULL)"
            )
            db.execute(
                "INSERT OR REPLACE INTO mapingtool_gpkg_snapshot_manifest VALUES (?, ?)",
                ("snapshot-v1", json.dumps(payload, sort_keys=True, separators=(",", ":"))),
            )
            db.commit()
        finally:
            db.close()

    @staticmethod
    def update_snapshot_progress(dialog, completed, total, start=0, end=100):
        ratio = min(1.0, max(0.0, float(completed) / max(1.0, float(total))))
        dialog.setValue(int(start + ((end - start) * ratio)))
        QApplication.processEvents()
        return dialog.wasCanceled()

    def snapshot_loaded_layers(self, mapping, progress):
        snapshot = None
        output_mapping = {}
        evidence = []
        initialized = False
        logical_names = list(self.required_entities())
        layer_count = max(1, len(logical_names))
        for layer_index, logical_name in enumerate(logical_names):
            segment_start = int((layer_index * 80) / layer_count)
            segment_end = int(((layer_index + 1) * 80) / layer_count)
            layer_id = mapping.get(logical_name, "")
            if not layer_id:
                self.update_snapshot_progress(progress, 1, 1, segment_start, segment_end)
                continue
            layer = QgsProject.instance().mapLayer(layer_id)
            if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                self.update_snapshot_progress(progress, 1, 1, segment_start, segment_end)
                continue
            if snapshot is None:
                snapshot = self.new_snapshot_path()
            options = QgsVectorFileWriter.SaveVectorOptions()
            options.driverName = "GPKG"
            options.layerName = logical_name
            feedback = QgsFeedback()
            options.feedback = feedback

            def writer_progress(value, start=segment_start, end=segment_end):
                if self.update_snapshot_progress(progress, value, 100, start, end):
                    feedback.cancel()

            feedback.progressChanged.connect(writer_progress)
            progress.canceled.connect(feedback.cancel)
            options.actionOnExistingFile = (
                QgsVectorFileWriter.CreateOrOverwriteFile
                if not initialized else QgsVectorFileWriter.CreateOrOverwriteLayer
            )
            result = QgsVectorFileWriter.writeAsVectorFormatV3(
                layer, str(snapshot), QgsProject.instance().transformContext(), options
            )
            if feedback.isCanceled() or progress.wasCanceled():
                raise InterruptedError("Captura de capas cancelada por el usuario.")
            if isinstance(result, tuple) and result[0] != QgsVectorFileWriter.NoError:
                raise RuntimeError("Fallo capturando {0}: {1}".format(logical_name, result))
            self.update_snapshot_progress(progress, 1, 1, segment_start, segment_end)
            initialized = True
            output_mapping[logical_name] = logical_name
            uri = str(layer.dataProvider().dataSourceUri() or "")
            evidence.append(
                {
                    "logical_name": logical_name,
                    "layer_id": layer.id(),
                    "layer_name": layer.name(),
                    "provider": layer.providerType(),
                    "provider_uri_sha256": hashlib.sha256(uri.encode("utf-8")).hexdigest().upper(),
                    "crs": layer.crs().authid(),
                    "fields": [field.name() for field in layer.fields()],
                    "feature_count": int(layer.featureCount()),
                }
            )
        if snapshot:
            self.write_snapshot_manifest(
                snapshot,
                {
                    "schema_version": 1,
                    "source_mode": "loaded_layers",
                    "provider_uri_stored": False,
                    "mapping": output_mapping,
                    "layers": evidence,
                },
            )
        return snapshot, output_mapping

    def prepare_config(self):
        self.cleanup_snapshot()
        self.refresh_package_scope()
        if self.package_scope_error:
            raise ValueError(self.package_scope_error)
        mapping = self.selected_mapping()
        project_name = self.selected_project()
        snapshot = None
        worker_mapping = {}
        self._snapshot_under_construction = None
        progress = QProgressDialog(
            "Preparando snapshot portable...",
            "Cancelar",
            0,
            100,
            self.dock,
        )
        progress.setWindowTitle("Calidad GPKG")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(250)
        progress.setAutoClose(False)
        try:
            if self.rule_ids and self.source_combo.currentData() == "loaded_layers":
                snapshot, worker_mapping = self.snapshot_loaded_layers(mapping, progress)
            elif self.rule_ids:
                source = Path(self.path_edit.text().strip()).expanduser().resolve()
                if source.suffix.lower() != ".gpkg":
                    raise ValueError("Seleccione un archivo .gpkg.")
                if any(part.casefold() == ".mergin" for part in source.parts):
                    raise ValueError(
                        "Seleccione el GeoPackage de trabajo, no la copia interna .mergin."
                    )
                snapshot = self.new_snapshot_path()
                backup_geopackage(
                    source,
                    snapshot,
                    cancel_check=progress.wasCanceled,
                    progress_callback=lambda completed, total: self.update_snapshot_progress(
                        progress, completed, total, 0, 80
                    ),
                )
                worker_mapping = mapping
            snapshot_sha256 = (
                _sha256_file(
                    snapshot,
                    cancel_check=progress.wasCanceled,
                    progress_callback=lambda completed, total: self.update_snapshot_progress(
                        progress, completed, total, 80, 100
                    ),
                )
                if snapshot
                else ""
            )
            config = {
                "snapshot_path": str(snapshot) if snapshot else "",
                "snapshot_sha256": snapshot_sha256,
                "layer_mapping": worker_mapping,
                "source_mode": str(self.source_combo.currentData()),
                "project_name": project_name,
                "scope_profile_id": (
                    self.package_scope.profile_id if self.package_scope else ""
                ),
                "scope_sha256": (
                    self.package_scope.sha256 if self.package_scope else ""
                ),
            }
        except BaseException:
            failed = self._snapshot_under_construction
            self._snapshot_under_construction = None
            _safe_remove(failed)
            raise
        finally:
            progress.close()
        self._snapshot_under_construction = None
        self.snapshot_path = str(snapshot) if snapshot else None
        settings = QSettings()
        settings.setValue(
            self.setting_key("gpkg_path"),
            self.path_edit.text().strip(),
        )
        settings.setValue(
            self.setting_key("source_mode"),
            self.source_combo.currentData(),
        )
        settings.setValue(
            self.setting_key("selected_project"),
            str(self.project_combo.currentData() or ""),
        )
        settings.sync()
        return config

    def cleanup_snapshot(self):
        path = self.snapshot_path
        self.snapshot_path = None
        _safe_remove(path)

    def cleanup_store(self):
        if self.store is not None:
            self.store.remove()
            self.store = None
            self.store_path = None
        elif self.store_path:
            _safe_remove(self.store_path)
            self.store_path = None

    def cleanup_run_files(self):
        self.cleanup_store()
        self.cleanup_snapshot()

    def preflight(self):
        if self.worker and self.worker.isRunning():
            return
        selected = self.selected_rules(selected_only=True)
        selected_ids = [rule.id for rule in selected]
        if not selected_ids:
            QMessageBox.information(
                self.dock,
                "Sin reglas",
                "Marque las reglas que sí hacen parte del análisis de este paquete.",
            )
            return
        try:
            config = self.prepare_config()
        except Exception as exc:
            self.status_label.setText(str(exc))
            return
        self.preflight_btn.setEnabled(False)
        current_reco_filter_policy = self.reco_filter_policy()
        config["reco_filter_policy"] = current_reco_filter_policy
        current_processing_filter_policy = self.processing_filter_policy()
        config["processing_filter_policy"] = current_processing_filter_policy
        self.worker = PortableValidationWorker(
            config,
            selected_ids,
            None,
            test_only=True,
            reco_filter_policy=current_reco_filter_policy,
            processing_filter_policy=current_processing_filter_policy,
        )
        self.worker.tested.connect(self.on_tested)
        self.worker.finished_all.connect(lambda _summary: self.preflight_btn.setEnabled(True))
        self.worker.start()

    def on_tested(self, ok, message):
        self.status_label.setText(message)
        if ok:
            QMessageBox.information(self.dock, "Preflight correcto", message)
        else:
            QMessageBox.warning(self.dock, "Preflight no apto", message)

    def start_validation(self):
        if not self.rule_ids or (self.worker and self.worker.isRunning()):
            return
        try:
            config = self.prepare_config()
        except Exception as exc:
            self.status_label.setText(str(exc))
            return
        self.cleanup_store()
        self.store = PortableResultStore.create()
        self.store_path = str(self.store.path)
        self.summary_table.setRowCount(0)
        self.summary_rows = {}
        for rule_id in self.rule_ids:
            self.add_summary(rule_id, "pendiente", 0, "")
        self.progress.setMaximum(len(self.rule_ids))
        self.progress.setValue(0)
        self.set_running(True)
        current_reco_filter_policy = self.reco_filter_policy()
        config["reco_filter_policy"] = current_reco_filter_policy
        current_processing_filter_policy = self.processing_filter_policy()
        config["processing_filter_policy"] = current_processing_filter_policy
        self.worker = PortableValidationWorker(
            config,
            self.rule_ids,
            self.store_path,
            test_only=False,
            reco_filter_policy=current_reco_filter_policy,
            processing_filter_policy=current_processing_filter_policy,
        )
        self.worker.rule_started.connect(
            lambda rule_id: self.update_summary(rule_id, "ejecutando", 0, "")
        )
        self.worker.rule_finished.connect(self.on_rule_finished)
        self.worker.finished_all.connect(self.on_finished)
        self.worker.start()

    def on_rule_finished(self, payload):
        rule_id = payload.get("rule_id", "")
        self.update_summary(
            rule_id,
            payload.get("status", "error"),
            payload.get("count", 0),
            payload.get("message", ""),
        )
        self.progress.setValue(min(self.progress.value() + 1, self.progress.maximum()))

    def on_finished(self, summary):
        if self._unloading:
            return
        cancelled = bool(summary.get("cancelled", False))
        if cancelled:
            for rule_id, row in list(self.summary_rows.items()):
                status = self.summary_table.item(row, 1).text()
                if status in ("pendiente", "ejecutando"):
                    self.update_summary(
                        rule_id,
                        "cancelado",
                        0,
                        "No ejecutada por cancelacion de la corrida.",
                    )
            self.progress.setValue(self.progress.maximum())
        self.set_running(False)
        self.page_number = 0
        self.refresh_page()
        self.status_label.setText(
            "Finalizada: {0} OK, {1} no OK, cancelada={2}.".format(
                summary.get("ok", 0), summary.get("errors", 0), summary.get("cancelled", False)
            )
        )

    def cancel(self):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()

    def set_running(self, running):
        self.run_btn.setEnabled(not running and bool(self.rule_ids))
        self.preflight_btn.setEnabled(not running)
        self.cancel_btn.setEnabled(running)
        self.export_btn.setEnabled(not running)
        self.source_combo.setEnabled(not running)
        self.mapping_table.setEnabled(not running)

    def refresh_page(self):
        total = self.store.count() if self.store is not None else 0
        pages = (total + PAGE_SIZE - 1) // PAGE_SIZE
        if pages:
            self.page_number = min(self.page_number, pages - 1)
        else:
            self.page_number = 0
        rows = self.store.page(self.page_number, PAGE_SIZE) if self.store else []
        self.detail_table.setRowCount(len(rows))
        for row_number, row in enumerate(rows):
            for column, name in enumerate(self.output_columns):
                item = QTableWidgetItem("" if row.get(name) is None else str(row.get(name)))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.detail_table.setItem(row_number, column, item)
        self.page_label.setText(
            "Pagina {0} de {1} | {2} filas".format(
                self.page_number + 1 if pages else 0, pages, total
            )
        )
        self.previous_btn.setEnabled(self.page_number > 0)
        self.next_btn.setEnabled(self.page_number + 1 < pages)

    def previous_page(self):
        if self.page_number > 0:
            self.page_number -= 1
            self.refresh_page()

    def next_page(self):
        if self.store and (self.page_number + 1) * PAGE_SIZE < self.store.count():
            self.page_number += 1
            self.refresh_page()

    def export_csv(self):
        if self.store is None or not self.store.count():
            QMessageBox.information(self.dock, "Sin resultados", "No hay hallazgos para exportar.")
            return
        path, _selected = QFileDialog.getSaveFileName(
            self.dock, "Exportar Calidad GPKG", "calidad_gpkg.csv", "CSV (*.csv)"
        )
        if not path:
            return
        destination = Path(path)
        descriptor, partial_value = tempfile.mkstemp(
            prefix="." + destination.name + ".partial-", dir=str(destination.parent)
        )
        os.close(descriptor)
        partial = Path(partial_value)
        try:
            with partial.open("w", encoding="utf-8-sig", newline="") as stream:
                writer = csv.DictWriter(
                    stream, fieldnames=self.output_columns, delimiter=";"
                )
                writer.writeheader()
                for row in self.store.iter_rows():
                    writer.writerow(
                        {name: _csv_value(row.get(name)) for name in self.output_columns}
                    )
            os.replace(partial, destination)
        finally:
            partial.unlink(missing_ok=True)
        self.status_label.setText("CSV exportado: {0}".format(destination))

    def create_dock(self):
            self.dock = QDockWidget(PLUGIN_NAME, self.iface.mainWindow())
            self.dock.setObjectName(PLUGIN_NAME.replace(" ", "_"))

            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            root = QWidget()
            scroll.setWidget(root)
            layout = QVBoxLayout(root)
            layout.setContentsMargins(8, 8, 8, 8)
            layout.setSpacing(8)

            family_key = PLUGIN_FAMILY if PLUGIN_FAMILY != "*" else "*"
            accent = FAMILY_COLORS.get(family_key, FAMILY_COLORS["*"])
            self.accent_color = accent
            header = QVBoxLayout()
            header.setContentsMargins(0, 0, 0, 0)
            header.setSpacing(2)
            title = QLabel(PLUGIN_NAME)
            title.setStyleSheet("QLabel { font-size: 16px; font-weight: 700; color: #17212b; }")
            family_context = QLabel(
                "{0} | {1} REGLAS GPKG".format(
                    FAMILY_LABELS.get(family_key, family_key.upper()),
                    len(self.rules),
                )
            )
            family_context.setObjectName("qualityFamilyContext")
            family_context.setStyleSheet(
                "QLabel { color: %s; padding: 1px 0 5px 0; "
                "border: 0; border-bottom: 2px solid %s; font-size: 11px; font-weight: 700; }"
                % (accent, accent)
            )
            header.addWidget(title)
            header.addWidget(family_context)
            layout.addLayout(header)

            layout.addLayout(self.create_action_bar())

            section_specs = [
                ("connection", "Fuente de capas / GeoPackage", self.create_connection_panel, True),
                ("rules", "Reglas", self.create_rules_panel, True),
                ("summary", "Resumen por regla", self.create_summary_panel, True),
                ("detail", "Detalle de inconsistencias", self.create_detail_panel, True),
                ("console", "Consola", self.create_console_panel, False),
            ]
            for key, section_title, factory, expanded in section_specs:
                section = CollapsibleSection(section_title, accent, expanded=expanded)
                section.setContentLayout(factory())
                self.sections[key] = section
                layout.addWidget(section)

            self.status_label = QTextEdit()
            self.status_label.setReadOnly(True)
            self.status_label.setPlainText("Listo.")
            self.status_label.setMinimumHeight(44)
            self.status_label.setMaximumHeight(92)
            self.status_label.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            self.status_label.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.status_label.setStyleSheet(
                "QTextEdit { background: #f7f9fb; color: #263746; "
                "border: 1px solid #cbd5df; border-radius: 3px; padding: 4px; }"
            )
            self.progress = QProgressBar()
            self.progress.setMinimum(0)
            self.progress.setMaximum(len(self.rules))
            self.progress.setValue(0)
            layout.addWidget(self.status_label)
            layout.addWidget(self.progress)
            layout.addStretch(1)

            self.dock.setWidget(scroll)
            self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dock)
            self.load_saved_connections()
            self.load_preferences()
            self.load_rules_table()

    def theme_icon(self, name: str, fallback):
            icon = QgsApplication.getThemeIcon("/" + name)
            if icon.isNull():
                return self.dock.style().standardIcon(fallback)
            return icon

    def command_button_style(self, role: str = "secondary") -> str:
            if role == "primary":
                hover = QColor(self.accent_color).darker(115).name()
                return (
                    "QToolButton { background: %s; color: white; border: 1px solid %s; "
                    "border-radius: 3px; padding: 4px 9px; font-weight: 700; }"
                    "QToolButton:hover { background: %s; border-color: %s; }"
                    "QToolButton:disabled { background: #d5dde3; color: #7a8791; border-color: #c4cdd4; }"
                    % (self.accent_color, self.accent_color, hover, hover)
                )
            return (
                "QToolButton { background: #ffffff; color: #263746; border: 1px solid #aebcc7; "
                "border-radius: 3px; padding: 4px 8px; font-weight: 600; }"
                "QToolButton:hover { background: #eef3f6; border-color: %s; }"
                "QToolButton:disabled { background: #f1f3f5; color: #9aa4ac; border-color: #d5dce1; }"
                % self.accent_color
            )

    def create_command_button(
            self,
            text: str,
            tooltip: str,
            theme_icon_name: str,
            fallback_icon,
            callback,
            role: str = "secondary",
            width=None,
        ):
            button = QToolButton()
            button.setText(text)
            button.setToolTip(tooltip)
            button.setAccessibleName(text)
            button.setIcon(self.theme_icon(theme_icon_name, fallback_icon))
            button.setIconSize(QSize(16, 16))
            button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            button.setAutoRaise(False)
            button.setMinimumHeight(30)
            button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            if width:
                button.setFixedWidth(width)
            button.setStyleSheet(self.command_button_style(role))
            button.clicked.connect(callback)
            return button

    def create_action_bar(self):
            layout = QVBoxLayout()
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(4)
            command_row = QHBoxLayout()
            command_row.setContentsMargins(0, 0, 0, 0)
            command_row.setSpacing(6)
            output_row = QHBoxLayout()
            output_row.setContentsMargins(0, 0, 0, 0)
            output_row.setSpacing(6)
            automation_row = QHBoxLayout()
            automation_row.setContentsMargins(2, 0, 0, 0)
            automation_row.setSpacing(6)
            self.run_selected_btn = self.create_command_button(
                "Ejecutar marcadas",
                "Ejecutar solamente las reglas marcadas del grupo actual",
                "mActionStart.svg",
                QStyle.SP_MediaPlay,
                lambda: self.start_validation(selected_only=True),
                role="primary",
                width=160,
            )
            self.run_all_btn = self.create_command_button(
                "Ejecutar grupo",
                "Ejecutar todas las reglas del grupo mostrado, estén marcadas o no",
                "mActionStart.svg",
                QStyle.SP_MediaPlay,
                lambda: self.start_validation(selected_only=False),
                width=160,
            )
            self.cancel_btn = self.create_command_button(
                "Cancelar",
                "Cancelar al finalizar la regla que esta en ejecucion",
                "mActionStop.svg",
                QStyle.SP_MediaStop,
                self.cancel_validation,
                width=90,
            )
            self.cancel_btn.setEnabled(False)
            self.load_map_btn = self.create_command_button(
                "Añadir al mapa",
                "Crear capas con los resultados actuales y añadirlas al proyecto QGIS",
                "mActionAddLayer.svg",
                QStyle.SP_FileDialogDetailedView,
                self.load_results_to_map,
                width=145,
            )
            self.save_config_btn = self.create_command_button(
                "Guardar ajustes",
                "Guardar conexión, reglas marcadas y disposición de la interfaz",
                "mActionFileSave.svg",
                QStyle.SP_DialogSaveButton,
                lambda: self.save_preferences(show_message=True),
                width=145,
            )

            self.export_menu_btn = QToolButton()
            self.export_menu_btn.setText("Exportar")
            self.export_menu_btn.setToolTip("Exportar los resultados actuales")
            self.export_menu_btn.setIcon(self.theme_icon("mActionExport.svg", QStyle.SP_DialogSaveButton))
            self.export_menu_btn.setIconSize(QSize(16, 16))
            self.export_menu_btn.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            self.export_menu_btn.setPopupMode(QToolButton.InstantPopup)
            self.export_menu_btn.setAutoRaise(False)
            self.export_menu_btn.setMinimumHeight(30)
            self.export_menu_btn.setFixedWidth(110)
            self.export_menu_btn.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            self.export_menu_btn.setStyleSheet(self.command_button_style())
            export_menu = QMenu(self.export_menu_btn)
            export_csv_action = export_menu.addAction("CSV")
            export_csv_action.triggered.connect(self.export_csv)
            export_excel_action = export_menu.addAction("Paquete Excel (ZIP)")
            export_excel_action.triggered.connect(self.export_excel)
            export_gpkg_action = export_menu.addAction("GeoPackage")
            export_gpkg_action.triggered.connect(self.export_gpkg)
            self.export_menu_btn.setMenu(export_menu)

            self.auto_map_box = QCheckBox("Añadir al mapa al finalizar")
            self.auto_map_box.setChecked(PLUGIN_FAMILY == "sig")
            self.auto_map_box.setToolTip("Crear automáticamente las capas al finalizar, si el volumen es manejable")

            command_row.addWidget(self.run_selected_btn)
            command_row.addWidget(self.run_all_btn)
            command_row.addWidget(self.cancel_btn)
            command_row.addStretch(1)
            output_row.addWidget(self.load_map_btn)
            output_row.addWidget(self.export_menu_btn)
            output_row.addWidget(self.save_config_btn)
            output_row.addStretch(1)
            automation_row.addWidget(self.auto_map_box)
            automation_row.addStretch(1)
            layout.addLayout(command_row)
            layout.addLayout(output_row)
            layout.addLayout(automation_row)
            return layout

    def create_rules_panel(self):
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(4, 4, 4, 4)

            processing_filter_title = QLabel("Filtros de procesamiento")
            processing_filter_title.setStyleSheet("QLabel { font-weight: 700; }")
            layout.addWidget(processing_filter_title)
            buttons = QGridLayout()
            self.select_all_box = QCheckBox("Procesar todas las reglas visibles")
            self.select_all_box.setChecked(True)
            self.select_all_box.stateChanged.connect(self.toggle_all_rules)
            self.family_filter_button = QToolButton()
            self.family_filter_button.setObjectName("MapingToolFamilyMultiFilter")
            self.family_filter_button.setText("Todos los grupos")
            self.family_filter_button.setPopupMode(QToolButton.InstantPopup)
            self.family_filter_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
            self.family_filter_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self.family_filter_menu = QMenu(self.family_filter_button)
            self.family_filter_all_action = self.family_filter_menu.addAction(
                "Todos los grupos"
            )
            self.family_filter_all_action.setCheckable(True)
            self.family_filter_all_action.setChecked(True)
            self.family_filter_all_action.toggled.connect(
                lambda checked, action=self.family_filter_all_action:
                self.on_family_filter_changed(checked, action)
            )
            self.family_filter_menu.addSeparator()
            self.family_filter_actions = OrderedDict()
            for family in sorted({rule.family for rule in self.rules}):
                action = self.family_filter_menu.addAction(
                    FAMILY_LABELS.get(family, family.upper())
                )
                action.setCheckable(True)
                action.setData(family)
                action.toggled.connect(
                    lambda checked, current_action=action:
                    self.on_family_filter_changed(checked, current_action)
                )
                self.family_filter_actions[family] = action
            self.family_filter_button.setMenu(self.family_filter_menu)
            self._changing_family_filter = False
            self.rule_search_edit = QLineEdit()
            self.rule_search_edit.setPlaceholderText(
                "Buscar regla por código, componente o descripción"
            )
            self.rule_search_edit.setClearButtonEnabled(True)
            self.rule_search_edit.textChanged.connect(self.apply_rule_filter)

            buttons.addWidget(self.select_all_box, 0, 0, 1, 2)
            buttons.addWidget(QLabel("Grupo"), 1, 0)
            buttons.addWidget(self.family_filter_button, 1, 1)
            buttons.addWidget(QLabel("Buscar"), 2, 0)
            buttons.addWidget(self.rule_search_edit, 2, 1)
            buttons.setColumnStretch(1, 1)
            layout.addLayout(buttons)

            self.reco_filter_panel = QWidget()
            self.reco_filter_panel.setObjectName("recoFilterPanel")
            reco_filter_layout = QGridLayout(self.reco_filter_panel)
            reco_filter_layout.setContentsMargins(8, 6, 8, 6)
            reco_filter_layout.setHorizontalSpacing(14)
            reco_filter_layout.setVerticalSpacing(3)
            reco_filter_title = QLabel("Filtros de alcance RECO")
            reco_filter_title.setStyleSheet("QLabel { font-weight: 700; }")
            reco_filter_help = QLabel(
                "Se aplican despues de cada regla RECO. Todos vienen activos por defecto."
            )
            reco_filter_help.setWordWrap(True)
            reco_filter_layout.addWidget(reco_filter_title, 0, 0, 1, 2)
            reco_filter_layout.addWidget(reco_filter_help, 1, 0, 1, 2)
            self.reco_filter_boxes = {}
            for index, (key, label, _short_label) in enumerate(RECO_FILTER_DEFINITIONS):
                checkbox = QCheckBox(label)
                checkbox.setChecked(True)
                checkbox.stateChanged.connect(self.update_reco_filter_status)
                self.reco_filter_boxes[key] = checkbox
                reco_filter_layout.addWidget(checkbox, 2 + (index // 2), index % 2)
            self.reco_filter_status_label = QLabel()
            self.reco_filter_status_label.setWordWrap(True)
            self.reco_filter_status_label.setStyleSheet(
                "QLabel { color: #334155; padding-top: 3px; }"
            )
            reco_filter_layout.addWidget(self.reco_filter_status_label, 4, 0, 1, 2)
            self.reco_filter_panel.setStyleSheet(
                "QWidget#recoFilterPanel { background: #f5f8fa; "
                "border: 1px solid #cbd5e1; border-radius: 4px; } "
                "QWidget#recoFilterPanel QCheckBox, QWidget#recoFilterPanel QLabel { "
                "border: none; background: transparent; }"
            )
            self.reco_filter_panel.setVisible(
                any(rule.family == "reco" for rule in self.rules)
            )
            layout.addWidget(self.reco_filter_panel)
            self.update_reco_filter_status()

            self.rules_table = QTableWidget()
            self.rules_table.setColumnCount(5)
            self.rules_table.setHorizontalHeaderLabels(["Usar", "Regla", "Grupo", "Componente", "Descripcion"])
            self.rules_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.rules_table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
            self.rules_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
            self.rules_table.setMinimumHeight(180)
            layout.addWidget(self.rules_table)
            return panel

    def create_summary_panel(self):
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(4, 4, 4, 4)
            self.summary_table = QTableWidget()
            self.summary_table.setColumnCount(8)
            self.summary_table.setHorizontalHeaderLabels(
                [
                    "Regla",
                    "Resultado",
                    "Inconsistencias",
                    "Descartadas por filtros",
                    "Predios afectados",
                    "Con excepción",
                    "Por corregir",
                    "Observación",
                ]
            )
            summary_tooltips = {
                0: "Código estable de la regla de calidad.",
                1: "Resultado de la ejecución: pendiente, ejecutando, correcta, no aplicable o error.",
                2: "Cantidad de inconsistencias detectadas por la regla.",
                3: "Resultados descartados por los filtros de procesamiento activos.",
                4: "Cantidad de predios diferentes afectados.",
                5: "Inconsistencias que ya tienen una excepción registrada.",
                6: "Inconsistencias que todavía requieren revisión o corrección.",
                7: "Explicación breve y entendible del resultado.",
            }
            for column, tooltip in summary_tooltips.items():
                self.summary_table.horizontalHeaderItem(column).setToolTip(tooltip)
            self.summary_table.horizontalHeaderItem(3).setToolTip(
                "Resultados descartados por los filtros de procesamiento activos."
            )
            self.summary_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.summary_table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
            self.summary_table.setAlternatingRowColors(True)
            self.summary_table.setWordWrap(False)
            self.summary_table.setMinimumHeight(320)
            self.summary_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            header = self.summary_table.horizontalHeader()
            header.setSectionResizeMode(QHeaderView.Interactive)
            header.setStretchLastSection(True)
            self.summary_table.setColumnWidth(0, 86)
            self.summary_table.setColumnWidth(1, 105)
            self.summary_table.setColumnWidth(2, 118)
            self.summary_table.setColumnWidth(3, 155)
            self.summary_table.setColumnWidth(4, 125)
            self.summary_table.setColumnWidth(5, 105)
            self.summary_table.setColumnWidth(6, 100)
            self.summary_table.setColumnWidth(7, 360)
            self.summary_table.itemClicked.connect(self.filter_detail_from_summary)
            self.summary_table.itemDoubleClicked.connect(self.open_detail_from_summary)
            layout.addWidget(self.summary_table)
            return panel

    def create_detail_panel(self):
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(4, 4, 4, 4)

            filters = QGridLayout()
            filters.setContentsMargins(0, 0, 0, 0)
            filters.setHorizontalSpacing(6)
            filters.setVerticalSpacing(3)
            self.detail_family_filter = QComboBox()
            self.detail_family_filter.addItem("Todos los grupos", "")
            for family in sorted({rule.family for rule in self.rules}):
                self.detail_family_filter.addItem(
                    FAMILY_LABELS.get(family, family.upper()),
                    family,
                )
            self.detail_family_filter.setVisible(PLUGIN_FAMILY == "*")
            self.detail_family_label = QLabel("Grupo")
            self.detail_family_label.setVisible(PLUGIN_FAMILY == "*")
            self.detail_family_filter.currentIndexChanged.connect(
                self.refresh_detail_rule_filter
            )
            self.only_rules_with_results_box = QCheckBox(
                "Listar solo reglas con inconsistencias"
            )
            self.only_rules_with_results_box.stateChanged.connect(
                self.refresh_detail_rule_filter
            )
            self.rule_filter = QComboBox()
            self.rule_filter.addItem("Todas las reglas", "")
            self.rule_filter.currentIndexChanged.connect(self.apply_detail_filter)
            self.search_edit = QLineEdit()
            self.search_edit.setPlaceholderText("Filtrar por NPN, manzana o pk")
            self.search_edit.setClearButtonEnabled(True)
            self.search_edit.textChanged.connect(self.apply_detail_filter)
            self.detail_window_btn = QPushButton("Ver detalle")
            self.detail_window_btn.clicked.connect(self.open_detail_window)
            self.detail_count_label = QLabel("0 inconsistencias")
            self.detail_prev_btn = QPushButton("Anterior")
            self.detail_prev_btn.clicked.connect(self.previous_detail_page)
            self.detail_next_btn = QPushButton("Siguiente")
            self.detail_next_btn.clicked.connect(self.next_detail_page)
            self.detail_page_label = QLabel("Pagina 0 de 0")
            filters.addWidget(self.detail_family_label, 0, 0)
            filters.addWidget(self.detail_family_filter, 0, 1)
            filters.addWidget(self.only_rules_with_results_box, 0, 2, 1, 2)
            filters.addWidget(QLabel("Regla"), 1, 0)
            filters.addWidget(self.rule_filter, 1, 1)
            filters.addWidget(self.detail_count_label, 1, 2)
            filters.addWidget(self.detail_window_btn, 1, 3)
            filters.addWidget(self.search_edit, 2, 0, 1, 4)
            filters.addWidget(self.detail_prev_btn, 3, 0)
            filters.addWidget(self.detail_page_label, 3, 1, 1, 2, Qt.AlignCenter)
            filters.addWidget(self.detail_next_btn, 3, 3)
            filters.setColumnStretch(1, 1)
            layout.addLayout(filters)

            self.detail_table = QTableWidget()
            self.configure_detail_table(self.detail_table)
            self.detail_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.detail_table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
            self.detail_table.setSelectionBehavior(QAbstractItemView.SelectRows)
            self.detail_table.setToolTip("Clic para seleccionar y acercar; doble clic para abrir el formulario QGIS.")
            self.detail_table.itemClicked.connect(self.zoom_from_detail_item)
            self.detail_table.itemDoubleClicked.connect(self.open_form_from_detail_item)
            self.detail_table.setMinimumHeight(340)
            self.detail_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            layout.addWidget(self.detail_table)
            return panel

    def create_console_panel(self):
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(4, 4, 4, 4)
            self.console = QTextEdit()
            self.console.setReadOnly(True)
            self.console.setMinimumHeight(150)
            self.console.setStyleSheet(
                "QTextEdit { background: #101418; color: #d6e2ee; "
                "font-family: Consolas, 'Courier New', monospace; font-size: 9pt; }"
            )
            layout.addWidget(self.console)
            return panel

    def checked_rule_ids(self) -> list[str]:
            if not hasattr(self, "rules_table"):
                return []
            selected = []
            for row, rule in enumerate(self.rules):
                item = self.rules_table.item(row, 0)
                if item and item.checkState() == Qt.Checked:
                    selected.append(rule.id)
            return selected

    def load_rules_table(self):
            self.rules_table.setRowCount(len(self.rules))
            for row, rule in enumerate(self.rules):
                check_item = QTableWidgetItem()
                check_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
                checked = self.saved_rule_ids is None or rule.id in self.saved_rule_ids
                check_item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
                self.rules_table.setItem(row, 0, check_item)
                for col, value in enumerate([rule.id, rule.family, rule.component, rule.title], start=1):
                    item = QTableWidgetItem(str(value))
                    if col == 2:
                        item.setForeground(QColor(FAMILY_COLORS.get(rule.family, "#244C66")))
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                    self.rules_table.setItem(row, col, item)
            self.rules_table.resizeColumnsToContents()
            self.select_all_box.blockSignals(True)
            self.select_all_box.setChecked(
                all(
                    self.rules_table.item(row, 0).checkState() == Qt.Checked
                    for row in range(self.rules_table.rowCount())
                )
            )
            self.select_all_box.blockSignals(False)
            self.apply_rule_filter()

    def toggle_all_rules(self):
            state = Qt.Checked if self.select_all_box.isChecked() else Qt.Unchecked
            for row in range(self.rules_table.rowCount()):
                if not self.rules_table.isRowHidden(row):
                    self.rules_table.item(row, 0).setCheckState(state)

    def selected_family_filters(self) -> set[str]:
            if not hasattr(self, "family_filter_all_action"):
                return set()
            if self.family_filter_all_action.isChecked():
                return set()
            return {
                family
                for family, action in self.family_filter_actions.items()
                if action.isChecked()
            }

    def set_family_filters(self, families) -> None:
            if not hasattr(self, "family_filter_all_action"):
                return
            selected = {
                str(value).strip()
                for value in families
                if str(value).strip() in self.family_filter_actions
            }
            self._changing_family_filter = True
            try:
                self.family_filter_all_action.setChecked(not selected)
                for family, action in self.family_filter_actions.items():
                    action.setChecked(family in selected)
            finally:
                self._changing_family_filter = False
            self.apply_rule_filter()

    def on_family_filter_changed(self, checked=False, source_action=None):
            if getattr(self, "_changing_family_filter", False):
                return
            # La clase principal del plugin no hereda QObject, por lo que no puede
            # usar QObject.sender(). Cada QAction entrega su identidad de forma
            # explicita al conectar la senal.
            sender = source_action
            self._changing_family_filter = True
            try:
                if sender is self.family_filter_all_action and checked:
                    for action in self.family_filter_actions.values():
                        action.setChecked(False)
                elif sender in self.family_filter_actions.values() and checked:
                    self.family_filter_all_action.setChecked(False)
                if not self.family_filter_all_action.isChecked() and not any(
                    action.isChecked()
                    for action in self.family_filter_actions.values()
                ):
                    self.family_filter_all_action.setChecked(True)
            finally:
                self._changing_family_filter = False
            self.apply_rule_filter()

    def apply_rule_filter(self):
            families = self.selected_family_filters()
            search = (
                self.rule_search_edit.text().strip().casefold()
                if hasattr(self, "rule_search_edit")
                else ""
            )
            visible = 0
            for row, rule in enumerate(self.rules):
                searchable = " ".join(
                    (str(rule.id), str(rule.family), str(rule.component), str(rule.title))
                ).casefold()
                hide = (bool(families) and rule.family not in families) or (
                    bool(search) and search not in searchable
                )
                self.rules_table.setRowHidden(row, hide)
                if not hide:
                    visible += 1
            if hasattr(self, "status_label"):
                self.status_label.setText("Reglas visibles: {0}".format(visible))
            if hasattr(self, "family_filter_button"):
                if not families:
                    label = "Todos los grupos"
                elif len(families) == 1:
                    family = next(iter(families))
                    label = FAMILY_LABELS.get(family, family.upper())
                else:
                    label = "{0} grupos seleccionados".format(len(families))
                self.family_filter_button.setText(label)
                self.family_filter_button.setToolTip(
                    "Mostrar: "
                    + (
                        "todos los grupos"
                        if not families
                        else ", ".join(
                            FAMILY_LABELS.get(family, family.upper())
                            for family in sorted(families)
                        )
                    )
                )

    def selected_rules(self, selected_only: bool) -> list:
            selected = []
            for row, rule in enumerate(self.rules):
                if self.rules_table.isRowHidden(row):
                    continue
                if not selected_only:
                    selected.append(rule)
                    continue
                item = self.rules_table.item(row, 0)
                if item and item.checkState() == Qt.Checked:
                    selected.append(rule)
            return selected

    def log(self, message: str, level: str | None = None):
            if self._unloading:
                return
            line = "[{0}] {1}".format(time.strftime("%H:%M:%S"), message)
            self.log_lines.append(line)
            print(line)
            if hasattr(self, "console") and self.console is not None:
                normalized = str(message).casefold()
                if level is None:
                    if any(
                        token in normalized
                        for token in (
                            "error",
                            "invalid",
                            "invalido",
                            "no es invocable",
                            "no such table",
                            "syntax",
                            "falló",
                            "fallo",
                            "crítico",
                            "critico",
                            "no apta",
                            "traceback",
                        )
                    ):
                        level = "error"
                    elif any(
                        token in normalized
                        for token in (
                            "advertencia",
                            "warning",
                            "dependencia",
                            "faltante",
                            "omitid",
                            "cancel",
                        )
                    ):
                        level = "warning"
                    elif any(
                        token in normalized
                        for token in (
                            "correct",
                            "finalizada",
                            "completad",
                            "éxito",
                            "exito",
                            "reglas ok",
                        )
                    ):
                        level = "success"
                colors = {
                    "error": QColor("#ff6b6b"),
                    "warning": QColor("#f6ad55"),
                    "success": QColor("#4dd0e1"),
                    "info": QColor("#e5eef5"),
                }
                self.console.setTextColor(colors.get(level or "info", colors["info"]))
                self.console.append(line)

    def snapshot_actions_allowed(self) -> bool:
            if self.validation_running:
                QMessageBox.warning(
                    self.dock,
                    "Validacion en curso",
                    "Espere a que la corrida termine o quede cancelada antes de exportar o crear el mapa.",
                )
                return False
            return True

    def on_rule_started(self, rule_id: str):
            if self._unloading:
                return
            self.status_label.setText("Ejecutando {0}...".format(rule_id))
            self.log("Regla en ejecucion: {0}".format(rule_id))
            self.update_summary_row(rule_id, "ejecutando", None, None, None, None, "")

    def on_rule_finished(self, payload: dict):
            if self._unloading:
                return
            rule_id = payload.get("rule_id", "")
            rows = payload.get("rows", [])
            status = payload.get("status", "error")
            error = payload.get("error", "")
            stored_total = int(payload.get("stored_total", len(rows)) or 0)
            raw_total = int(payload.get("raw_total", stored_total) or 0)
            filtered_out = int(payload.get("filtered_out", 0) or 0)

            if rule_id == "__CONNECTION__":
                self.status_label.setText(error)
                self.log(error)
                return

            predios = int(payload.get("predios", 0) or 0)
            exceptions = int(payload.get("exceptions", 0) or 0)
            missing = stored_total - exceptions
            message = error
            if not message and filtered_out:
                message = "Filtro RECO posterior: {0} filas descartadas.".format(filtered_out)

            self.update_summary_row(
                rule_id,
                status,
                stored_total,
                predios,
                exceptions,
                missing,
                message,
                filtered_out=filtered_out,
            )
            if error:
                self.log(
                    "{0}: {1}".format(rule_id, error),
                    "error"
                    if status in ("error", "backend_integrity_error")
                    else None,
                )
            self.ensure_rule_filter(rule_id)
            self.progress.setValue(min(self.progress.value() + 1, self.progress.maximum()))

    def on_validation_finished(self, summary: dict):
            if self._unloading:
                return
            self.set_running_state(False)
            total_results = self.result_count()
            if summary.get("cancelled"):
                self.status_label.setText("Validacion cancelada. Filas guardadas: {0}".format(total_results))
            else:
                self.status_label.setText(
                    "Validacion finalizada. Reglas OK: {0}. Errores/dependencias: {1}. Filas: {2}.".format(
                        summary.get("ok", 0),
                        summary.get("errors", 0),
                        total_results,
                    )
                )
            self.apply_detail_filter(reset_page=False)
            if total_results > MAX_AUTO_MAP_FEATURES:
                self.log(
                    "Conjunto voluminoso: {0} filas supera el limite de carga automatica de {1}.".format(
                        total_results,
                        MAX_AUTO_MAP_FEATURES,
                    ),
                    "warning",
                )
                action = self.choose_large_result_action(total_results)
                if action == "export":
                    self.export_gpkg()
                elif action == "load":
                    self.load_results_to_map(allow_large=True)
                return
            if (
                hasattr(self, "auto_map_box")
                and self.auto_map_box.isChecked()
                and total_results
                and total_results <= MAX_AUTO_MAP_FEATURES
            ):
                self.load_results_to_map()

    def add_summary_row(
            self,
            rule_id: str,
            status: str,
            total: int,
            predios: int,
            exceptions: int,
            missing: int,
            message: str,
        ):
            row = self.summary_table.rowCount()
            self.summary_table.insertRow(row)
            self.summary_rows[rule_id] = row
            self.summary_data[rule_id] = {
                "rule_id": rule_id,
                "status": status,
                "total": total,
                "predios": predios,
                "filtered_out": 0,
                "exceptions": exceptions,
                "missing": missing,
                "message": message,
            }
            values = [
                rule_id,
                self.summary_status_label(status),
                total,
                0,
                predios,
                exceptions,
                missing,
                message,
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(display_value(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                if col == 7 and value:
                    item.setToolTip(display_value(value))
                self.summary_table.setItem(row, col, item)
            self.summary_table.resizeRowsToContents()

    def update_summary_row(
            self,
            rule_id: str,
            status: str,
            total,
            predios,
            exceptions,
            missing,
            message: str,
            filtered_out=None,
        ):
            if rule_id not in self.summary_rows:
                self.add_summary_row(
                    rule_id,
                    status,
                    total or 0,
                    predios or 0,
                    exceptions or 0,
                    missing or 0,
                    message,
                )
                return
            row = self.summary_rows[rule_id]
            current = self.summary_data.setdefault(
                rule_id,
                {
                    "rule_id": rule_id,
                    "status": "",
                    "total": 0,
                    "predios": 0,
                    "filtered_out": 0,
                    "exceptions": 0,
                    "missing": 0,
                    "message": "",
                },
            )
            if status is not None:
                current["status"] = status
            if total is not None:
                current["total"] = total
            if filtered_out is not None:
                current["filtered_out"] = filtered_out
            if predios is not None:
                current["predios"] = predios
            if exceptions is not None:
                current["exceptions"] = exceptions
            if missing is not None:
                current["missing"] = missing
            if message is not None:
                current["message"] = message
            values = [
                rule_id,
                self.summary_status_label(status) if status is not None else None,
                total,
                filtered_out,
                predios,
                exceptions,
                missing,
                message,
            ]
            for col, value in enumerate(values):
                if value is None:
                    continue
                item = self.summary_table.item(row, col)
                if item is None:
                    item = QTableWidgetItem()
                    self.summary_table.setItem(row, col, item)
                item.setText(display_value(value))
                if col == 7:
                    item.setToolTip(display_value(value))
            self.color_summary_row(row, status, missing or 0)
            self.summary_table.resizeRowsToContents()

    def summary_status_label(self, status: str) -> str:
            labels = {
                "pendiente": "Pendiente",
                "ejecutando": "En ejecución",
                "ok": "Correcta",
                "dependencia": "Falta una capa o dato necesario",
                "dependency_missing": "Falta una capa o dato necesario",
                "not_applicable": "No aplica a este paquete",
                "no_aplica": "No aplica a este paquete",
                "opcional_ausente": "No aplica a este paquete",
                "backend_unsupported": "Aún no disponible para GPKG",
                "timeout": "Tiempo agotado",
                "cancelado": "Cancelada",
                "error": "Error",
            }
            normalized = str(status or "").strip()
            return labels.get(normalized, normalized.replace("_", " ").capitalize())

    def color_summary_row(self, row: int, status: str, missing: int):
            if status == "ok" and missing == 0:
                color = QColor("#1f7a1f")
            elif status == "ok":
                color = QColor("#b00020")
            elif status in ("dependencia", "dependency_missing"):
                color = QColor("#a16207")
            elif status in ("not_applicable", "no_aplica", "opcional_ausente"):
                color = QColor("#475569")
            elif status == "timeout":
                color = QColor("#b45309")
            elif status == "cancelado":
                color = QColor("#64748b")
            else:
                color = QColor("#b00020")
            for col in range(self.summary_table.columnCount()):
                item = self.summary_table.item(row, col)
                if item:
                    item.setForeground(color)
                    if col in (0, 1, 6):
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)

    def ensure_rule_filter(self, rule_id: str):
            self.refresh_detail_rule_filter(preferred_rule=rule_id)

    def refresh_detail_rule_filter(self, *_args, preferred_rule=None):
            if not hasattr(self, "rule_filter"):
                return
            current_rule = preferred_rule or self.rule_filter.currentData() or ""
            family = (
                self.detail_family_filter.currentData() or ""
                if hasattr(self, "detail_family_filter")
                else ""
            )
            only_with_results = (
                self.only_rules_with_results_box.isChecked()
                if hasattr(self, "only_rules_with_results_box")
                else False
            )
            rule_ids = []
            for rule in self.rules:
                if family and rule.family != family:
                    continue
                if only_with_results:
                    summary = self.summary_data.get(rule.id, {})
                    if int(summary.get("total", 0) or 0) <= 0:
                        continue
                rule_ids.append(rule.id)
            self.rule_filter.blockSignals(True)
            self.rule_filter.clear()
            self.rule_filter.addItem("Todas las reglas", "")
            for rule_id in rule_ids:
                self.rule_filter.addItem(rule_id, rule_id)
            index = self.rule_filter.findData(current_rule)
            self.rule_filter.setCurrentIndex(index if index >= 0 else 0)
            self.rule_filter.blockSignals(False)
            self.apply_detail_filter(reset_page=True)

    def filter_detail_from_summary(self, item):
            if item is None:
                return
            rule_item = self.summary_table.item(item.row(), 0)
            if rule_item:
                rule_id = rule_item.text()
                if hasattr(self, "detail_family_filter") and PLUGIN_FAMILY == "*":
                    family = self.family_for_rule(rule_id)
                    family_index = self.detail_family_filter.findData(family)
                    if family_index >= 0:
                        self.detail_family_filter.blockSignals(True)
                        self.detail_family_filter.setCurrentIndex(family_index)
                        self.detail_family_filter.blockSignals(False)
                        self.refresh_detail_rule_filter(preferred_rule=rule_id)
                idx = self.rule_filter.findData(rule_id)
                if idx >= 0:
                    self.rule_filter.setCurrentIndex(idx)

    def open_detail_from_summary(self, item):
            if item is None or self.validation_running:
                return
            rule_item = self.summary_table.item(item.row(), 0)
            if rule_item is None:
                return
            rule_id = rule_item.text().strip()
            self.filter_detail_from_summary(item)
            result_count = 0
            if self.result_store is not None:
                result_count = self.result_store.count(rule_id=rule_id)
            if result_count == 0:
                QMessageBox.information(
                    self.dock,
                    "Regla sin inconsistencias",
                    "La regla {0} no encontró inconsistencias.".format(rule_id),
                )
                return
            self.open_detail_window()

    def detail_columns(self) -> list[str]:
            priority = (
                "pk_id_predio",
                "numero_predial_nacional",
                "proyecto",
                "id_regla",
            )
            return [
                column
                for column in priority
                if column in EXPORT_COLUMNS
            ] + [
                column
                for column in EXPORT_COLUMNS
                if column not in priority
            ]

    def detail_header_labels(self) -> list[str]:
            labels = {
                "pk_id_predio": "PK ID",
                "numero_predial_nacional": "NPN",
                "proyecto": "Proyecto",
                "id_regla": "ID Regla",
                "descripcion_regla": "Descripción",
                "componente": "Componente",
                "matricula_inmobiliaria": "Matrícula inmobiliaria",
                "tabla_error_1": "Primera capa relacionada",
                "pk_tabla_error_1": "PK primera capa",
                "tabla_error_2": "Segunda capa relacionada",
                "pk_tabla_error_2": "PK segunda capa",
                "tiene_excepcion": "Tiene excepción",
                "descripcion_excepcion": "Descripción de la excepción",
            }
            return [
                labels.get(column, column.replace("_", " ").capitalize())
                for column in self.detail_columns()
            ]

    def configure_detail_table(self, table):
            columns = self.detail_columns()
            table.setColumnCount(len(columns))
            table.setHorizontalHeaderLabels(self.detail_header_labels())
            table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
            table.horizontalHeader().setStretchLastSection(False)
            for column, name in enumerate(columns):
                width = 155
                if name in ("pk_id_predio", "numero_predial_nacional"):
                    width = 205
                elif name == "id_regla":
                    width = 95
                elif name == "proyecto":
                    width = 150
                table.setColumnWidth(column, width)
                header_item = table.horizontalHeaderItem(column)
                if header_item is not None and name == "id_regla":
                    font = header_item.font()
                    font.setBold(True)
                    header_item.setFont(font)

    def populate_detail_table(self, table, rows):
            columns = self.detail_columns()
            signals_were_blocked = table.blockSignals(True)
            table.setUpdatesEnabled(False)
            try:
                table.clearContents()
                table.setRowCount(len(rows))
                for table_row, row_data in enumerate(rows):
                    for col, column in enumerate(columns):
                        item = QTableWidgetItem(display_value(row_data.get(column)))
                        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                        if col == 0:
                            item.setData(Qt.UserRole, row_data)
                        if column == "id_regla":
                            font = item.font()
                            font.setBold(True)
                            item.setFont(font)
                        if column == "tiene_excepcion" and is_truthy(row_data.get(column)):
                            item.setForeground(QColor("#1d4ed8"))
                        table.setItem(table_row, col, item)
            finally:
                table.blockSignals(signals_were_blocked)
                table.setUpdatesEnabled(True)
                table.viewport().update()

    def previous_detail_page(self):
            if self.detail_page_number > 0:
                self.detail_page_number -= 1
                self.apply_detail_filter(reset_page=False)

    def next_detail_page(self):
            if (self.detail_page_number + 1) * self.detail_page_size < self.detail_filtered_total:
                self.detail_page_number += 1
                self.apply_detail_filter(reset_page=False)

    def reco_filter_policy(self) -> dict[str, bool]:
            boxes = getattr(self, "reco_filter_boxes", {})
            return normalize_reco_filter_policy(
                {
                    key: checkbox.isChecked()
                    for key, checkbox in boxes.items()
                }
            )

    def update_reco_filter_status(self, *_args) -> None:
            label = getattr(self, "reco_filter_status_label", None)
            if label is not None:
                label.setText(reco_filter_policy_summary(self.reco_filter_policy()))

    def visible_detail_rows(self) -> list[dict]:
            return list(self.current_detail_rows)

    def row_data_from_item(self, item):
            if item is None:
                return None
            table = item.tableWidget() if hasattr(item, "tableWidget") else self.detail_table
            first = table.item(item.row(), 0) if table is not None else None
            if first:
                return first.data(Qt.UserRole)
            return None

    def zoom_from_detail_item(self, item):
            row_data = self.row_data_from_item(item)
            if row_data:
                self.select_predio(row_data, open_form=False)

    def open_form_from_detail_item(self, item):
            row_data = self.row_data_from_item(item)
            if row_data:
                self.select_predio(row_data, open_form=True)

    def predio_candidates(self, row_data: dict) -> list[str]:
            candidates = []
            for key in ("pk_id_predio", "pk_tabla_error_1", "pk_tabla_error_2"):
                value = row_data.get(key)
                if value not in (None, "") and str(value) not in candidates:
                    candidates.append(str(value))
            mapped = self.map_ph_to_gen_candidates(row_data)
            for value in mapped:
                if value and str(value) not in candidates:
                    candidates.insert(0, str(value))
            return candidates

    def predial_candidates(self, row_data: dict) -> list[str]:
            candidates = []
            for key in ("numero_predial_nacional", "codigo", "numero_predial_nacional_novedad"):
                value = row_data.get(key)
                if value not in (None, "") and str(value) not in candidates:
                    candidates.append(str(value))
            return candidates

    def predio_lookup_values(self, row_data: dict) -> list[str]:
            values = []
            pk_predio = row_data.get("pk_id_predio")
            if pk_predio not in (None, ""):
                values.append(str(pk_predio))
            for table_key, pk_key in (("tabla_error_1", "pk_tabla_error_1"), ("tabla_error_2", "pk_tabla_error_2")):
                table_name = str(row_data.get(table_key) or "").lower()
                pk_value = row_data.get(pk_key)
                if "lc_gen_predio" in table_name and pk_value not in (None, "") and str(pk_value) not in values:
                    values.append(str(pk_value))
            return values

    def result_layer_uri(self, predio_layer):
            if predio_layer and predio_layer.isValid() and predio_layer.wkbType() != QgsWkbTypes.NoGeometry:
                geometry_name = QgsWkbTypes.displayString(predio_layer.wkbType())
                crs = predio_layer.crs().authid()
                if crs:
                    return "{0}?crs={1}".format(geometry_name, crs)
                return geometry_name
            return "None"

    def fetch_geometry_cache(self, predio_layer, rows: list[dict], cancel_check=None) -> dict:
            cache = {"pk_id": {}, "numero_predial_nacional": {}}
            if not predio_layer or not predio_layer.isValid():
                return cache

            pk_values = []
            npn_values = []
            for row in rows:
                for value in self.predio_lookup_values(row):
                    if value and value not in pk_values:
                        pk_values.append(value)
                for value in self.predial_candidates(row):
                    if value and value not in npn_values:
                        npn_values.append(value)

            field_names = predio_layer.fields().names()
            if "pk_id" in field_names:
                cache["pk_id"].update(
                    self.fetch_geometries_by_field(
                        predio_layer,
                        "pk_id",
                        pk_values,
                        cancel_check=cancel_check,
                    )
                )
            if "numero_predial_nacional" in field_names:
                cache["numero_predial_nacional"].update(
                    self.fetch_geometries_by_field(
                        predio_layer,
                        "numero_predial_nacional",
                        npn_values,
                        cancel_check=cancel_check,
                    )
                )
            return cache

    def fetch_geometries_by_field(
            self,
            layer,
            field_name: str,
            values: list[str],
            cancel_check=None,
        ) -> dict:
            geometries = {}
            batch_size = 350
            clean_values = [str(value) for value in values if value not in (None, "")]
            for start in range(0, len(clean_values), batch_size):
                if cancel_check is not None and cancel_check():
                    raise InterruptedError("Preparacion de geometrias cancelada.")
                batch = clean_values[start : start + batch_size]
                quoted = ", ".join(_qgis_sql_string(value) for value in batch)
                expression = '"{0}" IN ({1})'.format(field_name, quoted)
                request = QgsFeatureRequest().setFilterExpression(expression)
                for feature in layer.getFeatures(request):
                    value = feature[field_name]
                    geometry = feature.geometry()
                    if value not in (None, "") and geometry and not geometry.isEmpty():
                        geometries[str(value)] = QgsGeometry(geometry)
                QApplication.processEvents()
            return geometries

    def geometry_for_result_row(self, row_data: dict, geometry_cache: dict):
            for value in self.predio_lookup_values(row_data):
                geometry = geometry_cache.get("pk_id", {}).get(str(value))
                if geometry:
                    return geometry
            for value in self.predial_candidates(row_data):
                geometry = geometry_cache.get("numero_predial_nacional", {}).get(str(value))
                if geometry:
                    return geometry
            return None

    def build_result_layer(
            self,
            rule_id: str,
            rows: list[dict],
            predio_layer,
            geometry_cache: dict,
            cancel_check=None,
        ):
            layer_name = self.result_layer_name(rule_id)
            layer = QgsVectorLayer(self.result_layer_uri(predio_layer), layer_name, "memory")
            if not layer.isValid():
                layer = QgsVectorLayer("None", layer_name, "memory")

            provider = layer.dataProvider()
            fields = QgsFields()
            used_names = set()
            for column in EXPORT_COLUMNS:
                field_name = _safe_name(column, 30).lower()
                base_name = field_name
                index = 2
                while field_name in used_names:
                    suffix = "_{0}".format(index)
                    field_name = (base_name[: 30 - len(suffix)] + suffix).lower()
                    index += 1
                used_names.add(field_name)
                fields.append(QgsField(field_name, QVariant.String))
            provider.addAttributes(list(fields))
            layer.updateFields()

            features = []
            missing_geometry = 0
            for row_index, row in enumerate(rows):
                if row_index % 250 == 0:
                    QApplication.processEvents()
                    if cancel_check is not None and cancel_check():
                        raise InterruptedError("Preparacion de capa cancelada.")
                feature = QgsFeature(layer.fields())
                feature.setAttributes([display_value(row.get(column)) for column in EXPORT_COLUMNS])
                geometry = self.geometry_for_result_row(row, geometry_cache)
                if geometry:
                    feature.setGeometry(QgsGeometry(geometry))
                elif layer.wkbType() != QgsWkbTypes.NoGeometry:
                    missing_geometry += 1
                features.append(feature)
            _add_features_checked(provider, features, layer_name)
            layer.updateExtents()

            try:
                color = QColor(FAMILY_COLORS.get(str(PLUGIN_FAMILY if PLUGIN_FAMILY != "*" else "sig"), "#1F5D99"))
                color.setAlpha(110)
                symbol = layer.renderer().symbol()
                if symbol:
                    symbol.setColor(color)
            except Exception:
                pass
            return layer, missing_geometry

    def build_table_layer(self, layer_name: str, columns: list[str], rows: list[list]):
            layer = QgsVectorLayer("None", _safe_name(layer_name, 60), "memory")
            provider = layer.dataProvider()
            fields = QgsFields()
            for column in columns:
                fields.append(QgsField(_safe_name(column, 30).lower(), QVariant.String))
            provider.addAttributes(list(fields))
            layer.updateFields()
            features = []
            for row in rows:
                feature = QgsFeature(layer.fields())
                feature.setAttributes([display_value(value) for value in row])
                features.append(feature)
            _add_features_checked(provider, features, layer_name)
            return layer

    def family_for_rule(self, rule_id: str) -> str:
            return self.rule_family_by_id.get(str(rule_id), str(rule_id).split("_")[0].lower())

    def result_layer_name(self, rule_id: str) -> str:
            family = self.family_for_rule(rule_id)
            if PLUGIN_FAMILY == "*":
                return "validacion_{0}_{1}".format(_safe_name(family, 12), _safe_name(rule_id, 32))
            return "validacion_{0}".format(_safe_name(rule_id, 38))

    def iter_result_page_layers(
            self,
            *,
            page_size: int = GPKG_EXPORT_PAGE_SIZE,
            cancel_check=None,
            progress=None,
        ):
            if self.result_store is None:
                return
            predio_layer = self.find_or_load_predio_layer(show_warning=False)
            if predio_layer:
                self.log("Usando geometria desde {0} para capas de resultados.".format(PREDIO_LAYER_NAME))
            else:
                self.log("No se pudo cargar {0}; se generaran capas/exports sin geometria.".format(PREDIO_LAYER_NAME))
            for rule_id in self.result_store.rule_ids():
                first_page = True
                for rows in self.result_store.iter_pages(
                    rule_id=rule_id,
                    page_size=page_size,
                ):
                    if cancel_check is not None and cancel_check():
                        raise InterruptedError("Escritura GPKG cancelada por el usuario.")
                    if progress is not None:
                        progress.setLabelText(
                            "Preparando geometrias para {0}...".format(rule_id)
                        )
                        QApplication.processEvents()
                    geometry_cache = self.fetch_geometry_cache(
                        predio_layer,
                        rows,
                        cancel_check=cancel_check,
                    )
                    page_layer, missing_geometry = self.build_result_layer(
                        rule_id,
                        rows,
                        predio_layer,
                        geometry_cache,
                        cancel_check=cancel_check,
                    )
                    yield rule_id, page_layer, missing_geometry, first_page
                    first_page = False

    def write_result_pages_to_gpkg(self, path: str, progress=None) -> dict:
            """Persist result layers page-by-page and return only complete layers."""

            errors = []
            missing_by_rule = OrderedDict()
            created_rules = set()
            failed_rules = set()
            file_initialized = False
            expected_counts = self.result_store.rule_counts() if self.result_store else {}
            expected_total = sum(int(value) for value in expected_counts.values())
            processed = 0

            def cancelled() -> bool:
                if progress is None:
                    return False
                QApplication.processEvents()
                return bool(progress.wasCanceled())

            for rule_id, layer, missing_geometry, _first_page in self.iter_result_page_layers(
                page_size=GPKG_EXPORT_PAGE_SIZE,
                cancel_check=cancelled,
                progress=progress,
            ):
                page_count = int(layer.featureCount()) if layer and layer.isValid() else 0
                if progress is not None:
                    progress.setLabelText(
                        "Guardando {0}: {1:,} de {2:,} filas...".format(
                            rule_id,
                            min(processed, expected_total),
                            expected_total,
                        )
                    )
                    progress.setValue(min(processed, expected_total))
                    QApplication.processEvents()
                if cancelled():
                    raise InterruptedError("Escritura GPKG cancelada por el usuario.")
                if missing_geometry:
                    missing_by_rule[rule_id] = missing_by_rule.get(rule_id, 0) + missing_geometry
                if rule_id in failed_rules:
                    processed += page_count
                    continue
                if not layer or not layer.isValid():
                    errors.append("{0}: no fue posible crear la pagina temporal".format(rule_id))
                    failed_rules.add(rule_id)
                    continue
                if not file_initialized:
                    action = QgsVectorFileWriter.CreateOrOverwriteFile
                elif rule_id not in created_rules:
                    action = QgsVectorFileWriter.CreateOrOverwriteLayer
                else:
                    action = QgsVectorFileWriter.AppendToLayerNoNewFields
                try:
                    options = QgsVectorFileWriter.SaveVectorOptions()
                    options.driverName = "GPKG"
                    options.layerName = layer.name()
                    options.actionOnExistingFile = action
                    feedback = QgsFeedback()
                    options.feedback = feedback
                    if progress is not None:
                        def writer_progress(value, base=processed, size=page_count, current_rule=rule_id):
                            completed = base + int((float(value) / 100.0) * size)
                            progress.setLabelText(
                                "Guardando {0}: {1:,} de {2:,} filas...".format(
                                    current_rule,
                                    min(completed, expected_total),
                                    expected_total,
                                )
                            )
                            progress.setValue(min(completed, expected_total))
                            QApplication.processEvents()
                            if progress.wasCanceled():
                                feedback.cancel()

                        feedback.progressChanged.connect(writer_progress)
                    result = QgsVectorFileWriter.writeAsVectorFormatV3(
                        layer,
                        path,
                        QgsProject.instance().transformContext(),
                        options,
                    )
                    if feedback.isCanceled() or cancelled():
                        raise InterruptedError("Escritura GPKG cancelada por el usuario.")
                    if isinstance(result, tuple) and result[0] != QgsVectorFileWriter.NoError:
                        errors.append("{0}: {1}".format(rule_id, result))
                        failed_rules.add(rule_id)
                        processed += page_count
                        continue
                    file_initialized = True
                    created_rules.add(rule_id)
                    processed += page_count
                    if progress is not None:
                        progress.setValue(min(processed, expected_total))
                        QApplication.processEvents()
                except Exception as exc:
                    if isinstance(exc, InterruptedError):
                        raise
                    errors.append("{0}: {1}".format(rule_id, exc))
                    failed_rules.add(rule_id)
            created_complete = [
                    rule_id
                    for rule_id in (self.result_store.rule_ids() if self.result_store else [])
                    if rule_id in created_rules and rule_id not in failed_rules
                ]
            if set(created_complete) != set(expected_counts):
                errors.append("El GPKG no contiene todas las reglas esperadas.")
            verified_counts = {}
            if not errors:
                for rule_id, expected in expected_counts.items():
                    if cancelled():
                        raise InterruptedError("Verificacion GPKG cancelada por el usuario.")
                    if progress is not None:
                        progress.setLabelText(
                            "Verificando capa {0}...".format(rule_id)
                        )
                        QApplication.processEvents()
                    layer_name = self.result_layer_name(rule_id)
                    check_layer = QgsVectorLayer(
                        "{0}|layername={1}".format(path, layer_name),
                        layer_name,
                        "ogr",
                    )
                    if not check_layer.isValid():
                        errors.append("{0}: la capa GPKG no puede reabrirse.".format(rule_id))
                        continue
                    actual = int(check_layer.featureCount())
                    verified_counts[rule_id] = actual
                    if actual != int(expected):
                        errors.append(
                            "{0}: GPKG contiene {1} filas; se esperaban {2}.".format(
                                rule_id, actual, expected
                            )
                        )
                    del check_layer
            actual_total = sum(verified_counts.values())
            if not errors and actual_total != expected_total:
                errors.append(
                    "Conteo GPKG total {0}; esperado {1}.".format(
                        actual_total, expected_total
                    )
                )
            return {
                "created_rules": created_complete if not errors else [],
                "errors": errors,
                "missing_by_rule": missing_by_rule,
                "file_initialized": file_initialized,
                "expected_counts": expected_counts,
                "verified_counts": verified_counts,
                "complete": bool(file_initialized and not errors),
            }

    def remove_existing_result_layer(self, layer_name: str):
            for existing in QgsProject.instance().mapLayersByName(layer_name):
                QgsProject.instance().removeMapLayer(existing.id())

    def choose_large_result_action(self, total_results: int) -> str:
            dialog = QMessageBox(self.dock)
            dialog.setIcon(QMessageBox.Warning)
            dialog.setWindowTitle("Resultados voluminosos")
            dialog.setText(
                "Se encontraron {0} inconsistencias.".format(total_results)
            )
            dialog.setInformativeText(
                "Cargar mas de {0} geometrias y numerosas capas puede bloquear QGIS. "
                "Guarde primero el GeoPackage completo para conservar la corrida y "
                "evitar procesarla nuevamente. Tambien puede continuar revisando la "
                "tabla paginada sin cargar todo al mapa.".format(MAX_AUTO_MAP_FEATURES)
            )
            save_button = dialog.addButton("Guardar GPKG", QMessageBox.AcceptRole)
            table_button = dialog.addButton(
                "Seguir en la tabla", QMessageBox.RejectRole
            )
            load_button = dialog.addButton(
                "Cargar de todos modos", QMessageBox.DestructiveRole
            )
            dialog.setDefaultButton(save_button)
            dialog.setEscapeButton(table_button)
            dialog.exec_()
            clicked = dialog.clickedButton()
            if clicked is save_button:
                return "export"
            if clicked is load_button:
                return "load"
            return "table"

    def load_saved_gpkg_results(
            self,
            path: str,
            created_rules,
            missing_geometry: int = 0,
        ) -> bool:
            """Load already-materialized result layers without writing another cache."""

            rules = list(created_rules or [])
            if not rules:
                QMessageBox.warning(
                    self.dock,
                    "GeoPackage sin capas",
                    "El archivo guardado no contiene capas de resultados para cargar.",
                )
                return False

            progress = QProgressDialog(
                "Preparando capas guardadas...",
                "Cancelar",
                0,
                len(rules),
                self.dock,
            )
            progress.setWindowTitle("Cargando resultados al mapa")
            progress.setWindowModality(Qt.WindowModal)
            progress.setMinimumDuration(0)
            progress.setAutoClose(False)
            progress.setAutoReset(False)
            progress.show()
            QApplication.processEvents()

            project = QgsProject.instance()
            canvas = self.iface.mapCanvas()
            previous_render_flag = bool(canvas.renderFlag())
            added_layer_ids = []
            combined_extent = None
            cancelled = False
            try:
                canvas.setRenderFlag(False)
                for index, rule_id in enumerate(rules):
                    progress.setLabelText(
                        "Cargando capa {0} ({1} de {2})...".format(
                            rule_id,
                            index + 1,
                            len(rules),
                        )
                    )
                    progress.setValue(index)
                    QApplication.processEvents()
                    if progress.wasCanceled():
                        cancelled = True
                        break
                    layer_name = self.result_layer_name(rule_id)
                    layer = QgsVectorLayer(
                        "{0}|layername={1}".format(path, layer_name),
                        layer_name,
                        "ogr",
                    )
                    if not layer or not layer.isValid():
                        self.log(
                            "{0}: no fue posible abrir la capa GPKG guardada.".format(
                                rule_id
                            )
                        )
                        continue
                    self.remove_existing_result_layer(layer.name())
                    project.addMapLayer(layer)
                    added_layer_ids.append(layer.id())
                    if (
                        layer.wkbType() != QgsWkbTypes.NoGeometry
                        and layer.featureCount() > 0
                        and not layer.extent().isEmpty()
                    ):
                        if combined_extent is None:
                            combined_extent = layer.extent()
                        else:
                            combined_extent.combineExtentWith(layer.extent())
                    progress.setValue(index + 1)
                    QApplication.processEvents()
            finally:
                canvas.setRenderFlag(previous_render_flag)
                progress.close()

            if cancelled:
                for layer_id in added_layer_ids:
                    if project.mapLayer(layer_id) is not None:
                        project.removeMapLayer(layer_id)
                if previous_render_flag:
                    canvas.refresh()
                self.log(
                    "Carga al mapa cancelada; el GeoPackage guardado se conserva.",
                    "warning",
                )
                QMessageBox.information(
                    self.dock,
                    "Carga cancelada",
                    "No se agregaron capas. El GeoPackage guardado se conserva completo.",
                )
                return False

            self.map_layer_ids.extend(added_layer_ids)
            if combined_extent is not None:
                canvas.setExtent(combined_extent)
            if previous_render_flag:
                canvas.refresh()
            added = len(added_layer_ids)
            self.log(
                "Capas de resultados cargadas desde el GPKG ya guardado: {0}. "
                "Geometrias faltantes: {1}.".format(added, missing_geometry)
            )
            QMessageBox.information(
                self.dock,
                "Resultados en mapa",
                "Capas cargadas desde el archivo guardado: {0}. "
                "Geometrias faltantes: {1}.".format(added, missing_geometry),
            )
            return bool(added)

    def load_results_to_map(self, allow_large: bool = False):
            if not self.snapshot_actions_allowed():
                return
            total_results = self.result_count()
            if not total_results:
                QMessageBox.information(self.dock, "Sin resultados", "No hay resultados para cargar en el mapa.")
                return
            if total_results > MAX_AUTO_MAP_FEATURES and not allow_large:
                action = self.choose_large_result_action(total_results)
                if action == "export":
                    self.export_gpkg()
                elif action == "load":
                    self.load_results_to_map(allow_large=True)
                return

            self.cleanup_map_cache()
            if self.map_cache_path:
                QMessageBox.warning(
                    self.dock,
                    "Cache en uso",
                    "La cache cartografica anterior sigue bloqueada; cierre capas o procesos que la usen e intente de nuevo.",
                )
                return
            handle, cache_path = tempfile.mkstemp(
                prefix="mapingtool-validator-map-", suffix=".gpkg"
            )
            os.close(handle)
            Path(cache_path).unlink(missing_ok=True)
            progress = QProgressDialog(
                "Materializando resultados para el mapa...",
                "Cancelar",
                0,
                max(1, total_results),
                self.dock,
            )
            progress.setWindowTitle("Preparando capas de resultados")
            progress.setWindowModality(Qt.WindowModal)
            progress.setMinimumDuration(0)
            progress.setAutoClose(False)
            progress.setAutoReset(False)
            progress.show()
            QApplication.processEvents()
            try:
                gpkg = self.write_result_pages_to_gpkg(cache_path, progress=progress)
            except InterruptedError:
                try:
                    remove_with_retry(cache_path)
                except PermissionError as cleanup_exc:
                    self.map_cache_path = cache_path
                    self.log("Cache cancelada pendiente de limpieza: {0}".format(cleanup_exc))
                self.log("Preparacion del mapa cancelada; la corrida sigue disponible en disco.", "warning")
                QMessageBox.information(
                    self.dock,
                    "Carga cancelada",
                    "La preparacion del mapa fue cancelada. Los resultados siguen disponibles en la tabla.",
                )
                return
            except Exception as exc:
                try:
                    remove_with_retry(cache_path)
                except PermissionError as cleanup_exc:
                    self.map_cache_path = cache_path
                    self.log("Cache fallida pendiente de limpieza: {0}".format(cleanup_exc))
                self.log("No se creo el mapa por error: {0}".format(exc))
                QMessageBox.warning(
                    self.dock,
                    "Error creando mapa",
                    "No se cargaron capas; la cache local no se completo.",
                )
                return
            finally:
                progress.close()
            if not gpkg["complete"]:
                try:
                    remove_with_retry(cache_path)
                except PermissionError as exc:
                    self.map_cache_path = cache_path
                    self.log("Cache fallida pendiente de limpieza: {0}".format(exc))
                self.log("No se creo el mapa completo: {0}".format(" | ".join(gpkg["errors"])))
                QMessageBox.warning(
                    self.dock,
                    "Mapa incompleto",
                    "No se cargaron capas porque la cache local no quedo completa.",
                )
                return
            self.map_cache_path = cache_path
            missing = sum(int(value) for value in gpkg["missing_by_rule"].values())
            if not self.load_saved_gpkg_results(
                cache_path,
                gpkg["created_rules"],
                missing,
            ):
                self.cleanup_map_cache()

    def export_csv(self):
            if not self.snapshot_actions_allowed():
                return
            if not self.result_count():
                QMessageBox.information(self.dock, "Sin resultados", "No hay resultados para exportar.")
                return

            path, _filter = QFileDialog.getSaveFileName(self.dock, "Guardar reporte", "", "CSV (*.csv)")
            if not path:
                return
            if not path.lower().endswith(".csv"):
                path += ".csv"

            identifier_columns = {
                "pk_id_predio",
                "numero_predial_nacional",
                "matricula_inmobiliaria",
                "pk_tabla_error_1",
                "pk_tabla_error_2",
            }

            try:
                with AtomicOutput(path) as output:
                    written = 0
                    with open(output.temporary, "w", newline="", encoding="utf-8-sig") as csv_file:
                        writer = csv.DictWriter(
                            csv_file,
                            fieldnames=EXPORT_COLUMNS,
                            delimiter=";",
                            quotechar='"',
                            quoting=csv.QUOTE_MINIMAL,
                            lineterminator="\r\n",
                            extrasaction="ignore",
                        )
                        writer.writeheader()
                        for row in self.iter_results():
                            out = {}
                            for column in EXPORT_COLUMNS:
                                out[column] = csv_safe_value(
                                    row.get(column),
                                    force_text=column in identifier_columns,
                                )
                            writer.writerow(out)
                            written += 1
                        csv_file.flush()
                        os.fsync(csv_file.fileno())
                    if written != self.result_count():
                        raise RuntimeError(
                            "CSV escribio {0} filas; se esperaban {1}.".format(
                                written, self.result_count()
                            )
                        )
                    output.commit()
            except Exception as exc:
                self.log("CSV no reemplazado por error: {0}".format(exc))
                QMessageBox.critical(
                    self.dock,
                    "Error exportando CSV",
                    "La exportacion fallo; el archivo anterior se conservo.",
                )
                return

            QMessageBox.information(self.dock, "Reporte guardado", "CSV exportado correctamente.")
            self.log("CSV exportado: {0}".format(path))

    def export_excel(self):
            if not self.snapshot_actions_allowed():
                return
            if not self.result_count() and not self.summary_data:
                QMessageBox.information(self.dock, "Sin resultados", "No hay resultados para exportar.")
                return

            path, _filter = QFileDialog.getSaveFileName(
                self.dock,
                "Guardar paquete Excel",
                "reporte_calidad.zip",
                "Paquete Excel (*.zip)",
            )
            if not path:
                return
            if not path.lower().endswith(".zip"):
                path += ".zip"

            try:
                with AtomicOutput(path) as output:
                    expected_total = self.result_count()
                    stored_rule_counts = (
                        self.result_store.rule_counts()
                        if self.result_store is not None
                        else {}
                    )
                    expected_rule_counts = OrderedDict(
                        (
                            str(rule_id),
                            int(stored_rule_counts.get(rule_id, 0)),
                        )
                        for rule_id in self.summary_data
                    )
                    for rule_id, count in stored_rule_counts.items():
                        expected_rule_counts.setdefault(str(rule_id), int(count))
                    manifest = write_quality_report_package_streaming(
                        output.temporary,
                        plugin_name=PLUGIN_NAME,
                        database_label="{0}:{1}/{2}".format(
                            self.current_config.get("host", ""),
                            self.current_config.get("port", ""),
                            self.current_config.get("dbname", ""),
                        ),
                        summary_rows=list(self.summary_data.values()),
                        detail_row_factory=lambda rule_id: self.iter_results(rule_id=rule_id),
                        rule_ids=expected_rule_counts,
                        log_lines=self.log_lines,
                        export_columns=EXPORT_COLUMNS,
                    )
                    if not zipfile.is_zipfile(output.temporary):
                        raise RuntimeError("El paquete Excel temporal no es un ZIP valido.")
                    with zipfile.ZipFile(output.temporary) as package:
                        corrupt_member = package.testzip()
                        if corrupt_member is not None:
                            raise RuntimeError(
                                "El paquete Excel contiene una entrada corrupta: {0}.".format(
                                    corrupt_member
                                )
                            )
                    verified_total = self.result_count()
                    verified_stored_counts = (
                        self.result_store.rule_counts()
                        if self.result_store is not None
                        else {}
                    )
                    verified_rule_counts = OrderedDict(
                        (
                            str(rule_id),
                            int(verified_stored_counts.get(rule_id, 0)),
                        )
                        for rule_id in self.summary_data
                    )
                    for rule_id, count in verified_stored_counts.items():
                        verified_rule_counts.setdefault(str(rule_id), int(count))
                    if (
                        verified_total != expected_total
                        or verified_rule_counts != expected_rule_counts
                    ):
                        raise RuntimeError(
                            "ResultStore cambio durante el paquete Excel; no se reemplaza el destino."
                        )
                    validate_excel_package_manifest(
                        manifest,
                        expected_total=verified_total,
                        expected_rule_counts=verified_rule_counts,
                    )
                    output.commit()
            except Exception as exc:
                self.log("Paquete Excel no reemplazado por error: {0}".format(exc))
                QMessageBox.critical(
                    self.dock,
                    "Error exportando Excel",
                    "La exportacion fallo; el archivo anterior se conservo.",
                )
                return
            QMessageBox.information(
                self.dock,
                "Reporte guardado",
                "Paquete Excel exportado correctamente.",
            )
            self.log("Paquete Excel exportado: {0}".format(path))

    def export_gpkg(self):
            if not self.snapshot_actions_allowed():
                return
            if not self.result_count():
                QMessageBox.information(self.dock, "Sin resultados", "No hay resultados para exportar.")
                return

            path, _filter = QFileDialog.getSaveFileName(self.dock, "Guardar GeoPackage", "", "GeoPackage (*.gpkg)")
            if not path:
                return
            if not path.lower().endswith(".gpkg"):
                path += ".gpkg"

            summary_rows = [
                [
                    row.get("rule_id", ""),
                    row.get("status", ""),
                    row.get("total", 0),
                    row.get("filtered_out", 0),
                    row.get("predios", 0),
                    row.get("exceptions", 0),
                    row.get("missing", 0),
                    row.get("message", ""),
                ]
                for row in self.summary_data.values()
            ]
            missing_by_rule = OrderedDict()
            stored_rule_counts = (
                self.result_store.rule_counts()
                if self.result_store is not None
                else {}
            )
            expected_result_total = sum(
                int(value) for value in stored_rule_counts.values()
            )
            verification_steps = len(stored_rule_counts) + 2
            progress = QProgressDialog(
                "Preparando GeoPackage de resultados...",
                "Cancelar",
                0,
                max(1, expected_result_total + 2 + verification_steps),
                self.dock,
            )
            progress.setWindowTitle("Guardando GeoPackage")
            progress.setWindowModality(Qt.WindowModal)
            progress.setMinimumDuration(0)
            progress.setAutoClose(False)
            progress.setAutoReset(False)
            progress.show()
            QApplication.processEvents()
            gpkg = None
            try:
                with AtomicOutput(path) as output:
                    temporary_path = str(output.temporary)
                    gpkg = self.write_result_pages_to_gpkg(
                        temporary_path,
                        progress=progress,
                    )
                    missing_by_rule = gpkg["missing_by_rule"]
                    if not gpkg["complete"]:
                        raise RuntimeError(" | ".join(gpkg["errors"]))
                    if progress.wasCanceled():
                        raise InterruptedError(
                            "Escritura GPKG cancelada por el usuario."
                        )

                    def write_aux_layer(layer_name, layer) -> None:
                        if not layer or not layer.isValid():
                            raise RuntimeError(
                                "{0}: no fue posible crear la capa auxiliar.".format(layer_name)
                            )
                        options = QgsVectorFileWriter.SaveVectorOptions()
                        options.driverName = "GPKG"
                        options.layerName = layer.name()
                        options.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
                        result = QgsVectorFileWriter.writeAsVectorFormatV3(
                            layer,
                            temporary_path,
                            QgsProject.instance().transformContext(),
                            options,
                        )
                        if isinstance(result, tuple) and result[0] != QgsVectorFileWriter.NoError:
                            raise RuntimeError("{0}: {1}".format(layer_name, result))

                    summary_layer = self.build_table_layer(
                        "resumen_validacion",
                        [
                            "regla",
                            "estado",
                            "filas_sql",
                            "descartadas_filtro_reco",
                            "predios_finales",
                            "excepciones",
                            "sin_excepcion",
                            "mensaje",
                        ],
                        summary_rows,
                    )
                    progress.setLabelText("Guardando resumen de validacion...")
                    progress.setValue(expected_result_total + 1)
                    QApplication.processEvents()
                    if progress.wasCanceled():
                        raise InterruptedError(
                            "Escritura GPKG cancelada por el usuario."
                        )
                    write_aux_layer("resumen_validacion", summary_layer)
                    log_layer = self.build_table_layer(
                        "log_validacion", ["linea"], [[line] for line in self.log_lines]
                    )
                    progress.setLabelText("Guardando log de la corrida...")
                    progress.setValue(expected_result_total + 2)
                    QApplication.processEvents()
                    if progress.wasCanceled():
                        raise InterruptedError(
                            "Escritura GPKG cancelada por el usuario."
                        )
                    write_aux_layer("log_validacion", log_layer)

                    expected_layers = {
                        self.result_layer_name(rule_id): int(count)
                        for rule_id, count in gpkg["expected_counts"].items()
                    }
                    expected_layers["resumen_validacion"] = len(summary_rows)
                    expected_layers["log_validacion"] = len(self.log_lines)
                    verified_result_total = 0
                    for verification_index, (layer_name, expected) in enumerate(
                        expected_layers.items(),
                        start=1,
                    ):
                        progress.setLabelText(
                            "Verificando {0} ({1} de {2})...".format(
                                layer_name,
                                verification_index,
                                len(expected_layers),
                            )
                        )
                        progress.setValue(
                            expected_result_total + 2 + verification_index
                        )
                        QApplication.processEvents()
                        if progress.wasCanceled():
                            raise InterruptedError(
                                "Verificacion GPKG cancelada por el usuario."
                            )
                        check_layer = QgsVectorLayer(
                            "{0}|layername={1}".format(temporary_path, layer_name),
                            layer_name,
                            "ogr",
                        )
                        if not check_layer.isValid():
                            raise RuntimeError(
                                "{0}: la capa final no puede reabrirse.".format(layer_name)
                            )
                        actual = int(check_layer.featureCount())
                        del check_layer
                        if actual != expected:
                            raise RuntimeError(
                                "{0}: conteo final {1}; esperado {2}.".format(
                                    layer_name, actual, expected
                                )
                            )
                        if layer_name not in ("resumen_validacion", "log_validacion"):
                            verified_result_total += actual
                    if verified_result_total != self.result_count():
                        raise RuntimeError(
                            "Conteo final GPKG {0}; esperado {1}.".format(
                                verified_result_total, self.result_count()
                            )
                        )
                    output.commit()
                    progress.setValue(progress.maximum())
                    QApplication.processEvents()
            except InterruptedError:
                self.log(
                    "Exportacion GPKG cancelada; el archivo anterior se conservo y "
                    "la corrida permanece en el almacenamiento incremental.",
                    "warning",
                )
                QMessageBox.information(
                    self.dock,
                    "Exportacion cancelada",
                    "No se reemplazo el archivo destino. La corrida sigue disponible "
                    "y puede guardarla nuevamente sin volver a validar.",
                )
                return
            except Exception as exc:
                self.log("GPKG no reemplazado por error: {0}".format(exc))
                QMessageBox.warning(
                    self.dock,
                    "Error exportando GPKG",
                    "La exportacion fallo; el archivo anterior se conservo.",
                )
                return
            finally:
                progress.close()

            missing_total = sum(int(value) for value in missing_by_rule.values())
            missing_notes = [
                "{0}: {1} filas sin geometria asociada".format(rule_id, count)
                for rule_id, count in missing_by_rule.items()
            ]
            if missing_notes:
                self.log("GPKG filas sin geometria: {0}".format(" | ".join(missing_notes)))
            message = "GPKG exportado correctamente."
            if missing_notes:
                message += " Filas sin geometria: {0}. Revise consola/log.".format(missing_total)
            QMessageBox.information(self.dock, "GeoPackage guardado", message)
            self.log("GPKG exportado: {0}".format(path))
            load_answer = QMessageBox.question(
                self.dock,
                "Cargar resultados al mapa",
                (
                    "El GeoPackage ya esta guardado y verificado.\n\n"
                    "Desea cargar ahora sus {0} capa(s) de resultados en el mapa?\n"
                    "Para conjuntos voluminosos QGIS puede tardar al dibujarlas, "
                    "pero no volvera a generar ni copiar el archivo."
                ).format(len(gpkg["created_rules"]) if gpkg else 0),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if load_answer == QMessageBox.Yes and gpkg is not None:
                self.cleanup_map_cache()
                if self.map_cache_path:
                    QMessageBox.warning(
                        self.dock,
                        "Cache en uso",
                        "La cache cartografica anterior sigue bloqueada; cierre sus "
                        "capas e intente cargar nuevamente el GeoPackage guardado.",
                    )
                    return
                self.load_saved_gpkg_results(
                    path,
                    gpkg["created_rules"],
                    missing_total,
                )

    def install_processing_filter_controls(self):
        if (
            self.processing_filter_panel is not None
            or not hasattr(self, "rules_table")
        ):
            return
        legacy_panel = getattr(self, "reco_filter_panel", None)
        if legacy_panel is not None:
            legacy_panel.hide()

        settings = QSettings()
        saved_value = settings.value(
            self.setting_key("processing_filter_policy"),
            "",
        )
        saved_policy = None
        if self.child_profile is not None:
            saved_policy = self.child_profile["processing_filter_policy"]
        elif str(saved_value).strip():
            try:
                saved_policy = json.loads(str(saved_value))
            except (TypeError, ValueError):
                saved_policy = None
        policy = normalize_processing_filter_policy(saved_policy)

        panel = QWidget()
        panel.setObjectName("processingFilterPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 7, 8, 7)
        layout.setSpacing(5)
        title = QLabel("Filtros operativos por grupo de reglas")
        title.setStyleSheet("QLabel { font-weight: 800; }")
        help_label = QLabel(
            "Cancelación y estado son generales. El alcance automático usa "
            "el perfil propio de cada regla; también puede forzar un perfil "
            "sobre todas las reglas seleccionadas. Al modificar un bloque "
            "específico, ese perfil queda activo para la ejecución."
        )
        help_label.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(help_label)

        general = QWidget()
        general.setObjectName("generalProcessingFilters")
        general_layout = QGridLayout(general)
        general_layout.setContentsMargins(5, 4, 5, 4)
        general_title = QLabel("GENERALES — todos los grupos")
        general_title.setStyleSheet("QLabel { font-weight: 700; color: #244C66; }")
        general_layout.addWidget(general_title, 0, 0, 1, 3)
        exclude_cancelled = QCheckBox("Excluir predios cancelados")
        exclude_cancelled.setChecked(
            policy["general"]["exclude_cancelled"]
        )
        require_assignment = QCheckBox(
            "Filtrar por estado de asignación"
        )
        require_assignment.setChecked(
            policy["general"]["require_assignment_state"]
        )
        assignment_states = QLineEdit(
            ", ".join(policy["general"]["assignment_states"])
        )
        assignment_states.setPlaceholderText("Ej.: 2 o 1, 2")
        assignment_states.setToolTip(
            "Estados permitidos, separados por coma. Acepta dígitos 0–9."
        )
        general_layout.addWidget(exclude_cancelled, 1, 0)
        general_layout.addWidget(require_assignment, 1, 1)
        general_layout.addWidget(QLabel("Estados permitidos"), 2, 0)
        general_layout.addWidget(assignment_states, 2, 1, 1, 2)
        layout.addWidget(general)
        self.processing_filter_widgets.update(
            {
                "exclude_cancelled": exclude_cancelled,
                "require_assignment_state": require_assignment,
                "assignment_states": assignment_states,
            }
        )

        profile_counts = OrderedDict()
        for rule in self.rules:
            profile = rule_filter_profile(rule.id, rule.family)
            profile_counts[profile] = profile_counts.get(profile, 0) + 1
        visible_profiles = profiles_for_rules(self.rules)

        scope_box = QWidget()
        scope_box.setObjectName("processingScopeSelector")
        scope_layout = QGridLayout(scope_box)
        scope_layout.setContentsMargins(5, 4, 5, 4)
        scope_title = QLabel("ALCANCE DE PREDIOS PARA ESTA EJECUCIÓN")
        scope_title.setStyleSheet(
            "QLabel { font-weight: 700; color: #244C66; }"
        )
        scope_combo = QComboBox()
        scope_combo.setObjectName("MapingToolProcessingScopeProfile")
        scope_combo.setStyleSheet(
            "QComboBox#MapingToolProcessingScopeProfile { "
            "background-color: #ffffff; color: #17212b; "
            "border: 1px solid #9aa8b5; padding: 3px 6px; } "
            "QComboBox#MapingToolProcessingScopeProfile QAbstractItemView { "
            "background-color: #ffffff; color: #17212b; "
            "selection-background-color: #287f73; selection-color: #ffffff; "
            "outline: 0; } "
            "QComboBox#MapingToolProcessingScopeProfile "
            "QAbstractItemView::item { "
            "background-color: #ffffff; color: #17212b; padding: 4px 6px; } "
            "QComboBox#MapingToolProcessingScopeProfile "
            "QAbstractItemView::item:hover, "
            "QComboBox#MapingToolProcessingScopeProfile "
            "QAbstractItemView::item:selected { "
            "background-color: #287f73; color: #ffffff; }"
        )
        scope_combo.view().setStyleSheet(
            "QAbstractItemView { background-color: #ffffff; color: #17212b; "
            "selection-background-color: #287f73; selection-color: #ffffff; "
            "outline: 0; } "
            "QAbstractItemView::item { background-color: #ffffff; "
            "color: #17212b; padding: 4px 6px; } "
            "QAbstractItemView::item:hover, QAbstractItemView::item:selected { "
            "background-color: #287f73; color: #ffffff; }"
        )
        self.scope_profile_delegate = ScopeProfileItemDelegate(
            scope_combo.view()
        )
        scope_combo.view().setItemDelegate(self.scope_profile_delegate)
        scope_combo.view().setMouseTracking(True)
        scope_combo.addItem(
            "Automático — cada regla usa su perfil",
            PROFILE_AUTO,
        )
        for profile_id in visible_profiles:
            scope_combo.addItem(
                "Forzar {0} en todas las reglas seleccionadas".format(
                    PROFILE_LABELS.get(profile_id, profile_id)
                ),
                profile_id,
            )
        saved_scope_index = scope_combo.findData(policy["scope_profile"])
        scope_combo.setCurrentIndex(max(saved_scope_index, 0))
        scope_help = QLabel(
            "Ejemplo: seleccione Informalidad para ejecutar todas las reglas "
            "marcadas únicamente sobre condiciones 2/5 y condición 0 marcada "
            "para visita, según la configuración inferior."
        )
        scope_help.setWordWrap(True)
        scope_layout.addWidget(scope_title, 0, 0)
        scope_layout.addWidget(scope_combo, 1, 0)
        scope_layout.addWidget(scope_help, 2, 0)
        layout.addWidget(scope_box)
        self.processing_filter_widgets["scope_profile"] = scope_combo

        def add_profile_box(profile_id, heading, description):
            box = QWidget()
            box.setObjectName(
                "processingProfile_{0}".format(profile_id)
            )
            box_layout = QGridLayout(box)
            box_layout.setContentsMargins(5, 4, 5, 4)
            box_layout.setHorizontalSpacing(8)
            count = profile_counts.get(profile_id, 0)
            if profile_id == PROFILE_PH:
                count += profile_counts.get(PROFILE_PH_MATRIZ, 0)
            heading_label = QLabel(
                "{0} — {1} regla(s) en alcance automático".format(
                    heading,
                    count,
                )
            )
            heading_label.setStyleSheet(
                "QLabel { font-weight: 700; color: #244C66; }"
            )
            description_label = QLabel(description)
            description_label.setWordWrap(True)
            box_layout.addWidget(heading_label, 0, 0, 1, 3)
            box_layout.addWidget(description_label, 1, 0, 1, 3)
            layout.addWidget(box)
            return box_layout

        if PROFILE_NPH in visible_profiles:
            values = policy["profiles"][PROFILE_NPH]
            block = add_profile_box(
                PROFILE_NPH,
                "NPH / PREDIO FORMAL",
                "Solo afecta reglas clasificadas como NPH o formales.",
            )
            enabled = QCheckBox("Excluir condiciones")
            enabled.setChecked(values["filter_conditions"])
            conditions = QLineEdit(
                ", ".join(values["excluded_conditions"])
            )
            conditions.setPlaceholderText("Ej.: 2, 5, 8, 9")
            exclude_visit = QCheckBox(
                "Excluir marcados para visita informal"
            )
            exclude_visit.setChecked(values["exclude_informal_visit"])
            block.addWidget(enabled, 2, 0)
            block.addWidget(conditions, 2, 1)
            block.addWidget(exclude_visit, 3, 0, 1, 2)
            self.processing_filter_widgets.update(
                {
                    "nph_filter_conditions": enabled,
                    "nph_conditions": conditions,
                    "nph_exclude_visit": exclude_visit,
                }
            )

        if PROFILE_CONDOMINIO in visible_profiles:
            values = policy["profiles"][PROFILE_CONDOMINIO]
            block = add_profile_box(
                PROFILE_CONDOMINIO,
                "CONDOMINIO",
                "Condiciones permitidas para reglas de condominio.",
            )
            enabled = QCheckBox("Exigir condición permitida")
            enabled.setChecked(values["filter_conditions"])
            conditions = QLineEdit(
                ", ".join(values["allowed_conditions"])
            )
            conditions.setPlaceholderText("Ej.: 8")
            block.addWidget(enabled, 2, 0)
            block.addWidget(conditions, 2, 1)
            self.processing_filter_widgets.update(
                {
                    "condominio_filter_conditions": enabled,
                    "condominio_conditions": conditions,
                }
            )

        if (
            PROFILE_PH in visible_profiles
            or PROFILE_PH_MATRIZ in visible_profiles
        ):
            values = policy["profiles"][PROFILE_PH]
            block = add_profile_box(
                PROFILE_PH,
                "PROPIEDAD HORIZONTAL",
                "PH_01–PH_09 y SIG_14 usan además el alcance de predio matriz.",
            )
            enabled = QCheckBox("Exigir condición permitida")
            enabled.setChecked(values["filter_conditions"])
            conditions = QLineEdit(
                ", ".join(values["allowed_conditions"])
            )
            conditions.setPlaceholderText("Ej.: 8, 9")
            matrix = QCheckBox(
                "PH matriz: exigir torre/piso 0000 y unidad 0000"
            )
            matrix.setChecked(values["enforce_matrix_identity"])
            block.addWidget(enabled, 2, 0)
            block.addWidget(conditions, 2, 1)
            block.addWidget(matrix, 3, 0, 1, 2)
            self.processing_filter_widgets.update(
                {
                    "ph_filter_conditions": enabled,
                    "ph_conditions": conditions,
                    "ph_matrix_identity": matrix,
                }
            )

        if PROFILE_INFORMALIDAD in visible_profiles:
            values = policy["profiles"][PROFILE_INFORMALIDAD]
            block = add_profile_box(
                PROFILE_INFORMALIDAD,
                "INFORMALIDAD",
                "Las condiciones indicadas pasan; la condición 0 puede "
                "admitirse únicamente cuando esté marcada para visita.",
            )
            enabled = QCheckBox("Exigir condición permitida")
            enabled.setChecked(values["filter_conditions"])
            conditions = QLineEdit(
                ", ".join(values["allowed_conditions"])
            )
            conditions.setPlaceholderText("Ej.: 2, 5")
            allow_zero = QCheckBox(
                "Permitir condición 0 solo si está marcada para visita"
            )
            allow_zero.setChecked(
                values["allow_zero_when_informal_visit"]
            )
            block.addWidget(enabled, 2, 0)
            block.addWidget(conditions, 2, 1)
            block.addWidget(allow_zero, 3, 0, 1, 2)
            self.processing_filter_widgets.update(
                {
                    "informal_filter_conditions": enabled,
                    "informal_conditions": conditions,
                    "informal_allow_zero_visit": allow_zero,
                }
            )

        self.processing_filter_status_label = QLabel()
        self.processing_filter_status_label.setWordWrap(True)
        layout.addWidget(self.processing_filter_status_label)
        panel.setStyleSheet(
            "QWidget#processingFilterPanel { background: #f5f8fa; "
            "border: 1px solid #cbd5e1; border-radius: 4px; } "
            "QWidget#processingFilterPanel QWidget, "
            "QWidget#processingFilterPanel QCheckBox, "
            "QWidget#processingFilterPanel QLabel { "
            "border: none; background: transparent; }"
        )
        rules_panel = self.rules_table.parentWidget()
        rules_layout = rules_panel.layout()
        table_index = rules_layout.indexOf(self.rules_table)
        rules_layout.insertWidget(max(table_index, 0), panel)
        self.processing_filter_panel = panel

        # The rule selector controls belong to the table, not above the
        # operational scope. Keep the visual order:
        # operational filters -> selector/search -> rule table.
        processing_title = next(
            (
                label
                for label in rules_panel.findChildren(QLabel)
                if label.text() == "Filtros de procesamiento"
            ),
            None,
        )
        if processing_title is not None:
            title_index = rules_layout.indexOf(processing_title)
            selector_layout = (
                rules_layout.itemAt(title_index + 1).layout()
                if title_index >= 0
                and title_index + 1 < rules_layout.count()
                else None
            )
            if title_index >= 0 and selector_layout is not None:
                rules_layout.removeWidget(processing_title)
                rules_layout.removeItem(selector_layout)
                table_index = rules_layout.indexOf(self.rules_table)
                rules_layout.insertWidget(table_index, processing_title)
                rules_layout.insertLayout(table_index + 1, selector_layout)

        profile_widget_names = {
            "nph_filter_conditions": PROFILE_NPH,
            "nph_conditions": PROFILE_NPH,
            "nph_exclude_visit": PROFILE_NPH,
            "condominio_filter_conditions": PROFILE_CONDOMINIO,
            "condominio_conditions": PROFILE_CONDOMINIO,
            "ph_filter_conditions": PROFILE_PH,
            "ph_conditions": PROFILE_PH,
            "ph_matrix_identity": PROFILE_PH,
            "informal_filter_conditions": PROFILE_INFORMALIDAD,
            "informal_conditions": PROFILE_INFORMALIDAD,
            "informal_allow_zero_visit": PROFILE_INFORMALIDAD,
        }
        for widget_name, widget in self.processing_filter_widgets.items():
            profile_id = profile_widget_names.get(widget_name)
            handler = (
                (
                    lambda *_args, selected_profile=profile_id:
                    self.on_profile_filter_changed(selected_profile)
                )
                if profile_id
                else self.on_processing_filter_changed
            )
            if isinstance(widget, QCheckBox):
                widget.stateChanged.connect(handler)
            elif isinstance(widget, QLineEdit):
                widget.editingFinished.connect(handler)
            elif isinstance(widget, QComboBox):
                widget.currentIndexChanged.connect(handler)

        export_menu = self.export_menu_btn.menu()
        if export_menu is not None and self.child_profile is None:
            export_menu.addSeparator()
            self.export_child_action = export_menu.addAction(
                "Generar perfiles simplificados…"
            )
            self.export_child_action.triggered.connect(
                self.export_simplified_plugins
            )
            self.publish_child_action = export_menu.addAction(
                "Crear o actualizar perfil de producción…"
            )
            self.publish_child_action.triggered.connect(
                self.publish_simplified_profile
            )
        self.update_processing_filter_status()

    def processing_filter_policy(self):
        if self.child_profile is not None:
            return normalize_processing_filter_policy(
                self.child_profile["processing_filter_policy"]
            )
        widgets = self.processing_filter_widgets
        if not widgets:
            return normalize_processing_filter_policy()

        defaults = DEFAULT_PROCESSING_FILTER_POLICY

        def checked(name, default):
            widget = widgets.get(name)
            return widget.isChecked() if widget is not None else default

        def text(name, default):
            widget = widgets.get(name)
            return widget.text() if widget is not None else default

        def current_data(name, default):
            widget = widgets.get(name)
            return widget.currentData() if widget is not None else default

        return normalize_processing_filter_policy(
            {
                "scope_profile": current_data(
                    "scope_profile",
                    defaults["scope_profile"],
                ),
                "general": {
                    "exclude_cancelled": checked(
                        "exclude_cancelled",
                        defaults["general"]["exclude_cancelled"],
                    ),
                    "require_assignment_state": checked(
                        "require_assignment_state",
                        defaults["general"]["require_assignment_state"],
                    ),
                    "assignment_states": text(
                        "assignment_states",
                        defaults["general"]["assignment_states"],
                    ),
                },
                "profiles": {
                    PROFILE_NPH: {
                        "filter_conditions": checked(
                            "nph_filter_conditions",
                            defaults["profiles"][PROFILE_NPH][
                                "filter_conditions"
                            ],
                        ),
                        "excluded_conditions": text(
                            "nph_conditions",
                            defaults["profiles"][PROFILE_NPH][
                                "excluded_conditions"
                            ],
                        ),
                        "exclude_informal_visit": checked(
                            "nph_exclude_visit",
                            defaults["profiles"][PROFILE_NPH][
                                "exclude_informal_visit"
                            ],
                        ),
                    },
                    PROFILE_CONDOMINIO: {
                        "filter_conditions": checked(
                            "condominio_filter_conditions",
                            defaults["profiles"][PROFILE_CONDOMINIO][
                                "filter_conditions"
                            ],
                        ),
                        "allowed_conditions": text(
                            "condominio_conditions",
                            defaults["profiles"][PROFILE_CONDOMINIO][
                                "allowed_conditions"
                            ],
                        ),
                    },
                    PROFILE_PH: {
                        "filter_conditions": checked(
                            "ph_filter_conditions",
                            defaults["profiles"][PROFILE_PH][
                                "filter_conditions"
                            ],
                        ),
                        "allowed_conditions": text(
                            "ph_conditions",
                            defaults["profiles"][PROFILE_PH][
                                "allowed_conditions"
                            ],
                        ),
                        "enforce_matrix_identity": checked(
                            "ph_matrix_identity",
                            defaults["profiles"][PROFILE_PH][
                                "enforce_matrix_identity"
                            ],
                        ),
                    },
                    PROFILE_INFORMALIDAD: {
                        "filter_conditions": checked(
                            "informal_filter_conditions",
                            defaults["profiles"][PROFILE_INFORMALIDAD][
                                "filter_conditions"
                            ],
                        ),
                        "allowed_conditions": text(
                            "informal_conditions",
                            defaults["profiles"][PROFILE_INFORMALIDAD][
                                "allowed_conditions"
                            ],
                        ),
                        "allow_zero_when_informal_visit": checked(
                            "informal_allow_zero_visit",
                            defaults["profiles"][PROFILE_INFORMALIDAD][
                                "allow_zero_when_informal_visit"
                            ],
                        ),
                    },
                },
            }
        )

    def on_processing_filter_changed(self, *_args):
        try:
            policy = self.processing_filter_policy()
        except ValueError as exc:
            if self.processing_filter_status_label is not None:
                self.processing_filter_status_label.setText(str(exc))
                self.processing_filter_status_label.setStyleSheet(
                    "QLabel { color: #b00020; font-weight: 700; }"
                )
            return
        if self.child_profile is None:
            settings = QSettings()
            settings.setValue(
                self.setting_key("processing_filter_policy"),
                json.dumps(
                    policy,
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            )
            settings.sync()
        self.update_processing_filter_status()
        self.refresh_mapping()

    def on_profile_filter_changed(self, profile_id):
        """Make the profile being edited the unambiguous execution scope."""

        scope_combo = self.processing_filter_widgets.get("scope_profile")
        if scope_combo is not None:
            index = scope_combo.findData(profile_id)
            if index >= 0 and scope_combo.currentIndex() != index:
                # ``currentIndexChanged`` persists and refreshes the policy.
                scope_combo.setCurrentIndex(index)
                return
        self.on_processing_filter_changed()

    def update_processing_filter_status(self, *_args):
        label = self.processing_filter_status_label
        if label is None:
            return
        try:
            policy = self.processing_filter_policy()
            profile_ids = profiles_for_rules(self.rules, policy)
            label.setText(
                processing_filter_summary(policy, profile_ids)
            )
            if policy["scope_profile"] == PROFILE_AUTO:
                label.setStyleSheet(
                    "QLabel { color: #9a5b00; background: #fff7df; "
                    "border: 1px solid #e7b44f; border-radius: 3px; "
                    "padding: 5px; font-weight: 700; }"
                )
            else:
                label.setStyleSheet(
                    "QLabel { color: #075f50; background: #e8f7f2; "
                    "border: 1px solid #70b7a8; border-radius: 3px; "
                    "padding: 5px; font-weight: 700; }"
                )
        except ValueError as exc:
            label.setText(str(exc))
            label.setStyleSheet(
                "QLabel { color: #b00020; font-weight: 700; }"
            )

    def reco_filter_policy(self):
        """Compatibility projection for legacy status/tests; execution uses profiles."""

        policy = self.processing_filter_policy()
        general = policy["general"]
        nph = policy["profiles"][PROFILE_NPH]
        return normalize_reco_filter_policy(
            {
                "exclude_cancelled": general["exclude_cancelled"],
                "require_assignment_2": (
                    general["require_assignment_state"]
                    and general["assignment_states"] == ["2"]
                ),
                "exclude_conditions": nph["filter_conditions"],
                "exclude_informal_visit": nph[
                    "exclude_informal_visit"
                ],
            }
        )

    def update_reco_filter_status(self, *_args):
        self.update_processing_filter_status()

    @staticmethod
    def child_package_slug(value):
        normalized = unicodedata.normalize("NFKD", str(value))
        ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
        slug = re.sub(r"[^a-z0-9]+", "_", ascii_value.casefold()).strip("_")
        if not slug:
            slug = "perfil"
        if not slug[0].isalpha():
            slug = "perfil_" + slug
        return slug[:48]

    def plugin_metadata_version(self):
        metadata = self.plugin_dir / "metadata.txt"
        if not metadata.is_file():
            return "0.0.0"
        for line in metadata.read_text(encoding="utf-8").splitlines():
            if line.startswith("version="):
                return line.partition("=")[2].strip() or "0.0.0"
        return "0.0.0"

    def render_child_metadata(self, content, profile):
        display_name = str(profile["display_name"])
        replacements = {
            "name": display_name,
            "version": str(profile.get("child_version") or "0.0.1"),
            "description": (
                "Perfil operativo simplificado generado desde {0}."
                .format(PLUGIN_NAME)
            ),
            "icon": "profile_icon.svg",
            "experimental": "False",
        }
        repository_url = str(profile.get("repository_url") or "").strip()
        if repository_url:
            replacements["homepage"] = repository_url
            replacements["repository"] = repository_url
        rendered = []
        seen = set()
        for line in content.splitlines():
            key, separator, _value = line.partition("=")
            if separator and key in replacements:
                rendered.append(key + "=" + replacements[key])
                seen.add(key)
            else:
                rendered.append(line)
        for key, value in replacements.items():
            if key not in seen:
                rendered.append(key + "=" + value)
        return "\n".join(rendered) + "\n"

    def child_export_target_counts(self):
        selected = set(self.checked_rule_ids())
        if PLUGIN_FAMILY == "*":
            targets = tuple(CHILD_EXPORT_TARGETS)
        else:
            targets = (PLUGIN_FAMILY,)
        counts = OrderedDict()
        for family in targets:
            if family == "*":
                counts[family] = len(selected)
            else:
                counts[family] = sum(
                    1
                    for rule_id in selected
                    if self.rule_family_by_id.get(rule_id) == family
                )
        return counts

    def choose_child_exports(self, target_counts):
        """Ask which simplified editions to generate in one batch."""

        dialog = QDialog(self.dock)
        dialog.setObjectName("MapingToolChildExportDialog")
        dialog.setWindowTitle("Generar perfiles simplificados")
        dialog.setMinimumWidth(460)
        layout = QVBoxLayout(dialog)
        help_label = QLabel(
            "Elija uno o varios plugins de producción. Cada uno quedará "
            "listo para que el trabajador solo ejecute y exporte resultados. "
            "Mixto personalizado conserva juntas las reglas marcadas de "
            "distintas familias."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)

        boxes = OrderedDict()
        current_families = self.selected_family_filters()
        current_family = (
            next(iter(current_families))
            if len(current_families) == 1
            else None
        )
        default_family = (
            current_family
            if current_family in target_counts
            and target_counts.get(current_family, 0)
            else ("*" if "*" in target_counts else PLUGIN_FAMILY)
        )
        for family, count in target_counts.items():
            if family == "*":
                selected_families = {
                    self.rule_family_by_id.get(rule_id)
                    for rule_id in self.checked_rule_ids()
                    if self.rule_family_by_id.get(rule_id)
                }
                label = (
                    "Mixto personalizado"
                    if len(selected_families) > 1
                    else "Selección simplificada"
                )
            else:
                label = CHILD_EXPORT_TARGETS.get(
                    family,
                    (family.upper(), family[:2].upper()),
                )[0]
            suffix = (
                "{0} regla(s) marcada(s)".format(count)
                if count
                else "sin reglas marcadas"
            )
            box = QCheckBox("{0} — {1}".format(label, suffix))
            box.setProperty("outputFamily", family)
            box.setEnabled(count > 0)
            box.setChecked(count > 0 and family == default_family)
            boxes[family] = box
            layout.addWidget(box)

        layout.addWidget(
            QLabel("Nombre visible para los trabajadores (opcional)")
        )
        profile_name = QLineEdit()
        profile_name.setObjectName("MapingToolChildProfileName")
        profile_name.setPlaceholderText(
            "Ej.: Control de calidad — Equipo Norte"
        )
        layout.addWidget(profile_name)
        name_help = QLabel(
            "Este será el nombre que verán en QGIS. Si genera varios, se "
            "agregará automáticamente Total, Jurídico, PH, RECO, SIG o "
            "Económico para diferenciarlos."
        )
        name_help.setWordWrap(True)
        layout.addWidget(name_help)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec_() != QDialog.Accepted:
            return None
        families = [
            family
            for family, box in boxes.items()
            if box.isEnabled() and box.isChecked()
        ]
        if not families:
            QMessageBox.information(
                self.dock,
                "Sin perfiles",
                "Seleccione al menos un perfil para generar.",
            )
            return None
        return {
            "families": families,
            "profile_name": profile_name.text().replace("\n", " ").strip(),
        }

    @staticmethod
    def child_profile_icon_svg(family):
        label, acronym = (
            ("Mixto personalizado", "M")
            if family == "mixed"
            else CHILD_EXPORT_TARGETS.get(
                family,
                ("Perfil", "P"),
            )
        )
        color = FAMILY_COLORS.get(family, "#244C66")
        font_size = 22 if len(acronym) == 1 else 15
        return (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<svg xmlns="http://www.w3.org/2000/svg" width="64" '
            'height="64" viewBox="0 0 64 64" role="img" '
            'aria-label="{0}">\n'
            '  <rect x="3" y="3" width="58" height="58" rx="14" '
            'fill="{1}"/>\n'
            '  <path d="M16 35l10 10 22-25" fill="none" '
            'stroke="#ffffff" stroke-width="6" '
            'stroke-linecap="round" stroke-linejoin="round" opacity=".35"/>\n'
            '  <text x="32" y="39" text-anchor="middle" '
            'font-family="Arial, sans-serif" font-size="{2}" '
            'font-weight="700" fill="#ffffff">{3}</text>\n'
            '</svg>\n'
        ).format(label, color, font_size, acronym).encode("utf-8")

    def child_profile_identity(self, family, profile_name, rule_ids=None):
        selected_rule_ids = tuple(rule_ids or ())
        selected_families = {
            self.rule_family_by_id.get(rule_id)
            for rule_id in selected_rule_ids
            if self.rule_family_by_id.get(rule_id)
        }
        if family == "*" and len(selected_families) > 1:
            family_label = "Mixto personalizado"
            family_slug = "mixto"
        elif family == "*" and len(selected_rule_ids) == len(self.rules):
            family_label = "Total simplificado"
            family_slug = "total"
        elif family == "*":
            family_label = "Selección simplificada"
            family_slug = "seleccion"
        else:
            family_label = CHILD_EXPORT_TARGETS.get(
                family,
                (family.upper(), family[:2].upper()),
            )[0]
            family_slug = family
        clean_name = str(profile_name).replace("\n", " ").strip()
        display_name = (
            "{0} — {1}".format(family_label, clean_name)
            if clean_name
            else family_label
        )
        package_parts = ["perfil_gpkg", family_slug]
        if clean_name:
            package_parts.append(self.child_package_slug(clean_name))
        package_id = self.child_package_slug("_".join(package_parts))[:64]
        return display_name, package_id

    def child_profile_payload(
        self,
        family,
        profile_name,
        rule_ids,
        *,
        child_version="0.0.1",
        repository_url="",
    ):
        display_name, package_id = self.child_profile_identity(
            family,
            profile_name,
            rule_ids,
        )
        selected_families = sorted(
            {
                self.rule_family_by_id.get(rule_id)
                for rule_id in rule_ids
                if self.rule_family_by_id.get(rule_id)
            }
        )
        selection_mode = (
            "mixed"
            if family == "*" and len(selected_families) > 1
            else "family"
            if family != "*"
            else "selection"
        )
        return {
            "schema_version": 3,
            "locked": True,
            "simplified": True,
            "display_name": display_name,
            "package_id": package_id,
            "child_version": str(child_version),
            "parent_plugin": PLUGIN_NAME,
            "parent_version": self.plugin_metadata_version(),
            "parent_family": PLUGIN_FAMILY,
            "output_family": family,
            "selection_mode": selection_mode,
            "selected_families": selected_families,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "rule_ids": list(rule_ids),
            "processing_filter_policy": self.processing_filter_policy(),
            "layer_mapping": (
                self.selected_mapping()
                if self.source_combo.currentData() == "gpkg"
                else {}
            ),
            "preferred_source_mode": self.source_combo.currentData(),
            "auto_map": self.auto_map_box.isChecked(),
            "hide_exception_rows": self.detail_exceptions_hidden(),
            "source_path_stored": False,
            "repository_url": str(repository_url or ""),
        }


    def profile_registry_session(self, force=False):
        settings = QSettings()
        device_key = self.setting_key("profile_registry_device_id")
        auth_key = self.setting_key("profile_registry_authcfg")
        device_id = str(settings.value(device_key, "") or "")
        authcfg = str(settings.value(auth_key, "") or "")
        if not force and device_id and authcfg:
            config = QgsAuthMethodConfig()
            if QgsApplication.authManager().loadAuthenticationConfig(
                authcfg,
                config,
                True,
            ):
                grant_token = str(config.config("password") or "")
                if grant_token:
                    return device_id, grant_token
        if not re.fullmatch(
            r"[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}",
            device_id,
            re.I,
        ):
            device_id = str(uuid.uuid4())
        client = ProfileRegistryClient()
        challenge = client.start_authorization(device_id)
        QDesktopServices.openUrl(QUrl(challenge.verification_uri_complete))
        progress = QProgressDialog(
            "Autorice este equipo en el navegador. Código: {0}".format(
                challenge.user_code
            ),
            "Cancelar",
            0,
            0,
            self.dock,
        )
        progress.setWindowTitle("Mapper GIS — autorizar Centro de Perfiles")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        interval = challenge.interval
        authorized = None
        while datetime.now(timezone.utc) < challenge.expires_at:
            if progress.wasCanceled():
                progress.close()
                raise ProfileRegistryError("Autorización cancelada.")
            QApplication.processEvents()
            value = client.poll_authorization(challenge)
            status = value.get("status")
            if status == "authorized":
                authorized = value
                break
            if status in {"denied", "expired"}:
                progress.close()
                raise ProfileRegistryError(
                    "La autorización fue rechazada o expiró."
                )
            if status == "slow_down":
                interval = min(interval + 5, 30)
            for _step in range(interval * 10):
                if progress.wasCanceled():
                    break
                time.sleep(0.1)
                QApplication.processEvents()
        progress.close()
        if authorized is None:
            raise ProfileRegistryError("No se completó la autorización.")
        config = QgsAuthMethodConfig()
        config.setMethod("Basic")
        config.setName("Mapper GIS — Centro de Perfiles")
        config.setConfig("username", device_id)
        config.setConfig("password", authorized["grant_token"])
        config.setConfig("refresh_token", authorized["refresh_token"])
        if not QgsApplication.authManager().storeAuthenticationConfig(config):
            raise ProfileRegistryError(
                "QGIS no pudo guardar la autorización de forma cifrada."
            )
        settings.setValue(device_key, device_id)
        settings.setValue(auth_key, config.id())
        settings.sync()
        return device_id, authorized["grant_token"]

    def choose_profile_registry_target(self, profiles, proposed_name):
        dialog = QDialog(self.dock)
        dialog.setWindowTitle("Crear o actualizar perfil de producción")
        dialog.setMinimumWidth(580)
        layout = QVBoxLayout(dialog)
        help_label = QLabel(
            "Cree un canal nuevo o publique una revisión de uno existente. "
            "Los trabajadores conservarán la misma URL de actualización."
        )
        help_label.setWordWrap(True)
        layout.addWidget(help_label)
        layout.addWidget(QLabel("Canal de destino"))
        target_combo = QComboBox()
        target_combo.addItem("Crear perfil nuevo", None)
        for profile in profiles:
            if str(profile.get("status") or "") != "active":
                continue
            label = "{0} — {1}".format(
                profile.get("displayName") or profile.get("packageId"),
                profile.get("currentVersion") or "sin publicar",
            )
            target_combo.addItem(label, profile)
        layout.addWidget(target_combo)
        layout.addWidget(QLabel("Nombre visible para los trabajadores"))
        name_edit = QLineEdit(proposed_name)
        name_edit.setMaxLength(120)
        layout.addWidget(name_edit)

        def target_changed(_index):
            current = target_combo.currentData()
            if isinstance(current, dict):
                name_edit.setText(
                    str(current.get("displayName") or proposed_name)
                )

        target_combo.currentIndexChanged.connect(target_changed)
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec_() != QDialog.Accepted:
            return None
        display_name = " ".join(name_edit.text().split())
        if len(display_name) < 3:
            QMessageBox.warning(
                self.dock,
                "Nombre requerido",
                "Ingrese un nombre claro de al menos tres caracteres.",
            )
            return None
        current = target_combo.currentData()
        if isinstance(current, dict):
            return {
                "display_name": display_name,
                "profile_id": current["profileId"],
                "expected_revision": int(current["currentRevision"]),
            }
        return {"display_name": display_name}

    def publish_simplified_profile(self):
        selected = set(self.checked_rule_ids())
        if not selected:
            QMessageBox.information(
                self.dock,
                "Sin reglas",
                "Marque al menos una regla antes de publicar el perfil.",
            )
            return
        selection = self.choose_child_exports(
            self.child_export_target_counts()
        )
        if selection is None:
            return
        families = list(selection["families"])
        if len(families) != 1:
            QMessageBox.information(
                self.dock,
                "Una publicación por vez",
                "Elija un solo perfil; puede publicar los demás enseguida.",
            )
            return
        family = families[0]
        rule_ids = sorted(
            selected
            if family == "*"
            else {
                rule_id
                for rule_id in selected
                if self.rule_family_by_id.get(rule_id) == family
            }
        )
        if not rule_ids:
            return
        try:
            device_id, grant_token = self.profile_registry_session()
            client = ProfileRegistryClient()
            try:
                profiles = client.list_profiles(device_id, grant_token)
            except ProfileRegistryHttpError as exc:
                if exc.status != 401:
                    raise
                device_id, grant_token = self.profile_registry_session(
                    force=True
                )
                profiles = client.list_profiles(device_id, grant_token)
        except ProfileRegistryError as exc:
            QMessageBox.warning(self.dock, "Centro de Perfiles", str(exc))
            return
        proposed_name, local_package_id = self.child_profile_identity(
            family,
            selection["profile_name"],
            rule_ids,
        )
        target = self.choose_profile_registry_target(
            profiles,
            proposed_name,
        )
        if target is None:
            return
        selected_families = sorted(
            {
                self.rule_family_by_id.get(rule_id)
                for rule_id in rule_ids
                if self.rule_family_by_id.get(rule_id)
            }
        )
        spec = {
            "schema_version": 1,
            "display_name": target["display_name"],
            "parent_family": (
                "total" if PLUGIN_FAMILY == "*" else PLUGIN_FAMILY
            ),
            "parent_version": self.plugin_metadata_version(),
            "rule_ids": list(rule_ids),
            "selected_families": selected_families,
            "processing_filter_policy": self.processing_filter_policy(),
            "hide_exception_rows": self.detail_exceptions_hidden(),
        }
        progress = QProgressDialog(
            "Registrando configuración y preparando el plugin…",
            "Cancelar espera",
            0,
            0,
            self.dock,
        )
        progress.setWindowTitle("Mapper GIS — Centro de Perfiles")
        progress.setWindowModality(Qt.WindowModal)
        progress.setMinimumDuration(0)
        progress.show()
        QApplication.processEvents()
        try:
            result = client.save_profile(
                device_id,
                grant_token,
                spec,
                package_id=(
                    local_package_id
                    if target.get("profile_id") is None
                    else None
                ),
                profile_id=target.get("profile_id"),
                expected_revision=target.get("expected_revision"),
                idempotency_key=uuid.uuid4().hex,
            )
            profile = result["profile"]
            profile_id = str(profile["profileId"])
            expected_revision = int(profile["currentRevision"])
            deadline = time.monotonic() + 20 * 60
            while (
                time.monotonic() < deadline
                and not progress.wasCanceled()
            ):
                progress.setLabelText(
                    "Construyendo revisión {0}; cancelar la espera no detiene la publicación…".format(
                        expected_revision
                    )
                )
                QApplication.processEvents()
                current = client.get_profile(
                    device_id,
                    grant_token,
                    profile_id,
                )
                if int(current.get("currentRevision") or 0) == expected_revision:
                    state = str(current.get("currentState") or "")
                    if state == "published":
                        profile = current
                        break
                    if state == "failed":
                        error_code = str(
                            (current.get("build") or {}).get("errorCode")
                            or "profile_build_failed"
                        )
                        raise ProfileRegistryError(
                            "El pipeline no publicó el perfil: " + error_code
                        )
                for _step in range(30):
                    if progress.wasCanceled():
                        break
                    time.sleep(0.1)
                    QApplication.processEvents()
            if progress.wasCanceled():
                return
            if str(profile.get("currentState") or "") != "published":
                raise ProfileRegistryError(
                    "La publicación continúa en segundo plano; consulte el canal en unos minutos."
                )
        except (ProfileRegistryError, OSError, ValueError, KeyError) as exc:
            QMessageBox.warning(
                self.dock,
                "No se pudo publicar",
                str(exc),
            )
            return
        finally:
            progress.close()
        QMessageBox.information(
            self.dock,
            "Perfil publicado",
            (
                "{0} quedó publicado en la versión {1}.\n\n"
                "Agregue una sola vez este repositorio en QGIS:\n{2}\n\n"
                "Release:\n{3}"
            ).format(
                profile["displayName"],
                profile["currentVersion"],
                profile["build"]["repositoryXml"],
                profile["build"]["releaseUrl"],
            ),
        )


    def write_child_plugin_zip(self, destination_path, profile, icon_bytes):
        package_id = str(profile["package_id"])
        selected_rule_ids = {
            str(rule_id).casefold(): str(rule_id)
            for rule_id in profile.get("rule_ids", ())
        }
        if not selected_rule_ids:
            raise ValueError("El perfil simplificado no contiene reglas.")
        manifest_path = self.plugin_dir / "quality_core" / "portable_manifest.json"
        parent_manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        parent_rules = parent_manifest.get("rules")
        if not isinstance(parent_rules, dict):
            raise ValueError("El manifiesto portable del plugin padre no es valido.")
        parent_by_folded = {
            str(rule_id).casefold(): (str(rule_id), declaration)
            for rule_id, declaration in parent_rules.items()
        }
        missing_rules = sorted(set(selected_rule_ids) - set(parent_by_folded))
        if missing_rules:
            raise ValueError(
                "El plugin padre no contiene estas reglas seleccionadas: {0}.".format(
                    ", ".join(selected_rule_ids[value] for value in missing_rules)
                )
            )
        portable_root = self.plugin_dir / "quality_core"
        allowed_modes = {"generated_plan_v1", "python_adapter_v1"}

        def rule_artifact_path(value, field_name):
            if not isinstance(value, str) or not value or "\\" in value:
                raise ValueError(
                    "{0} declara una ruta portable invalida.".format(field_name)
                )
            relative = PurePosixPath(value)
            if (
                relative.is_absolute()
                or relative.as_posix() != value
                or any(part in ("", ".", "..") for part in relative.parts)
            ):
                raise ValueError(
                    "{0} declara una ruta portable invalida.".format(field_name)
                )
            return (PurePosixPath("quality_core") / relative).as_posix()

        parent_rule_artifacts = set()
        for parent_rule_id, parent_declaration in parent_rules.items():
            if not isinstance(parent_declaration, dict):
                raise ValueError(
                    "La declaracion portable de {0} no es valida.".format(
                        parent_rule_id
                    )
                )
            for field_name in ("implementation_path", "plan_path"):
                value = parent_declaration.get(field_name)
                if value:
                    parent_rule_artifacts.add(
                        rule_artifact_path(
                            value,
                            "{0}.{1}".format(parent_rule_id, field_name),
                        )
                    )
            support_files = parent_declaration.get("support_files") or []
            if not isinstance(support_files, list):
                raise ValueError(
                    "{0}.support_files no es una lista valida.".format(
                        parent_rule_id
                    )
                )
            for support in support_files:
                if not isinstance(support, dict):
                    raise ValueError(
                        "{0}.support_files contiene una entrada invalida.".format(
                            parent_rule_id
                        )
                    )
                parent_rule_artifacts.add(
                    rule_artifact_path(
                        support.get("path"),
                        "{0}.support_files".format(parent_rule_id),
                    )
                )

        child_rules = {}
        selected_rule_artifacts = set()
        for folded in selected_rule_ids:
            rule_id, declaration = parent_by_folded[folded]
            execution_mode = declaration.get("execution_mode")
            if execution_mode not in allowed_modes:
                raise ValueError(
                    "{0} declara un motor portable no autorizado: {1}.".format(
                        rule_id,
                        execution_mode,
                    )
                )
            try:
                verified_bundle = verify_execution_bundle(
                    portable_root,
                    declaration,
                )
            except ValueError as exc:
                raise ValueError(
                    "El bundle portable de {0} no supera integridad: {1}".format(
                        rule_id,
                        exc,
                    )
                ) from exc
            selected_rule_artifacts.add(
                rule_artifact_path(
                    verified_bundle.implementation.relative_path,
                    "{0}.implementation_path".format(rule_id),
                )
            )
            selected_rule_artifacts.update(
                rule_artifact_path(
                    support.relative_path,
                    "{0}.support_files".format(rule_id),
                )
                for support in verified_bundle.support_files
            )
            if execution_mode == "generated_plan_v1":
                plan_path = str(declaration.get("plan_path") or "")
                if not plan_path.startswith("generated_plans/"):
                    raise ValueError(
                        "{0} no declara un plan generado valido.".format(rule_id)
                    )
                plan_file = resolve_package_file(portable_root, plan_path)
                plan_sha256 = hashlib.sha256(plan_file.read_bytes()).hexdigest().upper()
                if plan_sha256 != str(declaration.get("plan_sha256") or "").upper():
                    raise ValueError(
                        "El hash del plan generado no coincide para {0}.".format(
                            rule_id
                        )
                    )
                selected_rule_artifacts.add(
                    rule_artifact_path(
                        plan_path,
                        "{0}.plan_path".format(rule_id),
                    )
                )
            child_rules[rule_id] = declaration
        child_manifest = dict(parent_manifest)
        child_manifest["rules"] = child_rules
        child_manifest["family"] = str(profile.get("output_family") or "*")
        child_manifest["family_contract"] = {
            "canonical_rule_count": len(child_rules),
            "portable_rule_count": len(child_rules),
            "backend_unsupported_count": 0,
            "unsupported_status": "backend_unsupported",
            "false_ok_allowed": False,
        }
        child_manifest_bytes = (
            json.dumps(
                child_manifest,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n"
        ).encode("utf-8")
        profile_bytes = (
            json.dumps(
                profile,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n"
        ).encode("utf-8")

        descriptor, temporary_value = tempfile.mkstemp(
            prefix="." + destination_path.name + ".partial-",
            dir=str(destination_path.parent),
        )
        os.close(descriptor)
        temporary = Path(temporary_value)
        try:
            with zipfile.ZipFile(
                temporary,
                "w",
                compression=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            ) as archive:
                for path in sorted(self.plugin_dir.rglob("*")):
                    if not path.is_file():
                        continue
                    relative = path.relative_to(self.plugin_dir)
                    relative_posix = relative.as_posix()
                    if (
                        path.name == "child_profile.json"
                        or path.name == "profile_icon.svg"
                        or (
                            path.name == "portable_rules.py"
                            and relative_posix not in selected_rule_artifacts
                        )
                        or (
                            path.name.startswith("portable_rule_")
                            and relative_posix not in selected_rule_artifacts
                        )
                        or "__pycache__" in relative.parts
                        or path.suffix.casefold() in {".pyc", ".pyo"}
                        or any(part.startswith(".") for part in relative.parts)
                    ):
                        continue
                    if (
                        relative_posix in parent_rule_artifacts
                        and relative_posix not in selected_rule_artifacts
                    ):
                        continue
                    archive_name = (
                        Path(package_id) / relative
                    ).as_posix()
                    if relative_posix == "metadata.txt":
                        content = self.render_child_metadata(
                            path.read_text(encoding="utf-8"),
                            profile,
                        ).encode("utf-8")
                        archive.writestr(archive_name, content)
                    elif relative_posix == "quality_core/portable_manifest.json":
                        archive.writestr(archive_name, child_manifest_bytes)
                    else:
                        archive.write(path, archive_name)
                archive.writestr(
                    (Path(package_id) / "child_profile.json").as_posix(),
                    profile_bytes,
                )
                archive.writestr(
                    (Path(package_id) / "profile_icon.svg").as_posix(),
                    icon_bytes,
                )
            with zipfile.ZipFile(temporary) as check:
                names = set(check.namelist())
                required = {
                    (Path(package_id) / "__init__.py").as_posix(),
                    (Path(package_id) / "metadata.txt").as_posix(),
                    (Path(package_id) / "plugin.py").as_posix(),
                    (Path(package_id) / "child_profile.json").as_posix(),
                    (Path(package_id) / "profile_icon.svg").as_posix(),
                }
                if not required.issubset(names) or check.testzip() is not None:
                    raise ValueError("El ZIP hijo no superó la verificación.")
                packaged_rule_artifacts = {
                    name.split(package_id + "/", 1)[1]
                    for name in names
                    if name.startswith(package_id + "/")
                    and name.split(package_id + "/", 1)[1]
                    in parent_rule_artifacts
                }
                if packaged_rule_artifacts != selected_rule_artifacts:
                    raise ValueError(
                        "El ZIP hijo no contiene exactamente los artefactos "
                        "portables de las reglas seleccionadas."
                    )
                packaged_manifest_name = (
                    Path(package_id)
                    / "quality_core"
                    / "portable_manifest.json"
                ).as_posix()
                packaged_manifest = json.loads(
                    check.read(packaged_manifest_name).decode("utf-8")
                )
                if set(packaged_manifest.get("rules", {})) != set(child_rules):
                    raise ValueError(
                        "El manifiesto del ZIP hijo no coincide con sus reglas."
                    )
            os.replace(temporary, destination_path)
        finally:
            temporary.unlink(missing_ok=True)

    def export_simplified_plugins(self):
        if self.child_profile is not None:
            return
        selected = set(self.checked_rule_ids())
        target_counts = self.child_export_target_counts()
        if not any(target_counts.values()):
            QMessageBox.information(
                self.dock,
                "Sin reglas",
                "Marque al menos una regla antes de generar perfiles.",
            )
            return
        selection = self.choose_child_exports(target_counts)
        if selection is None:
            return
        settings = QSettings()
        initial_dir_value = str(
            settings.value(
                self.setting_key("child_export_directory"),
                "",
            )
        )
        initial_dir = (
            Path(initial_dir_value)
            if initial_dir_value and Path(initial_dir_value).is_dir()
            else None
        )
        families = list(selection["families"])
        if len(families) == 1:
            suggested_rule_ids = (
                sorted(selected)
                if families[0] == "*"
                else sorted(
                    rule_id
                    for rule_id in selected
                    if self.rule_family_by_id.get(rule_id) == families[0]
                )
            )
            _display_name, suggested_package = self.child_profile_identity(
                families[0],
                selection["profile_name"],
                suggested_rule_ids,
            )
            suggested_name = suggested_package + ".zip"
            dialog_title = "Guardar plugin de producción"
        else:
            suffix = (
                self.child_package_slug(selection["profile_name"])
                if selection["profile_name"]
                else "produccion"
            )
            suggested_name = "plugins_gpkg_{0}.zip".format(suffix)
            dialog_title = "Guardar paquete de plugins de producción"
        suggested_path = (
            initial_dir / suggested_name
            if initial_dir is not None
            else Path(suggested_name)
        )
        destination, _selected_filter = QFileDialog.getSaveFileName(
            self.dock,
            dialog_title,
            str(suggested_path),
            "Archivo ZIP (*.zip)",
        )
        if not destination:
            return
        destination_path = Path(destination)
        if destination_path.suffix.casefold() != ".zip":
            destination_path = destination_path.with_suffix(".zip")
        settings.setValue(
            self.setting_key("child_export_directory"),
            str(destination_path.parent),
        )
        settings.sync()

        generated = []
        bundle_workspace = None
        try:
            if len(families) > 1:
                bundle_workspace = tempfile.TemporaryDirectory(
                    prefix="mapingtool-profile-bundle-"
                )
                output_dir = Path(bundle_workspace.name)
            else:
                output_dir = destination_path.parent

            for family in families:
                if family == "*":
                    rule_ids = sorted(selected)
                else:
                    rule_ids = sorted(
                        rule_id
                        for rule_id in selected
                        if self.rule_family_by_id.get(rule_id) == family
                    )
                if not rule_ids:
                    continue
                display_name, package_id = self.child_profile_identity(
                    family,
                    selection["profile_name"],
                    rule_ids,
                )
                plugin_path = (
                    destination_path
                    if len(families) == 1
                    else output_dir / (package_id + ".zip")
                )
                profile = self.child_profile_payload(
                    family,
                    selection["profile_name"],
                    rule_ids,
                )
                self.write_child_plugin_zip(
                    plugin_path,
                    profile,
                    self.child_profile_icon_svg(
                        "mixed"
                        if profile["selection_mode"] == "mixed"
                        else family
                    ),
                )
                generated.append(
                    {
                        "filename": plugin_path.name,
                        "rule_count": len(rule_ids),
                        "family": family,
                        "display_name": display_name,
                    }
                )

            if len(families) > 1 and generated:
                descriptor, partial_value = tempfile.mkstemp(
                    prefix="." + destination_path.name + ".partial-",
                    dir=str(destination_path.parent),
                )
                os.close(descriptor)
                partial = Path(partial_value)
                try:
                    manifest = {
                        "schema_version": 1,
                        "created_at": datetime.now(timezone.utc).isoformat(),
                        "plugins": generated,
                    }
                    readme = (
                        "PLUGINS GPKG DE PRODUCCIÓN\n\n"
                        "Este paquete contiene plugins QGIS instalables.\n"
                        "1. Descomprima este archivo.\n"
                        "2. En QGIS use Instalar a partir de ZIP para cada "
                        "plugin interno que necesite.\n"
                    )
                    with zipfile.ZipFile(
                        partial,
                        "w",
                        compression=zipfile.ZIP_DEFLATED,
                        compresslevel=9,
                    ) as archive:
                        for item in generated:
                            plugin_path = output_dir / item["filename"]
                            archive.write(plugin_path, item["filename"])
                        archive.writestr(
                            "manifest.json",
                            (
                                json.dumps(
                                    manifest,
                                    ensure_ascii=False,
                                    indent=2,
                                    sort_keys=True,
                                )
                                + "\n"
                            ).encode("utf-8"),
                        )
                        archive.writestr(
                            "LEEME.txt",
                            readme.encode("utf-8"),
                        )
                    with zipfile.ZipFile(partial) as check:
                        if check.testzip() is not None:
                            raise ValueError(
                                "El paquete múltiple no superó la verificación."
                            )
                    os.replace(partial, destination_path)
                finally:
                    partial.unlink(missing_ok=True)
        except Exception as exc:
            self.log(
                "No se pudieron generar los plugins simplificados: {0}".format(exc),
                "error",
            )
            self.log(traceback.format_exc(), "error")
            QMessageBox.warning(
                self.dock,
                "No se pudieron generar los plugins",
                (
                    "La exportacion fue detenida de forma segura y no se dejo "
                    "un ZIP incompleto.\n\n{0}"
                ).format(exc),
            )
            return
        finally:
            if bundle_workspace is not None:
                bundle_workspace.cleanup()

        if not generated:
            QMessageBox.information(
                self.dock,
                "Sin perfiles",
                "Las ediciones elegidas no tienen reglas marcadas.",
            )
            return
        summary = "\n".join(
            "• {0}: {1} regla(s)".format(
                item["filename"],
                item["rule_count"],
            )
            for item in generated
        )
        if len(generated) == 1:
            message = "Plugin listo:\n{0}\n\n{1}".format(
                destination_path,
                summary,
            )
        else:
            message = (
                "Paquete listo:\n{0}\n\nContiene {1} plugins. "
                "Descomprímalo para instalar los ZIP internos.\n\n{2}"
            ).format(destination_path, len(generated), summary)
        QMessageBox.information(
            self.dock,
            "Plugins de producción generados",
            message,
        )

    def export_locked_child_plugin(self):
        """Backward-compatible entry point for profiles generated by 0.0.79."""

        return self.export_simplified_plugins()

    def apply_child_mode(self):
        if self.child_profile is None or not hasattr(self, "rules_table"):
            return
        if self.processing_filter_panel is not None:
            self.processing_filter_panel.hide()
        self.save_config_btn.hide()
        self.run_selected_btn.hide()
        self.run_all_btn.setText("Ejecutar perfil")
        self.run_all_btn.setToolTip(
            "Ejecutar las reglas configuradas de este perfil."
        )
        self.select_all_box.hide()
        is_mixed = self.child_profile.get("selection_mode") == "mixed"
        self.family_filter_button.setVisible(is_mixed)
        self.rule_search_edit.hide()
        if self.mapping_unlock_box is not None:
            self.mapping_unlock_box.hide()
        if self.mapping_lock_status_label is not None:
            self.mapping_lock_status_label.hide()
        for label in self.rules_table.parentWidget().findChildren(QLabel):
            if label.text() in {"Buscar"} or (
                not is_mixed
                and label.text() in {"Grupo", "Filtros de procesamiento"}
            ):
                label.hide()
        if is_mixed:
            self.family_filter_button.setToolTip(
                "Elija uno o varios grupos incluidos en este perfil mixto. "
                "Las reglas del perfil permanecen bloqueadas."
            )
        self.rules_table.setColumnHidden(0, True)
        for row in range(self.rules_table.rowCount()):
            item = self.rules_table.item(row, 0)
            if item is not None:
                item.setCheckState(Qt.Checked)
                item.setFlags(Qt.NoItemFlags)
        self.mapping_table.hide()
        self.refresh_btn.setText("Detectar capas")
        self.auto_map_box.setChecked(
            bool(self.child_profile.get("auto_map", False))
        )

    def install_portable_detail_controls(self):
        """Add portable-only filters without changing the PostGIS edition."""

        if self._detail_controls_installed or not hasattr(self, "detail_table"):
            return
        panel = self.detail_table.parentWidget()
        panel_layout = panel.layout() if panel is not None else None
        filter_layout = (
            panel_layout.itemAt(0).layout()
            if panel_layout is not None and panel_layout.count()
            else None
        )
        if filter_layout is None:
            return

        self.search_edit.setPlaceholderText(
            "Filtrar por manzana (NPN), NPN completo o PK"
        )
        self.detail_count_label.setStyleSheet(
            "QLabel { color: #165DCE; font-weight: 800; }"
        )
        self.hide_exception_rows_box = QCheckBox(
            "Ocultar registros con excepción"
        )
        settings = QSettings()
        self.hide_exception_rows_box.setChecked(
            self.bool_setting(settings, "detail_hide_exceptions", True)
        )
        self.hide_exception_rows_box.setToolTip(
            "Activado: muestra únicamente inconsistencias sin excepción. "
            "La preferencia queda guardada para la próxima sesión."
        )
        self.hide_exception_rows_box.stateChanged.connect(
            self.on_hide_exception_rows_changed
        )
        filter_layout.addWidget(self.hide_exception_rows_box, 4, 0, 1, 4)
        self._detail_controls_installed = True
        self.apply_detail_filter()

    def on_hide_exception_rows_changed(self, *_args):
        if self.hide_exception_rows_box is None:
            return
        settings = QSettings()
        settings.setValue(
            self.setting_key("detail_hide_exceptions"),
            self.hide_exception_rows_box.isChecked(),
        )
        settings.sync()
        self.apply_detail_filter()

    def update_search_from_detail_window(self, text):
        if not hasattr(self, "search_edit"):
            return
        if self.search_edit.text() != text:
            self.search_edit.setText(text)
        else:
            self.apply_detail_filter()

    def update_exception_filter_from_detail_window(self, state):
        if self.hide_exception_rows_box is None:
            return
        checked = bool(state)
        if self.hide_exception_rows_box.isChecked() != checked:
            self.hide_exception_rows_box.setChecked(checked)
        else:
            self.apply_detail_filter()

    def detail_exceptions_hidden(self) -> bool:
        if self.hide_exception_rows_box is not None:
            return self.hide_exception_rows_box.isChecked()
        return self.bool_setting(
            QSettings(),
            "detail_hide_exceptions",
            True,
        )

    def apply_detail_filter(self, *_args, reset_page=True):
        if self._detail_refreshing:
            return
        if reset_page:
            self.detail_page_number = 0
        if self.validation_running:
            return
        self._detail_refreshing = True
        self.detail_prev_btn.setEnabled(False)
        self.detail_next_btn.setEnabled(False)
        try:
            selected_rule = self.rule_filter.currentData() or None
            text = self.search_edit.text().strip() or None
            hide_exceptions = self.detail_exceptions_hidden()
            total_results = self.result_count()
            if self.result_store is None:
                filtered_total = 0
                rows = []
            else:
                filtered_total = self.result_store.count(
                    rule_id=selected_rule,
                    search=text,
                    exclude_exceptions=hide_exceptions,
                )
                last_page = max(
                    (filtered_total - 1) // self.detail_page_size,
                    0,
                )
                self.detail_page_number = min(
                    self.detail_page_number,
                    last_page,
                )
                rows = self.result_store.page(
                    self.detail_page_number,
                    page_size=self.detail_page_size,
                    rule_id=selected_rule,
                    search=text,
                    exclude_exceptions=hide_exceptions,
                )
            self.detail_filtered_total = filtered_total
            self.current_detail_rows = rows
            self.populate_detail_table(self.detail_table, rows)

            page_count = (
                filtered_total + self.detail_page_size - 1
            ) // self.detail_page_size
            current_page = self.detail_page_number + 1 if page_count else 0
            self.detail_prev_btn.setEnabled(self.detail_page_number > 0)
            self.detail_next_btn.setEnabled(
                (self.detail_page_number + 1) * self.detail_page_size
                < filtered_total
            )
            self.detail_page_label.setText(
                "Página {0} de {1}".format(current_page, page_count)
            )
            if hasattr(self, "status_label") and total_results:
                self.status_label.setText(
                    "Visibles: {0} de {1}; página con {2} filas.".format(
                        filtered_total,
                        total_results,
                        len(rows),
                    )
                )
            self.detail_count_label.setText(
                "Inconsistencias visibles: {0} | Total detectadas: {1}".format(
                    filtered_total,
                    total_results,
                )
            )
        finally:
            self._detail_refreshing = False
        self.refresh_detail_window()

    def open_detail_window(self):
        if self.validation_running:
            return
        self.install_portable_detail_controls()
        if self.detail_dock is None:
            self.detail_dock = QDockWidget(
                "Detalle de inconsistencias - {0}".format(PLUGIN_NAME),
                self.iface.mainWindow(),
            )
            self.detail_dock.setObjectName(
                PLUGIN_NAME.replace(" ", "_") + "_detalle"
            )
            wrapper = QWidget()
            layout = QVBoxLayout(wrapper)
            filters = QGridLayout()
            filters.addWidget(QLabel("Filtrar por Manzana (NPN):"), 0, 0)
            self.detail_dock_search_edit = QLineEdit()
            self.detail_dock_search_edit.setPlaceholderText(
                "Escriba el número de la manzana, NPN completo o PK"
            )
            self.detail_dock_search_edit.setClearButtonEnabled(True)
            self.detail_dock_search_edit.setText(self.search_edit.text())
            self.detail_dock_search_edit.textChanged.connect(
                self.update_search_from_detail_window
            )
            filters.addWidget(self.detail_dock_search_edit, 0, 1)
            self.detail_dock_count_label = QLabel()
            self.detail_dock_count_label.setStyleSheet(
                "QLabel { color: #165DCE; font-weight: 800; }"
            )
            filters.addWidget(self.detail_dock_count_label, 0, 2)
            self.detail_dock_hide_exceptions_box = QCheckBox(
                "Ocultar registros con excepción"
            )
            self.detail_dock_hide_exceptions_box.setChecked(
                self.detail_exceptions_hidden()
            )
            self.detail_dock_hide_exceptions_box.stateChanged.connect(
                self.update_exception_filter_from_detail_window
            )
            filters.addWidget(
                self.detail_dock_hide_exceptions_box,
                1,
                0,
                1,
                3,
            )
            filters.setColumnStretch(1, 1)
            layout.addLayout(filters)

            self.detail_dock_label = QLabel()
            self.detail_dock_table = QTableWidget()
            self.configure_detail_table(self.detail_dock_table)
            self.detail_dock_table.setEditTriggers(
                QAbstractItemView.NoEditTriggers
            )
            self.detail_dock_table.setSelectionBehavior(
                QAbstractItemView.SelectRows
            )
            self.detail_dock_table.itemClicked.connect(
                self.zoom_from_detail_item
            )
            self.detail_dock_table.itemDoubleClicked.connect(
                self.open_form_from_detail_item
            )
            layout.addWidget(self.detail_dock_label)
            layout.addWidget(self.detail_dock_table)
            self.detail_dock.setWidget(wrapper)
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.detail_dock)
        self.detail_dock.show()
        self.detail_dock.raise_()
        self.refresh_detail_window()

    def refresh_detail_window(self):
        if self.validation_running:
            return
        if (
            self.detail_dock is None
            or self.detail_dock_table is None
            or not self.detail_dock.isVisible()
        ):
            return
        rows = self.visible_detail_rows()
        counts = OrderedDict()
        for row in rows:
            rule_id = str(row.get("id_regla") or "SIN_REGLA")
            counts[rule_id] = counts.get(rule_id, 0) + 1
        preview = ", ".join(
            "{0}: {1}".format(rule, count)
            for rule, count in list(counts.items())[:10]
        )
        if len(counts) > 10:
            preview += ", ..."

        if self.detail_dock_search_edit is not None:
            blocked = self.detail_dock_search_edit.blockSignals(True)
            self.detail_dock_search_edit.setText(self.search_edit.text())
            self.detail_dock_search_edit.blockSignals(blocked)
        if self.detail_dock_hide_exceptions_box is not None:
            blocked = self.detail_dock_hide_exceptions_box.blockSignals(True)
            self.detail_dock_hide_exceptions_box.setChecked(
                self.detail_exceptions_hidden()
            )
            self.detail_dock_hide_exceptions_box.blockSignals(blocked)
        if self.detail_dock_count_label is not None:
            self.detail_dock_count_label.setText(
                "Inconsistencias visibles: {0}".format(
                    self.detail_filtered_total
                )
            )
        self.detail_dock_label.setText(
            "Página visible: {0}; total detectadas: {1}. {2}".format(
                len(rows),
                self.result_count(),
                preview,
            )
        )
        self.populate_detail_table(self.detail_dock_table, rows)

    def setting_key(self, name: str) -> str:
        if self.child_profile is not None:
            prefix = "MapingTool/PerfilesGPKG/{0}".format(
                self.child_profile["package_id"]
            )
        else:
            prefix = SETTINGS_PREFIX
        return prefix + "/" + name

    def bool_setting(self, settings: QSettings, name: str, default: bool) -> bool:
        value = settings.value(self.setting_key(name), default)
        if isinstance(value, bool):
            return value
        return str(value).strip().casefold() in {"1", "true", "yes", "si", "sí"}

    def create_connection_panel(self):
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(5)

        source = QGridLayout()
        source.setHorizontalSpacing(6)
        source.setVerticalSpacing(4)
        self.source_combo = QComboBox()
        self.source_combo.addItem("Capas vectoriales cargadas", "loaded_layers")
        self.source_combo.addItem("GeoPackage local", "gpkg")
        self.source_combo.currentIndexChanged.connect(self.on_source_changed)
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("GeoPackage recibido del DBA")
        self.path_edit.editingFinished.connect(self.refresh_mapping)
        self.browse_btn = QPushButton("Examinar")
        self.browse_btn.clicked.connect(self.browse_gpkg)
        self.refresh_btn = QPushButton("Actualizar mapeo")
        self.refresh_btn.clicked.connect(self.refresh_mapping)
        self.test_btn = QPushButton("Probar fuente")
        self.test_btn.clicked.connect(self.preflight)
        self.preflight_btn = self.test_btn
        self.connection_status_label = QTextEdit()
        self.connection_status_label.setReadOnly(True)
        self.connection_status_label.setPlainText("Sin probar")
        self.connection_status_label.setMinimumHeight(58)
        self.connection_status_label.setMaximumHeight(128)
        self.connection_status_label.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.connection_status_label.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.set_connection_status("Sin probar", "idle")

        source.addWidget(QLabel("Fuente"), 0, 0)
        source.addWidget(self.source_combo, 0, 1, 1, 3)
        source.addWidget(QLabel("Archivo"), 1, 0)
        source.addWidget(self.path_edit, 1, 1)
        source.addWidget(self.browse_btn, 1, 2)
        source.addWidget(self.refresh_btn, 1, 3)
        source.addWidget(self.test_btn, 1, 4)
        self.scope_status_label = QLabel(
            "Selección manual: este paquete no está obligado a ejecutar todo el catálogo."
        )
        self.scope_status_label.setWordWrap(True)
        source.addWidget(QLabel("Alcance"), 2, 0)
        source.addWidget(self.scope_status_label, 2, 1, 1, 4)
        self.project_combo = QComboBox()
        self.project_combo.setObjectName("MapingToolProjectSelector")
        self.project_combo.currentIndexChanged.connect(
            self.on_project_selection_changed
        )
        self.project_status_label = QLabel(
            "El proyecto se detectará desde lc_gen_predio y la carpeta/QGZ."
        )
        self.project_status_label.setWordWrap(True)
        source.addWidget(QLabel("Proyecto"), 3, 0)
        source.addWidget(self.project_combo, 3, 1, 1, 2)
        source.addWidget(self.project_status_label, 3, 3, 1, 2)
        source.addWidget(QLabel("Estado"), 4, 0)
        source.addWidget(self.connection_status_label, 4, 1, 1, 4)
        layout.addLayout(source)

        mapping_lock_row = QHBoxLayout()
        mapping_lock_row.setContentsMargins(0, 2, 0, 0)
        self.mapping_unlock_box = QCheckBox(
            "Desbloquear edicion del mapeo de capas"
        )
        self.mapping_unlock_box.setObjectName("MapingToolMappingUnlock")
        self.mapping_unlock_box.setChecked(False)
        self.mapping_unlock_box.setToolTip(
            "Active esta casilla solamente mientras necesite cambiar una "
            "asignacion de capa fisica."
        )
        self.mapping_unlock_box.toggled.connect(
            self.update_mapping_lock_state
        )
        self.mapping_lock_status_label = QLabel("Mapeo protegido")
        self.mapping_lock_status_label.setObjectName("MapingToolMappingLockStatus")
        mapping_lock_row.addWidget(self.mapping_unlock_box)
        mapping_lock_row.addStretch(1)
        mapping_lock_row.addWidget(self.mapping_lock_status_label)
        layout.addLayout(mapping_lock_row)

        self.mapping_table = QTableWidget()
        self.mapping_table.setColumnCount(3)
        self.mapping_table.setHorizontalHeaderLabels(
            ["Entidad requerida", "Capa física", "Estado"]
        )
        self.mapping_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.mapping_table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        self.mapping_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.mapping_table.setMinimumHeight(210)
        layout.addWidget(self.mapping_table)
        self.update_mapping_lock_state()
        return panel

    def load_rules_table(self):
        self.rules_table.blockSignals(True)
        self.rules_table.setRowCount(len(self.rules))
        for row, rule in enumerate(self.rules):
            check_item = QTableWidgetItem()
            self.rules_table.setItem(row, 0, check_item)
            for col, value in enumerate(
                [rule.id, rule.family, rule.component, rule.title],
                start=1,
            ):
                item = QTableWidgetItem(str(value))
                if col == 2:
                    item.setForeground(
                        QColor(FAMILY_COLORS.get(rule.family, "#244C66"))
                    )
                    font = item.font()
                    font.setBold(True)
                    item.setFont(font)
                self.rules_table.setItem(row, col, item)
        self.apply_package_scope_to_rules(initial=True)
        self.rules_table.blockSignals(False)
        self.rules_table.itemChanged.connect(self.on_rule_selection_changed)
        self.rules_table.resizeColumnsToContents()
        self.apply_rule_filter()
        self.update_mapping_status()
        self.apply_child_mode()

    def on_rule_selection_changed(self, item):
        if item is None or item.column() != 0:
            return
        self.update_mapping_status()

    def apply_package_scope_to_rules(self, initial=False):
        if not hasattr(self, "rules_table"):
            return
        signals_were_blocked = self.rules_table.blockSignals(True)
        scoped_ids = (
            set(self.package_scope.rule_ids)
            if self.package_scope is not None
            else None
        )
        for row, rule in enumerate(self.rules):
            check_item = self.rules_table.item(row, 0)
            if check_item is None:
                continue
            in_scope = scoped_ids is None or rule.id in scoped_ids
            if in_scope:
                check_item.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
                if scoped_ids is not None:
                    checked = True
                elif initial:
                    checked = (
                        self.saved_rule_ids is None
                        or rule.id in self.saved_rule_ids
                    )
                else:
                    checked = (
                        self.saved_rule_ids is None
                        or rule.id in self.saved_rule_ids
                    )
                check_item.setCheckState(Qt.Checked if checked else Qt.Unchecked)
                check_item.setToolTip(
                    "Regla aplicable al alcance actual."
                    if scoped_ids is not None
                    else "Selección manual del analista."
                )
            else:
                check_item.setFlags(Qt.NoItemFlags)
                check_item.setCheckState(Qt.Unchecked)
                check_item.setToolTip(
                    "Fuera del alcance declarado para este paquete; no es un error."
                )
            for column in range(1, self.rules_table.columnCount()):
                item = self.rules_table.item(row, column)
                if item is None:
                    continue
                item.setToolTip(check_item.toolTip())
                if not in_scope:
                    item.setForeground(QColor("#8a949e"))
                elif column == 2:
                    item.setForeground(
                        QColor(FAMILY_COLORS.get(rule.family, "#244C66"))
                    )
                else:
                    item.setForeground(QColor("#17212b"))
        selected_count = len(self.checked_rule_ids())
        self.select_all_box.blockSignals(True)
        self.select_all_box.setChecked(
            selected_count > 0
            and selected_count
            == len(scoped_ids if scoped_ids is not None else self.rules)
        )
        self.select_all_box.blockSignals(False)
        self.rules_table.blockSignals(signals_were_blocked)

    def checked_rule_ids(self) -> list[str]:
        scoped_ids = (
            set(self.package_scope.rule_ids)
            if self.package_scope is not None
            else None
        )
        selected = []
        for row, rule in enumerate(self.rules):
            if scoped_ids is not None and rule.id not in scoped_ids:
                continue
            item = self.rules_table.item(row, 0)
            if item and item.checkState() == Qt.Checked:
                selected.append(rule.id)
        return selected

    def toggle_all_rules(self):
        state = Qt.Checked if self.select_all_box.isChecked() else Qt.Unchecked
        signals_were_blocked = self.rules_table.blockSignals(True)
        scoped_ids = (
            set(self.package_scope.rule_ids)
            if self.package_scope is not None
            else None
        )
        for row, rule in enumerate(self.rules):
            if self.rules_table.isRowHidden(row):
                continue
            if scoped_ids is not None and rule.id not in scoped_ids:
                continue
            self.rules_table.item(row, 0).setCheckState(state)
        self.rules_table.blockSignals(signals_were_blocked)
        self.update_mapping_status()

    def selected_rules(self, selected_only: bool) -> list:
        scoped_ids = (
            set(self.package_scope.rule_ids)
            if self.package_scope is not None
            else None
        )
        selected = []
        for row, rule in enumerate(self.rules):
            if self.rules_table.isRowHidden(row):
                continue
            if scoped_ids is not None and rule.id not in scoped_ids:
                continue
            if not selected_only:
                selected.append(rule)
                continue
            item = self.rules_table.item(row, 0)
            if item and item.checkState() == Qt.Checked:
                selected.append(rule)
        return selected

    def set_connection_status(self, message: str, state: str):
        if not hasattr(self, "connection_status_label"):
            return
        colors = {
            "ok": ("#e8f5e9", "#1b5e20", "#2e7d32"),
            "error": ("#ffebee", "#b00020", "#c62828"),
            "testing": ("#fff8e1", "#7a4d00", "#b45309"),
            "idle": ("#eef2f6", "#334155", "#94a3b8"),
        }
        background, foreground, border = colors.get(state, colors["idle"])
        self.connection_status_label.setText(message)
        self.connection_status_label.setStyleSheet(
            "QTextEdit { background: %s; color: %s; border: 1px solid %s; "
            "border-radius: 4px; padding: 4px 8px; font-weight: 700; }"
            % (background, foreground, border)
        )

    def load_saved_connections(self):
        self.run_btn = self.run_selected_btn
        if not self.rules:
            self.run_selected_btn.setEnabled(False)
            self.run_all_btn.setEnabled(False)
        if self.summary_table.rowCount() == 0:
            for rule in self.rules:
                self.add_summary_row(rule.id, "pendiente", 0, 0, 0, 0, "")
        self.connect_project_layer_signals()
        self.refresh_mapping()

    def load_preferences(self):
        self.install_processing_filter_controls()
        settings = QSettings()
        self.path_edit.setText(str(settings.value(self.setting_key("gpkg_path"), "")))
        mode = str(settings.value(self.setting_key("source_mode"), "loaded_layers"))
        index = self.source_combo.findData(mode)
        if index >= 0:
            self.source_combo.setCurrentIndex(index)
        selected = str(settings.value(self.setting_key("selected_rule_ids"), "")).strip()
        self.saved_rule_ids = {value for value in selected.split(",") if value} or None
        saved_families = str(
            settings.value(self.setting_key("family_filters"), "") or ""
        )
        self.set_family_filters(
            value for value in saved_families.split(",") if value
        )
        try:
            self.saved_layer_mapping = json.loads(
                str(settings.value(self.setting_key("layer_mapping"), "{}"))
            )
        except (TypeError, ValueError):
            self.saved_layer_mapping = {}
        if self.child_profile is not None:
            self.saved_rule_ids = set(self.rule_ids)
            self.saved_layer_mapping = dict(
                self.child_profile.get("layer_mapping") or {}
            )
        self.auto_map_box.setChecked(
            self.bool_setting(settings, "auto_map", PLUGIN_FAMILY == "sig")
        )
        for key, checkbox in getattr(self, "reco_filter_boxes", {}).items():
            checkbox.setChecked(
                self.bool_setting(settings, "reco_filter_{0}".format(key), True)
            )
        self.update_reco_filter_status()
        for key, section in self.sections.items():
            setting_name = "section_{0}_expanded".format(key)
            if settings.contains(self.setting_key(setting_name)):
                section.setExpanded(
                    self.bool_setting(settings, setting_name, section.isExpanded())
                )
        self.refresh_mapping()
        self.install_portable_detail_controls()
        self.log("Configuración restaurada para {0}.".format(PLUGIN_NAME))

    def save_preferences(self, show_message: bool = False):
        settings = QSettings()
        settings.setValue(self.setting_key("settings_schema"), SETTINGS_SCHEMA_VERSION)
        settings.setValue(self.setting_key("gpkg_path"), self.path_edit.text().strip())
        settings.setValue(self.setting_key("source_mode"), self.source_combo.currentData())
        settings.setValue(
            self.setting_key("layer_mapping"),
            json.dumps(self.selected_mapping(), ensure_ascii=False, sort_keys=True),
        )
        settings.setValue(self.setting_key("selected_rule_ids"), ",".join(self.checked_rule_ids()))
        settings.setValue(
            self.setting_key("family_filters"),
            ",".join(sorted(self.selected_family_filters())),
        )
        settings.setValue(
            self.setting_key("selected_project"),
            str(self.project_combo.currentData() or ""),
        )
        settings.setValue(self.setting_key("auto_map"), self.auto_map_box.isChecked())
        if self.child_profile is None:
            settings.setValue(
                self.setting_key("processing_filter_policy"),
                json.dumps(
                    self.processing_filter_policy(),
                    ensure_ascii=False,
                    sort_keys=True,
                ),
            )
        if self.hide_exception_rows_box is not None:
            settings.setValue(
                self.setting_key("detail_hide_exceptions"),
                self.hide_exception_rows_box.isChecked(),
            )
        for key, checkbox in getattr(self, "reco_filter_boxes", {}).items():
            settings.setValue(
                self.setting_key("reco_filter_{0}".format(key)),
                checkbox.isChecked(),
            )
        for key, section in self.sections.items():
            settings.setValue(
                self.setting_key("section_{0}_expanded".format(key)),
                section.isExpanded(),
            )
        settings.sync()
        self.log("Fuente, reglas y disposición guardadas para {0}.".format(PLUGIN_NAME))
        if show_message:
            QMessageBox.information(
                self.dock,
                "Configuración guardada",
                "Fuente GPKG, mapeo, reglas y disposición guardados.",
            )

    def result_count(self) -> int:
        return self.result_store.count() if self.result_store is not None else 0

    def iter_results(self, *, rule_id=None, search=None):
        if self.result_store is None:
            return iter(())
        return self.result_store.iter_rows(rule_id=rule_id, search=search)

    def cleanup_map_cache(self) -> None:
        for layer_id in self.map_layer_ids:
            if QgsProject.instance().mapLayer(layer_id) is not None:
                QgsProject.instance().removeMapLayer(layer_id)
        self.map_layer_ids = []
        if self.map_cache_path:
            try:
                remove_with_retry(self.map_cache_path)
            except PermissionError as exc:
                self.log("Caché GPKG pendiente de limpieza: {0}".format(exc))
                return
        self.map_cache_path = None

    def cleanup_navigation_layer(self) -> None:
        project = QgsProject.instance()
        if self.feature_form_dialog is not None:
            try:
                self.feature_form_dialog.close()
            except (AttributeError, RuntimeError):
                pass
            self.feature_form_dialog = None
        for relation_id in self.navigation_relation_ids:
            try:
                project.relationManager().removeRelation(relation_id)
            except (AttributeError, RuntimeError):
                pass
        self.navigation_relation_ids = []
        layer_ids = list(self.navigation_context_layer_ids)
        if self.navigation_layer_id and self.navigation_layer_id not in layer_ids:
            layer_ids.append(self.navigation_layer_id)
        self.navigation_layer_id = None
        self.navigation_context_layer_ids = []
        for layer_id in reversed(layer_ids):
            if project.mapLayer(layer_id) is not None:
                project.removeMapLayer(layer_id)

    def cleanup_store(self):
        store = self.result_store or self.store
        self.result_store = None
        self.store = None
        self.result_store_path = None
        self.store_path = None
        self.current_detail_rows = []
        if store is not None:
            store.remove()

    def start_validation(self, selected_only: bool = True):
        if self.worker and self.worker.isRunning():
            return
        selected = self.selected_rules(selected_only)
        selected_ids = [rule.id for rule in selected]
        if not selected_ids:
            QMessageBox.information(self.dock, "Sin reglas", "Marque al menos una regla.")
            return
        self.cleanup_map_cache()
        self.cleanup_navigation_layer()
        self.cleanup_store()
        self.detail_page_number = 0
        self.detail_filtered_total = 0
        self.current_detail_rows = []
        self.summary_table.setRowCount(0)
        self.summary_rows = {}
        self.summary_data = OrderedDict()
        self.populate_detail_table(self.detail_table, [])
        if self.detail_dock_table is not None:
            self.populate_detail_table(self.detail_dock_table, [])
        self.refresh_detail_rule_filter()
        try:
            config = self.prepare_config()
        except Exception as exc:
            self.set_connection_status(str(exc), "error")
            self.status_label.setText(str(exc))
            return
        config["selected_rule_ids"] = selected_ids
        current_reco_filter_policy = self.reco_filter_policy()
        config["reco_filter_policy"] = current_reco_filter_policy
        current_processing_filter_policy = self.processing_filter_policy()
        config["processing_filter_policy"] = current_processing_filter_policy
        self.current_config = {
            **config,
            "host": "GPKG",
            "port": "",
            "dbname": self.path_edit.text().strip() or "capas cargadas",
        }
        if self.package_scope is not None:
            self.log(
                "Alcance {0}: {1} regla(s); SHA-256 {2}.".format(
                    self.package_scope.profile_id,
                    len(selected_ids),
                    self.package_scope.sha256,
                )
            )
        else:
            self.log(
                "Alcance manual: se ejecutarán {0} regla(s), no el catálogo completo.".format(
                    len(selected_ids)
                )
            )
        self.log(
            processing_filter_summary(
                current_processing_filter_policy,
                profiles_for_rules(
                    selected,
                    current_processing_filter_policy,
                ),
            )
        )
        self.result_store = PortableResultStore.create()
        self.store = self.result_store
        self.result_store_path = str(self.result_store.path)
        self.store_path = self.result_store_path
        for rule in selected:
            self.add_summary_row(rule.id, "pendiente", 0, 0, 0, 0, "")
        self.progress.setMaximum(len(selected_ids))
        self.progress.setValue(0)
        self.set_running_state(True)
        self.worker = PortableValidationWorker(
            config,
            selected_ids,
            self.result_store_path,
            test_only=False,
            reco_filter_policy=current_reco_filter_policy,
            processing_filter_policy=current_processing_filter_policy,
        )
        self.worker.rule_started.connect(self.on_rule_started)
        self.worker.rule_finished.connect(self.on_rule_finished)
        self.worker.finished_all.connect(self.on_validation_finished)
        self.worker.log_message.connect(self.log)
        self.worker.start()

    def cancel_validation(self):
        if self.worker and self.worker.isRunning():
            self.worker.cancel()
            self.status_label.setText("Solicitando cancelación de la regla portable...")

    def set_running_state(self, running: bool):
        self.validation_running = bool(running)
        self.run_selected_btn.setEnabled(not running)
        self.run_all_btn.setEnabled(not running)
        self.cancel_btn.setEnabled(running)
        self.test_btn.setEnabled(not running)
        self.load_map_btn.setEnabled(not running)
        self.export_menu_btn.setEnabled(not running)
        self.detail_window_btn.setEnabled(not running)
        self.source_combo.setEnabled(not running)
        if self.project_combo is not None:
            self.project_combo.setEnabled(not running)
        if hasattr(self, "family_filter_button"):
            self.family_filter_button.setEnabled(not running)
        self.path_edit.setEnabled(not running and self.source_combo.currentData() == "gpkg")
        self.browse_btn.setEnabled(not running and self.source_combo.currentData() == "gpkg")
        self.refresh_btn.setEnabled(not running)
        self.mapping_table.setEnabled(not running)
        if self.mapping_unlock_box is not None:
            if running:
                self.mapping_unlock_box.setChecked(False)
            self.mapping_unlock_box.setEnabled(not running)
        self.update_mapping_lock_state()
        for checkbox in getattr(self, "reco_filter_boxes", {}).values():
            checkbox.setEnabled(not running)
        for widget in self.processing_filter_widgets.values():
            widget.setEnabled(not running and self.child_profile is None)
        if self.export_child_btn is not None:
            self.export_child_btn.setEnabled(
                not running and self.child_profile is None
            )
        if self.export_child_action is not None:
            self.export_child_action.setEnabled(
                not running and self.child_profile is None
            )
        if self.publish_child_action is not None:
            self.publish_child_action.setEnabled(
                not running and self.child_profile is None
            )
        if self.detail_dock is not None:
            self.detail_dock.setEnabled(not running)

    def on_rule_finished(self, payload: dict):
        if self._unloading:
            return
        rule_id = str(payload.get("rule_id") or "")
        status = str(payload.get("status") or "error")
        stored_total = int(payload.get("count", 0) or 0)
        raw_total = int(payload.get("raw_total", stored_total) or 0)
        filtered_out = int(
            payload.get("filtered_out", max(raw_total - stored_total, 0)) or 0
        )
        message = str(payload.get("message") or "")
        if not message and filtered_out:
            message = "Filtro RECO posterior: {0} filas descartadas.".format(
                filtered_out
            )
        predios = 0
        exceptions = 0
        if self.result_store is not None and rule_id and not rule_id.startswith("__"):
            metrics = self.result_store.rule_metrics(rule_id)
            predios = int(metrics.get("predios", 0))
            exceptions = int(metrics.get("exceptions", 0))
        self.update_summary_row(
            rule_id,
            status,
            stored_total,
            predios,
            exceptions,
            max(stored_total - exceptions, 0),
            message,
            filtered_out=filtered_out,
        )
        self.ensure_rule_filter(rule_id)
        self.progress.setValue(min(self.progress.value() + 1, self.progress.maximum()))
        if message:
            self.log(
                "{0}: {1}".format(rule_id, message),
                "error"
                if status in ("error", "backend_integrity_error")
                else None,
            )

    def on_validation_finished(self, summary: dict):
        if self._unloading:
            return
        self.set_running_state(False)
        total_results = self.result_count()
        self.status_label.setText(
            (
                "Validación finalizada. Reglas OK: {0}. "
                "No aplicables/opcionales: {1}. Errores/dependencias reales: {2}. "
                "Filas: {3}."
            ).format(
                summary.get("ok", 0),
                summary.get("not_applicable", 0),
                summary.get("errors", 0),
                total_results,
            )
        )
        self.apply_detail_filter(reset_page=False)
        self.log(
            "Validacion finalizada. Reglas OK: {0}. No aplicables/opcionales: {1}. "
            "Errores/dependencias reales: {2}. Filas: {3}.".format(
                summary.get("ok", 0),
                summary.get("not_applicable", 0),
                summary.get("errors", 0),
                total_results,
            ),
            "error" if summary.get("errors", 0) else "success",
        )
        if total_results > MAX_AUTO_MAP_FEATURES:
            self.log(
                "Conjunto voluminoso: {0} filas supera el limite de carga automatica de {1}.".format(
                    total_results,
                    MAX_AUTO_MAP_FEATURES,
                ),
                "warning",
            )
            action = self.choose_large_result_action(total_results)
            if action == "export":
                self.export_gpkg()
            elif action == "load":
                self.load_results_to_map(allow_large=True)
            return
        if self.auto_map_box.isChecked() and total_results:
            self.load_results_to_map()

    def on_tested(self, ok, message):
        self.status_label.setText(message)
        self.set_connection_status(message, "ok" if ok else "error")
        self.log(message)
        dialog_message = message
        if len(dialog_message) > 700:
            dialog_message = (
                dialog_message[:700].rstrip()
                + "\n\nEl detalle completo está disponible en Estado y Consola."
            )
        if ok:
            QMessageBox.information(self.dock, "Fuente correcta", dialog_message)
        else:
            QMessageBox.warning(self.dock, "Fuente no apta", dialog_message)

    def mapped_layer(self, logical_name: str):
        mapping = self.selected_mapping()
        physical = mapping.get(logical_name, "")
        if not physical:
            return None
        if self.source_combo.currentData() == "loaded_layers":
            layer = QgsProject.instance().mapLayer(physical)
            return layer if isinstance(layer, QgsVectorLayer) and layer.isValid() else None
        path = self.path_edit.text().strip()
        layer = QgsVectorLayer(
            "{0}|layername={1}".format(path, physical),
            logical_name,
            "ogr",
        )
        return layer if layer.isValid() else None

    def packaged_qgis_projects(self) -> list[Path]:
        if self.source_combo.currentData() != "gpkg":
            return []
        gpkg_path = Path(self.path_edit.text().strip())
        if not gpkg_path.is_file():
            return []
        return sorted(gpkg_path.parent.glob("*.qgz"))

    def project_predio_layer(self):
        gpkg_path = Path(self.path_edit.text().strip())
        try:
            expected_path = gpkg_path.resolve()
        except OSError:
            expected_path = gpkg_path
        for layer in QgsProject.instance().mapLayersByName(PREDIO_LAYER_NAME):
            if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                continue
            source_path = str(layer.source()).split("|", 1)[0]
            try:
                if Path(source_path).resolve() == expected_path:
                    return layer
            except OSError:
                continue
        return None

    def load_packaged_form_context(self):
        """Import the QGIS form configuration shipped beside a direct GPKG.

        QGIS stores tabs, relation widgets and editor configuration in the
        project, not in the GeoPackage table.  The DBA work package already
        ships that project, so clone its configured relation graph into the
        current project without replacing the operator's open project.
        """

        existing = self.project_predio_layer()
        if existing is not None:
            return existing

        main_project = QgsProject.instance()
        for project_path in self.packaged_qgis_projects():
            source_project = QgsProject()
            if not source_project.read(str(project_path)):
                continue
            roots = source_project.mapLayersByName(PREDIO_LAYER_NAME)
            if not roots:
                continue
            source_root = next(
                (
                    layer
                    for layer in roots
                    if isinstance(layer, QgsVectorLayer) and layer.isValid()
                ),
                None,
            )
            if source_root is None:
                continue

            source_relations = source_project.relationManager().relations()
            required_layer_ids = {source_root.id()}
            required_relation_ids = set()
            changed = True
            while changed:
                changed = False
                for relation_id, relation in source_relations.items():
                    if relation.referencedLayerId() not in required_layer_ids:
                        continue
                    required_relation_ids.add(relation_id)
                    child_id = relation.referencingLayerId()
                    if child_id not in required_layer_ids:
                        required_layer_ids.add(child_id)
                        changed = True

            layer_id_map = {}
            imported_layers = []
            for source_layer_id in required_layer_ids:
                source_layer = source_project.mapLayer(source_layer_id)
                if not isinstance(source_layer, QgsVectorLayer) or not source_layer.isValid():
                    continue
                target_layer = QgsVectorLayer(
                    source_layer.source(),
                    source_layer.name(),
                    source_layer.providerType(),
                )
                if not target_layer.isValid():
                    continue
                style = QgsMapLayerStyle()
                style.readFromLayer(source_layer)
                style.writeToLayer(target_layer)
                main_project.addMapLayer(
                    target_layer,
                    source_layer_id == source_root.id(),
                )
                layer_id_map[source_layer_id] = target_layer.id()
                imported_layers.append(target_layer.id())

            target_root_id = layer_id_map.get(source_root.id())
            if not target_root_id:
                for layer_id in reversed(imported_layers):
                    main_project.removeMapLayer(layer_id)
                continue

            imported_relations = []
            existing_relations = main_project.relationManager().relations()
            for relation_id in required_relation_ids:
                source_relation = source_relations[relation_id]
                referenced_id = layer_id_map.get(source_relation.referencedLayerId())
                referencing_id = layer_id_map.get(source_relation.referencingLayerId())
                if not referenced_id or not referencing_id:
                    continue
                if relation_id in existing_relations:
                    continue
                relation = QgsRelation()
                relation.setId(relation_id)
                relation.setName(source_relation.name())
                relation.setReferencedLayer(referenced_id)
                relation.setReferencingLayer(referencing_id)
                for referencing_field, referenced_field in source_relation.fieldPairs().items():
                    relation.addFieldPair(referencing_field, referenced_field)
                try:
                    relation.setStrength(source_relation.strength())
                except AttributeError:
                    pass
                if relation.isValid():
                    main_project.relationManager().addRelation(relation)
                    imported_relations.append(relation_id)

            self.navigation_layer_id = target_root_id
            self.navigation_context_layer_ids = imported_layers
            self.navigation_relation_ids = imported_relations
            self.log(
                (
                    "Formulario profesional importado desde {0}: "
                    "{1} capas relacionadas y {2} relaciones."
                ).format(
                    project_path.name,
                    len(imported_layers),
                    len(imported_relations),
                ),
                level="success",
            )
            return main_project.mapLayer(target_root_id)
        return None

    def find_or_load_predio_layer(self, show_warning: bool = True):
        if self.navigation_layer_id:
            cached = QgsProject.instance().mapLayer(self.navigation_layer_id)
            if isinstance(cached, QgsVectorLayer) and cached.isValid():
                return cached
        configured = self.load_packaged_form_context()
        if configured is not None:
            return configured
        layer = self.mapped_layer("lc_gen_predio")
        if layer is not None:
            if (
                self.source_combo.currentData() == "gpkg"
                and QgsProject.instance().mapLayer(layer.id()) is None
            ):
                layer.setName(PREDIO_LAYER_NAME)
                QgsProject.instance().addMapLayer(layer)
                self.navigation_layer_id = layer.id()
                self.log(
                    "Capa lc_gen_predio cargada automáticamente para zoom y formulario.",
                    level="success",
                )
                self.log(
                    (
                        "Formulario básico activo: no se encontró o no se pudo "
                        "importar un proyecto QGIS .qgz junto al GeoPackage."
                    ),
                    level="warning",
                )
            return layer
        if show_warning:
            QMessageBox.warning(
                self.dock,
                "Capa no disponible",
                (
                    "Para navegar a la inconsistencia se necesita lc_gen_predio. "
                    "Cárguela en el proyecto o asígnela en Fuente de capas / GeoPackage."
                ),
            )
        return None

    def map_ph_to_gen_candidates(self, row_data: dict) -> list[str]:
        layer = self.mapped_layer("lc_ph_predio")
        if layer is None or "pk_id" not in layer.fields().names() or "fk_id" not in layer.fields().names():
            return []
        values = []
        for table_key, pk_key in (("tabla_error_1", "pk_tabla_error_1"), ("tabla_error_2", "pk_tabla_error_2")):
            if "lc_ph_predio" not in str(row_data.get(table_key) or "").casefold():
                continue
            pk_value = row_data.get(pk_key)
            if pk_value in (None, ""):
                continue
            request = QgsFeatureRequest().setFilterExpression(
                '"pk_id" = {0}'.format(_qgis_sql_string(pk_value))
            )
            feature = next(layer.getFeatures(request), None)
            if feature is not None and feature["fk_id"] not in (None, ""):
                values.append(str(feature["fk_id"]))
        return values

    def select_predio(self, row_data: dict, open_form: bool = False):
        layer = self.find_or_load_predio_layer()
        if not layer:
            return

        found_feature = None
        for pk in self.predio_candidates(row_data):
            expression = '"pk_id" = {0}'.format(_qgis_sql_string(pk))
            request = QgsFeatureRequest().setFilterExpression(expression)
            found_feature = next(layer.getFeatures(request), None)
            if found_feature:
                break

        if not found_feature:
            for npn in self.predial_candidates(row_data):
                expression = '"numero_predial_nacional" = {0}'.format(
                    _qgis_sql_string(npn)
                )
                request = QgsFeatureRequest().setFilterExpression(expression)
                found_feature = next(layer.getFeatures(request), None)
                if found_feature:
                    break

        if not found_feature:
            QMessageBox.information(
                self.dock,
                "Sin geometría",
                "No se encontró el predio en lc_gen_predio.",
            )
            return

        layer.removeSelection()
        layer.selectByIds([found_feature.id()])
        if found_feature.geometry() and not found_feature.geometry().isEmpty():
            canvas = self.iface.mapCanvas()
            canvas.setExtent(found_feature.geometry().boundingBox())
            canvas.refresh()
            target_scale = (
                800
                if QgsWkbTypes.geometryType(layer.wkbType())
                == QgsWkbTypes.PointGeometry
                else 1500
            )
            try:
                if canvas.scale() > target_scale:
                    canvas.zoomScale(target_scale)
            except AttributeError:
                pass
            try:
                canvas.flashFeatureIds(
                    layer,
                    [found_feature.id()],
                    QColor("#ff1744"),
                    QColor("#fff176"),
                    6,
                    350,
                )
            except (AttributeError, TypeError):
                pass
            canvas.refresh()

        if open_form:
            self.feature_form_dialog = self.iface.getFeatureForm(
                layer,
                found_feature,
            )
            self.feature_form_dialog.show()
            if hasattr(self.feature_form_dialog, "raise_"):
                self.feature_form_dialog.raise_()
            if hasattr(self.feature_form_dialog, "activateWindow"):
                self.feature_form_dialog.activateWindow()
