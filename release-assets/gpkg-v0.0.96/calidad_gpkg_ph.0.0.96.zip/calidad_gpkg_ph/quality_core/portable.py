"""Fail-closed contracts for quality rules over portable vector sources."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable, Iterator, Mapping
from dataclasses import dataclass, field
import importlib
import json
from pathlib import Path
import sqlite3
import sys
from typing import Any

from .portable_integrity import verify_execution_bundle
from .portable_postprocessors import POSTPROCESSORS
from .portable_store import PortableResultStore


PORTABLE_MANIFEST_NAME = "portable_manifest.json"
VERIFIED_SOURCE_DIGEST_ATTRIBUTE = "__mapingtool_verified_source_sha256__"
DERIVED_CONSTRUCTION_ENTITY = "determinacion_area_construccion"
CONSTRUCTION_USAGE_FIELDS = (
    "uso_residencial",
    "uso_comercial",
    "uso_industrial",
    "uso_institucional",
    "uso_anexo",
    "uso_tradicional_cultural",
)
DERIVED_CONSTRUCTION_FIELDS = (
    "fuente",
    "nombre_proyecto",
    "pk_id",
    "numero_predial_nacional",
    "pk_carac",
    "identificador",
    "tipo_unidad_construccion",
    "uso_construccion",
    "area_construida",
    "total_plantas",
    "anio_construccion",
    "estado_conservacion",
    "puntaje",
    "puntaje_masivo",
    "uso_anterior",
    "puntaje_anterior",
)
DERIVED_CONSTRUCTION_TYPES = {
    "fuente": "TEXT",
    "nombre_proyecto": "TEXT",
    "pk_id": "TEXT",
    "numero_predial_nacional": "TEXT",
    "pk_carac": "TEXT",
    "identificador": "TEXT",
    "tipo_unidad_construccion": "INTEGER",
    "uso_construccion": "INTEGER",
    "area_construida": "REAL",
    "total_plantas": "INTEGER",
    "anio_construccion": "INTEGER",
    "estado_conservacion": "INTEGER",
    "puntaje": "INTEGER",
    "puntaje_masivo": "INTEGER",
    "uso_anterior": "TEXT",
    "puntaje_anterior": "INTEGER",
}

# These are narrow, rule-specific representations found in the portable
# CartoFlow packages.  They are accepted only where the implementation treats
# the value safely (presence/copy or explicit integer parsing).  This avoids
# weakening type checks for unrelated rules or fields.
RULE_TYPE_FAMILY_COMPATIBILITY = {
    "Reco_19": {("lc_gen_predio", "condicion"): {"text"}},
    "Reco_22": {("lc_gen_predio", "condicion"): {"text"}},
    "Reco_24": {("lc_gen_predio", "condicion"): {"text"}},
    "Jur_80": {
        ("lc_gen_predio", "destinacion_economica_anterior"): {"text"},
    },
    "SIG_07": {
        ("lc_gen_unidadconstruccion", "tipo_construccion"): {"text"},
        ("lc_gen_unidadconstruccion_informal", "tipo_construccion"): {"text"},
    },
    "SIG_08": {
        ("lc_gen_unidadconstruccion", "tipo_construccion"): {"text"},
        ("lc_gen_unidadconstruccion_informal", "tipo_construccion"): {"text"},
    },
    "PH_40": {
        ("lc_ph_caracteristicasunidadconstruccion", "puntaje_anterior"): {
            "integer",
        },
    },
    "PH_43": {
        ("lc_ph_caracteristicasunidadconstruccion", "puntaje_anterior"): {
            "integer",
        },
    },
    "PH_44": {
        ("lc_ph_caracteristicasunidadconstruccion", "puntaje_anterior"): {
            "integer",
        },
    },
}


@dataclass(frozen=True)
class LayerDescriptor:
    physical_name: str
    fields: tuple[str, ...]
    field_types: Mapping[str, str] = field(default_factory=dict)
    crs: str = ""
    feature_count: int | None = None


class DataSource(ABC):
    """Read-only source of named vector/attribute entities."""

    backend_id = "abstract"

    @abstractmethod
    def entities(self) -> tuple[str, ...]:
        raise NotImplementedError

    @abstractmethod
    def describe(self, physical_name: str) -> LayerDescriptor:
        raise NotImplementedError

    @abstractmethod
    def iter_rows(
        self,
        physical_name: str,
        fields: Iterable[str],
    ) -> Iterator[dict[str, Any]]:
        raise NotImplementedError

    def close(self) -> None:
        return None


@dataclass(frozen=True)
class LayerMapping:
    """Explicit relation from canonical entities to physical layer names."""

    layers: Mapping[str, str]

    def resolve(self, logical_name: str) -> str:
        value = str(self.layers.get(logical_name, "")).strip()
        if not value:
            raise KeyError(logical_name)
        return value


@dataclass(frozen=True)
class PreflightResult:
    rule_id: str
    status: str
    message: str = ""
    missing_entities: tuple[str, ...] = ()
    missing_fields: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    incompatible_fields: Mapping[str, tuple[str, ...]] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.status == "ok"


@dataclass(frozen=True)
class RuleExecution:
    rule_id: str
    status: str
    rows: Iterable[dict[str, Any]] = ()
    message: str = ""
    implementation_sha256: str = ""


class MappingDataSource(DataSource):
    """Small deterministic source used by pure tests and adapters."""

    backend_id = "mapping"

    def __init__(self, entities: Mapping[str, Iterable[Mapping[str, Any]]]):
        self._rows = {
            str(name): [dict(row) for row in rows]
            for name, rows in entities.items()
        }

    def entities(self) -> tuple[str, ...]:
        return tuple(sorted(self._rows))

    def describe(self, physical_name: str) -> LayerDescriptor:
        if physical_name not in self._rows:
            raise KeyError(physical_name)
        fields: set[str] = set()
        observed_types: dict[str, set[str]] = {}
        for row in self._rows[physical_name]:
            fields.update(str(key) for key in row)
            for key, value in row.items():
                if value is None:
                    continue
                if isinstance(value, bool):
                    family = "BOOLEAN"
                elif isinstance(value, int):
                    family = "INTEGER"
                elif isinstance(value, float):
                    family = "REAL"
                elif isinstance(value, (bytes, bytearray, memoryview)):
                    family = "BLOB"
                else:
                    family = "TEXT"
                observed_types.setdefault(str(key), set()).add(family)
        field_types = {
            name: next(iter(values)) if len(values) == 1 else "MIXED"
            for name, values in observed_types.items()
        }
        return LayerDescriptor(
            physical_name=physical_name,
            fields=tuple(sorted(fields)),
            field_types=field_types,
            feature_count=len(self._rows[physical_name]),
        )

    def iter_rows(self, physical_name: str, fields: Iterable[str]) -> Iterator[dict[str, Any]]:
        descriptor = self.describe(physical_name)
        requested = tuple(str(name) for name in fields)
        missing = sorted(set(requested) - set(descriptor.fields))
        if missing:
            raise KeyError("Campos ausentes en {0}: {1}".format(physical_name, ", ".join(missing)))
        for row in self._rows[physical_name]:
            yield {name: row.get(name) for name in requested}


class GeoPackageDataSource(DataSource):
    """Read a GeoPackage, including safe unregistered business tables.

    Mergin/CartoFlow packages can store relational tables in the same SQLite
    file without registering them in ``gpkg_contents``.  They are still part of
    the delivered model and are exposed read-only here.  GeoPackage internals,
    tile matrices, RTree helpers and MapingTool snapshot metadata remain hidden.
    """

    backend_id = "gpkg-sqlite"

    def __init__(self, path: str | Path):
        self.path = Path(path).expanduser().resolve()
        if not self.path.is_file():
            raise FileNotFoundError("No existe el GeoPackage: {0}".format(self.path))
        uri = self.path.as_uri() + "?mode=ro"
        self._db = sqlite3.connect(uri, uri=True, check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        try:
            content_rows = self._db.execute(
                "SELECT table_name, data_type FROM gpkg_contents ORDER BY table_name"
            ).fetchall()
            object_rows = self._db.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type IN ('table', 'view') ORDER BY name"
            ).fetchall()
        except sqlite3.DatabaseError as exc:
            self._db.close()
            raise ValueError("El archivo no es un GeoPackage legible.") from exc
        registered_business = {
            str(row[0])
            for row in content_rows
            if str(row[1]).casefold() in {"features", "attributes"}
        }
        registered_non_business = {
            str(row[0])
            for row in content_rows
            if str(row[1]).casefold() not in {"features", "attributes"}
        }
        business_entities = set(registered_business)
        for row in object_rows:
            name = str(row[0])
            folded = name.casefold()
            if (
                name in registered_non_business
                or folded.startswith(("sqlite_", "gpkg_", "rtree_"))
                or folded == "mapingtool_gpkg_snapshot_manifest"
            ):
                continue
            business_entities.add(name)
        self._derived_construction_sources = self._construction_sources(
            business_entities
        )
        if (
            DERIVED_CONSTRUCTION_ENTITY.casefold()
            not in {name.casefold() for name in business_entities}
            and self._derived_construction_sources
        ):
            business_entities.add(DERIVED_CONSTRUCTION_ENTITY)
        self._entities = tuple(sorted(business_entities, key=str.casefold))

    @staticmethod
    def _quote_identifier(value: str) -> str:
        return '"' + str(value).replace('"', '""') + '"'

    def entities(self) -> tuple[str, ...]:
        return self._entities

    def _table_fields(self, physical_name: str) -> set[str]:
        rows = self._db.execute(
            "PRAGMA table_info({0})".format(self._quote_identifier(physical_name))
        ).fetchall()
        return {str(row[1]) for row in rows}

    def _has_fields(
        self,
        entities: set[str],
        physical_name: str,
        required_fields: Iterable[str],
    ) -> bool:
        actual_name = next(
            (
                name
                for name in entities
                if name.casefold() == physical_name.casefold()
            ),
            "",
        )
        return (
            bool(actual_name)
            and set(required_fields).issubset(self._table_fields(actual_name))
        )

    def _construction_sources(self, entities: set[str]) -> tuple[str, ...]:
        characteristic_fields = {
            "pk_id",
            "fk_id",
            "identificador",
            "tipo_unidad_construccion",
            "area_construida",
            "total_plantas",
            "anio_construccion",
            "estado_conservacion",
            "puntaje_final",
            "puntaje_masivo",
            "uso_anterior",
            "puntaje_anterior",
            *CONSTRUCTION_USAGE_FIELDS,
        }
        general_ready = self._has_fields(
            entities,
            "lc_gen_predio",
            {"pk_id", "nombre_proyecto", "numero_predial_nacional"},
        )
        sources = []
        if general_ready and self._has_fields(
            entities,
            "lc_reco_caracteristicasunidadconstruccion",
            characteristic_fields,
        ):
            sources.append("reco")
        if (
            general_ready
            and self._has_fields(
                entities,
                "lc_ph_predio",
                {"pk_id", "fk_id", "numero_predial_nacional"},
            )
            and self._has_fields(
                entities,
                "lc_ph_caracteristicasunidadconstruccion",
                characteristic_fields,
            )
        ):
            sources.append("ph")
        return tuple(sources)

    @staticmethod
    def _construction_projection(prefix: str = "b") -> str:
        fields = (
            "fuente",
            "nombre_proyecto",
            "pk_id",
            "numero_predial_nacional",
            "pk_carac",
            "identificador",
            "tipo_unidad_construccion",
        )
        first = ", ".join("{0}.{1}".format(prefix, field) for field in fields)
        remaining = (
            "area_construida",
            "total_plantas",
            "anio_construccion",
            "estado_conservacion",
            "puntaje",
            "puntaje_masivo",
            "uso_anterior",
            "puntaje_anterior",
        )
        last = ", ".join("{0}.{1}".format(prefix, field) for field in remaining)
        return first + ", {usage} AS uso_construccion, " + last

    def _derived_construction_sql(self, requested: Iterable[str]) -> str:
        requested_fields = tuple(str(value) for value in requested)
        unknown = sorted(set(requested_fields) - set(DERIVED_CONSTRUCTION_FIELDS))
        if unknown:
            raise KeyError(
                "Campos ausentes en {0}: {1}".format(
                    DERIVED_CONSTRUCTION_ENTITY,
                    ", ".join(unknown),
                )
            )
        base_selects = []
        if "reco" in self._derived_construction_sources:
            base_selects.append(
                """
                SELECT
                    'LC_Reco_Caracteristicasunidadconstruccion' AS fuente,
                    p.nombre_proyecto,
                    p.pk_id,
                    p.numero_predial_nacional,
                    c.pk_id AS pk_carac,
                    c.identificador,
                    c.tipo_unidad_construccion,
                    c.area_construida,
                    c.total_plantas,
                    c.anio_construccion,
                    c.estado_conservacion,
                    c.puntaje_final AS puntaje,
                    c.puntaje_masivo,
                    c.uso_anterior,
                    c.puntaje_anterior,
                    c.uso_residencial,
                    c.uso_comercial,
                    c.uso_industrial,
                    c.uso_institucional,
                    c.uso_anexo,
                    c.uso_tradicional_cultural
                FROM lc_reco_caracteristicasunidadconstruccion c
                JOIN lc_gen_predio p ON p.pk_id = c.fk_id
                """
            )
        if "ph" in self._derived_construction_sources:
            base_selects.append(
                """
                SELECT
                    'LC_Ph_Caracteristicasunidadconstruccion' AS fuente,
                    gp.nombre_proyecto,
                    ph.pk_id,
                    ph.numero_predial_nacional,
                    c.pk_id AS pk_carac,
                    c.identificador,
                    c.tipo_unidad_construccion,
                    c.area_construida,
                    c.total_plantas,
                    c.anio_construccion,
                    c.estado_conservacion,
                    c.puntaje_final AS puntaje,
                    c.puntaje_masivo,
                    c.uso_anterior,
                    c.puntaje_anterior,
                    c.uso_residencial,
                    c.uso_comercial,
                    c.uso_industrial,
                    c.uso_institucional,
                    c.uso_anexo,
                    c.uso_tradicional_cultural
                FROM lc_ph_caracteristicasunidadconstruccion c
                JOIN lc_ph_predio ph ON ph.pk_id = c.fk_id
                JOIN lc_gen_predio gp ON gp.pk_id = ph.fk_id
                """
            )
        if not base_selects:
            raise KeyError(DERIVED_CONSTRUCTION_ENTITY)
        projection = self._construction_projection()
        unpivot = [
            (
                "SELECT {0} FROM base b WHERE b.{1} IS NOT NULL".format(
                    projection.format(usage="b." + usage),
                    usage,
                )
            )
            for usage in CONSTRUCTION_USAGE_FIELDS
        ]
        null_filter = " AND ".join(
            "b.{0} IS NULL".format(usage)
            for usage in CONSTRUCTION_USAGE_FIELDS
        )
        unpivot.append(
            "SELECT {0} FROM base b WHERE {1}".format(
                projection.format(usage="NULL"),
                null_filter,
            )
        )
        selected = ", ".join(
            self._quote_identifier(field) for field in requested_fields
        )
        return (
            "WITH base AS ({0}), derived AS ({1}) SELECT {2} FROM derived".format(
                " UNION ALL ".join(base_selects),
                " UNION ALL ".join(unpivot),
                selected,
            )
        )

    def _require_entity(self, physical_name: str) -> str:
        name = str(physical_name)
        if name not in self._entities:
            raise KeyError(name)
        return name

    def describe(self, physical_name: str) -> LayerDescriptor:
        name = self._require_entity(physical_name)
        if (
            name == DERIVED_CONSTRUCTION_ENTITY
            and self._derived_construction_sources
        ):
            return LayerDescriptor(
                physical_name=name,
                fields=DERIVED_CONSTRUCTION_FIELDS,
                field_types=DERIVED_CONSTRUCTION_TYPES,
                feature_count=None,
            )
        pragma = "PRAGMA table_info({0})".format(self._quote_identifier(name))
        rows = self._db.execute(pragma).fetchall()
        fields = tuple(str(row[1]) for row in rows)
        field_types = {str(row[1]): str(row[2] or "") for row in rows}
        count = int(
            self._db.execute(
                "SELECT COUNT(*) FROM {0}".format(self._quote_identifier(name))
            ).fetchone()[0]
        )
        crs_row = self._db.execute(
            "SELECT s.organization, s.organization_coordsys_id "
            "FROM gpkg_geometry_columns g JOIN gpkg_spatial_ref_sys s "
            "ON s.srs_id = g.srs_id WHERE g.table_name = ?",
            (name,),
        ).fetchone()
        crs = ""
        if crs_row is not None:
            crs = "{0}:{1}".format(crs_row[0], crs_row[1])
        return LayerDescriptor(name, fields, field_types, crs, count)

    def iter_rows(self, physical_name: str, fields: Iterable[str]) -> Iterator[dict[str, Any]]:
        descriptor = self.describe(physical_name)
        requested = tuple(str(name) for name in fields)
        missing = sorted(set(requested) - set(descriptor.fields))
        if missing:
            raise KeyError("Campos ausentes en {0}: {1}".format(physical_name, ", ".join(missing)))
        if not requested:
            return
        if (
            descriptor.physical_name == DERIVED_CONSTRUCTION_ENTITY
            and self._derived_construction_sources
        ):
            sql = self._derived_construction_sql(requested)
        else:
            sql = "SELECT {0} FROM {1}".format(
                ", ".join(self._quote_identifier(name) for name in requested),
                self._quote_identifier(descriptor.physical_name),
            )
        cursor = self._db.execute(sql)
        try:
            for row in cursor:
                yield {name: row[name] for name in requested}
        finally:
            cursor.close()

    def close(self) -> None:
        if self._db is not None:
            self._db.close()
            self._db = None


def _perform_sqlite_backup(source_db, destination_db, progress=None) -> None:
    source_db.backup(destination_db, pages=256, progress=progress, sleep=0.01)


def backup_geopackage(
    source: str | Path,
    destination: str | Path,
    cancel_check: Callable[[], bool] | None = None,
    progress_callback: Callable[[int, int], None] | None = None,
) -> Path:
    """Create a transactionally consistent SQLite snapshot, including WAL state."""

    source_path = Path(source).expanduser().resolve()
    destination_path = Path(destination).expanduser().resolve()
    if not source_path.is_file():
        raise FileNotFoundError(source_path)
    if destination_path.exists():
        raise FileExistsError(destination_path)
    if source_path == destination_path:
        raise ValueError("Origen y snapshot GeoPackage deben ser distintos.")
    destination_path.parent.mkdir(parents=True, exist_ok=True)
    source_db = None
    destination_db = None

    def on_progress(_status: int, remaining: int, total: int) -> None:
        if cancel_check is not None and cancel_check():
            raise InterruptedError("Captura GeoPackage cancelada por el usuario.")
        if progress_callback is not None:
            progress_callback(max(0, int(total) - int(remaining)), max(1, int(total)))

    try:
        source_db = sqlite3.connect(source_path.as_uri() + "?mode=ro", uri=True)
        destination_db = sqlite3.connect(str(destination_path))
        _perform_sqlite_backup(source_db, destination_db, on_progress)
        destination_db.commit()
    except BaseException:
        if destination_db is not None:
            destination_db.close()
            destination_db = None
        destination_path.unlink(missing_ok=True)
        raise
    finally:
        if destination_db is not None:
            destination_db.close()
        if source_db is not None:
            source_db.close()
    # Reopen with the production read-only adapter before accepting the copy.
    check = GeoPackageDataSource(destination_path)
    check.close()
    return destination_path


def resolve_portable_rule_id(manifest: Mapping, rule_id: Any) -> str:
    """Resolve a rule ID case-insensitively while preserving its canonical spelling."""

    requested = str(rule_id).strip()
    rules = manifest.get("rules", {})
    if not isinstance(rules, Mapping) or not requested:
        return requested
    if requested in rules:
        return requested
    folded = requested.casefold()
    matches = [
        candidate
        for candidate in rules
        if isinstance(candidate, str) and candidate.casefold() == folded
    ]
    if len(matches) > 1:
        raise ValueError(
            "El manifiesto portable contiene IDs ambiguos por mayusculas/minusculas: "
            + ", ".join(sorted(matches))
        )
    return matches[0] if matches else requested


class BackendPreflight:
    """Validate only explicitly declared portable dependencies."""

    def __init__(self, data_source: DataSource, layer_mapping: LayerMapping, manifest: Mapping):
        self.data_source = data_source
        self.layer_mapping = layer_mapping
        self.manifest = manifest

    @staticmethod
    def _type_family(declared_type: str) -> str:
        value = str(declared_type or "").strip().upper()
        if value == "MIXED":
            return "mixed"
        if "BOOL" in value:
            return "boolean"
        if "INT" in value:
            return "integer"
        if any(token in value for token in ("CHAR", "CLOB", "TEXT")):
            return "text"
        if any(token in value for token in ("REAL", "FLOA", "DOUB")):
            return "real"
        if any(token in value for token in ("NUM", "DEC", "DATE", "TIME")):
            return "numeric"
        if "BLOB" in value:
            return "blob"
        return "unknown"

    def check_rule(self, rule_id: str) -> PreflightResult:
        rule_key = resolve_portable_rule_id(self.manifest, rule_id)
        declaration = self.manifest.get("rules", {}).get(rule_key)
        if not isinstance(declaration, dict) or declaration.get("status") != "implemented":
            return PreflightResult(
                rule_id=rule_key,
                status="backend_unsupported",
                message="La regla no tiene implementacion portable versionada.",
            )

        entities = set(self.data_source.entities())
        missing_entities = []
        missing_fields: dict[str, tuple[str, ...]] = {}
        incompatible_fields: dict[str, tuple[str, ...]] = {}
        for logical_name, requirement in declaration.get("dependencies", {}).items():
            try:
                physical_name = self.layer_mapping.resolve(logical_name)
            except KeyError:
                missing_entities.append(logical_name)
                continue
            if physical_name not in entities:
                missing_entities.append(logical_name)
                continue
            descriptor = self.data_source.describe(physical_name)
            absent = tuple(
                sorted(set(requirement.get("fields", ())) - set(descriptor.fields))
            )
            if absent:
                missing_fields[logical_name] = absent
            type_errors = []
            for field_name, allowed in requirement.get("types", {}).items():
                if field_name in absent:
                    continue
                actual = self._type_family(descriptor.field_types.get(field_name, ""))
                accepted = {str(item).strip().lower() for item in allowed}
                compatible = RULE_TYPE_FAMILY_COMPATIBILITY.get(
                    rule_key,
                    {},
                ).get((logical_name, field_name), set())
                if actual not in accepted and actual not in compatible:
                    type_errors.append(
                        "{0}:{1}->{2}".format(
                            field_name,
                            actual,
                            "/".join(sorted(accepted)),
                        )
                    )
            if type_errors:
                incompatible_fields[logical_name] = tuple(sorted(type_errors))
        optional_missing_entities = set()
        if declaration.get("optional_for_work_packages") is True:
            optional_missing_entities = set(
                str(value).strip()
                for value in declaration.get("optional_missing_entities", ())
                if str(value).strip()
            ).intersection(missing_entities)
        required_missing_entities = set(missing_entities) - optional_missing_entities
        if required_missing_entities or missing_fields or incompatible_fields:
            messages = []
            if required_missing_entities:
                messages.append(
                    "capas: " + ", ".join(sorted(required_missing_entities))
                )
            if missing_fields:
                messages.append(
                    "campos: "
                    + "; ".join(
                        "{0}({1})".format(name, ", ".join(fields))
                        for name, fields in sorted(missing_fields.items())
                    )
                )
            if incompatible_fields:
                messages.append(
                    "tipos: "
                    + "; ".join(
                        "{0}({1})".format(name, ", ".join(fields))
                        for name, fields in sorted(incompatible_fields.items())
                    )
                )
            return PreflightResult(
                rule_id=rule_key,
                status="dependency_missing",
                message="Dependencias portables faltantes: " + " | ".join(messages),
                missing_entities=tuple(sorted(required_missing_entities)),
                missing_fields=missing_fields,
                incompatible_fields=incompatible_fields,
            )
        if optional_missing_entities:
            return PreflightResult(
                rule_id=rule_key,
                status="not_applicable",
                message=(
                    "Regla opcional no aplicable a este paquete; no se recibió: "
                    + ", ".join(sorted(optional_missing_entities))
                    + "."
                ),
                missing_entities=tuple(sorted(optional_missing_entities)),
            )
        return PreflightResult(rule_id=rule_key, status="ok")


class RuleBackend(ABC):
    backend_id = "abstract"

    @abstractmethod
    def execute(self, rule, cancel_check: Callable[[], bool] | None = None) -> RuleExecution:
        raise NotImplementedError


def load_portable_manifest(root: str | Path | None = None) -> dict:
    base = Path(root) if root is not None else Path(__file__).resolve().parent
    path = base / PORTABLE_MANIFEST_NAME
    payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") != 1 or not isinstance(payload.get("rules"), dict):
        raise ValueError("portable_manifest.json no cumple el contrato versionado.")
    folded_rule_ids: dict[str, str] = {}
    for rule_id, declaration in payload["rules"].items():
        if not isinstance(rule_id, str) or not rule_id.strip():
            raise ValueError("portable_manifest.json contiene un ID de regla invalido.")
        folded = rule_id.casefold()
        previous = folded_rule_ids.get(folded)
        if previous is not None:
            raise ValueError(
                "portable_manifest.json repite un ID ignorando mayusculas: "
                "{0}, {1}.".format(previous, rule_id)
            )
        folded_rule_ids[folded] = rule_id
        if not isinstance(declaration, dict):
            raise ValueError("Declaracion portable invalida para {0}.".format(rule_id))
        if declaration.get("status") != "implemented":
            continue
        execution_mode = declaration.get("execution_mode")
        if execution_mode not in {
            "generated_plan_v1",
            "python_adapter_v1",
        }:
            raise ValueError(
                "La regla {0} usa un modo portable no autorizado.".format(rule_id)
            )
        output_columns = declaration.get("output_columns")
        if (
            not isinstance(output_columns, list)
            or not output_columns
            or any(
                not isinstance(column, str) or not column.strip()
                for column in output_columns
            )
            or len(set(output_columns)) != len(output_columns)
        ):
            raise ValueError(
                "output_columns debe declarar columnas unicas para {0}.".format(
                    rule_id
                )
            )
        postprocessor = declaration.get("operational_postprocessor")
        if declaration.get("family") == "reco" and postprocessor is None:
            raise ValueError(
                "La regla RECO {0} no declara su postprocesador operativo.".format(
                    rule_id
                )
            )
        if postprocessor is not None:
            required = {
                "id",
                "implementation",
                "implementation_path",
                "implementation_sha256",
                "canonical_sql_path",
                "canonical_sql_sha256",
                "canonical_sql_sha256_basis",
            }
            if (
                not isinstance(postprocessor, dict)
                or not required.issubset(postprocessor)
                or any(
                    not isinstance(postprocessor[key], str)
                    or not postprocessor[key].strip()
                    for key in required
                )
            ):
                raise ValueError(
                    "operational_postprocessor invalido para {0}.".format(rule_id)
                )
            if (
                declaration.get("family") == "reco"
                and postprocessor.get("id") != "reco_post_filter"
            ):
                raise ValueError(
                    "La regla RECO {0} no fija reco_post_filter.".format(rule_id)
                )
            digests = (
                postprocessor.get("implementation_sha256"),
                postprocessor.get("canonical_sql_sha256"),
            )
            if any(
                len(str(digest)) != 64
                or any(
                    character not in "0123456789ABCDEF"
                    for character in str(digest)
                )
                for digest in digests
            ):
                raise ValueError(
                    "Hashes del postprocesador invalidos para {0}.".format(rule_id)
                )
            if (
                postprocessor.get("canonical_sql_sha256_basis")
                != "utf8_lf_normalized"
                or postprocessor.get("canonical_sql_distributed") is not False
                or postprocessor.get("contract")
                != "normalized_distinct_pk_id_scope_then_filter_v1"
            ):
                raise ValueError(
                    "Contrato del postprocesador invalido para {0}.".format(rule_id)
                )
    return payload


class PortableRuleBackend(RuleBackend):
    backend_id = "portable"

    def __init__(
        self,
        data_source: DataSource,
        layer_mapping: LayerMapping,
        manifest_root: str | Path | None = None,
    ):
        self.data_source = data_source
        self.layer_mapping = layer_mapping
        self.manifest_root = (
            Path(manifest_root) if manifest_root is not None else Path(__file__).resolve().parent
        )
        self.manifest = load_portable_manifest(self.manifest_root)
        self.preflight = BackendPreflight(data_source, layer_mapping, self.manifest)

    @staticmethod
    def _runtime_module_for_path(relative_path: str) -> str | None:
        path = Path(relative_path)
        if path.suffix.casefold() != ".py" or path.name == "__init__.py":
            return None
        module_suffix = ".".join(path.with_suffix("").parts)
        return "{0}.{1}".format(__package__, module_suffix)

    def _reload_loaded_support_modules(
        self,
        support_files,
        *,
        exclude_path: Path | None = None,
    ) -> bool:
        """Load verified support and refresh it only when its digest changed."""

        reloaded_any = False
        ordered = sorted(
            support_files,
            key=lambda support: (
                0 if support.relative_path == "portable_primitives.py" else 1,
                support.relative_path,
            ),
        )
        for support in ordered:
            if exclude_path is not None and support.path == exclude_path:
                continue
            runtime_module = self._runtime_module_for_path(support.relative_path)
            if not runtime_module:
                continue
            module = sys.modules.get(runtime_module)
            if module is None:
                module = importlib.import_module(runtime_module)
                reloaded_any = True
            elif reloaded_any or getattr(
                module, VERIFIED_SOURCE_DIGEST_ATTRIBUTE, None
            ) != support.sha256:
                module = importlib.reload(module)
                reloaded_any = True
            setattr(
                module,
                VERIFIED_SOURCE_DIGEST_ATTRIBUTE,
                support.sha256,
            )
        return reloaded_any

    @staticmethod
    def _load_verified_entrypoint_module(
        runtime_module: str,
        digest: str,
        *,
        force_reload: bool,
    ):
        module = sys.modules.get(runtime_module)
        if module is None:
            module = importlib.import_module(runtime_module)
        elif force_reload or getattr(
            module, VERIFIED_SOURCE_DIGEST_ATTRIBUTE, None
        ) != digest:
            module = importlib.reload(module)
        setattr(module, VERIFIED_SOURCE_DIGEST_ATTRIBUTE, digest)
        return module

    def _verified_implementation(self, rule_id: str):
        declaration = self.manifest["rules"][rule_id]
        verified_bundle = verify_execution_bundle(self.manifest_root, declaration)
        support_reloaded = self._reload_loaded_support_modules(
            verified_bundle.support_files
        )

        execution_mode = str(declaration.get("execution_mode") or "")
        if execution_mode == "python_adapter_v1":
            declared_symbol = str(declaration.get("implementation", ""))
            module_name, separator, symbol_name = declared_symbol.rpartition(".")
            runtime_module = self._runtime_module_for_path(
                verified_bundle.implementation.relative_path
            )
            relative_module = ".".join(
                Path(verified_bundle.implementation.relative_path)
                .with_suffix("")
                .parts
            )
            canonical_module = "quality_core.{0}".format(relative_module)
            if (
                separator != "."
                or not runtime_module
                or module_name != canonical_module
                or not symbol_name
            ):
                raise ValueError(
                    "El adaptador portable declarado es invalido para {0}.".format(
                        rule_id
                    )
                )
            importlib.invalidate_caches()
            module = self._load_verified_entrypoint_module(
                runtime_module,
                verified_bundle.implementation.sha256,
                force_reload=support_reloaded,
            )
            executor = getattr(module, symbol_name, None)
            if not callable(executor):
                raise ValueError(
                    "El adaptador portable no es invocable para {0}.".format(
                        rule_id
                    )
                )
            return executor, verified_bundle.execution_bundle_sha256

        if execution_mode != "generated_plan_v1":
            raise ValueError(
                "Modo de ejecucion portable no soportado para {0}.".format(rule_id)
            )

        declared_symbol = str(declaration.get("implementation", ""))
        expected_symbol = (
            "quality_core.portable_plan_runtime.execute_generated_plan"
        )
        if declared_symbol != expected_symbol:
            raise ValueError(
                "El simbolo del plan generado es invalido para {0}.".format(
                    rule_id
                )
            )
        if verified_bundle.implementation.relative_path != "portable_plan_runtime.py":
            raise ValueError(
                "El runtime del plan generado es invalido para {0}.".format(
                    rule_id
                )
            )
        plan_relative = declaration.get("plan_path")
        plan_sha256 = str(declaration.get("plan_sha256", "")).upper()
        matching_plans = [
            support
            for support in verified_bundle.support_files
            if support.relative_path == plan_relative
        ]
        if (
            not isinstance(plan_relative, str)
            or len(plan_sha256) != 64
            or len(matching_plans) != 1
            or matching_plans[0].sha256 != plan_sha256
        ):
            raise ValueError(
                "El plan generado no coincide con el bundle para {0}.".format(
                    rule_id
                )
            )
        runtime_module = "{0}.portable_plan_runtime".format(__package__)
        importlib.invalidate_caches()
        module = self._load_verified_entrypoint_module(
            runtime_module,
            verified_bundle.implementation.sha256,
            force_reload=support_reloaded,
        )
        executor = getattr(module, "execute_generated_plan", None)
        loader = getattr(module, "load_plan", None)
        if not callable(executor) or not callable(loader):
            raise ValueError(
                "El runtime del plan generado no es invocable para {0}.".format(
                    rule_id
                )
            )
        plan = loader(matching_plans[0].path)

        def implementation(data_source, layer_mapping, cancel_check=None):
            return executor(plan, data_source, layer_mapping, cancel_check)

        return implementation, verified_bundle.execution_bundle_sha256

    def operational_postprocessor_id(self, rule) -> str:
        """Return the explicitly declared operational postprocessor, if any."""

        rule_id = resolve_portable_rule_id(
            self.manifest, getattr(rule, "id", rule)
        )
        declaration = self.manifest.get("rules", {}).get(rule_id, {})
        postprocessor = declaration.get("operational_postprocessor")
        if not isinstance(postprocessor, dict):
            return ""
        return str(postprocessor.get("id", "")).strip()

    def _verified_postprocessor(self, rule_ids: Iterable[str], postprocessor_id: str):
        canonical_ids = tuple(
            resolve_portable_rule_id(self.manifest, rule_id) for rule_id in rule_ids
        )
        if not canonical_ids:
            raise ValueError("No se declararon reglas para el postprocesador portable.")
        expected_id = str(postprocessor_id).strip()
        registered_symbol = POSTPROCESSORS.get(expected_id)
        if registered_symbol is None:
            raise ValueError(
                "Postprocesador portable no registrado: {0}.".format(expected_id)
            )

        common_declaration = None
        verified_path = None
        verified_sha256 = ""
        verified_support_files = None
        for rule_id in canonical_ids:
            declaration = self.manifest["rules"][rule_id]
            postprocessor = declaration.get("operational_postprocessor")
            if (
                not isinstance(postprocessor, dict)
                or postprocessor.get("id") != expected_id
                or postprocessor.get("implementation") != registered_symbol
            ):
                raise ValueError(
                    "El postprocesador portable de {0} no coincide con el registro.".format(
                        rule_id
                    )
                )
            comparable = json.dumps(
                postprocessor,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            )
            if common_declaration is None:
                common_declaration = comparable
            elif comparable != common_declaration:
                raise ValueError(
                    "Las reglas no fijan el mismo postprocesador portable."
                )

            verified_bundle = verify_execution_bundle(
                self.manifest_root, declaration
            )
            if verified_support_files is None:
                verified_support_files = verified_bundle.support_files
            declared_path = str(postprocessor["implementation_path"])
            declared_sha256 = str(postprocessor["implementation_sha256"]).upper()
            matching = [
                support
                for support in verified_bundle.support_files
                if support.relative_path == declared_path
            ]
            if (
                len(matching) != 1
                or matching[0].sha256 != declared_sha256
            ):
                raise ValueError(
                    "El postprocesador de {0} no esta fijado en su bundle.".format(
                        rule_id
                    )
                )
            if verified_path is None:
                verified_path = matching[0].path
                verified_sha256 = matching[0].sha256
            elif (
                matching[0].path != verified_path
                or matching[0].sha256 != verified_sha256
            ):
                raise ValueError(
                    "Las reglas resolvieron bytes distintos del postprocesador."
                )

        try:
            declared_module, declared_name = registered_symbol.rsplit(".", 1)
        except ValueError as exc:
            raise ValueError("Simbolo de postprocesador portable invalido.") from exc
        if not declared_module.startswith("quality_core.") or not declared_name:
            raise ValueError("Simbolo de postprocesador portable invalido.")
        module_suffix = declared_module[len("quality_core.") :]
        runtime_module = "{0}.{1}".format(__package__, module_suffix)
        importlib.invalidate_caches()
        support_reloaded = self._reload_loaded_support_modules(
            verified_support_files or (),
            exclude_path=verified_path,
        )
        module = self._load_verified_entrypoint_module(
            runtime_module,
            verified_sha256,
            force_reload=support_reloaded,
        )
        implementation = getattr(module, declared_name, None)
        if not callable(implementation):
            raise ValueError("Postprocesador portable no invocable.")
        code = getattr(implementation, "__code__", None)
        if (
            str(getattr(implementation, "__module__", "")) != runtime_module
            or str(getattr(implementation, "__name__", "")) != declared_name
            or code is None
            or verified_path is None
            or Path(code.co_filename).resolve() != verified_path
        ):
            raise ValueError(
                "Los bytes cargados del postprocesador no coinciden con el manifiesto."
            )
        return implementation, verified_sha256

    def validate_postprocessor(
        self,
        rule_ids: Iterable[str],
        postprocessor_id: str,
    ) -> str:
        """Verify a shared postprocessor without reading source rows."""

        _implementation, digest = self._verified_postprocessor(
            rule_ids, postprocessor_id
        )
        return digest

    def iter_postprocessor_scope(
        self,
        rule_ids: Iterable[str],
        postprocessor_id: str,
        cancel_check: Callable[[], bool] | None = None,
    ) -> Iterable[dict[str, Any]]:
        """Return a verified, streaming operational scope for a rule group."""

        implementation, _digest = self._verified_postprocessor(
            rule_ids, postprocessor_id
        )
        return implementation(self.data_source, self.layer_mapping, cancel_check)

    def execute_raw(
        self,
        rule,
        cancel_check: Callable[[], bool] | None = None,
    ) -> RuleExecution:
        """Execute only the independently reimplemented canonical rule stage."""

        rule_id = resolve_portable_rule_id(
            self.manifest, getattr(rule, "id", rule)
        )
        preflight = self.preflight.check_rule(rule_id)
        if not preflight.ok:
            return RuleExecution(rule_id, preflight.status, (), preflight.message)
        try:
            implementation, digest = self._verified_implementation(rule_id)
        except Exception as exc:
            return RuleExecution(
                rule_id,
                "backend_integrity_error",
                (),
                str(exc),
            )
        return RuleExecution(
            rule_id,
            "ok",
            implementation(self.data_source, self.layer_mapping, cancel_check),
            "",
            digest,
        )

    def _iter_operational_reco_rows(
        self,
        rule_id: str,
        raw_rows: Iterable[dict[str, Any]],
        postprocessor_id: str,
        cancel_check: Callable[[], bool] | None,
    ) -> Iterator[dict[str, Any]]:
        store = PortableResultStore.create()
        try:
            store.replace_reco_allowed(
                self.iter_postprocessor_scope(
                    (rule_id,),
                    postprocessor_id,
                    cancel_check=cancel_check,
                ),
                cancel_check=cancel_check,
            )
            yield from store.iter_reco_filtered_rows(
                raw_rows,
                cancel_check=cancel_check,
            )
        finally:
            store.remove()

    def execute(
        self,
        rule,
        cancel_check: Callable[[], bool] | None = None,
    ) -> RuleExecution:
        """Execute the complete operational rule contract.

        Every implemented RECO rule is filtered by its mandatory shared
        postprocessor.  Canonical/equivalence tooling must opt into
        :meth:`execute_raw`; normal consumers cannot accidentally receive the
        pre-filter 9/7-style result set.
        """

        raw = self.execute_raw(rule, cancel_check=cancel_check)
        if raw.status != "ok":
            return raw
        postprocessor_id = self.operational_postprocessor_id(raw.rule_id)
        if not postprocessor_id:
            return raw
        if postprocessor_id != "reco_post_filter":
            return RuleExecution(
                raw.rule_id,
                "backend_integrity_error",
                (),
                "Postprocesador operativo no soportado: {0}.".format(
                    postprocessor_id
                ),
                raw.implementation_sha256,
            )
        try:
            self.validate_postprocessor((raw.rule_id,), postprocessor_id)
        except Exception as exc:
            return RuleExecution(
                raw.rule_id,
                "backend_integrity_error",
                (),
                str(exc),
                raw.implementation_sha256,
            )
        return RuleExecution(
            raw.rule_id,
            "ok",
            self._iter_operational_reco_rows(
                raw.rule_id,
                raw.rows,
                postprocessor_id,
                cancel_check,
            ),
            "",
            raw.implementation_sha256,
        )

    def close(self) -> None:
        self.data_source.close()


def required_entities_for_rules(rule_ids: Iterable[str], manifest_root=None) -> tuple[str, ...]:
    manifest = load_portable_manifest(manifest_root)
    entities: set[str] = set()
    for rule_id in rule_ids:
        canonical_id = resolve_portable_rule_id(manifest, rule_id)
        declaration = manifest.get("rules", {}).get(canonical_id, {})
        if declaration.get("status") == "implemented":
            entities.update(str(name) for name in declaration.get("dependencies", {}))
    return tuple(sorted(entities))
