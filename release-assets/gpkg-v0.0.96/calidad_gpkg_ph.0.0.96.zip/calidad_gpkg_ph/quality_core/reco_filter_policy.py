"""Shared user-configurable scope for the operational RECO post-filter."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Iterable


RECO_FILTER_DEFINITIONS = (
    (
        "exclude_cancelled",
        "Excluir predios cancelados",
        "cancelados",
    ),
    (
        "require_assignment_2",
        "Solo asignación de reconocimiento = 2",
        "asignación 2",
    ),
    (
        "exclude_conditions",
        "Excluir condiciones 2, 5, 8 y 9",
        "condiciones 2/5/8/9",
    ),
    (
        "exclude_informal_visit",
        "Excluir marcados para visita informal",
        "visita informal",
    ),
)

DEFAULT_RECO_FILTER_POLICY = {
    key: True for key, _label, _short_label in RECO_FILTER_DEFINITIONS
}


def _coerce_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    normalized = str(value).strip().casefold()
    if normalized in {"1", "true", "yes", "si", "sí", "on"}:
        return True
    if normalized in {"0", "false", "no", "off", ""}:
        return False
    return default


def normalize_reco_filter_policy(
    policy: Mapping[str, Any] | None = None,
) -> dict[str, bool]:
    """Return the closed four-flag policy, defaulting every filter to enabled."""

    source = policy if isinstance(policy, Mapping) else {}
    return {
        key: _coerce_bool(source.get(key), default)
        for key, default in DEFAULT_RECO_FILTER_POLICY.items()
    }


def reco_filter_policy_active(policy: Mapping[str, Any] | None = None) -> bool:
    return any(normalize_reco_filter_policy(policy).values())


def reco_filter_policy_summary(policy: Mapping[str, Any] | None = None) -> str:
    normalized = normalize_reco_filter_policy(policy)
    active = [
        short_label
        for key, _label, short_label in RECO_FILTER_DEFINITIONS
        if normalized[key]
    ]
    inactive = [
        short_label
        for key, _label, short_label in RECO_FILTER_DEFINITIONS
        if not normalized[key]
    ]
    if not active:
        return "Filtros RECO desactivados: se conservarán los hallazgos crudos."
    message = "Filtros RECO activos {0}/4: {1}.".format(
        len(active),
        ", ".join(active),
    )
    if inactive:
        message += " Desactivados: {0}.".format(", ".join(inactive))
    return message


class RecoFilterPolicyDataSource:
    """Read-only view that neutralizes only the disabled RECO predicates."""

    def __init__(self, source, policy: Mapping[str, Any] | None = None):
        self.source = source
        self.policy = normalize_reco_filter_policy(policy)
        self.backend_id = source.backend_id

    def entities(self):
        return self.source.entities()

    def describe(self, physical_name):
        return self.source.describe(physical_name)

    def iter_rows(self, physical_name, fields):
        for source_row in self.source.iter_rows(physical_name, fields):
            row = dict(source_row)
            if not self.policy["exclude_cancelled"]:
                row["juridico_predio_cancelado"] = False
            if not self.policy["require_assignment_2"]:
                row["reconocimiento_estado_asignacion"] = "2"
            if not self.policy["exclude_conditions"]:
                row["condicion"] = ""
            if not self.policy["exclude_informal_visit"]:
                row["informal_predio_para_visita"] = False
            yield row

    def close(self) -> None:
        # The backend owns the wrapped source and remains responsible for it.
        return None


def iter_portable_reco_scope(
    backend,
    rule_ids: Iterable[str],
    postprocessor_id: str,
    policy: Mapping[str, Any] | None = None,
    cancel_check=None,
):
    """Execute the integrity-verified portable postprocessor under a UI policy."""

    normalized = normalize_reco_filter_policy(policy)
    if normalized == DEFAULT_RECO_FILTER_POLICY:
        return backend.iter_postprocessor_scope(
            rule_ids,
            postprocessor_id,
            cancel_check=cancel_check,
        )
    implementation, _digest = backend._verified_postprocessor(
        rule_ids,
        postprocessor_id,
    )
    source = RecoFilterPolicyDataSource(backend.data_source, normalized)
    return implementation(source, backend.layer_mapping, cancel_check)
