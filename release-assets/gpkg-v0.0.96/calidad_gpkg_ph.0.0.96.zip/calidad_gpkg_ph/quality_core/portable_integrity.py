"""Integrity contract for independently versioned portable rule bundles.

The manifest is untrusted input.  This module resolves every declared file
inside the portable package, verifies its SHA-256, and then verifies one
canonical digest binding the implementation to all of its support files.
No rule module is imported here.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Iterable, Mapping


EXECUTION_BUNDLE_FORMAT = "mapingtool-portable-execution-bundle-v1"


@dataclass(frozen=True)
class VerifiedPortableFile:
    """A package-local file whose declared digest matched its bytes."""

    relative_path: str
    path: Path
    sha256: str


@dataclass(frozen=True)
class VerifiedExecutionBundle:
    """Verified implementation and its complete transitive support set."""

    implementation: VerifiedPortableFile
    support_files: tuple[VerifiedPortableFile, ...]
    execution_bundle_sha256: str


def _manifest_sha256(value: object, field_name: str) -> str:
    if not isinstance(value, str) or len(value) != 64:
        raise ValueError("{0} debe ser un SHA-256 hexadecimal.".format(field_name))
    normalized = value.upper()
    if any(character not in "0123456789ABCDEF" for character in normalized):
        raise ValueError("{0} debe ser un SHA-256 hexadecimal.".format(field_name))
    return normalized


def resolve_package_file(package_root: str | Path, relative_path: object) -> Path:
    """Resolve a canonical POSIX relative path without allowing package escape."""

    if not isinstance(relative_path, str) or not relative_path:
        raise ValueError("La ruta portable debe ser un texto relativo no vacio.")
    if relative_path != relative_path.strip() or "\\" in relative_path:
        raise ValueError("La ruta portable no usa una forma relativa canonica.")

    portable_path = PurePosixPath(relative_path)
    windows_path = PureWindowsPath(relative_path)
    if (
        portable_path.is_absolute()
        or bool(windows_path.drive)
        or portable_path.as_posix() != relative_path
        or any(part in ("", ".", "..") for part in portable_path.parts)
    ):
        raise ValueError("La ruta portable no usa una forma relativa canonica.")

    root = Path(package_root).resolve()
    if not root.is_dir():
        raise ValueError(
            "La raiz del paquete portable no existe o no es un directorio."
        )
    try:
        resolved = root.joinpath(*portable_path.parts).resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise ValueError(
            "El archivo portable declarado no existe: {0}.".format(relative_path)
        ) from exc
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError("El archivo portable declarado sale del paquete.") from exc
    if not resolved.is_file():
        raise ValueError(
            "La ruta portable declarada no es un archivo: {0}.".format(relative_path)
        )
    return resolved


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def _canonical_support_files(
    support_files: Iterable[Mapping[str, object]],
) -> list[dict[str, str]]:
    canonical = []
    seen: set[str] = set()
    for index, entry in enumerate(support_files):
        if not isinstance(entry, Mapping) or set(entry) != {"path", "sha256"}:
            raise ValueError(
                "support_files[{0}] debe contener solo path y sha256.".format(index)
            )
        path = entry["path"]
        if not isinstance(path, str) or not path:
            raise ValueError("support_files[{0}].path es invalido.".format(index))
        if path in seen:
            raise ValueError(
                "support_files contiene una ruta duplicada: {0}.".format(path)
            )
        seen.add(path)
        canonical.append(
            {
                "path": path,
                "sha256": _manifest_sha256(
                    entry["sha256"], "support_files[{0}].sha256".format(index)
                ),
            }
        )
    return sorted(canonical, key=lambda item: item["path"])


def canonical_execution_bundle_bytes(
    implementation_path: str,
    implementation_sha256: str,
    support_files: Iterable[Mapping[str, object]],
) -> bytes:
    """Return the canonical UTF-8 JSON bound by ``execution_bundle_sha256``.

    Object keys are sorted, separators contain no whitespace, support files
    are sorted by path, hashes are uppercase, and no trailing newline is used.
    """

    payload = {
        "format": EXECUTION_BUNDLE_FORMAT,
        "implementation": {
            "path": implementation_path,
            "sha256": _manifest_sha256(
                implementation_sha256, "implementation_sha256"
            ),
        },
        "support_files": _canonical_support_files(support_files),
    }
    return json.dumps(
        payload,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def compute_execution_bundle_sha256(
    implementation_path: str,
    implementation_sha256: str,
    support_files: Iterable[Mapping[str, object]],
) -> str:
    """Compute the canonical digest for a portable execution bundle."""

    return hashlib.sha256(
        canonical_execution_bundle_bytes(
            implementation_path,
            implementation_sha256,
            support_files,
        )
    ).hexdigest().upper()


def verify_execution_bundle(
    package_root: str | Path,
    declaration: Mapping[str, object],
) -> VerifiedExecutionBundle:
    """Verify all declared bytes and their canonical aggregate, fail closed."""

    if not isinstance(declaration, Mapping):
        raise ValueError("La declaracion portable es invalida.")
    if "support_files" not in declaration:
        raise ValueError("La declaracion portable no contiene support_files.")
    raw_support_files = declaration["support_files"]
    if not isinstance(raw_support_files, list):
        raise ValueError("support_files debe ser una lista explicita.")

    implementation_relative = declaration.get("implementation_path")
    if not isinstance(implementation_relative, str) or not implementation_relative:
        raise ValueError("La declaracion portable no contiene implementation_path.")
    implementation_expected = _manifest_sha256(
        declaration.get("implementation_sha256"), "implementation_sha256"
    )
    implementation_path = resolve_package_file(package_root, implementation_relative)
    implementation_actual = _file_sha256(implementation_path)
    if implementation_actual != implementation_expected:
        raise ValueError("El hash de la implementacion portable no coincide.")

    canonical_support = _canonical_support_files(raw_support_files)
    verified_support = []
    resolved_support_paths: set[Path] = set()
    for entry in canonical_support:
        support_path = resolve_package_file(package_root, entry["path"])
        if support_path == implementation_path:
            raise ValueError(
                "La implementacion no puede repetirse como archivo de soporte."
            )
        if support_path in resolved_support_paths:
            raise ValueError(
                "support_files contiene rutas que resuelven al mismo archivo."
            )
        resolved_support_paths.add(support_path)
        support_actual = _file_sha256(support_path)
        if support_actual != entry["sha256"]:
            raise ValueError(
                "El hash del archivo portable de soporte no coincide: {0}.".format(
                    entry["path"]
                )
            )
        verified_support.append(
            VerifiedPortableFile(entry["path"], support_path, support_actual)
        )

    expected_bundle = _manifest_sha256(
        declaration.get("execution_bundle_sha256"), "execution_bundle_sha256"
    )
    actual_bundle = compute_execution_bundle_sha256(
        implementation_relative,
        implementation_actual,
        canonical_support,
    )
    if actual_bundle != expected_bundle:
        raise ValueError("El hash del bundle de ejecucion portable no coincide.")

    return VerifiedExecutionBundle(
        implementation=VerifiedPortableFile(
            implementation_relative,
            implementation_path,
            implementation_actual,
        ),
        support_files=tuple(verified_support),
        execution_bundle_sha256=actual_bundle,
    )
