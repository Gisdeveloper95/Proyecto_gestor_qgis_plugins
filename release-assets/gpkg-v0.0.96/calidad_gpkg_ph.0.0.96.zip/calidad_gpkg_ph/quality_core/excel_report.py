"""Minimal XLSX report writer for quality-rule validations.

The plugin runs inside QGIS installations where optional packages such as
openpyxl are not guaranteed to exist. This writer uses only the Python standard
library and produces a practical workbook with summary, detail, and log sheets.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator, Mapping
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import re
import tempfile
from xml.sax.saxutils import escape
import zipfile

try:
    from .sql_runtime import EXPORT_COLUMNS, display_value
except ImportError:  # Calidad GPKG intentionally excludes the PostGIS runtime.
    from .portable_store import PORTABLE_EXPORT_COLUMNS as EXPORT_COLUMNS
    from .portable_store import display_value


XLSX_MAX_DATA_ROWS_PER_SHEET = 1_048_575
_NO_ROW = object()


@dataclass(frozen=True)
class WorksheetWriteCount:
    """Rows physically written to one worksheet member."""

    name: str
    kind: str
    rule_id: str | None
    split_index: int
    data_rows: int


@dataclass(frozen=True)
class ExcelWriteManifest:
    """Auditable counts accumulated only after worksheet writes succeed."""

    detail_total: int
    detail_by_rule: dict[str, int]
    rule_sheet_counts: dict[str, int]
    summary_rows: int
    log_rows: int
    worksheets: tuple[WorksheetWriteCount, ...]


@dataclass(frozen=True)
class ExcelPackageManifest:
    """Counts and members written to the distributable Excel ZIP."""

    general_report: ExcelWriteManifest
    rule_rows: dict[str, int]
    rule_files: dict[str, str]
    archive_members: tuple[str, ...]


def write_quality_report_streaming(
    path: str | Path,
    *,
    plugin_name: str,
    database_label: str,
    summary_rows: list[dict],
    detail_row_factory: Callable[[str | None], Iterable[dict]],
    rule_ids: Iterable[str],
    log_lines: Iterable[str],
    export_columns: Iterable[str] | None = None,
    max_data_rows_per_sheet: int = XLSX_MAX_DATA_ROWS_PER_SHEET,
) -> ExcelWriteManifest:
    """Write an XLSX without materializing the complete findings collection.

    ``detail_row_factory`` must return a fresh iterable on each call.  The
    ``None`` argument represents the complete detail sheet and a rule ID
    represents that rule's sheet.  This contract lets the disk-backed result
    store stream every worksheet through a bounded SQLite cursor.
    """

    max_rows = int(max_data_rows_per_sheet)
    if max_rows < 1 or max_rows > XLSX_MAX_DATA_ROWS_PER_SHEET:
        raise ValueError(
            "max_data_rows_per_sheet debe estar entre 1 y {0}.".format(
                XLSX_MAX_DATA_ROWS_PER_SHEET
            )
        )

    summary_snapshot = list(summary_rows)
    log_snapshot = list(log_lines)
    report_columns = _normalized_export_columns(export_columns)
    ordered_rule_ids = []
    for value in rule_ids:
        rule_id = display_value(value) or "SIN_REGLA"
        if rule_id not in ordered_rule_ids:
            ordered_rule_ids.append(rule_id)

    summary_headers = [
        "Regla",
        "Estado",
        "Filas SQL",
        "Descartadas filtro RECO",
        "Predios finales",
        "Excepciones",
        "Sin excepcion",
        "Mensaje",
    ]

    def summary_factory() -> Iterator[list]:
        for row in summary_snapshot:
            yield [
                row.get("rule_id", ""),
                row.get("status", ""),
                row.get("total", 0),
                row.get("filtered_out", 0),
                row.get("predios", 0),
                row.get("exceptions", 0),
                row.get("missing", 0),
                row.get("message", ""),
            ]

    xlsx_path = Path(path)
    if xlsx_path.suffix.lower() != ".xlsx":
        xlsx_path = xlsx_path.with_suffix(".xlsx")

    detail_total = 0
    detail_by_rule: dict[str, int] = {}
    rule_sheet_counts = {rule_id: 0 for rule_id in ordered_rule_ids}
    summary_written = 0
    log_written = 0
    worksheet_counts: list[WorksheetWriteCount] = []
    used_sheet_names: set[str] = set()
    next_sheet_index = 1

    def on_summary_written(_row) -> None:
        nonlocal summary_written
        summary_written += 1

    def on_detail_written(row: dict) -> None:
        nonlocal detail_total
        observed_rule = display_value(row.get("id_regla")) or "SIN_REGLA"
        detail_total += 1
        detail_by_rule[observed_rule] = detail_by_rule.get(observed_rule, 0) + 1

    def on_log_written(_row) -> None:
        nonlocal log_written
        log_written += 1

    timestamp = datetime.now().isoformat(timespec="seconds")

    with zipfile.ZipFile(xlsx_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        written, next_sheet_index = _write_split_worksheets(
            zf,
            start_sheet_index=next_sheet_index,
            base_name="Resumen",
            kind="summary",
            rule_id=None,
            headers=summary_headers,
            rows=summary_factory(),
            row_values=lambda row: row,
            on_row_written=on_summary_written,
            used_sheet_names=used_sheet_names,
            max_data_rows=max_rows,
        )
        worksheet_counts.extend(written)

        written, next_sheet_index = _write_split_worksheets(
            zf,
            start_sheet_index=next_sheet_index,
            base_name="Detalle",
            kind="detail_all",
            rule_id=None,
            headers=report_columns,
            rows=detail_row_factory(None),
            row_values=lambda row: [
                display_value(row.get(column)) for column in report_columns
            ],
            on_row_written=on_detail_written,
            used_sheet_names=used_sheet_names,
            max_data_rows=max_rows,
        )
        worksheet_counts.extend(written)

        for rule_id in ordered_rule_ids:
            def on_rule_written(row: dict, expected_rule: str = rule_id) -> None:
                observed_rule = display_value(row.get("id_regla")) or "SIN_REGLA"
                if observed_rule != expected_rule:
                    raise RuntimeError(
                        "La hoja de {0} recibio una fila de {1}.".format(
                            expected_rule, observed_rule
                        )
                    )
                rule_sheet_counts[expected_rule] += 1

            written, next_sheet_index = _write_split_worksheets(
                zf,
                start_sheet_index=next_sheet_index,
                base_name=_safe_sheet_name(rule_id),
                kind="detail_rule",
                rule_id=rule_id,
                headers=report_columns,
                rows=detail_row_factory(rule_id),
                row_values=lambda row: [
                    display_value(row.get(column)) for column in report_columns
                ],
                on_row_written=on_rule_written,
                used_sheet_names=used_sheet_names,
                max_data_rows=max_rows,
            )
            worksheet_counts.extend(written)

        written, next_sheet_index = _write_split_worksheets(
            zf,
            start_sheet_index=next_sheet_index,
            base_name="Consola",
            kind="log",
            rule_id=None,
            headers=["Fecha", "Plugin", "Base", "Log"],
            rows=log_snapshot,
            row_values=lambda line: [timestamp, plugin_name, database_label, line],
            on_row_written=on_log_written,
            used_sheet_names=used_sheet_names,
            max_data_rows=max_rows,
        )
        worksheet_counts.extend(written)

        sheet_metadata = [
            (worksheet.name, [], []) for worksheet in worksheet_counts
        ]
        _write_content_types(zf, len(worksheet_counts))
        _write_root_rels(zf)
        _write_workbook(zf, sheet_metadata)
        _write_workbook_rels(zf, len(worksheet_counts))
        _write_styles(zf)
        _write_doc_props(zf, plugin_name)

    return ExcelWriteManifest(
        detail_total=detail_total,
        detail_by_rule=dict(detail_by_rule),
        rule_sheet_counts=dict(rule_sheet_counts),
        summary_rows=summary_written,
        log_rows=log_written,
        worksheets=tuple(worksheet_counts),
    )


def write_quality_report_package_streaming(
    path: str | Path,
    *,
    plugin_name: str,
    database_label: str,
    summary_rows: list[dict],
    detail_row_factory: Callable[[str | None], Iterable[dict]],
    rule_ids: Iterable[str],
    log_lines: Iterable[str],
    export_columns: Iterable[str] | None = None,
    max_data_rows_per_sheet: int = XLSX_MAX_DATA_ROWS_PER_SHEET,
) -> ExcelPackageManifest:
    """Write one ZIP with a general workbook and one workbook per rule.

    The general workbook retains the current Resumen, Detalle, per-rule and
    Consola sheets.  ``Reglas/<ID>.xlsx`` provides a focused workbook whose
    first worksheet is named after the rule.  Every source is streamed from a
    fresh result-store cursor, so the export remains bounded by one row.
    """

    report_columns = _normalized_export_columns(export_columns)
    ordered_rule_ids = _normalized_rule_ids(rule_ids)
    summary_snapshot = list(summary_rows)
    log_snapshot = list(log_lines)
    package_path = Path(path)
    if package_path.suffix.lower() != ".zip":
        package_path = package_path.with_suffix(".zip")

    rule_rows: dict[str, int] = {}
    rule_files: dict[str, str] = {}
    archive_members: list[str] = []
    used_archive_names: set[str] = set()

    with tempfile.TemporaryDirectory(
        prefix="mapingtool-excel-package-"
    ) as temporary_directory:
        temporary_root = Path(temporary_directory)
        general_path = temporary_root / "Reporte_general.xlsx"
        general_manifest = write_quality_report_streaming(
            general_path,
            plugin_name=plugin_name,
            database_label=database_label,
            summary_rows=summary_snapshot,
            detail_row_factory=detail_row_factory,
            rule_ids=ordered_rule_ids,
            log_lines=log_snapshot,
            export_columns=report_columns,
            max_data_rows_per_sheet=max_data_rows_per_sheet,
        )
        _validate_xlsx_container(general_path)

        individual_workbooks: list[tuple[Path, str]] = []
        for rule_id in ordered_rule_ids:
            archive_name = _unique_rule_archive_name(rule_id, used_archive_names)
            workbook_path = temporary_root / Path(archive_name).name
            row_count = _write_rule_report_streaming(
                workbook_path,
                plugin_name=plugin_name,
                database_label=database_label,
                rule_id=rule_id,
                rows=detail_row_factory(rule_id),
                export_columns=report_columns,
                max_data_rows_per_sheet=max_data_rows_per_sheet,
            )
            _validate_xlsx_container(workbook_path)
            rule_rows[rule_id] = row_count
            rule_files[rule_id] = archive_name
            individual_workbooks.append((workbook_path, archive_name))

        readme = (
            "PAQUETE DE REPORTE DE CALIDAD\n"
            "==============================\n\n"
            "Reporte_general.xlsx: Resumen, Detalle/Matriz, hojas por regla y Consola.\n"
            "Reglas/<CODIGO>.xlsx: un libro independiente por cada regla ejecutada.\n"
            "Los identificadores se conservan como texto para evitar perdida de ceros.\n"
        )
        with zipfile.ZipFile(
            package_path, "w", compression=zipfile.ZIP_DEFLATED
        ) as package:
            package.write(
                general_path,
                "Reporte_general.xlsx",
                compress_type=zipfile.ZIP_STORED,
            )
            archive_members.append("Reporte_general.xlsx")
            for workbook_path, archive_name in individual_workbooks:
                package.write(
                    workbook_path,
                    archive_name,
                    compress_type=zipfile.ZIP_STORED,
                )
                archive_members.append(archive_name)
            package.writestr("LEEME.txt", readme.encode("utf-8"))
            archive_members.append("LEEME.txt")
        with zipfile.ZipFile(package_path) as package:
            corrupt_member = package.testzip()
            if corrupt_member is not None:
                raise RuntimeError(
                    "El paquete Excel contiene una entrada corrupta: {0}.".format(
                        corrupt_member
                    )
                )

    return ExcelPackageManifest(
        general_report=general_manifest,
        rule_rows=rule_rows,
        rule_files=rule_files,
        archive_members=tuple(archive_members),
    )


def validate_excel_package_manifest(
    manifest: ExcelPackageManifest,
    *,
    expected_total: int,
    expected_rule_counts: Mapping[str, int],
) -> None:
    """Reject missing, duplicated or truncated workbooks in an Excel package."""

    normalized_expected = {
        str(rule_id): int(count) for rule_id, count in expected_rule_counts.items()
    }
    validate_excel_manifest(
        manifest.general_report,
        expected_total=expected_total,
        expected_rule_counts=normalized_expected,
    )
    errors = []
    if manifest.rule_rows != normalized_expected:
        errors.append(
            "libros por regla escritos={0}, esperado={1}".format(
                manifest.rule_rows, normalized_expected
            )
        )
    if set(manifest.rule_files) != set(normalized_expected):
        errors.append(
            "reglas con archivo={0}, esperado={1}".format(
                sorted(manifest.rule_files), sorted(normalized_expected)
            )
        )
    members = list(manifest.archive_members)
    if len(members) != len(set(members)):
        errors.append("el ZIP contiene nombres de miembros duplicados")
    expected_members = {
        "Reporte_general.xlsx",
        "LEEME.txt",
        *manifest.rule_files.values(),
    }
    if set(members) != expected_members:
        errors.append(
            "miembros ZIP={0}, esperado={1}".format(
                sorted(members), sorted(expected_members)
            )
        )
    if errors:
        raise RuntimeError(
            "Manifiesto del paquete Excel incompleto: " + " | ".join(errors)
        )


def validate_excel_manifest(
    manifest: ExcelWriteManifest,
    *,
    expected_total: int,
    expected_rule_counts: Mapping[str, int],
) -> None:
    """Reject a cleanly truncated or structurally inconsistent XLSX stream."""

    normalized_expected = {
        str(rule_id): int(count) for rule_id, count in expected_rule_counts.items()
    }
    expected_total_value = int(expected_total)
    errors = []
    if expected_total_value != sum(normalized_expected.values()):
        errors.append(
            "ResultStore total={0}, suma por regla={1}".format(
                expected_total_value, sum(normalized_expected.values())
            )
        )
    if manifest.detail_total != expected_total_value:
        errors.append(
            "detalle total escrito={0}, esperado={1}".format(
                manifest.detail_total, expected_total_value
            )
        )
    normalized_detail_by_rule = {
        rule_id: int(manifest.detail_by_rule.get(rule_id, 0))
        for rule_id in normalized_expected
    }
    unexpected_detail_rules = sorted(
        set(manifest.detail_by_rule) - set(normalized_expected)
    )
    if (
        normalized_detail_by_rule != normalized_expected
        or unexpected_detail_rules
    ):
        errors.append(
            "detalle por regla escrito={0}, esperado={1}".format(
                manifest.detail_by_rule, normalized_expected
            )
        )
    if manifest.rule_sheet_counts != normalized_expected:
        errors.append(
            "hojas por regla escritas={0}, esperado={1}".format(
                manifest.rule_sheet_counts, normalized_expected
            )
        )

    detail_sheet_total = sum(
        sheet.data_rows
        for sheet in manifest.worksheets
        if sheet.kind == "detail_all"
    )
    if detail_sheet_total != manifest.detail_total:
        errors.append(
            "splits Detalle={0}, manifiesto detalle={1}".format(
                detail_sheet_total, manifest.detail_total
            )
        )

    rule_sheet_totals: dict[str, int] = {}
    for sheet in manifest.worksheets:
        if sheet.kind != "detail_rule":
            continue
        rule_id = sheet.rule_id or "SIN_REGLA"
        rule_sheet_totals[rule_id] = rule_sheet_totals.get(rule_id, 0) + sheet.data_rows
    normalized_rule_sheet_totals = {
        rule_id: int(rule_sheet_totals.get(rule_id, 0))
        for rule_id in normalized_expected
    }
    unexpected_rule_sheets = sorted(
        set(rule_sheet_totals) - set(normalized_expected)
    )
    if (
        normalized_rule_sheet_totals != normalized_expected
        or unexpected_rule_sheets
    ):
        errors.append(
            "splits por regla={0}, esperado={1}".format(
                rule_sheet_totals, normalized_expected
            )
        )

    summary_sheet_total = sum(
        sheet.data_rows
        for sheet in manifest.worksheets
        if sheet.kind == "summary"
    )
    if summary_sheet_total != manifest.summary_rows:
        errors.append(
            "splits Resumen={0}, manifiesto resumen={1}".format(
                summary_sheet_total, manifest.summary_rows
            )
        )
    log_sheet_total = sum(
        sheet.data_rows for sheet in manifest.worksheets if sheet.kind == "log"
    )
    if log_sheet_total != manifest.log_rows:
        errors.append(
            "splits Consola={0}, manifiesto log={1}".format(
                log_sheet_total, manifest.log_rows
            )
        )

    names = [sheet.name for sheet in manifest.worksheets]
    if len(names) != len(set(names)):
        errors.append("hay nombres de hojas fisicas duplicados")
    for key in {(sheet.kind, sheet.rule_id) for sheet in manifest.worksheets}:
        indices = sorted(
            sheet.split_index
            for sheet in manifest.worksheets
            if (sheet.kind, sheet.rule_id) == key
        )
        if indices != list(range(1, len(indices) + 1)):
            errors.append("splits no consecutivos para {0}".format(key))

    if errors:
        raise RuntimeError("Manifiesto XLSX incompleto: " + " | ".join(errors))


def _normalized_export_columns(
    export_columns: Iterable[str] | None,
) -> tuple[str, ...]:
    values = EXPORT_COLUMNS if export_columns is None else export_columns
    columns = tuple(str(value).strip() for value in values)
    if not columns or any(not value for value in columns):
        raise ValueError("export_columns debe contener nombres no vacios.")
    if len(columns) != len(set(columns)):
        raise ValueError("export_columns contiene nombres duplicados.")
    return columns


def _normalized_rule_ids(rule_ids: Iterable[str]) -> tuple[str, ...]:
    ordered = []
    for value in rule_ids:
        rule_id = display_value(value) or "SIN_REGLA"
        if rule_id not in ordered:
            ordered.append(rule_id)
    return tuple(ordered)


def _validate_xlsx_container(path: Path) -> None:
    if not zipfile.is_zipfile(path):
        raise RuntimeError("{0} no es un contenedor OOXML valido.".format(path.name))
    with zipfile.ZipFile(path) as workbook:
        corrupt_member = workbook.testzip()
        if corrupt_member is not None:
            raise RuntimeError(
                "{0} contiene una entrada corrupta: {1}.".format(
                    path.name, corrupt_member
                )
            )


def _unique_rule_archive_name(rule_id: str, used: set[str]) -> str:
    base = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", display_value(rule_id)).strip(
        " ."
    )
    if not base:
        base = "SIN_REGLA"
    if base.upper() in {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        "COM1",
        "COM2",
        "COM3",
        "COM4",
        "COM5",
        "COM6",
        "COM7",
        "COM8",
        "COM9",
        "LPT1",
        "LPT2",
        "LPT3",
        "LPT4",
        "LPT5",
        "LPT6",
        "LPT7",
        "LPT8",
        "LPT9",
    }:
        base = "_" + base
    base = base[:120]
    index = 1
    while True:
        suffix = "" if index == 1 else "_{0}".format(index)
        candidate = "Reglas/{0}{1}.xlsx".format(
            base[: 120 - len(suffix)], suffix
        )
        folded = candidate.casefold()
        if folded not in used:
            used.add(folded)
            return candidate
        index += 1


def _write_rule_report_streaming(
    path: Path,
    *,
    plugin_name: str,
    database_label: str,
    rule_id: str,
    rows: Iterable[dict],
    export_columns: tuple[str, ...],
    max_data_rows_per_sheet: int,
) -> int:
    written_rows = 0
    worksheet_counts: list[WorksheetWriteCount] = []
    used_sheet_names: set[str] = set()

    def on_row_written(row: dict) -> None:
        nonlocal written_rows
        observed_rule = display_value(row.get("id_regla")) or "SIN_REGLA"
        if observed_rule != rule_id:
            raise RuntimeError(
                "El libro de {0} recibio una fila de {1}.".format(
                    rule_id, observed_rule
                )
            )
        written_rows += 1

    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as workbook:
        written, _next_index = _write_split_worksheets(
            workbook,
            start_sheet_index=1,
            base_name=_safe_sheet_name(rule_id),
            kind="detail_rule",
            rule_id=rule_id,
            headers=export_columns,
            rows=rows,
            row_values=lambda row: [
                display_value(row.get(column)) for column in export_columns
            ],
            on_row_written=on_row_written,
            used_sheet_names=used_sheet_names,
            max_data_rows=max_data_rows_per_sheet,
        )
        worksheet_counts.extend(written)
        sheet_metadata = [
            (worksheet.name, [], []) for worksheet in worksheet_counts
        ]
        _write_content_types(workbook, len(worksheet_counts))
        _write_root_rels(workbook)
        _write_workbook(workbook, sheet_metadata)
        _write_workbook_rels(workbook, len(worksheet_counts))
        _write_styles(workbook)
        _write_doc_props(
            workbook,
            "{0} - {1} - {2}".format(
                plugin_name, rule_id, database_label
            ),
        )
    return written_rows


def _write_content_types(zf: zipfile.ZipFile, sheet_count: int) -> None:
    overrides = [
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
        '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>',
        '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>',
    ]
    for index in range(1, sheet_count + 1):
        overrides.append(
            f'<Override PartName="/xl/worksheets/sheet{index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        )
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        + "".join(overrides)
        + "</Types>"
    )
    zf.writestr("[Content_Types].xml", xml)


def _write_root_rels(zf: zipfile.ZipFile) -> None:
    zf.writestr(
        "_rels/.rels",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
        '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
        "</Relationships>",
    )


def _write_workbook(zf: zipfile.ZipFile, sheets: list[tuple[str, list[str], list[list]]]) -> None:
    nodes = []
    for index, (name, _headers, _rows) in enumerate(sheets, start=1):
        nodes.append(f'<sheet name="{_xml(name)}" sheetId="{index}" r:id="rId{index}"/>')
    zf.writestr(
        "xl/workbook.xml",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        "<sheets>"
        + "".join(nodes)
        + "</sheets></workbook>",
    )


def _write_workbook_rels(zf: zipfile.ZipFile, sheet_count: int) -> None:
    rels = []
    for index in range(1, sheet_count + 1):
        rels.append(
            f'<Relationship Id="rId{index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{index}.xml"/>'
        )
    rels.append(
        f'<Relationship Id="rId{sheet_count + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
    )
    zf.writestr(
        "xl/_rels/workbook.xml.rels",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        + "".join(rels)
        + "</Relationships>",
    )


def _write_styles(zf: zipfile.ZipFile) -> None:
    zf.writestr(
        "xl/styles.xml",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        '<fonts count="3"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="10"/><name val="Calibri"/></font></fonts>'
        '<fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F4E79"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFEAF3F8"/></patternFill></fill></fills>'
        '<borders count="2"><border/><border><left style="thin"><color rgb="FFD9E2EA"/></left><right style="thin"><color rgb="FFD9E2EA"/></right><top style="thin"><color rgb="FFD9E2EA"/></top><bottom style="thin"><color rgb="FFD9E2EA"/></bottom></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="4">'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>'
        '<xf numFmtId="0" fontId="2" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>'
        '<xf numFmtId="0" fontId="1" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment vertical="center"/></xf>'
        '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf>'
        "</cellXfs>"
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        "</styleSheet>",
    )


def _write_doc_props(zf: zipfile.ZipFile, plugin_name: str) -> None:
    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    zf.writestr(
        "docProps/core.xml",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
        'xmlns:dc="http://purl.org/dc/elements/1.1/" '
        'xmlns:dcterms="http://purl.org/dc/terms/" '
        'xmlns:dcmitype="http://purl.org/dc/dcmitype/" '
        'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
        f"<dc:title>{_xml(plugin_name)} - Reporte de calidad</dc:title>"
        "<dc:creator>Validador Calidad SQL</dc:creator>"
        f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created>'
        f'<dcterms:modified xsi:type="dcterms:W3CDTF">{now}</dcterms:modified>'
        "</cp:coreProperties>",
    )
    zf.writestr(
        "docProps/app.xml",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
        'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
        "<Application>Validador Calidad SQL</Application></Properties>",
    )


def _write_split_worksheets(
    zf: zipfile.ZipFile,
    *,
    start_sheet_index: int,
    base_name: str,
    kind: str,
    rule_id: str | None,
    headers: list[str],
    rows: Iterable,
    row_values: Callable[[object], list],
    on_row_written: Callable[[object], None],
    used_sheet_names: set[str],
    max_data_rows: int,
) -> tuple[list[WorksheetWriteCount], int]:
    """Consume one source once and split it with at most one row buffered."""

    iterator = iter(rows)
    worksheet_counts = []
    sheet_index = int(start_sheet_index)
    split_index = 1
    wrote_sheet = False
    try:
        while True:
            try:
                first_row = next(iterator)
            except StopIteration:
                if not wrote_sheet:
                    name = _physical_sheet_name(
                        base_name, split_index, used_sheet_names
                    )
                    _write_worksheet_chunk(
                        zf,
                        "xl/worksheets/sheet{0}.xml".format(sheet_index),
                        headers,
                        first_row=_NO_ROW,
                        iterator=iterator,
                        row_values=row_values,
                        on_row_written=on_row_written,
                        max_data_rows=max_data_rows,
                    )
                    worksheet_counts.append(
                        WorksheetWriteCount(name, kind, rule_id, split_index, 0)
                    )
                    sheet_index += 1
                break

            name = _physical_sheet_name(base_name, split_index, used_sheet_names)
            written, exhausted = _write_worksheet_chunk(
                zf,
                "xl/worksheets/sheet{0}.xml".format(sheet_index),
                headers,
                first_row=first_row,
                iterator=iterator,
                row_values=row_values,
                on_row_written=on_row_written,
                max_data_rows=max_data_rows,
            )
            worksheet_counts.append(
                WorksheetWriteCount(name, kind, rule_id, split_index, written)
            )
            wrote_sheet = True
            sheet_index += 1
            if exhausted:
                break
            split_index += 1
    finally:
        close = getattr(iterator, "close", None)
        if callable(close):
            close()
    return worksheet_counts, sheet_index


def _physical_sheet_name(base_name: str, split_index: int, used: set[str]) -> str:
    suffix = "" if split_index == 1 else "_{0}".format(split_index)
    candidate_base = _safe_sheet_name(base_name)
    candidate = candidate_base[: 31 - len(suffix)] + suffix
    name = _unique_sheet_name(candidate, used)
    used.add(name)
    return name


def _write_worksheet_chunk(
    zf: zipfile.ZipFile,
    member_name: str,
    headers: list[str],
    *,
    first_row,
    iterator: Iterator,
    row_values: Callable[[object], list],
    on_row_written: Callable[[object], None],
    max_data_rows: int,
) -> tuple[int, bool]:
    """Write one physical worksheet and report successful data-row writes."""

    column_count = max(len(headers), 1)
    widths = "".join(
        '<col min="{0}" max="{0}" width="{1}" customWidth="1"/>'.format(
            index, _width_for(index, headers)
        )
        for index in range(1, column_count + 1)
    )
    prefix = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        + '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" '
        'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
        + '<sheetFormatPr defaultRowHeight="15"/>'
        + "<cols>{0}</cols>".format(widths)
        + "<sheetData>"
    )
    written = 0
    exhausted = first_row is _NO_ROW
    with zf.open(member_name, "w") as member:
        member.write(prefix.encode("utf-8"))
        member.write(
            _row_xml(1, headers, style=1, headers=headers).encode("utf-8")
        )
        pending = first_row
        while pending is not _NO_ROW and written < max_data_rows:
            member.write(
                _row_xml(
                    written + 2,
                    row_values(pending),
                    style=0,
                    headers=headers,
                ).encode("utf-8")
            )
            on_row_written(pending)
            written += 1
            if written >= max_data_rows:
                exhausted = False
                break
            try:
                pending = next(iterator)
            except StopIteration:
                pending = _NO_ROW
                exhausted = True
        last_row_index = written + 1
        last_cell = "{0}{1}".format(_column_name(column_count), last_row_index)
        member.write(
            (
                "</sheetData>"
                + '<autoFilter ref="A1:{0}"/>'.format(last_cell)
                + "</worksheet>"
            ).encode("utf-8")
        )
    return written, exhausted


def _row_xml(
    row_index: int,
    values: list,
    style: int,
    *,
    headers: list[str] | tuple[str, ...] | None = None,
) -> str:
    cells = []
    for col_index, value in enumerate(values, start=1):
        cell_ref = f"{_column_name(col_index)}{row_index}"
        header = (
            headers[col_index - 1]
            if headers is not None and col_index - 1 < len(headers)
            else ""
        )
        selected_style = style or (3 if _wrap_column(header) else 0)
        cell_style = f' s="{selected_style}"' if selected_style else ""
        text = display_value(value)
        preserve = (
            ' xml:space="preserve"'
            if text != text.strip() or "\n" in text or "\r" in text
            else ""
        )
        cells.append(
            f'<c r="{cell_ref}" t="inlineStr"{cell_style}><is><t{preserve}>{_xml(text)}</t></is></c>'
        )
    row_height = ' ht="30" customHeight="1"' if style == 1 else ""
    return f'<row r="{row_index}"{row_height}>{"".join(cells)}</row>'


def _column_name(index: int) -> str:
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


def _width_for(index: int, headers: list[str]) -> int:
    header = headers[index - 1] if index - 1 < len(headers) else ""
    normalized = header.casefold()
    exact_widths = {
        "id_regla": 15,
        "regla": 15,
        "estado": 18,
        "componente": 22,
        "proyecto": 24,
        "pk_id_predio": 22,
        "numero_predial_nacional": 34,
        "matricula_inmobiliaria": 24,
        "tabla_error_1": 26,
        "tabla_error_2": 26,
        "pk_tabla_error_1": 24,
        "pk_tabla_error_2": 24,
        "tiene_excepcion": 18,
        "fecha": 21,
        "plugin": 28,
        "base": 28,
    }
    if normalized in exact_widths:
        return exact_widths[normalized]
    if _wrap_column(header):
        return 52
    if (
        "numero" in normalized
        or "predial" in normalized
        or normalized.startswith("pk")
        or "identificador" in normalized
    ):
        return 28
    if (
        "area" in normalized
        or "total" in normalized
        or "filas" in normalized
        or "predios" in normalized
        or "excepciones" in normalized
    ):
        return 18
    return max(13, min(26, len(header) + 4))


def _wrap_column(header: str) -> bool:
    normalized = display_value(header).casefold()
    return any(
        token in normalized
        for token in ("descripcion", "mensaje", "observacion", "detalle", "log")
    )


def _xml(value: str) -> str:
    return escape(_clean_xml_text(str(value)), {'"': "&quot;"})


def _clean_xml_text(value: str) -> str:
    """Strip characters that are illegal in XML 1.0 and make Excel repair files."""

    cleaned = []
    for char in value:
        code = ord(char)
        if code in (0x09, 0x0A, 0x0D) or 0x20 <= code <= 0xD7FF or 0xE000 <= code <= 0xFFFD:
            cleaned.append(char)
        else:
            cleaned.append(" ")
    return "".join(cleaned)


def _safe_sheet_name(value: str) -> str:
    name = re.sub(r"[\[\]\:\*\?\/\\]", "_", display_value(value)).strip()
    return (name or "Hoja")[:31]


def _unique_sheet_name(name: str, used: set[str]) -> str:
    candidate = name[:31]
    index = 2
    while candidate in used:
        suffix = f"_{index}"
        candidate = name[: 31 - len(suffix)] + suffix
        index += 1
    return candidate
