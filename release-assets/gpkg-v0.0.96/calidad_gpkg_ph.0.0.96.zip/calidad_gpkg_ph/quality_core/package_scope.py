"""Validated, optional rule scope for a delivered GeoPackage."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Iterable


SCOPE_SCHEMA_VERSION = 1
DEFAULT_SCOPE_NAME = "mapingtool_scope.json"
RULE_ID_PATTERN = re.compile(r"^(Reco|PH|Jur|SIG|Eco)_[0-9]{2,3}$", re.IGNORECASE)
FAMILY_PREFIX = {
    "*": None,
    "reco": "reco_",
    "ph": "ph_",
    "juridico": "jur_",
    "sig": "sig_",
    "economico": "eco_",
}


@dataclass(frozen=True)
class PackageRuleScope:
    """Rules declared applicable by the coordinator/DBA for one package."""

    profile_id: str
    rule_ids: tuple[str, ...]
    source_path: Path
    sha256: str
    reason: str = ""
    ignored_other_editions: tuple[str, ...] = ()


def scope_candidates(gpkg_path: str | Path) -> tuple[Path, ...]:
    source = Path(gpkg_path).expanduser().resolve()
    return (
        source.with_name(source.stem + ".mapingtool-scope.json"),
        source.with_name(DEFAULT_SCOPE_NAME),
    )


def _canonical_rule_lookup(rule_ids: Iterable[str]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for value in rule_ids:
        rule_id = str(value).strip()
        folded = rule_id.casefold()
        if not rule_id or folded in lookup:
            raise ValueError("El catalogo de la edicion contiene IDs vacios o ambiguos.")
        lookup[folded] = rule_id
    return lookup


def load_package_rule_scope(
    gpkg_path: str | Path,
    available_rule_ids: Iterable[str],
    edition_family: str = "*",
) -> PackageRuleScope | None:
    """Load an adjacent scope without ever modifying the delivered package.

    A scope uses explicit rule IDs.  The total edition rejects every unknown ID.
    A family edition ignores valid IDs belonging to other families, but still
    rejects typos that claim to belong to its own family.
    """

    candidate = next((path for path in scope_candidates(gpkg_path) if path.is_file()), None)
    if candidate is None:
        return None
    raw = candidate.read_bytes()
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("El alcance MapingTool no es JSON UTF-8 valido.") from exc
    if not isinstance(payload, dict):
        raise ValueError("El alcance MapingTool debe ser un objeto JSON.")
    allowed_keys = {"schema_version", "profile_id", "rule_ids", "reason"}
    extra = sorted(set(payload) - allowed_keys)
    if extra:
        raise ValueError(
            "El alcance MapingTool contiene claves no soportadas: {0}.".format(
                ", ".join(extra)
            )
        )
    if payload.get("schema_version") != SCOPE_SCHEMA_VERSION:
        raise ValueError(
            "Version de alcance no soportada; se esperaba schema_version={0}.".format(
                SCOPE_SCHEMA_VERSION
            )
        )
    profile_id = str(payload.get("profile_id") or "").strip()
    if not profile_id or len(profile_id) > 100:
        raise ValueError("El alcance requiere profile_id de 1 a 100 caracteres.")
    declared = payload.get("rule_ids")
    if not isinstance(declared, list) or not declared:
        raise ValueError("El alcance requiere rule_ids como lista explicita no vacia.")
    if any(not isinstance(value, str) or not value.strip() for value in declared):
        raise ValueError("Todos los rule_ids del alcance deben ser textos no vacios.")
    folded_declared = [value.strip().casefold() for value in declared]
    if len(folded_declared) != len(set(folded_declared)):
        raise ValueError("El alcance repite rule_ids.")

    available = _canonical_rule_lookup(available_rule_ids)
    family = str(edition_family or "*").casefold()
    own_prefix = FAMILY_PREFIX.get(family)
    selected = []
    ignored = []
    unknown = []
    for original in (value.strip() for value in declared):
        canonical = available.get(original.casefold())
        if canonical:
            selected.append(canonical)
            continue
        if not RULE_ID_PATTERN.fullmatch(original):
            unknown.append(original)
            continue
        if family != "*" and own_prefix and not original.casefold().startswith(own_prefix):
            ignored.append(original)
            continue
        unknown.append(original)
    if unknown:
        raise ValueError(
            "El alcance declara reglas desconocidas para esta edicion: {0}.".format(
                ", ".join(sorted(unknown, key=str.casefold))
            )
        )
    if not selected:
        raise ValueError("El alcance no contiene reglas para esta edicion.")
    return PackageRuleScope(
        profile_id=profile_id,
        rule_ids=tuple(selected),
        source_path=candidate,
        sha256=hashlib.sha256(raw).hexdigest().upper(),
        reason=str(payload.get("reason") or "").strip(),
        ignored_other_editions=tuple(ignored),
    )
