"""Sibling-temporary output helpers for atomic local file replacement."""

from __future__ import annotations

import os
from pathlib import Path
import tempfile
import threading
import time


_PENDING_LOCK = threading.RLock()
_PENDING_REMOVALS: set[str] = set()


def remove_with_retry(
    path: str | Path,
    *,
    attempts: int = 6,
    delay_seconds: float = 0.05,
) -> bool:
    """Remove one exact file, retrying transient Windows sharing violations."""

    target = Path(path)
    for attempt in range(max(int(attempts), 1)):
        try:
            target.unlink()
            with _PENDING_LOCK:
                _PENDING_REMOVALS.discard(str(target.resolve()))
            return True
        except FileNotFoundError:
            with _PENDING_LOCK:
                _PENDING_REMOVALS.discard(str(target.resolve()))
            return True
        except PermissionError:
            if attempt + 1 >= attempts:
                with _PENDING_LOCK:
                    _PENDING_REMOVALS.add(str(target.resolve()))
                raise
            time.sleep(max(float(delay_seconds), 0.0))
    return False


def pending_removals() -> tuple[str, ...]:
    with _PENDING_LOCK:
        return tuple(sorted(_PENDING_REMOVALS))


def retry_pending_removals() -> dict[str, str]:
    failures = {}
    for value in pending_removals():
        try:
            remove_with_retry(value)
        except PermissionError as exc:
            failures[value] = str(exc)
    return failures


class AtomicOutput:
    """Write beside a destination and replace it only after explicit commit."""

    def __init__(self, destination: str | Path):
        self.destination = Path(destination).resolve()
        self.destination.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary = tempfile.mkstemp(
            prefix=".{0}.partial-".format(self.destination.name),
            suffix=self.destination.suffix,
            dir=str(self.destination.parent),
        )
        os.close(descriptor)
        self.temporary = Path(temporary)
        self.committed = False

    def commit(self, *, require_nonempty: bool = True) -> None:
        if not self.temporary.is_file():
            raise FileNotFoundError(self.temporary)
        if require_nonempty and self.temporary.stat().st_size <= 0:
            raise RuntimeError("La salida temporal esta vacia; no se reemplaza el destino.")
        os.replace(str(self.temporary), str(self.destination))
        self.committed = True

    def abort(self) -> None:
        if not self.committed:
            remove_with_retry(self.temporary)

    def __enter__(self) -> "AtomicOutput":
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        if not self.committed:
            self.abort()
