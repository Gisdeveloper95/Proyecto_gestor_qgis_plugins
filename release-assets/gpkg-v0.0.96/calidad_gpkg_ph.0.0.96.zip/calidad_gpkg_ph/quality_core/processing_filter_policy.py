"""Rule-aware operational filters shared by the portable GPKG plugins.

The quality SQL determines findings.  This module applies the operational
scope supplied by the owner: general predicates plus one profile per rule.
Profiles are explicit and versioned so a condition intended for PH or
informality can never be applied silently to every catalog family.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from copy import deepcopy
import re
from typing import Any


PROFILE_NPH = "nph"
PROFILE_CONDOMINIO = "condominio"
PROFILE_PH = "ph"
PROFILE_PH_MATRIZ = "ph_matriz"
PROFILE_INFORMALIDAD = "informalidad"
PROFILE_AUTO = "auto"

PROFILE_LABELS = {
    PROFILE_AUTO: "Automático por regla",
    PROFILE_NPH: "NPH / predio formal",
    PROFILE_CONDOMINIO: "Condominio",
    PROFILE_PH: "Propiedad horizontal",
    PROFILE_PH_MATRIZ: "PH — predio matriz",
    PROFILE_INFORMALIDAD: "Informalidad",
}

# The source provided by the owner identifies these exceptions explicitly.
# All other rules inherit the family profile below.  Keeping the mapping here,
# instead of scattered through the UI/worker, makes it reviewable and testable.
_CONDOMINIO_RULES = frozenset(("Reco_03", "Reco_04", "Reco_30", "Jur_16"))
_INFORMALIDAD_RULES = frozenset(
    (
        "Reco_58",
        "Reco_59",
        "Reco_64",
        "Jur_13",
        "Jur_27",
        "Jur_29",
        "Jur_31",
        "Jur_33",
        "Jur_47",
    )
)
_PH_MATRIX_RULES = frozenset(
    tuple("PH_{0:02d}".format(index) for index in range(1, 10))
    + ("SIG_14",)
)

_DEFAULT_PROFILE_BY_FAMILY = {
    "economico": PROFILE_NPH,
    "juridico": PROFILE_NPH,
    "ph": PROFILE_PH,
    "reco": PROFILE_NPH,
    "sig": PROFILE_NPH,
}

DEFAULT_PROCESSING_FILTER_POLICY = {
    "schema_version": 2,
    "scope_profile": PROFILE_AUTO,
    "general": {
        "exclude_cancelled": True,
        "require_assignment_state": True,
        "assignment_states": ["2"],
    },
    "profiles": {
        PROFILE_NPH: {
            "filter_conditions": True,
            "excluded_conditions": ["2", "5", "8", "9"],
            "exclude_informal_visit": True,
        },
        PROFILE_CONDOMINIO: {
            "filter_conditions": True,
            "allowed_conditions": ["8"],
        },
        PROFILE_PH: {
            "filter_conditions": True,
            "allowed_conditions": ["8", "9"],
            "enforce_matrix_identity": True,
        },
        PROFILE_INFORMALIDAD: {
            "filter_conditions": True,
            "allowed_conditions": ["2", "5"],
            "allow_zero_when_informal_visit": True,
        },
    },
}

DISABLED_PROCESSING_FILTER_POLICY = {
    "schema_version": 2,
    "scope_profile": PROFILE_AUTO,
    "general": {
        "exclude_cancelled": False,
        "require_assignment_state": False,
        "assignment_states": ["2"],
    },
    "profiles": {
        PROFILE_NPH: {
            "filter_conditions": False,
            "excluded_conditions": ["2", "5", "8", "9"],
            "exclude_informal_visit": False,
        },
        PROFILE_CONDOMINIO: {
            "filter_conditions": False,
            "allowed_conditions": ["8"],
        },
        PROFILE_PH: {
            "filter_conditions": False,
            "allowed_conditions": ["8", "9"],
            "enforce_matrix_identity": False,
        },
        PROFILE_INFORMALIDAD: {
            "filter_conditions": False,
            "allowed_conditions": ["2", "5"],
            "allow_zero_when_informal_visit": False,
        },
    },
}

PROCESSING_FILTER_FIELDS = (
    "pk_id",
    "juridico_predio_cancelado",
    "reconocimiento_estado_asignacion",
    "condicion",
    "informal_predio_para_visita",
    "torre_piso",
    "unidad_predial",
)


def _coerce_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    normalized = str(value).strip().casefold()
    if normalized in {"1", "true", "yes", "si", "sí", "on"}:
        return True
    if normalized in {"0", "false", "no", "off", ""}:
        return False
    return default


def normalize_condition(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"\.0$", "", str(value).strip())


def normalize_condition_values(
    values: Any,
    default: Iterable[str],
) -> list[str]:
    """Normalize a user-entered list of single cadastral condition digits."""

    if values is None:
        source = list(default)
    elif isinstance(values, str):
        source = [
            token
            for token in re.split(r"[\s,;|]+", values.strip())
            if token
        ]
    elif isinstance(values, Iterable):
        source = list(values)
    else:
        raise ValueError("La lista de condiciones no tiene un formato válido.")
    normalized = []
    for value in source:
        token = normalize_condition(value)
        if not re.fullmatch(r"[0-9]", token):
            raise ValueError(
                "La condición {0!r} no es un dígito entre 0 y 9.".format(
                    value
                )
            )
        if token not in normalized:
            normalized.append(token)
    return sorted(normalized)


def normalize_processing_filter_policy(
    policy: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    source = policy if isinstance(policy, Mapping) else {}
    defaults = DEFAULT_PROCESSING_FILTER_POLICY
    requested_scope = str(
        source.get("scope_profile") or PROFILE_AUTO
    ).strip().casefold()
    valid_scopes = {
        PROFILE_AUTO,
        PROFILE_NPH,
        PROFILE_CONDOMINIO,
        PROFILE_PH,
        PROFILE_PH_MATRIZ,
        PROFILE_INFORMALIDAD,
    }
    source_general = (
        source.get("general")
        if isinstance(source.get("general"), Mapping)
        else {}
    )
    normalized = {
        "schema_version": 2,
        "scope_profile": (
            requested_scope
            if requested_scope in valid_scopes
            else PROFILE_AUTO
        ),
        "general": {
            "exclude_cancelled": _coerce_bool(
                source_general.get("exclude_cancelled"),
                defaults["general"]["exclude_cancelled"],
            ),
            "require_assignment_state": _coerce_bool(
                source_general.get("require_assignment_state"),
                defaults["general"]["require_assignment_state"],
            ),
            "assignment_states": normalize_condition_values(
                source_general.get("assignment_states"),
                defaults["general"]["assignment_states"],
            ),
        },
        "profiles": {},
    }
    source_profiles = (
        source.get("profiles")
        if isinstance(source.get("profiles"), Mapping)
        else {}
    )
    for profile_id, profile_defaults in defaults["profiles"].items():
        profile_source = (
            source_profiles.get(profile_id)
            if isinstance(source_profiles.get(profile_id), Mapping)
            else {}
        )
        profile = {}
        for key, default in profile_defaults.items():
            if key in {"excluded_conditions", "allowed_conditions"}:
                profile[key] = normalize_condition_values(
                    profile_source.get(key),
                    default,
                )
            else:
                profile[key] = _coerce_bool(
                    profile_source.get(key),
                    bool(default),
                )
        normalized["profiles"][profile_id] = profile
    return normalized


def rule_filter_profile(rule_id: str, family: str) -> str:
    if rule_id in _PH_MATRIX_RULES:
        return PROFILE_PH_MATRIZ
    if rule_id in _CONDOMINIO_RULES:
        return PROFILE_CONDOMINIO
    if rule_id in _INFORMALIDAD_RULES:
        return PROFILE_INFORMALIDAD
    return _DEFAULT_PROFILE_BY_FAMILY.get(
        str(family).strip().casefold(),
        PROFILE_NPH,
    )


def effective_rule_filter_profile(
    rule_id: str,
    family: str,
    policy: Mapping[str, Any] | None = None,
) -> str:
    """Resolve the profile used by a rule for this concrete execution."""

    normalized = normalize_processing_filter_policy(policy)
    scope_profile = normalized["scope_profile"]
    if scope_profile != PROFILE_AUTO:
        return str(scope_profile)
    return rule_filter_profile(rule_id, family)


def profiles_for_rules(
    rules: Iterable[Any],
    policy: Mapping[str, Any] | None = None,
) -> tuple[str, ...]:
    found = {
        effective_rule_filter_profile(
            str(rule.id),
            str(rule.family),
            policy,
        )
        for rule in rules
    }
    order = (
        PROFILE_NPH,
        PROFILE_CONDOMINIO,
        PROFILE_PH,
        PROFILE_PH_MATRIZ,
        PROFILE_INFORMALIDAD,
    )
    return tuple(profile for profile in order if profile in found)


def profile_policy(
    policy: Mapping[str, Any] | None,
    profile_id: str,
) -> dict[str, Any]:
    normalized = normalize_processing_filter_policy(policy)
    base_profile = (
        PROFILE_PH if profile_id == PROFILE_PH_MATRIZ else profile_id
    )
    return deepcopy(normalized["profiles"][base_profile])


def processing_profile_active(
    policy: Mapping[str, Any] | None,
    profile_id: str,
) -> bool:
    normalized = normalize_processing_filter_policy(policy)
    general = normalized["general"]
    if (
        general["exclude_cancelled"]
        or general["require_assignment_state"]
    ):
        return True
    profile = profile_policy(normalized, profile_id)
    if profile.get("filter_conditions"):
        return True
    if profile_id == PROFILE_NPH and profile.get(
        "exclude_informal_visit"
    ):
        return True
    if (
        profile_id == PROFILE_PH_MATRIZ
        and profile.get("enforce_matrix_identity")
    ):
        return True
    return False


def processing_required_fields(
    policy: Mapping[str, Any] | None,
    profile_ids: Iterable[str],
) -> tuple[str, ...]:
    normalized = normalize_processing_filter_policy(policy)
    profiles = tuple(dict.fromkeys(str(value) for value in profile_ids))
    fields = {"pk_id"}
    general = normalized["general"]
    if general["exclude_cancelled"]:
        fields.add("juridico_predio_cancelado")
    if general["require_assignment_state"]:
        fields.add("reconocimiento_estado_asignacion")
    for profile_id in profiles:
        profile = profile_policy(normalized, profile_id)
        if profile.get("filter_conditions"):
            fields.add("condicion")
        if profile_id == PROFILE_NPH and profile.get(
            "exclude_informal_visit"
        ):
            fields.add("informal_predio_para_visita")
        if (
            profile_id == PROFILE_INFORMALIDAD
            and profile.get("allow_zero_when_informal_visit")
        ):
            fields.add("informal_predio_para_visita")
        if (
            profile_id == PROFILE_PH_MATRIZ
            and profile.get("enforce_matrix_identity")
        ):
            fields.update(("torre_piso", "unidad_predial"))
    order = PROCESSING_FILTER_FIELDS
    return tuple(field for field in order if field in fields)


def predio_allowed(
    row: Mapping[str, Any],
    profile_id: str,
    policy: Mapping[str, Any] | None = None,
) -> bool:
    normalized = normalize_processing_filter_policy(policy)
    general = normalized["general"]
    if general["exclude_cancelled"] and _coerce_bool(
        row.get("juridico_predio_cancelado"),
        False,
    ):
        return False
    if general["require_assignment_state"]:
        assignment = normalize_condition(
            row.get("reconocimiento_estado_asignacion")
        )
        if assignment not in general["assignment_states"]:
            return False

    profile = profile_policy(normalized, profile_id)
    condition = normalize_condition(row.get("condicion"))
    informal_visit = _coerce_bool(
        row.get("informal_predio_para_visita"),
        False,
    )
    if profile_id == PROFILE_NPH:
        if (
            profile["filter_conditions"]
            and condition in profile["excluded_conditions"]
        ):
            return False
        if profile["exclude_informal_visit"] and informal_visit:
            return False
    elif profile_id == PROFILE_CONDOMINIO:
        if (
            profile["filter_conditions"]
            and condition not in profile["allowed_conditions"]
        ):
            return False
    elif profile_id in {PROFILE_PH, PROFILE_PH_MATRIZ}:
        if (
            profile["filter_conditions"]
            and condition not in profile["allowed_conditions"]
        ):
            return False
        if (
            profile_id == PROFILE_PH_MATRIZ
            and profile["enforce_matrix_identity"]
            and (
                normalize_condition(row.get("torre_piso")) != "0000"
                or normalize_condition(row.get("unidad_predial")) != "0000"
            )
        ):
            return False
    elif profile_id == PROFILE_INFORMALIDAD:
        if profile["filter_conditions"]:
            if condition in profile["allowed_conditions"]:
                pass
            elif (
                condition == "0"
                and profile["allow_zero_when_informal_visit"]
                and informal_visit
            ):
                pass
            else:
                return False
    return True


def processing_filter_summary(
    policy: Mapping[str, Any] | None,
    profile_ids: Iterable[str],
) -> str:
    normalized = normalize_processing_filter_policy(policy)
    labels = [
        PROFILE_LABELS.get(profile, profile)
        for profile in profile_ids
        if processing_profile_active(normalized, profile)
    ]
    general = normalized["general"]
    selected_scope = normalized["scope_profile"]
    scope_label = (
        "automático por regla"
        if selected_scope == PROFILE_AUTO
        else "manual: {0}".format(
            PROFILE_LABELS.get(selected_scope, selected_scope)
        )
    )
    return (
        "Filtros operativos: alcance {0}; generales [{1}]; perfiles [{2}].".format(
            scope_label,
            ", ".join(
                item
                for item, active in (
                    ("cancelados", general["exclude_cancelled"]),
                    (
                        "asignación "
                        + "/".join(general["assignment_states"]),
                        general["require_assignment_state"],
                    ),
                )
                if active
            )
            or "ninguno",
            ", ".join(labels) or "sin filtros específicos",
        )
    )


def iter_processing_allowed_predio_ids(
    data_source,
    layer_mapping,
    profile_ids: Iterable[str],
    policy: Mapping[str, Any] | None = None,
    cancel_check=None,
):
    """Stream disk-stageable profile membership from ``lc_gen_predio``."""

    profiles = tuple(dict.fromkeys(str(value) for value in profile_ids))
    physical_name = layer_mapping.resolve("lc_gen_predio")
    for row in data_source.iter_rows(
        physical_name,
        processing_required_fields(policy, profiles),
    ):
        if cancel_check is not None and cancel_check():
            raise InterruptedError("Carga de filtros operativos cancelada.")
        value = row.get("pk_id")
        predio_id = str(value).strip() if value not in (None, "") else ""
        if not predio_id:
            continue
        for profile_id in profiles:
            if not processing_profile_active(policy, profile_id):
                continue
            if predio_allowed(row, profile_id, policy):
                yield {
                    "profile_id": profile_id,
                    "pk_id_predio": predio_id,
                }
