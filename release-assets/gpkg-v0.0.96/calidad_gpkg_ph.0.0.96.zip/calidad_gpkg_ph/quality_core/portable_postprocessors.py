"""Registry for generic operational stages applied after rule SQL."""

POSTPROCESSORS = {
    "reco_post_filter": (
        "quality_core.portable_reco_post_filter.iter_reco_allowed_predio_ids"
    ),
}
