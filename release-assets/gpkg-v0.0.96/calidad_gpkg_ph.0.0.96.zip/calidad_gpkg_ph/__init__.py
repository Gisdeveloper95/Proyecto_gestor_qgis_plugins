def classFactory(iface):
    from .plugin import CalidadGpkgPlugin
    return CalidadGpkgPlugin(iface)
