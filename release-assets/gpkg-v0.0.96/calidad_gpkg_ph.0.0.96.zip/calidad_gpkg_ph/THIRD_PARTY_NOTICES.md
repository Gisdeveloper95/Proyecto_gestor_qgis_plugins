# Third-party notices - Calidad GPKG

Este inventario corresponde exclusivamente a los seis paquetes Calidad GPKG.
El código first-party se distribuye bajo `GPL-2.0-or-later`, según el archivo
`LICENSE` incluido en cada paquete.

## Dependencias no incluidas en los ZIP

- QGIS 3.36 o posterior, Qt/PyQt y GDAL/OGR son suministrados por la instalacion QGIS
  del usuario y no se redistribuyen dentro de estos paquetes.
- `sqlite3` forma parte del runtime Python suministrado por QGIS. Se usa para
  snapshots consistentes, lectura de atributos y resultados locales.

La edicion `0.0.67` no empaqueta DuckDB, Shapely, pyogrio, PostgreSQL, un driver
QPSQL ni extensiones descargadas en tiempo de ejecucion.

## Codigo portable del proyecto

Los ZIP contienen código Python, el manifiesto portable familiar y activos de
interfaz. No contienen el catálogo de 253 SQL de la edición DBA/PostGIS.
