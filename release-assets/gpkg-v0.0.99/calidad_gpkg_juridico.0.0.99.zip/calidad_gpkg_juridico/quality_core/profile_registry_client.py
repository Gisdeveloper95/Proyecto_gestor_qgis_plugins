"""Bounded HTTPS client for centrally managed simplified QGIS profiles."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import json
import re
import secrets
from urllib import error, parse, request
from uuid import UUID


PORTAL_ORIGIN = "https://mapingtool-catastral.vercel.app"
CLIENT_ID = "mapingtool-catastral-desktop"
DEVICE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"
MAX_RESPONSE = 1_000_000
UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
    re.I,
)


class ProfileRegistryError(RuntimeError):
    pass


class ProfileRegistryHttpError(ProfileRegistryError):
    def __init__(self, status: int, code: str):
        messages = {
            "service_unavailable": (
                "El Centro de Perfiles no está disponible temporalmente. "
                "La exportación local no se perdió; inténtelo nuevamente."
            ),
            "rate_limited": (
                "El Centro de Perfiles recibió demasiados intentos. "
                "Espere un minuto y vuelva a intentarlo."
            ),
        }
        super().__init__(messages.get(code, code))
        self.status = status
        self.code = code


class _RejectRedirects(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        del req, fp, code, msg, headers, newurl
        return None


@dataclass(frozen=True)
class DeviceChallenge:
    device_id: str
    device_code: str
    user_code: str
    verification_uri_complete: str
    code_verifier: str
    interval: int
    expires_at: datetime


class ProfileRegistryClient:
    def __init__(self, origin: str = PORTAL_ORIGIN, timeout: int = 30):
        parsed = parse.urlsplit(origin)
        if (
            parsed.scheme != "https"
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.query
            or parsed.fragment
        ):
            raise ValueError("El portal de perfiles requiere un origen HTTPS válido.")
        self.origin = origin.rstrip("/")
        self.timeout = max(2, min(int(timeout), 60))
        self.opener = request.build_opener(_RejectRedirects())

    def _json(self, method, path, payload=None, headers=None):
        body = None
        call_headers = {
            "Accept": "application/json",
            "User-Agent": "Mapper-GIS-QGIS-Profile-Registry/0.0.99",
        }
        if payload is not None:
            body = json.dumps(
                payload,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            ).encode("utf-8")
            if len(body) > 64 * 1024:
                raise ProfileRegistryError("La configuración supera el tamaño permitido.")
            call_headers["Content-Type"] = "application/json"
        call_headers.update(headers or {})
        call = request.Request(
            self.origin + path,
            data=body,
            method=method,
            headers=call_headers,
        )
        try:
            response = self.opener.open(call, timeout=self.timeout)
        except error.HTTPError as exc:
            response = exc
        except (error.URLError, TimeoutError, OSError) as exc:
            raise ProfileRegistryError(
                "No fue posible conectar con el Centro de Perfiles."
            ) from exc
        try:
            raw = response.read(MAX_RESPONSE + 1)
            if len(raw) > MAX_RESPONSE:
                raise ProfileRegistryError("La respuesta del portal es demasiado grande.")
            try:
                value = json.loads(raw.decode("utf-8")) if raw else {}
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise ProfileRegistryError("El portal devolvió una respuesta inválida.") from exc
            if not isinstance(value, dict):
                raise ProfileRegistryError("El portal devolvió un contrato inválido.")
            if not 200 <= int(response.status) < 300:
                code = str(value.get("error") or "profile_registry_error")[:120]
                raise ProfileRegistryHttpError(int(response.status), code)
            return value
        finally:
            response.close()

    def start_authorization(self, device_id: str) -> DeviceChallenge:
        UUID(device_id)
        alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"
        verifier = "".join(secrets.choice(alphabet) for _ in range(64))
        challenge = base64.urlsafe_b64encode(
            hashlib.sha256(verifier.encode("ascii")).digest()
        ).rstrip(b"=").decode("ascii")
        value = self._json(
            "POST",
            "/api/device/authorization",
            {
                "client_id": CLIENT_ID,
                "code_challenge": challenge,
                "device_id": device_id,
            },
        )
        try:
            return DeviceChallenge(
                device_id=device_id,
                device_code=str(value["device_code"]),
                user_code=str(value["user_code"]),
                verification_uri_complete=str(value["verification_uri_complete"]),
                code_verifier=verifier,
                interval=max(1, min(int(value["interval"]), 30)),
                expires_at=datetime.now(timezone.utc)
                + timedelta(seconds=int(value["expires_in"])),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ProfileRegistryError("El portal devolvió un reto de acceso inválido.") from exc

    def poll_authorization(self, challenge: DeviceChallenge):
        if datetime.now(timezone.utc) >= challenge.expires_at:
            return {"status": "expired"}
        try:
            value = self._json(
                "POST",
                "/api/device/token",
                {
                    "client_id": CLIENT_ID,
                    "grant_type": DEVICE_GRANT_TYPE,
                    "device_code": challenge.device_code,
                    "code_verifier": challenge.code_verifier,
                    "device_id": challenge.device_id,
                },
            )
        except ProfileRegistryHttpError as exc:
            return {
                "status": {
                    "authorization_pending": "pending",
                    "slow_down": "slow_down",
                    "expired_token": "expired",
                    "access_denied": "denied",
                    "invalid_grant": "denied",
                }.get(exc.code, "unavailable")
            }
        grant = str(value.get("grant_token") or "")
        refresh = str(value.get("refresh_token") or "")
        if not grant or not refresh or len(grant) > 2048 or len(refresh) > 384:
            raise ProfileRegistryError("El portal devolvió una autorización inválida.")
        return {"status": "authorized", "grant_token": grant, "refresh_token": refresh}

    @staticmethod
    def auth_headers(device_id: str, grant_token: str) -> dict:
        if not UUID_RE.fullmatch(device_id) or not grant_token or len(grant_token) > 2048:
            raise ProfileRegistryError("La autorización local no es válida.")
        return {
            "Authorization": "Bearer " + grant_token,
            "X-Mapper-Device-Id": device_id,
        }

    def list_profiles(self, device_id: str, grant_token: str):
        value = self._json(
            "GET",
            "/api/profile-registry/profiles",
            headers=self.auth_headers(device_id, grant_token),
        )
        profiles = value.get("profiles")
        if not isinstance(profiles, list):
            raise ProfileRegistryError("El catálogo de perfiles no es válido.")
        return profiles

    def save_profile(
        self,
        device_id: str,
        grant_token: str,
        spec: dict,
        *,
        package_id: str | None = None,
        profile_id: str | None = None,
        expected_revision: int | None = None,
        idempotency_key: str,
    ):
        payload = {"spec": spec}
        if package_id:
            if not re.fullmatch(r"[a-z][a-z0-9_]{2,63}", package_id):
                raise ProfileRegistryError("El identificador local del perfil no es válido.")
            payload["package_id"] = package_id
        if profile_id:
            payload["profile_id"] = profile_id
            payload["expected_revision"] = expected_revision
        headers = self.auth_headers(device_id, grant_token)
        headers["Idempotency-Key"] = idempotency_key
        return self._json(
            "POST",
            "/api/profile-registry/profiles",
            payload,
            headers,
        )

    def get_profile(self, device_id: str, grant_token: str, profile_id: str):
        if not UUID_RE.fullmatch(profile_id):
            raise ProfileRegistryError("El identificador del perfil no es válido.")
        return self._json(
            "GET",
            "/api/profile-registry/profiles/" + profile_id,
            headers=self.auth_headers(device_id, grant_token),
        )["profile"]

    def check_update(
        self,
        package_id: str,
        current_version: str,
        profile_fingerprint: str | None = None,
    ) -> dict:
        if not re.fullmatch(r"[a-z][a-z0-9_]{2,63}", package_id):
            raise ProfileRegistryError("El identificador del perfil no es válido.")
        if not re.fullmatch(r"0\.0\.(?:0|[1-9][0-9]{0,5})", current_version):
            raise ProfileRegistryError("La versión instalada no es válida.")
        parameters = {"package_id": package_id, "current_version": current_version}
        if profile_fingerprint:
            if not re.fullmatch(r"[A-F0-9]{64}", profile_fingerprint.upper()):
                raise ProfileRegistryError("La huella del perfil no es válida.")
            parameters["profile_fingerprint"] = profile_fingerprint.upper()
        query = parse.urlencode(parameters)
        value = self._json("GET", "/api/profile-registry/updates?" + query)
        status = str(value.get("status") or "")
        if status not in {
            "current",
            "update_available",
            "installed_release_revoked",
            "recovery_pending",
            "unknown_profile",
        }:
            raise ProfileRegistryError("El portal devolvió un estado de actualización inválido.")
        recommended = value.get("recommendedVersion")
        if recommended is not None and not re.fullmatch(
            r"0\.0\.(?:0|[1-9][0-9]{0,5})", str(recommended)
        ):
            raise ProfileRegistryError("El portal devolvió una versión inválida.")
        for key in ("releaseUrl", "repositoryXml"):
            url = value.get(key)
            if url is not None and not str(url).startswith("https://github.com/"):
                raise ProfileRegistryError("El portal devolvió un enlace no autorizado.")
        return value
